import Foundation
import Combine

@MainActor
final class NovelStore: ObservableObject {
    @Published private(set) var projects: [NovelProject] = []
    @Published private(set) var running: NovelRun?
    @Published var errorMessage: String?
    @Published private(set) var saveRecoveryAvailable = false
    private var task: Task<Void, Never>?
    private var root: URL?
    private let encoder: JSONEncoder = {
        let value = JSONEncoder(); value.dateEncodingStrategy = .iso8601
        value.outputFormatting = [.prettyPrinted, .sortedKeys]; return value
    }()
    private let decoder: JSONDecoder = {
        let value = JSONDecoder(); value.dateDecodingStrategy = .iso8601; return value
    }()
    private var partial: (projectID: UUID, candidateID: UUID, runID: UUID, text: String)?
    private var lastPartialSave = Date.distantPast
    private var streamSaveError: String?

    var isGenerating: Bool { running != nil }

    init() {
        do {
            let folder = try FileManager.default.url(for: .applicationSupportDirectory, in: .userDomainMask,
                                                     appropriateFor: nil, create: true)
                .appendingPathComponent("QingJian", isDirectory: true).appendingPathComponent("novels", isDirectory: true)
            try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
            root = folder
            let files = try FileManager.default.contentsOfDirectory(at: folder, includingPropertiesForKeys: nil)
            var issues: [String] = []
            for file in files where file.pathExtension == "json" {
                do {
                    let data = try Data(contentsOf: file)
                    guard data.count <= 100 * 1024 * 1024 else { throw NovelError.message("文件过大") }
                    var value = try decoder.decode(NovelProject.self, from: data)
                    try value.validate()
                    guard file.deletingPathExtension().lastPathComponent == value.id.uuidString,
                          !projects.contains(where: { $0.id == value.id }) else { throw NovelError.message("项目编号不匹配") }
                    if value.lastRun?.status == .running {
                        value.lastRun?.status = .paused
                        value.lastRun?.issue = "上次任务中断；已保存候选保留，点继续重新完成当前步骤。"
                        try persist(value)
                    }
                    projects.append(value)
                } catch { issues.append(file.lastPathComponent + "：" + error.localizedDescription) }
            }
            projects.sort { $0.updatedAt > $1.updatedAt }
            if !issues.isEmpty { errorMessage = "部分小说未能读取，原文件已保留：\n" + issues.joined(separator: "\n") }
        } catch { errorMessage = "小说库未能打开：" + error.localizedDescription }
    }

    func project(_ id: UUID) -> NovelProject? { projects.first { $0.id == id } }

    private func persist(_ value: NovelProject) throws {
        guard let root else { throw NovelError.message("小说存储不可用，请重新打开应用。") }
        try value.validate()
        let data = try encoder.encode(value)
        guard data.count <= 100 * 1024 * 1024 else { throw NovelError.message("这部作品超过100 MB，请导出并整理历史候选后重试。") }
        try data.write(to: root.appendingPathComponent(value.id.uuidString + ".json"), options: [.atomic, .completeFileProtection])
    }

    private func commit(_ value: NovelProject) throws {
        var next = value; next.updatedAt = Date()
        try persist(next)
        if let index = projects.firstIndex(where: { $0.id == next.id }) { projects[index] = next }
        else { projects.insert(next, at: 0) }
    }

    private func failure(_ error: Error) { errorMessage = error.localizedDescription }

    @discardableResult func create(title: String, brief: String = "") -> UUID? {
        do {
            let clean = title.trimmingCharacters(in: .whitespacesAndNewlines)
            var value = NovelProject(title: clean.isEmpty ? "未命名小说" : clean)
            value.brief = brief
            try commit(value); return value.id
        } catch { failure(error); return nil }
    }

    @discardableResult func update(_ value: NovelProject) -> Bool {
        guard var latest = project(value.id) else { return false }
        guard latest.revision == value.revision else { errorMessage = "资料已有更新，请重新打开后再保存。"; return false }
        if latest.title == value.title && latest.brief == value.brief && latest.world == value.world && latest.characters == value.characters && latest.outline == value.outline { return true }
        if running?.projectID == value.id { stop() }
        guard !saveRecoveryAvailable else { errorMessage = "半稿尚未保存，请先重试保存或导出备份。"; return false }
        guard let saved = project(value.id) else { return false }; latest = saved
        latest.title = value.title.trimmingCharacters(in: .whitespacesAndNewlines)
        latest.brief = value.brief; latest.world = value.world; latest.characters = value.characters; latest.outline = value.outline
        latest.revision += 1
        for index in latest.chapters.indices where latest.chapters[index].status == .confirmed { latest.chapters[index].needsReview = true }
        do { try commit(latest); return true } catch { failure(error); return false }
    }

    @discardableResult func addChapter(projectID: UUID) -> UUID? {
        guard var value = project(projectID) else { return nil }
        guard running?.projectID != projectID else { errorMessage = "请先停止本书的生成任务，再添加章节。"; return nil }
        let chapter = NovelChapter(title: "第\(value.chapters.count + 1)章")
        value.chapters.append(chapter)
        do { try commit(value); return chapter.id } catch { failure(error); return nil }
    }

    private func archiveBody(_ chapter: inout NovelChapter, label: String) {
        guard !chapter.body.isEmpty, chapter.versions.last?.body != chapter.body else { return }
        chapter.versions.append(NovelRevision(body: chapter.body, label: label))
    }

    private func invalidateFollowing(_ value: inout NovelProject, after index: Int) {
        for later in value.chapters.indices where later > index { value.chapters[later].needsReview = true }
    }

    @discardableResult func updateChapter(projectID: UUID, chapter: NovelChapter) -> Bool {
        guard let original = project(projectID), let originalIndex = original.chapters.firstIndex(where: { $0.id == chapter.id }) else { return false }
        guard original.chapters[originalIndex].revision == chapter.revision else { errorMessage = "本章已有新版本，请重新打开再编辑。"; return false }
        if running?.projectID == projectID { stop() }
        guard !saveRecoveryAvailable else { errorMessage = "半稿尚未保存，请先重试保存或导出备份。"; return false }
        guard var value = project(projectID), let index = value.chapters.firstIndex(where: { $0.id == chapter.id }) else { return false }
        var edited = value.chapters[index]
        let bodyChanged = edited.body != chapter.body
        let contentChanged = bodyChanged || edited.title != chapter.title || edited.plan != chapter.plan
        if bodyChanged { archiveBody(&edited, label: "手动修改前") }
        edited.title = chapter.title; edited.plan = chapter.plan; edited.body = chapter.body; edited.review = chapter.review
        // Derived memory is committed only by confirmChapter, never from an editor copy.
        if contentChanged {
            edited.status = .draft; edited.confirmedAt = nil; edited.needsReview = true
            edited.memoryCandidate = nil
            invalidateFollowing(&value, after: index)
        }
        edited.revision += 1; edited.updatedAt = Date(); value.chapters[index] = edited; value.revision += 1
        do { try commit(value); return true } catch { failure(error); return false }
    }

    @discardableResult func acceptCandidate(projectID: UUID, candidateID: UUID) -> Bool {
        guard var value = project(projectID), let position = value.candidates.firstIndex(where: { $0.id == candidateID }) else { return false }
        guard running?.projectID != projectID else { errorMessage = "请等本次任务结束或先停止，再采纳候选。"; return false }
        let candidate = value.candidates[position]
        guard candidate.isComplete else { errorMessage = "这份候选尚未完整返回；可复制半稿，或点继续重新生成。"; return false }
        guard candidate.sourceRevision == value.revision else { errorMessage = "生成后资料或手稿已改变，这份候选已过期。可复制需要的内容手动合入，或重新生成。"; return false }
        if let chapterID = candidate.chapterID,
           value.chapters.first(where: { $0.id == chapterID })?.revision != candidate.chapterRevision {
            errorMessage = "本章在候选生成后已有更新，请核对内容或重新生成。"; return false
        }
        guard NovelWorkflow.dependenciesMatch(candidate, project: value) else {
            errorMessage = "候选参考的前章正文已经改变，请重新生成或手动合入。"; return false
        }
        switch candidate.action {
        case .world: value.world = candidate.text; value.revision += 1
        case .characters: value.characters = candidate.text; value.revision += 1
        case .outline: value.outline = candidate.text; value.revision += 1
        case .plan, .draft, .polish, .review:
            guard let index = value.chapters.firstIndex(where: { $0.id == candidate.chapterID }) else { return false }
            var chapter = value.chapters[index]
            switch candidate.action {
            case .plan: chapter.plan = candidate.text
            case .review: chapter.review = candidate.text
            default: archiveBody(&chapter, label: "采纳新稿前"); chapter.body = candidate.text
            }
            if candidate.action != .review {
                chapter.status = .draft; chapter.confirmedAt = nil; chapter.needsReview = true
                chapter.memoryCandidate = nil
                invalidateFollowing(&value, after: index)
            }
            chapter.revision += 1; chapter.updatedAt = Date(); value.chapters[index] = chapter
            // Batch candidates share their unchanged input settings. Accepting the exact prior
            // candidate keeps later candidates usable; manual edits increment project.revision.
        case .confirm: errorMessage = "请使用章节的定稿按钮重新核对并提交摘要。"; return false
        }
        if !candidate.action.needsChapter {
            for index in value.chapters.indices where value.chapters[index].status == .confirmed { value.chapters[index].needsReview = true }
        }
        value.candidates.remove(at: position)
        if value.lastRun?.candidateID == candidateID { value.lastRun?.candidateID = nil }
        do { try commit(value); return true } catch { failure(error); return false }
    }

    @discardableResult func discardCandidate(projectID: UUID, candidateID: UUID) -> Bool {
        guard var value = project(projectID) else { return false }
        guard running?.candidateID != candidateID else { errorMessage = "请先停止生成，再删除半稿。"; return false }
        value.candidates.removeAll { $0.id == candidateID }
        if value.lastRun?.candidateID == candidateID { value.lastRun?.candidateID = nil }
        do { try commit(value); return true } catch { failure(error); return false }
    }

    @discardableResult func updateChapterMemory(projectID: UUID, chapterID: UUID, summary: String,
        characterState: String, foreshadowing: String, expectedRevision: Int) -> Bool {
        guard var value = project(projectID), let index = value.chapters.firstIndex(where: { $0.id == chapterID }) else { return false }
        guard running?.projectID != projectID else { errorMessage = "请先停止任务，再纠正记忆。"; return false }
        guard value.chapters[index].status == .confirmed, value.chapters[index].revision == expectedRevision else {
            errorMessage = "本章状态已更新，请重新打开记忆再修改。"; return false
        }
        guard !summary.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { errorMessage = "定稿摘要不能为空。"; return false }
        value.chapters[index].summary = summary; value.chapters[index].characterState = characterState
        value.chapters[index].foreshadowing = foreshadowing; value.chapters[index].revision += 1
        value.chapters[index].memoryDelta?.summary = summary
        value.chapters[index].memoryDelta?.characterState = characterState
        value.chapters[index].memoryDelta?.foreshadowing = foreshadowing
        value.chapters[index].updatedAt = Date(); value.revision += 1
        invalidateFollowing(&value, after: index)
        do { try commit(value); return true } catch { failure(error); return false }
    }

    @discardableResult func restoreVersion(projectID: UUID, chapterID: UUID, versionID: UUID) -> Bool {
        guard let value = project(projectID), var chapter = value.chapters.first(where: { $0.id == chapterID }),
              let version = chapter.versions.first(where: { $0.id == versionID }) else { return false }
        chapter.body = version.body
        return updateChapter(projectID: projectID, chapter: chapter)
    }

    func deleteProject(_ id: UUID) {
        if running?.projectID == id { stop() }
        guard !saveRecoveryAvailable else { errorMessage = "半稿尚未保存，请先重试保存或导出备份。"; return }
        do {
            guard let root else { throw NovelError.message("小说存储不可用。") }
            try FileManager.default.removeItem(at: root.appendingPathComponent(id.uuidString + ".json"))
            projects.removeAll { $0.id == id }
        } catch { failure(error) }
    }

    func generate(projectID: UUID, chapterID: UUID? = nil, action: NovelAction, generator: @escaping NovelTextGenerator) {
        if action == .confirm, let chapterID { confirmChapter(projectID: projectID, chapterID: chapterID, generator: generator); return }
        guard running == nil, let value = project(projectID) else { errorMessage = "请先结束当前生成任务。"; return }
        do {
            _ = try NovelWorkflow.request(action, project: value, chapterID: chapterID)
            start(NovelRun(projectID: projectID, chapterID: chapterID, action: action), generator: generator)
        } catch { failure(error) }
    }

    func draftBatch(projectID: UUID, count: Int, generator: @escaping NovelTextGenerator) {
        guard running == nil, var value = project(projectID) else { errorMessage = "请先结束当前生成任务。"; return }
        let count = min(5, max(1, count))
        var ids: [UUID] = []
        for _ in 0..<count {
            let chapter = NovelChapter(title: "第\(value.chapters.count + 1)章")
            value.chapters.append(chapter); ids.append(chapter.id)
        }
        do {
            try commit(value)
            var run = NovelRun(projectID: projectID, chapterID: ids.first, action: .draft)
            run.isBatch = true; run.requestedCount = count; run.chapterIDs = ids
            start(run, generator: generator)
        } catch { failure(error) }
    }

    func confirmChapter(projectID: UUID, chapterID: UUID, generator: @escaping NovelTextGenerator) {
        guard running == nil, let value = project(projectID), let index = value.chapters.firstIndex(where: { $0.id == chapterID }) else { errorMessage = "请先结束当前任务。"; return }
        guard value.chapters[index].status != .confirmed || value.chapters[index].needsReview || value.chapters[index].memoryDelta == nil else {
            errorMessage = "本章已经定稿；需要纠正摘要或人物状态时，请使用编辑记忆。"; return
        }
        guard value.chapters.prefix(index).allSatisfy({ $0.status == .confirmed && !$0.needsReview && $0.memoryDelta != nil }) else {
            errorMessage = "请先定稿或重新核对前面的章节，再确认本章，避免把旧状态带进正式记忆。"; return
        }
        do {
            _ = try NovelWorkflow.request(.confirm, project: value, chapterID: chapterID)
            start(NovelRun(projectID: projectID, chapterID: chapterID, action: .confirm), generator: generator)
        } catch { failure(error) }
    }

    func resume(projectID: UUID, generator: @escaping NovelTextGenerator) {
        guard running == nil, let value = project(projectID), var run = value.lastRun,
              run.status == .paused || run.status == .failed else { return }
        if !run.isBatch {
            generate(projectID: projectID, chapterID: run.chapterID, action: run.action, generator: generator)
            return
        }
        guard run.completedCount < run.chapterIDs.count else { return }
        run.id = UUID(); run.status = .running; run.issue = nil; run.candidateID = nil
        start(run, generator: generator)
    }

    private func start(_ proposed: NovelRun, generator: @escaping NovelTextGenerator) {
        guard var value = project(proposed.projectID), running == nil, !saveRecoveryAvailable else {
            errorMessage = "有尚未保存的半稿，请先重试保存或导出备份。"; return
        }
        var run = proposed; run.status = .running; run.issue = nil; run.updatedAt = Date()
        value.lastRun = run
        do { try commit(value) } catch { failure(error); return }
        errorMessage = nil; streamSaveError = nil; partial = nil; running = run
        task = Task { [weak self] in
            guard let self else { return }
            do {
                if run.isBatch {
                    for index in run.completedCount..<run.chapterIDs.count {
                        try Task.checkCancellation()
                        try await self.perform(runID: run.id, chapterID: run.chapterIDs[index], generator: generator)
                        try self.updateRun(run.id) { $0.completedCount = index + 1 }
                    }
                } else {
                    try await self.perform(runID: run.id, chapterID: run.chapterID, generator: generator)
                    try self.updateRun(run.id) { $0.completedCount = 1 }
                }
                try self.finishRun(run.id, status: .completed, issue: nil)
            } catch {
                guard self.running?.id == run.id else { return }
                let cancelled = Task.isCancelled || error is CancellationError || (error as? URLError)?.code == .cancelled
                let issue = self.streamSaveError ?? (cancelled ? "已停止，已收到的候选保留。" : error.localizedDescription)
                do { try self.flushPartial(); try self.finishRun(run.id, status: cancelled ? .paused : .failed, issue: issue) }
                catch { self.errorMessage = "任务停止，但最后一次保存失败：" + error.localizedDescription; self.saveRecoveryAvailable = true; self.task = nil }
                if !cancelled || self.streamSaveError != nil { self.errorMessage = issue }
            }
        }
    }

    private func updateRun(_ id: UUID, change: (inout NovelRun) -> Void) throws {
        guard var run = running, run.id == id, var value = project(run.projectID) else { throw CancellationError() }
        change(&run); run.updatedAt = Date(); value.lastRun = run
        try commit(value); running = run
    }

    private func perform(runID: UUID, chapterID: UUID?, generator: @escaping NovelTextGenerator) async throws {
        guard let run = running, run.id == runID, var value = project(run.projectID) else { throw CancellationError() }
        let expectedRevision = value.revision
        let expectedChapterRevision = value.chapters.first { $0.id == chapterID }?.revision
        let request = try NovelWorkflow.request(run.action, project: value, chapterID: chapterID, batch: run.isBatch)
        let candidate = NovelCandidate(action: run.action, chapterID: chapterID, sourceRevision: expectedRevision,
                                       chapterRevision: expectedChapterRevision,
                                       dependencies: NovelWorkflow.dependencies(project: value, before: chapterID),
                                       memoryDescription: request.memoryDescription)
        value.candidates.append(candidate)
        var updatedRun = run; updatedRun.chapterID = chapterID; updatedRun.candidateID = candidate.id
        value.lastRun = updatedRun
        try commit(value); running = updatedRun; lastPartialSave = .distantPast
        let text = try await generator(request.system, request.prompt) { [weak self] text in
            guard let self, self.running?.id == runID,
                  self.project(run.projectID)?.revision == expectedRevision else { return }
            self.partial = (run.projectID, candidate.id, runID, text)
            if Date().timeIntervalSince(self.lastPartialSave) >= 1 {
                do { try self.flushPartial(); self.lastPartialSave = Date() }
                catch { self.streamSaveError = "生成内容未能保存：" + error.localizedDescription; self.task?.cancel() }
            }
        }
        try Task.checkCancellation()
        guard running?.id == runID, var latest = project(run.projectID), latest.revision == expectedRevision,
              latest.chapters.first(where: { $0.id == chapterID })?.revision == expectedChapterRevision,
              let ci = latest.candidates.firstIndex(where: { $0.id == candidate.id }) else { throw NovelError.message("生成期间资料已改变，候选已保留，请核对后重试。") }
        guard !text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { throw NovelError.message("模型没有返回正文，请重试。") }
        latest.candidates[ci].text = text; latest.candidates[ci].isComplete = true
        if run.action == .confirm {
            guard let index = latest.chapters.firstIndex(where: { $0.id == chapterID }) else { throw CancellationError() }
            let ledger = try NovelMemory.replay(project: latest, beforeChapterID: chapterID)
            var memory = try NovelWorkflow.memory(text, chapter: latest.chapters[index], chapterIndex: index, ledger: ledger)
            if let previous = latest.chapters[index].memoryDelta,
               previous.sourceBodyFingerprint == memory.sourceBodyFingerprint {
                // A model may omit an unchanged fact during a fresh extraction. Keep the
                // exact source records that the author already corrected on this same body.
                let correctedIDs = Set((latest.memoryCorrections ?? []).filter {
                    $0.sourceChapterID == chapterID && $0.sourceBodyFingerprint == memory.sourceBodyFingerprint
                }.map(\.factID))
                let retainedIDs = Set(memory.updates.map(\.id))
                memory.updates += previous.updates.filter { correctedIDs.contains($0.id) && !retainedIDs.contains($0.id) }
            }
            try NovelMemory.validate(delta: memory, chapter: latest.chapters[index], ledger: ledger)
            latest.chapters[index].memoryCandidate = memory
            latest.candidates.remove(at: ci)
            latest.lastRun?.candidateID = nil
        }
        try commit(latest)
        if run.action == .confirm { running?.candidateID = nil }
        partial = nil
    }

    private func flushPartial() throws {
        guard let partial, running?.id == partial.runID, var value = project(partial.projectID),
              let index = value.candidates.firstIndex(where: { $0.id == partial.candidateID }) else { return }
        value.candidates[index].text = partial.text
        try commit(value)
    }

    private func finishRun(_ id: UUID, status: NovelRunStatus, issue: String?) throws {
        try updateRun(id) { $0.status = status; $0.issue = issue }
        partial = nil; running = nil; task = nil; saveRecoveryAvailable = false
    }

    func stop() {
        guard let run = running else { return }
        task?.cancel()
        do { try flushPartial(); try finishRun(run.id, status: .paused, issue: "已停止；半稿已保留，继续会重新生成当前步骤。") }
        catch { errorMessage = "停止时没能保存最后内容：" + error.localizedDescription; saveRecoveryAvailable = true; task = nil }
    }

    @discardableResult func retrySave() -> Bool {
        guard saveRecoveryAvailable, let run = running else { return true }
        do {
            try flushPartial(); try finishRun(run.id, status: .paused, issue: "半稿已恢复保存，可继续。")
            errorMessage = nil; return true
        } catch { errorMessage = "重试保存失败：" + error.localizedDescription; return false }
    }

    private func exportSnapshot(_ id: UUID) -> NovelProject? {
        guard var value = project(id) else { return nil }
        if let partial, partial.projectID == id,
           let index = value.candidates.firstIndex(where: { $0.id == partial.candidateID }) {
            value.candidates[index].text = partial.text
        }
        if value.lastRun?.status == .running { value.lastRun?.status = .paused; value.lastRun?.issue = "导出时任务未完成；候选半稿已保留。" }
        return value
    }

    func exportText(projectID: UUID, markdown: Bool = true) -> URL? {
        guard let value = exportSnapshot(projectID) else { return nil }
        do {
            let url = FileManager.default.temporaryDirectory.appendingPathComponent(safeName(value.title) + "-" + UUID().uuidString.prefix(6) + (markdown ? ".md" : ".txt"))
            try NovelWorkflow.export(value, markdown: markdown).write(to: url, atomically: true, encoding: .utf8)
            return url
        } catch { failure(error); return nil }
    }

    func exportBackup(projectID: UUID) -> URL? {
        guard let value = exportSnapshot(projectID) else { return nil }
        do {
            try value.validate()
            let url = FileManager.default.temporaryDirectory.appendingPathComponent("Sermo小说备份-" + safeName(value.title) + "-" + UUID().uuidString.prefix(6) + ".json")
            try encoder.encode(NovelArchive(project: value)).write(to: url, options: [.atomic, .completeFileProtection])
            return url
        } catch { failure(error); return nil }
    }

    @discardableResult func importBackup(_ url: URL) -> UUID? {
        let scoped = url.startAccessingSecurityScopedResource()
        defer { if scoped { url.stopAccessingSecurityScopedResource() } }
        do {
            let size = try url.resourceValues(forKeys: [.fileSizeKey]).fileSize ?? 0
            guard size <= 100 * 1024 * 1024 else { throw NovelError.message("请选择100 MB以内的小说备份。") }
            let data = try Data(contentsOf: url)
            guard data.count <= 100 * 1024 * 1024 else { throw NovelError.message("备份文件过大。") }
            let archive = try decoder.decode(NovelArchive.self, from: data)
            guard archive.format == "sermo.novel", archive.version == 1 else { throw NovelError.message("这不是支持的Sermo小说创作备份。") }
            var value = archive.project; try value.validate()
            let originalLedger = try NovelMemory.replay(project: value)
            let validMemoryDeltas = Set(value.chapters.prefix(originalLedger.throughChapter).compactMap { $0.memoryDelta?.id })
            let validMemoryCandidates = try Set(value.chapters.compactMap { chapter -> UUID? in
                guard let candidate = chapter.memoryCandidate,
                      candidate.sourceBodyFingerprint == NovelMemory.bodyFingerprint(chapter.body),
                      candidate.baseLedgerFingerprint == (try NovelMemory.replay(project: value, beforeChapterID: chapter.id)).fingerprint else { return nil }
                return candidate.id
            })
            value.id = UUID(); value.createdAt = Date(); value.updatedAt = Date()
            let ids = Dictionary(uniqueKeysWithValues: value.chapters.map { ($0.id, UUID()) })
            let candidateIDs = Dictionary(uniqueKeysWithValues: value.candidates.map { ($0.id, UUID()) })
            for index in value.chapters.indices {
                guard let newID = ids[value.chapters[index].id] else { throw NovelError.message("章节编号不完整。") }
                value.chapters[index].id = newID
                if var delta = value.chapters[index].memoryDelta {
                    delta.sourceChapterID = newID
                    for fi in delta.updates.indices { delta.updates[fi].sourceChapterID = newID }
                    value.chapters[index].memoryDelta = delta
                }
                if var delta = value.chapters[index].memoryCandidate {
                    delta.sourceChapterID = newID
                    for fi in delta.updates.indices { delta.updates[fi].sourceChapterID = newID }
                    value.chapters[index].memoryCandidate = delta
                }
            }
            if var corrections = value.memoryCorrections {
                for index in corrections.indices {
                    guard let mapped = ids[corrections[index].sourceChapterID] else { throw NovelError.message("记忆纠正来源缺失。") }
                    corrections[index].sourceChapterID = mapped
                }
                value.memoryCorrections = corrections
            }
            // Chapter IDs are intentionally new in an imported copy. Rebind only memories
            // that were valid in the source, so stale candidates never become current.
            for index in value.chapters.indices {
                let chapterID = value.chapters[index].id
                let ledger = try NovelMemory.replay(project: value, beforeChapterID: chapterID)
                if ledger.throughChapter == index, value.chapters[index].status == .confirmed, !value.chapters[index].needsReview,
                   value.chapters[index].memoryDelta.map({ validMemoryDeltas.contains($0.id) }) == true,
                   value.chapters[index].memoryDelta?.sourceBodyFingerprint == NovelMemory.bodyFingerprint(value.chapters[index].body) {
                    value.chapters[index].memoryDelta?.baseLedgerFingerprint = ledger.fingerprint
                }
                if let delta = value.chapters[index].memoryCandidate, validMemoryCandidates.contains(delta.id), ledger.throughChapter == index {
                    value.chapters[index].memoryCandidate?.baseLedgerFingerprint = ledger.fingerprint
                }
            }
            for index in value.candidates.indices {
                guard let newID = candidateIDs[value.candidates[index].id] else { throw NovelError.message("候选编号不完整。") }
                value.candidates[index].id = newID
                if let old = value.candidates[index].chapterID { value.candidates[index].chapterID = ids[old] }
                if let dependencies = value.candidates[index].dependencies {
                    value.candidates[index].dependencies = try dependencies.map { dependency in
                        guard let newID = ids[dependency.chapterID] else { throw NovelError.message("前文依赖编号不完整。") }
                        return NovelDependency(chapterID: newID, fingerprint: dependency.fingerprint)
                    }
                }
            }
            if var run = value.lastRun {
                run.id = UUID(); run.projectID = value.id
                run.chapterID = run.chapterID.flatMap { ids[$0] }
                run.chapterIDs = run.chapterIDs.compactMap { ids[$0] }
                run.candidateID = run.candidateID.flatMap { candidateIDs[$0] }
                if run.status == .running { run.status = .paused; run.issue = "已从备份恢复，请点继续。" }
                value.lastRun = run
            }
            try commit(value); return value.id
        } catch { failure(error); return nil }
    }

    private func safeName(_ title: String) -> String {
        let clean = title.components(separatedBy: CharacterSet(charactersIn: "/\\:*?\"<>|\n\r")).joined()
        return String((clean.isEmpty ? "小说" : clean).prefix(40))
    }

    func canon(projectID: UUID) -> NovelCanonSnapshot? {
        guard let value = project(projectID) else { return nil }
        do { return try NovelMemory.replay(project: value) } catch { failure(error); return nil }
    }

    @discardableResult func acceptMemoryCandidate(projectID: UUID, chapterID: UUID) -> Bool {
        guard running?.projectID != projectID else { errorMessage = "请先等待本次提取完成。"; return false }
        guard var value = project(projectID), let index = value.chapters.firstIndex(where: { $0.id == chapterID }),
              let delta = value.chapters[index].memoryCandidate else { return false }
        do {
            let ledger = try NovelMemory.replay(project: value, beforeChapterID: chapterID)
            guard ledger.throughChapter == index else { throw NovelError.message("前文尚有未确认或失效记忆，请按章节顺序先核对前文。") }
            try NovelMemory.validate(delta: delta, chapter: value.chapters[index], ledger: ledger)
            value.chapters[index].memoryDelta = delta; value.chapters[index].memoryCandidate = nil
            value.chapters[index].summary = delta.summary; value.chapters[index].characterState = delta.characterState
            value.chapters[index].foreshadowing = delta.foreshadowing
            value.chapters[index].status = .confirmed; value.chapters[index].needsReview = false
            value.chapters[index].confirmedAt = Date(); value.chapters[index].updatedAt = Date()
            value.chapters[index].revision += 1
            invalidateFollowing(&value, after: index)
            // Replaying before writing validates deterministic merge and the body-bound source.
            _ = try NovelMemory.replay(project: value, beforeChapterID: value.chapters.dropFirst(index + 1).first?.id)
            try commit(value); return true
        } catch { failure(error); return false }
    }

    @discardableResult func discardMemoryCandidate(projectID: UUID, chapterID: UUID) -> Bool {
        guard var value = project(projectID), let index = value.chapters.firstIndex(where: { $0.id == chapterID }) else { return false }
        value.chapters[index].memoryCandidate = nil
        do { try commit(value); return true } catch { failure(error); return false }
    }

    @discardableResult func correctFact(projectID: UUID, factID: UUID, value newValue: String,
                                       note: String, locked: Bool = false) -> Bool {
        guard running?.projectID != projectID else { errorMessage = "请先停止生成，再纠正正式记忆。"; return false }
        guard var value = project(projectID) else { return false }
        do {
            let ledger = try NovelMemory.replay(project: value)
            guard let fact = ledger.activeFacts.first(where: { $0.id == factID }),
                  let index = value.chapters.firstIndex(where: { $0.id == fact.sourceChapterID }) else {
                throw NovelError.message("这条记忆已失效或不在有效正文中，请先重新核对对应章节。")
            }
            let clean = newValue.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !clean.isEmpty, clean.count <= 2000, note.count <= 2000 else { throw NovelError.message("纠正后的内容不能为空，内容及说明各最多2000字。") }
            let correction = NovelFactCorrection(factID: fact.id, sourceChapterID: fact.sourceChapterID,
                sourceBodyFingerprint: fact.sourceBodyFingerprint, value: clean,
                note: note.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? "作者手动纠正" : note, locked: locked)
            value.memoryCorrections = (value.memoryCorrections ?? []) + [correction]
            value.revision += 1; invalidateFollowing(&value, after: index)
            _ = try NovelMemory.replay(project: value)
            try commit(value); return true
        } catch { failure(error); return false }
    }

    @discardableResult func invalidateFact(projectID: UUID, factID: UUID, note: String) -> Bool {
        guard running?.projectID != projectID else { errorMessage = "请先停止生成，再作废记忆。"; return false }
        guard var value = project(projectID) else { return false }
        do {
            let ledger = try NovelMemory.replay(project: value)
            guard let fact = ledger.activeFacts.first(where: { $0.id == factID }),
                  let index = value.chapters.firstIndex(where: { $0.id == fact.sourceChapterID }) else {
                throw NovelError.message("该事实已经失效，或不在当前有效记忆中。")
            }
            guard note.count <= 2000 else { throw NovelError.message("作废说明最多2000字。") }
            var correction = NovelFactCorrection(factID: fact.id, sourceChapterID: fact.sourceChapterID,
                sourceBodyFingerprint: fact.sourceBodyFingerprint, value: fact.value,
                note: note.isEmpty ? "作者确认：这条记忆不成立" : note)
            correction.invalidated = true
            value.memoryCorrections = (value.memoryCorrections ?? []) + [correction]
            value.revision += 1; invalidateFollowing(&value, after: index)
            _ = try NovelMemory.replay(project: value)
            try commit(value); return true
        } catch { failure(error); return false }
    }
}
