import SwiftUI
import UniformTypeIdentifiers

struct StudyMemoryView: View {
    @EnvironmentObject private var store: AppStore
    let projectID: UUID
    @State private var records: [StudyMemoryRecord] = []
    @State private var events: [StudyMemoryEvent] = []
    @State private var pending: [StudyPendingOperation] = []
    @State private var editing: EditTarget?
    @State private var exportURL: URL?
    @State private var showExport = false
    @State private var loadError: String?
    @State private var importingWords = false
    @State private var importingWordsBusy = false
    @State private var wordCount = 0
    private struct EditTarget: Identifiable { let id = UUID(); let record: StudyMemoryRecord?; let category: String }
    private var subject: StudySubject? { store.project(projectID)?.studySubject }

    var body: some View {
        Form {
            if let subject, !store.isLocked(projectID) {
                if let issue = store.studyIssue {
                    Section { Text(issue).foregroundStyle(.red); Button("重新读取") { reload() } }
                }
                Section {
                    Text("学习记录由这个项目的对话共用。每条记录保留出处与修改历史，切换模型后仍读取这里。")
                        .font(TypeScale.caption).foregroundStyle(Ink.ink3)
                }
                if subject == .english {
                    Section("私人词库") {
                        Text(wordCount == 0 ? "导入一次后，在聊天里说“开始背词”即可。" : "已导入 \(wordCount) 个词，可以在聊天里开始或继续。")
                            .font(TypeScale.caption).foregroundStyle(Ink.ink3)
                        Button(importingWordsBusy ? "正在导入…" : "导入词库 JSON") { importingWords = true }.disabled(importingWordsBusy)
                    }
                }
                ForEach(subject.categories, id: \.self) { category in
                    Section(category) {
                        let matches = records.filter { $0.category == category }
                        if matches.isEmpty { Text(loadError == nil ? "尚无记录" : "暂时无法读取").foregroundStyle(Ink.ink3) }
                        ForEach(matches) { record in
                            VStack(alignment: .leading, spacing: 8) {
                                Text(record.text).textSelection(.enabled)
                                Text("\(sourceName(record.source.kind)) · \(record.updatedAt.formatted(date: .abbreviated, time: .shortened))")
                                    .font(TypeScale.caption).foregroundStyle(Ink.ink3)
                                DisclosureGroup("出处") { Text(record.source.quote).font(TypeScale.caption).textSelection(.enabled) }
                                Button("编辑") { editing = EditTarget(record: record, category: category) }.font(TypeScale.caption)
                            }.padding(.vertical, 4)
                        }
                        Button("添加记录") { editing = EditTarget(record: nil, category: category) }
                    }
                }
                if !pending.isEmpty {
                    Section("待处理") {
                        ForEach(pending) { item in
                            VStack(alignment: .leading, spacing: 8) {
                                Text(item.command.text)
                                Text(item.error ?? "等待完成保存").font(TypeScale.caption).foregroundStyle(Ink.ink3)
                                HStack {
                                    Button("重试") { store.retryStudyOperation(item) }
                                    Spacer()
                                    Button("取消这项操作", role: .destructive) { store.discardStudyOperation(item) }
                                }.buttonStyle(.borderless)
                            }
                        }
                    }
                }
                Section("修改历史") {
                    if events.isEmpty { Text("尚无修改").foregroundStyle(Ink.ink3) }
                    ForEach(events.prefix(100)) { event in
                        DisclosureGroup {
                            if let before = event.before { Text("修改前\n" + before.text).font(TypeScale.caption) }
                            Text("修改后\n" + event.after.text).font(TypeScale.caption)
                            Text(event.after.source.quote).font(TypeScale.caption).foregroundStyle(Ink.ink3)
                            Button("撤销这次修改") { store.undoStudyEvent(event) }
                        } label: {
                            VStack(alignment: .leading, spacing: 4) {
                                Text(StudyReceipt(event: event).message)
                                Text(event.date.formatted(date: .abbreviated, time: .shortened)).font(TypeScale.caption).foregroundStyle(Ink.ink3)
                            }
                        }
                    }
                }
                Section {
                    Button("导出本项目学习记录") {
                        exportURL = store.exportStudyMemory(projectID: projectID)
                        showExport = exportURL != nil
                    }
                } footer: {
                    Text("导出包含学习记录、出处、修改历史和学习现场。云盘自动备份将在后续版本接入。")
                }
            } else { Text("项目已上锁或不存在，请返回后重新打开。") }
        }
        .font(TypeScale.body).scrollContentBackground(.hidden).background(AppBackground())
        .foregroundStyle(Ink.ink).tint(Ink.ink).navigationTitle("项目学习记忆")
        .navigationBarTitleDisplayMode(.inline)
        .onAppear(perform: reload)
        .onChange(of: store.studyRevision) { _, _ in reload() }
        .onChange(of: store.unlockedProjectIDs) { _, _ in reload() }
        .sheet(item: $editing) { target in
            StudyRecordEditor(projectID: projectID, record: target.record, category: target.category).environmentObject(store)
        }
        .sheet(isPresented: $showExport) { if let exportURL { ShareSheet(items: [exportURL]) } }
        .fileImporter(isPresented: $importingWords, allowedContentTypes: [.json]) { result in
            do {
                let url = try result.get()
                importingWordsBusy = true
                Task { @MainActor in
                    _ = await store.importStudyVocabulary(projectID: projectID, url: url)
                    importingWordsBusy = false; reload()
                }
            } catch { store.studyIssue = error.localizedDescription }
        }
    }
    private func reload() {
        do {
            records = try store.studyRecords(for: projectID)
            events = try store.studyEvents(for: projectID)
            pending = try store.studyPending(for: projectID)
            if subject == .english { wordCount = try store.studyVocabularyCount(projectID: projectID) }
            loadError = nil
        } catch {
            records = []; events = []; pending = []
            loadError = error.localizedDescription; store.studyIssue = error.localizedDescription
        }
    }
    private func sourceName(_ kind: StudySource.Kind) -> String {
        switch kind { case .manual: return "手动记录"; case .userStatement: return "用户原话"; case .modelInference: return "模型判断，可纠正" }
    }
}

private struct StudyRecordEditor: View {
    @EnvironmentObject private var store: AppStore
    @Environment(\.dismiss) private var dismiss
    let projectID: UUID
    let record: StudyMemoryRecord?
    @State private var category: String
    @State private var text: String
    @State private var deleting = false
    @State private var operationID = UUID().uuidString
    @State private var sourceThreadID = UUID()
    @State private var lastAttempt: String?
    init(projectID: UUID, record: StudyMemoryRecord?, category: String) {
        self.projectID = projectID; self.record = record
        _category = State(initialValue: category); _text = State(initialValue: record?.text ?? "")
    }
    var body: some View {
        NavigationStack {
            Form {
                Picker("栏目", selection: $category) {
                    ForEach(store.project(projectID)?.studySubject?.categories ?? [], id: \.self) { Text($0).tag($0) }
                }
                TextEditor(text: $text).frame(minHeight: 180)
                Text("\(text.count) / 4000 字").font(TypeScale.caption).foregroundStyle(Ink.ink3)
                if let issue = store.studyIssue { Text(issue).font(TypeScale.caption).foregroundStyle(.red) }
                if record != nil { Button("移出有效记忆", role: .destructive) { deleting = true } }
            }
            .font(TypeScale.body).scrollContentBackground(.hidden).background(AppBackground()).tint(Ink.ink)
            .navigationTitle(record == nil ? "添加学习记录" : "编辑学习记录").navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("取消") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("保存") {
                        save(deleting: false)
                    }.disabled(text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || text.count > 4000)
                }
            }
            .confirmationDialog("移出有效记忆后，可以在修改历史里撤销。", isPresented: $deleting) {
                Button("移出有效记忆", role: .destructive) {
                    save(deleting: true)
                }
            }
        }
    }
    private func save(deleting: Bool) {
        let value = deleting ? (record?.text ?? text) : text
        let selected = deleting ? (record?.category ?? category) : category
        let signature = "\(deleting)\n\(selected)\n\(value)"
        if let lastAttempt, lastAttempt != signature {
            guard store.discardStudyOperation(projectID: projectID, operationID: operationID) else { return }
            operationID = UUID().uuidString
        }
        lastAttempt = signature
        if store.saveStudyRecord(projectID: projectID, record: record, category: selected, text: value,
                                 operationID: operationID, sourceThreadID: sourceThreadID, deleting: deleting) { dismiss() }
    }
}
