import SwiftUI
import Observation

/// The whole look of the app, chosen in Settings → 阅读与外观 → 界面风格.
/// 纸笺: warm paper, Songti, highlighter strokes, liquid glass.
/// 瑞士: grey-white sheet, black sans, blue bold emphasis, ruled grid, square edges.
/// 夜江 (千江有水千江月): night river, moonlight the only colour, Songti, liquid glass.
///   Always dark. It shares the paper look's layout; only colours, the moon mark,
///   the sidebar's moon phases, reply capsules and the bookshelf's spines differ.
/// Colours and fonts read it through `StyleAppearance`, so a switch redraws the
/// app in place, keeping open sheets and unsaved drafts, the way a font change does.
enum InterfaceStyle: String, CaseIterable, Identifiable, Sendable {
    case paper, swiss, night

    static let key = "sermo.interface.style"

    var id: String { rawValue }
    var title: String {
        switch self {
        case .paper: return "纸笺"
        case .swiss: return "瑞士"
        case .night: return "夜江"
        }
    }
    var detail: String {
        switch self {
        case .paper: return "暖纸色、重点加粗、液态玻璃"
        case .swiss: return "灰白底、黑体、蓝色粗体、网格线与方角"
        case .night: return "千江有水千江月：夜色江水、重点加粗，始终是深色"
        }
    }

    /// The look views draw with. Reading it inside a view's body subscribes that view to changes.
    static var current: InterfaceStyle { StyleAppearance.shared.style }
    static var isSwiss: Bool { current == .swiss }
    static var isNight: Bool { current == .night }

    /// What is saved in Settings.
    static var stored: InterfaceStyle {
        InterfaceStyle(rawValue: UserDefaults.standard.string(forKey: key) ?? "") ?? .paper
    }
}

/// Observable holder for the current look; `reload()` after the setting changes.
@Observable
final class StyleAppearance {
    static let shared = StyleAppearance()
    private(set) var style: InterfaceStyle
    init() {
        let arguments = ProcessInfo.processInfo.arguments
        if arguments.contains("--ui-preview") {
            // Preview runs start from their launch flag, so a value left in the
            // simulator never changes a screenshot; the picker can still switch.
            let flagged: InterfaceStyle = arguments.contains("--preview-swiss") ? .swiss
                : (arguments.contains("--preview-night") ? .night : .paper)
            UserDefaults.standard.set(flagged.rawValue, forKey: InterfaceStyle.key)
        }
        style = InterfaceStyle.stored
    }
    func reload() {
        let value = InterfaceStyle.stored
        if value != style { style = value }
    }
}

/// Light or dark for 纸笺 and 瑞士: with the system by default, or held on one side.
/// 夜江 is a night scene and always stays dark.
enum AppearanceMode: String, CaseIterable, Identifiable, Sendable {
    case system, light, dark
    static let key = "sermo.appearance.mode"
    var id: String { rawValue }
    var title: String {
        switch self {
        case .system: return "跟随系统"
        case .light: return "始终浅色"
        case .dark: return "始终深色"
        }
    }
    /// The scheme the window should use for a stored mode in the current look.
    static func scheme(_ raw: String) -> ColorScheme? {
        if InterfaceStyle.isNight { return .dark }
        switch AppearanceMode(rawValue: raw) ?? .system {
        case .system: return nil
        case .light: return .light
        case .dark: return .dark
        }
    }
}

/// Settings row: pick the look. Saved at once; the app redraws in place.
@MainActor
struct InterfaceStylePicker: View {
    @AppStorage(InterfaceStyle.key) private var stored = InterfaceStyle.paper.rawValue
    @AppStorage(AppearanceMode.key) private var appearance = AppearanceMode.system.rawValue
    var body: some View {
        Picker("界面风格", selection: $stored) {
            ForEach(InterfaceStyle.allCases) { style in
                Text(style.title).tag(style.rawValue)
            }
        }
        .accessibilityIdentifier("interface-style")
        .accessibilityValue((InterfaceStyle(rawValue: stored) ?? .paper).title)
        // The app also listens for this key; reloading here as well makes the switch immediate.
        .onChange(of: stored) { _, _ in StyleAppearance.shared.reload(); InkAppearance.apply() }
        Picker("白天与夜晚", selection: $appearance) {
            ForEach(AppearanceMode.allCases) { mode in Text(mode.title).tag(mode.rawValue) }
        }
        .disabled(InterfaceStyle(rawValue: stored) == .night)
        .accessibilityIdentifier("appearance-mode")
        Text((InterfaceStyle(rawValue: stored) ?? .paper).detail + "。切换后整个 App 立刻换样式，对话和设置都不受影响。纸笺和瑞士默认跟着手机的浅色、深色模式自动切换，也可以固定一边；瑞士风格固定使用系统字体；夜江始终是深色。")
            .font(TypeScale.serif(12)).foregroundStyle(.secondary)
    }
}

// MARK: - Swiss pieces shared by several screens

/// Small monospaced label: Q.01, A.01, COPY, FLASH / HIGH.
struct MonoLabel: View {
    let text: String
    var color: Color = Ink.ink3
    var size: CGFloat = 11
    var body: some View {
        Text(text).font(TypeScale.mono(size)).tracking(0.4).foregroundStyle(color)
    }
}

/// Full-width rule; the Swiss look separates with lines instead of space and shadow.
struct SwissRule: View {
    var weight: CGFloat = 1
    var strong = false
    var body: some View {
        Rectangle().fill(strong ? Ink.ink : Ink.line).frame(height: weight).accessibilityHidden(true)
    }
}

/// The big title block that opens a conversation in the Swiss look.
struct SwissThreadHeader: View {
    let title: String
    let date: Date
    let model: String
    let rounds: Int
    private static let dateFormat: DateFormatter = {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "zh_CN")
        formatter.dateFormat = "yyyy.MM.dd"
        return formatter
    }()
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text(title)
                .font(TypeScale.heavy(30, relativeTo: .largeTitle))
                .tracking(-0.4).lineSpacing(2)
                .foregroundStyle(Ink.ink)
                .fixedSize(horizontal: false, vertical: true)
                .accessibilityAddTraits(.isHeader)
            HStack {
                MonoLabel(text: Self.dateFormat.string(from: date))
                Spacer(minLength: 8)
                MonoLabel(text: model.uppercased()).lineLimit(1)
                Spacer(minLength: 8)
                MonoLabel(text: String(format: "%02d 轮", rounds))
            }
            SwissRule(weight: 2, strong: true)
        }
        .accessibilityElement(children: .combine)
    }
}

/// A capsule in the paper look, a plain rectangle in the Swiss look.
/// The look is captured when the view is built, so a switch redraws the shape.
struct InkCapsule: Shape {
    var swiss = InterfaceStyle.isSwiss
    func path(in rect: CGRect) -> Path {
        swiss ? Path(rect) : Capsule(style: .continuous).path(in: rect)
    }
}

/// Rounded corners in the paper look, square in the Swiss look.
struct InkRounded: Shape {
    var radius: CGFloat
    var swiss = InterfaceStyle.isSwiss
    func path(in rect: CGRect) -> Path {
        RoundedRectangle(cornerRadius: swiss ? 0 : radius, style: .continuous).path(in: rect)
    }
}

// MARK: - 夜江 pieces shared by several screens

/// Sermo's mark in the 夜江 look: a pale gold moon with a soft halo.
/// `glow` brightens it while an answer is on its way ("月出").
struct MoonDisc: View {
    var size: CGFloat = 20
    var glow = false
    var body: some View {
        Circle()
            .fill(RadialGradient(colors: [Color(red: 1, green: 0.965, blue: 0.867), Ink.seal,
                                          Color(red: 0.80, green: 0.68, blue: 0.45)],
                                 center: UnitPoint(x: 0.38, y: 0.36), startRadius: 0, endRadius: size * 0.62))
            .frame(width: size, height: size)
            .shadow(color: Ink.seal.opacity(glow ? 0.75 : 0.35), radius: glow ? size * 0.9 : size * 0.55)
            .shadow(color: Ink.seal.opacity(glow ? 0.35 : 0.16), radius: glow ? size * 2.6 : size * 1.6)
            .accessibilityHidden(true)
    }
}

/// The lit part of a waxing moon: 0 is a new moon, 1 a full moon, lit on the right.
struct MoonLitShape: Shape {
    var phase: Double
    func path(in rect: CGRect) -> Path {
        let r = min(rect.width, rect.height) / 2
        let c = CGPoint(x: rect.midX, y: rect.midY)
        let p = CGFloat(min(1, max(0, phase)))
        var path = Path()
        guard p > 0.02 else { return path }
        // Right half of the disc, top to bottom.
        path.move(to: CGPoint(x: c.x, y: c.y - r))
        path.addArc(center: c, radius: r, startAngle: .degrees(-90), endAngle: .degrees(90), clockwise: false)
        // Back up along the terminator: an ellipse whose width shrinks to zero at half moon.
        let rx = abs(1 - 2 * p) * r
        let steps = 24
        for step in 1...steps {
            let t = CGFloat(step) / CGFloat(steps)
            let angle = CGFloat.pi / 2 - t * CGFloat.pi       // 90° → -90°, bottom to top
            let x = p < 0.5 ? c.x + rx * cos(angle) : c.x - rx * cos(angle)
            path.addLine(to: CGPoint(x: x, y: c.y + r * sin(angle)))
        }
        path.closeSubpath()
        return path
    }
}

/// A conversation's moon phase in the 夜江 sidebar: the longer the talk, the fuller the moon.
struct MoonPhaseIcon: View {
    var phase: Double
    var size: CGFloat = 18
    var body: some View {
        ZStack {
            Circle().stroke(Ink.line, lineWidth: 1)
            MoonLitShape(phase: phase).fill(Ink.seal)
        }
        .frame(width: size, height: size)
        .accessibilityHidden(true)
    }

    /// One full moon at about thirty of your messages; a sliver as soon as a talk starts.
    static func phase(for thread: ChatThread) -> Double {
        let turns = thread.messages.reduce(0) { $0 + ($1.role == .user ? 1 : 0) }
        guard turns > 0 else { return 0.06 }
        return min(1, 0.1 + Double(turns) / 30)
    }
}

/// A faint water line between exchanges in the 夜江 look.
struct WaveRule: View {
    var body: some View {
        WaveShape().stroke(Ink.line, lineWidth: 1).frame(height: 8).accessibilityHidden(true)
    }
}

struct WaveShape: Shape {
    func path(in rect: CGRect) -> Path {
        var path = Path()
        let mid = rect.midY, w = rect.width
        path.move(to: CGPoint(x: rect.minX, y: mid))
        let segments = 4
        for index in 0..<segments {
            let x0 = rect.minX + w * Double(index) / Double(segments)
            let x1 = rect.minX + w * Double(index + 1) / Double(segments)
            let lift: Double = index % 2 == 0 ? -3 : 3
            path.addCurve(to: CGPoint(x: x1, y: mid),
                          control1: CGPoint(x: x0 + (x1 - x0) / 3, y: mid + lift),
                          control2: CGPoint(x: x0 + (x1 - x0) * 2 / 3, y: mid - lift))
        }
        return path
    }
}

/// Lays children out in rows, wrapping to the next row when one is full (reply capsules).
struct FlowRows: Layout {
    var spacing: CGFloat = 8
    func sizeThatFits(proposal: ProposedViewSize, subviews: Subviews, cache: inout ()) -> CGSize {
        let width = proposal.width ?? .infinity
        var x: CGFloat = 0, y: CGFloat = 0, rowHeight: CGFloat = 0, widest: CGFloat = 0
        for subview in subviews {
            let size = subview.sizeThatFits(ProposedViewSize(width: width, height: nil))
            if x > 0 && x + size.width > width { y += rowHeight + spacing; x = 0; rowHeight = 0 }
            x += size.width + spacing
            rowHeight = max(rowHeight, size.height)
            widest = max(widest, x - spacing)
        }
        return CGSize(width: width.isFinite ? width : widest, height: y + rowHeight)
    }
    func placeSubviews(in bounds: CGRect, proposal: ProposedViewSize, subviews: Subviews, cache: inout ()) {
        var x = bounds.minX, y = bounds.minY, rowHeight: CGFloat = 0
        for subview in subviews {
            let size = subview.sizeThatFits(ProposedViewSize(width: bounds.width, height: nil))
            if x > bounds.minX && x + size.width > bounds.maxX { y += rowHeight + spacing; x = bounds.minX; rowHeight = 0 }
            subview.place(at: CGPoint(x: x, y: y), proposal: ProposedViewSize(width: min(size.width, bounds.width), height: size.height))
            x += size.width + spacing
            rowHeight = max(rowHeight, size.height)
        }
    }
}
