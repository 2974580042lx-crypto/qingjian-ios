import SwiftUI
import UIKit
import LocalAuthentication
import UniformTypeIdentifiers

enum ProjectLock {
    // Face ID, falling back to the phone passcode. Unlocks for this session only.
    @MainActor static func open(_ id: UUID, store: AppStore) async -> Bool {
        guard store.isLocked(id) else { return true }
        if store.isPreview { store.unlock(id); return true }
        let context = LAContext()
        var error: NSError?
        guard context.canEvaluatePolicy(.deviceOwnerAuthentication, error: &error) else {
            store.errorMessage = "这台手机没有设置面容 ID 或锁屏密码，暂时打不开上锁的项目。"
            return false
        }
        do {
            let ok = try await context.evaluatePolicy(.deviceOwnerAuthentication, localizedReason: "打开上锁的项目")
            if ok { store.unlock(id) }
            return ok
        } catch { return false }
    }
}

private extension View {
    func errorAlert(_ store: AppStore) -> some View {
        alert("暂时没有完成", isPresented: Binding(get: { store.errorMessage != nil }, set: { if !$0 { store.errorMessage = nil } })) {
            Button("知道了") { store.errorMessage = nil }
        } message: { Text(store.errorMessage ?? "") }
    }
}

@MainActor
struct ProjectsView: View {
    @EnvironmentObject private var store: AppStore
    @Environment(\.dismiss) private var dismiss
    // Called after a conversation was opened, so the sheet and the sidebar can close.
    let opened: () -> Void
    @State private var path: [UUID] = []
    @State private var creating = false
    @State private var newName = ""

    var body: some View {
        NavigationStack(path: $path) {
            List {
                if store.projects.isEmpty {
                    Text("项目有自己的指令、资料和默认模型。项目里的对话只在项目中出现，不会进侧栏的「最近」。")
                        .font(TypeScale.serif(15)).foregroundStyle(Ink.ink3).listRowBackground(Color.clear)
                }
                ForEach(store.projects) { project in
                    Button { open(project.id) } label: {
                        HStack(spacing: 14) {
                            Image(systemName: project.isLocked ? "lock" : "folder").font(.system(size: 17)).foregroundStyle(Ink.ink2).frame(width: 24)
                            VStack(alignment: .leading, spacing: 3) {
                                Text(project.name).font(TypeScale.serif(17)).foregroundStyle(Ink.ink)
                                Text(project.isLocked && store.isLocked(project.id) ? "已上锁" : "\(store.threads(in: project.id).count) 个对话")
                                    .font(TypeScale.tiny).foregroundStyle(Ink.ink3)
                            }
                            Spacer()
                            Image(systemName: "chevron.right").font(.system(size: 12)).foregroundStyle(Ink.ink3)
                        }.padding(.vertical, 6).contentShape(Rectangle())
                    }
                    .buttonStyle(.plain)
                    .listRowBackground(Color.clear)
                    .accessibilityIdentifier("project-row")
                }
            }
            .listStyle(.plain)
            .scrollContentBackground(.hidden)
            .background(AppBackground())
            .navigationTitle("项目")
            .toolbar {
                ToolbarItem(placement: .topBarLeading) { Button("完成") { dismiss() } }
                ToolbarItem(placement: .topBarTrailing) {
                    Button { newName = ""; creating = true } label: { Image(systemName: "plus") }.accessibilityLabel("新建项目")
                }
            }
            .navigationDestination(for: UUID.self) { id in ProjectPageView(projectID: id, opened: opened) }
            .alert("新建项目", isPresented: $creating) {
                TextField("项目名称", text: $newName)
                Button("取消", role: .cancel) { }
                Button("创建") { if let id = store.createProject(name: newName) { path.append(id) } }
            }
            .errorAlert(store)
        }
        .tint(Ink.ink)
        .onAppear {
            if ProcessInfo.processInfo.arguments.contains("--preview-project"), let first = store.projects.first { path = [first.id] }
        }
    }

    private func open(_ id: UUID) {
        Task { if await ProjectLock.open(id, store: store) { path.append(id) } }
    }
}

// Changes one stored project in place; the small project screens all save straight away.
@MainActor private func editProject(_ store: AppStore, _ id: UUID, _ change: (inout ChatProject) -> Void) {
    guard var project = store.project(id) else { return }
    change(&project)
    _ = store.updateProject(project)
}

// After the Claude app's project screen: files and instructions on top, the
// project's conversations below, and a new-conversation button at the bottom right.
@MainActor
struct ProjectPageView: View {
    @EnvironmentObject private var store: AppStore
    @Environment(\.dismiss) private var dismiss
    let projectID: UUID
    let opened: () -> Void
    @State private var editingInstructions = false
    @State private var renaming = false
    @State private var renameText = ""
    @State private var confirmDelete = false
    private var project: ChatProject? { store.project(projectID) }

    var body: some View {
        let threads = store.threads(in: projectID)
        VStack(spacing: 0) {
            HStack(spacing: 12) {
                NavigationLink { ProjectFilesView(projectID: projectID) } label: {
                    pill((project?.documents.isEmpty ?? true) ? "添加文件" : "文件 · \(project?.documents.count ?? 0)")
                }
                .accessibilityIdentifier("project-files")
                Button { editingInstructions = true } label: {
                    pill((project?.instructions.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ?? true) ? "添加指令" : "编辑指令")
                }
                .accessibilityIdentifier("project-instructions-button")
            }
            .buttonStyle(.plain)
            .padding(.horizontal, 16).padding(.top, 8).padding(.bottom, 12)
            // Every service can use manually written project memory.
            if project != nil {
                NavigationLink { ProjectMemoryView(projectID: projectID) } label: {
                    HStack(spacing: 10) {
                        Image(systemName: "brain").font(.system(size: 15)).foregroundStyle(Ink.ink2).frame(width: 24)
                        Text("项目记忆").font(TypeScale.serif(16)).foregroundStyle(Ink.ink)
                        Spacer()
                        Text(memorySummary).font(TypeScale.tiny).foregroundStyle(Ink.ink3)
                        Image(systemName: "chevron.right").font(.system(size: 12)).foregroundStyle(Ink.ink3)
                    }
                    .padding(.horizontal, 20).frame(height: 44).contentShape(Rectangle())
                }
                .buttonStyle(.plain)
                .accessibilityIdentifier("project-memory")
            }
            if threads.isEmpty {
                Spacer()
                VStack(spacing: 12) {
                    Image(systemName: "bubble.left.and.bubble.right").font(.system(size: 21)).foregroundStyle(Ink.ink2)
                        .frame(width: 56, height: 56).background(Ink.raised, in: Circle())
                    Text("向 Sermo 提出任何问题").font(TypeScale.serif(18)).foregroundStyle(Ink.ink2)
                    Text("此项目中的会话将显示在这里。").font(TypeScale.serif(15)).foregroundStyle(Ink.ink3)
                }
                Spacer(); Spacer()
            } else {
                List {
                    ForEach(threads) { thread in
                        Button { store.select(thread.id); opened() } label: {
                            HStack(spacing: 14) {
                                Image(systemName: "bubble.left").font(.system(size: 16)).foregroundStyle(Ink.ink2).frame(width: 24)
                                VStack(alignment: .leading, spacing: 3) {
                                    Text(thread.title).font(TypeScale.serif(17)).foregroundStyle(Ink.ink).lineLimit(1)
                                    Text(thread.updatedAt.formatted(date: .abbreviated, time: .omitted)).font(TypeScale.tiny).foregroundStyle(Ink.ink3)
                                }
                            }
                            .padding(.vertical, 4).frame(maxWidth: .infinity, alignment: .leading).contentShape(Rectangle())
                        }
                        .buttonStyle(.plain)
                        .listRowBackground(Color.clear)
                        .swipeActions { Button("移出") { store.moveThreads([thread.id], to: nil) }.tint(Ink.ink3) }
                        .accessibilityIdentifier("project-thread-row")
                    }
                }
                .listStyle(.plain)
                .scrollContentBackground(.hidden)
                .contentMargins(.bottom, 90, for: .scrollContent)
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(AppBackground())
        .overlay(alignment: .bottomTrailing) {
            Button { store.createThread(in: projectID); opened() } label: {
                HStack(spacing: 8) {
                    Image(systemName: "plus").font(.system(size: 15, weight: .medium))
                    Text("新建会话").font(TypeScale.serif(16).weight(.semibold))
                }
                .foregroundStyle(Ink.onSolid).padding(.horizontal, 20).frame(height: 48)
                .background(Ink.solid, in: InkCapsule()).contentShape(Capsule())
            }
            .buttonStyle(.plain)
            .padding(.trailing, 20).padding(.bottom, 12)
            .accessibilityIdentifier("project-new-chat")
        }
        .navigationTitle(project?.name ?? "项目")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItemGroup(placement: .topBarTrailing) {
                Button { store.togglePinnedProject(projectID) } label: {
                    Image(systemName: project?.isPinned == true ? "pin.fill" : "pin")
                }
                .accessibilityLabel(project?.isPinned == true ? "从侧栏取消固定" : "固定到侧栏")
                .accessibilityIdentifier("project-pin")
                optionsMenu
            }
        }
        .sheet(isPresented: $editingInstructions) {
            ProjectInstructionsView(projectID: projectID).environmentObject(store)
        }
        .alert("重命名项目", isPresented: $renaming) {
            TextField("项目名称", text: $renameText)
            Button("取消", role: .cancel) { }
            Button("保存") { editProject(store, projectID) { $0.name = renameText } }
        }
        .confirmationDialog("删除「\(project?.name ?? "")」？", isPresented: $confirmDelete, titleVisibility: .visible) {
            Button("删除项目，对话移回「最近」") { store.deleteProject(projectID, keepConversations: true); dismiss() }
            Button("连同里面的对话一起删除", role: .destructive) { store.deleteProject(projectID, keepConversations: false); dismiss() }
        }
        .errorAlert(store)
    }

    private var optionsMenu: some View {
        Menu {
            Button("重命名", systemImage: "pencil") { renameText = project?.name ?? ""; renaming = true }
            Menu("服务", systemImage: "server.rack") {
                Picker("服务", selection: Binding(get: { project?.service ?? .deepSeek },
                                                set: { value in editProject(store, projectID) { $0.provider = value } })) {
                    ForEach(AIProvider.allCases) { Text($0.title).tag($0) }
                }
            }
            if project?.service == .chatGPT {
                Menu("默认模型", systemImage: "cpu") {
                    Picker("默认模型", selection: Binding(get: { project?.subscriptionModel ?? "follow" },
                                                      set: { value in editProject(store, projectID) { $0.subscriptionModel = value == "follow" ? nil : value } })) {
                        Text("跟随当前").tag("follow")
                        ForEach(store.subscription.models) { Text($0.displayName).tag($0.slug) }
                    }
                }
                Menu("默认思考", systemImage: "sparkle") {
                    Picker("默认思考", selection: Binding(get: { project?.subscriptionEffort?.rawValue ?? "follow" },
                                                      set: { value in editProject(store, projectID) { $0.subscriptionEffort = SubscriptionEffort(rawValue: value) } })) {
                        Text("跟随当前").tag("follow")
                        ForEach(SubscriptionEffort.allCases) { Text($0.title).tag($0.rawValue) }
                    }
                }
                Toggle(isOn: Binding(get: { project?.autoMemory != false },
                                     set: { value in editProject(store, projectID) { $0.autoMemory = value } })) {
                    Label("自动整理记忆", systemImage: "brain")
                }
            } else {
            Menu("默认模型", systemImage: "cpu") {
                Picker("默认模型", selection: Binding(get: { project?.model?.rawValue ?? "follow" },
                                                  set: { value in editProject(store, projectID) { $0.model = DeepSeekModel(rawValue: value) } })) {
                    Text("跟随当前").tag("follow")
                    ForEach(DeepSeekModel.allCases) { Text($0.title).tag($0.rawValue) }
                }
            }
            Menu("默认思考", systemImage: "sparkle") {
                Picker("默认思考", selection: Binding(get: {
                    guard let thinking = project?.thinkingEnabled else { return "follow" }
                    return thinking ? (project?.effort ?? .high).rawValue : "off"
                }, set: { value in
                    editProject(store, projectID) { project in
                        switch value {
                        case "follow": project.thinkingEnabled = nil; project.effort = nil
                        case "off": project.thinkingEnabled = false
                        default: project.thinkingEnabled = true; project.effort = ThinkingEffort(rawValue: value)
                        }
                    }
                })) {
                    Text("跟随当前").tag("follow")
                    Text("Off").tag("off")
                    ForEach(ThinkingEffort.allCases) { Text($0.title).tag($0.rawValue) }
                }
            }
            // Off by default, so role-play and other projects never see any tools.
            Toggle(isOn: Binding(get: { project?.driveTools == true },
                                 set: { value in editProject(store, projectID) { $0.driveTools = value } })) {
                Label("谷歌云盘工具", systemImage: "externaldrive")
            }
            Toggle(isOn: Binding(get: { project?.githubTools == true },
                                 set: { value in editProject(store, projectID) { $0.githubTools = value } })) {
                Label("GitHub 工具", systemImage: "chevron.left.forwardslash.chevron.right")
            }
            Toggle(isOn: Binding(get: { project?.webTools == true },
                                 set: { value in editProject(store, projectID) { $0.webTools = value } })) {
                Label("联网工具", systemImage: "globe")
            }
            }
            // After a long gap (or on a conversation's first message) the model hears what time it is.
            Toggle(isOn: Binding(get: { project?.timeAwareness == true },
                                 set: { value in editProject(store, projectID) { $0.timeAwareness = value } })) {
                Label("告诉角色时间流逝", systemImage: "clock")
            }
            Toggle(isOn: Binding(get: { project?.isLocked == true },
                                 set: { value in editProject(store, projectID) { $0.isLocked = value } })) {
                Label("面容 ID 锁", systemImage: "faceid")
            }
            Divider()
            Button("删除项目", systemImage: "trash", role: .destructive) { confirmDelete = true }
        } label: {
            Image(systemName: "ellipsis")
        }
        .accessibilityLabel("项目选项")
        .accessibilityIdentifier("project-options")
    }

    private var memorySummary: String {
        if store.memorizingProjectID == projectID { return "正在整理…" }
        let count = (project?.memory ?? "").components(separatedBy: .newlines).filter { !$0.trimmingCharacters(in: .whitespaces).isEmpty }.count
        if count == 0 { return project?.remembers == true ? "离开对话后自动整理" : "手动填写" }
        return "\(count) 条"
    }

    private func pill(_ title: String) -> some View {
        Text(title).font(TypeScale.serif(16).weight(.semibold)).foregroundStyle(Ink.ink)
            .frame(maxWidth: .infinity).frame(height: 50)
            .overlay(InkCapsule().stroke(Ink.line, lineWidth: 1))
            .contentShape(Capsule())
    }
}

// What the project remembers across conversations; yours to read, correct or clear.
@MainActor
struct ProjectMemoryView: View {
    @EnvironmentObject private var store: AppStore
    @Environment(\.dismiss) private var dismiss
    let projectID: UUID
    @State private var draft = ""
    @State private var confirmClear = false
    private var project: ChatProject? { store.isLocked(projectID) ? nil : store.project(projectID) }
    private var changed: Bool { draft != (project?.memory ?? "") }
    private var overLimit: Bool { draft.count > ChatProject.memoryCharacterLimit }

    var body: some View {
        Form {
            if project == nil {
                Text("项目已上锁或不存在，请返回后重新打开。").foregroundStyle(Ink.ink3)
            } else {
            Section {
                TextEditor(text: $draft).frame(minHeight: 260).font(TypeScale.serif(15)).scrollContentBackground(.hidden)
                    .accessibilityIdentifier("project-memory-editor")
                Text("\(draft.count.formatted()) / \(ChatProject.memoryCharacterLimit.formatted()) 字")
                    .font(TypeScale.tiny).foregroundStyle(overLimit ? Color.red : Ink.ink3)
                if overLimit {
                    Text("请删减到 4,000 字以内再保存，超出的内容不会被自动截断。")
                        .font(TypeScale.label).foregroundStyle(.red)
                }
            } footer: {
                Text(footer)
            }
            Section {
                Button("清空记忆", role: .destructive) { confirmClear = true }
                    .disabled((project?.memory ?? "").isEmpty || !store.canPersist)
            }
            }
        }
        .font(TypeScale.body)
        .scrollContentBackground(.hidden)
        .background(AppBackground())
        .navigationTitle("项目记忆")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .cancellationAction) { Button("取消") { dismiss() } }
            ToolbarItem(placement: .topBarTrailing) {
                Button("保存") {
                    guard project != nil, store.canPersist, !overLimit else { return }
                    if store.setMemory(draft, for: projectID) { dismiss() }
                }.disabled(!changed || overLimit || project == nil || !store.canPersist)
            }
        }
        .confirmationDialog("清空这个项目的记忆？", isPresented: $confirmClear, titleVisibility: .visible) {
            Button("清空", role: .destructive) {
                guard project != nil, store.canPersist else { return }
                if store.setMemory(nil, for: projectID) { draft = "" }
            }
        } message: { Text("已经整理过的对话不会再被重新记一遍。") }
        .onAppear { draft = project?.memory ?? "" }
        .onChange(of: project?.memory) { old, new in
            // A background update landed; take it unless you are mid-edit.
            if draft == (old ?? "") { draft = new ?? "" }
        }
        .interactiveDismissDisabled(changed)
        .errorAlert(store)
    }

    private var footer: String {
        var parts: [String] = []
        if store.memorizingProjectID == projectID { parts.append("正在整理刚才的对话…") }
        if let date = project?.memoryUpdatedAt { parts.append("上次更新：\(date.formatted(date: .abbreviated, time: .shortened))。") }
        parts.append(project?.remembers == true ?
            "离开这个项目里的对话时，ChatGPT 会把新内容整理进来，用的是订阅额度。每条一行，可以直接改。" :
            "可以手动写下长期要求和已确认的结论。这里不自动整理，记忆会随本项目的每次提问发给模型。")
        parts.append("上限 \(ChatProject.memoryCharacterLimit) 字。")
        return parts.joined(separator: " ")
    }
}

// The project's documents: each sent with every request while switched on.
@MainActor
struct ProjectFilesView: View {
    @EnvironmentObject private var store: AppStore
    let projectID: UUID
    @State private var importing = false
    @State private var search = ""
    @State private var editingDocument: ProjectDocument?
    private var project: ChatProject? { store.isLocked(projectID) ? nil : store.project(projectID) }
    private var query: String { search.trimmingCharacters(in: .whitespacesAndNewlines) }
    private var visibleDocuments: [ProjectDocument] {
        (project?.documents ?? []).filter {
            query.isEmpty || $0.name.localizedCaseInsensitiveContains(query) || $0.text.localizedCaseInsensitiveContains(query)
        }
    }
    private var cannotAdd: Bool {
        project == nil || !store.canPersist || (project?.documents.count ?? 0) >= 50
            || (project?.includedCharacters ?? 0) >= ChatProject.documentCharacterLimit
    }

    var body: some View {
        Form {
            if project == nil {
                Text("项目已上锁或不存在，请返回后重新打开。").foregroundStyle(Ink.ink3)
            } else {
            Section {
                if visibleDocuments.isEmpty {
                    Text(query.isEmpty ? "还没有资料，可以导入文件或粘贴文字。" : "没有匹配的资料，试试名称或正文中的其他关键词。")
                        .foregroundStyle(Ink.ink3)
                }
                ForEach(visibleDocuments) { document in
                    HStack(spacing: 14) {
                        Button { editingDocument = document } label: {
                            HStack(spacing: 8) {
                                VStack(alignment: .leading, spacing: 4) {
                                    Text(document.name).foregroundStyle(Ink.ink).lineLimit(1)
                                    Text("\(document.text.count.formatted()) 字 · 点开查看与编辑")
                                        .font(TypeScale.tiny).foregroundStyle(Ink.ink3)
                                }
                                Spacer(minLength: 0)
                                Image(systemName: "chevron.right").font(TypeScale.tiny).foregroundStyle(Ink.ink3)
                            }.frame(maxWidth: .infinity, alignment: .leading).contentShape(Rectangle())
                        }.buttonStyle(.plain)
                        Toggle("提问时引用", isOn: Binding(get: { document.isIncluded }, set: { value in
                            updateDocuments { documents in
                                if let i = documents.firstIndex(where: { $0.id == document.id }) { documents[i].isIncluded = value }
                            }
                        }))
                        .labelsHidden().fixedSize()
                        .accessibilityLabel("提问时引用《\(document.name)》")
                        .disabled(!store.canPersist)
                    }
                }
                .onDelete(perform: removeDocuments)
            } header: {
                Text(query.isEmpty ? "资料 · \(project?.documents.count ?? 0) / 50" : "搜索结果 · \(visibleDocuments.count)")
            } footer: {
                Text("启用的资料每次提问都会发给模型，会增加 token 用量。已启用 \((project?.includedCharacters ?? 0).formatted()) / \(ChatProject.documentCharacterLimit.formatted()) 字。左滑可删除。")
            }
            Section {
                Button { importing = true } label: { Label("导入文字文件", systemImage: "doc.badge.plus") }
                    .disabled(cannotAdd)
                Button { pasteDocument() } label: { Label("粘贴文字作为资料", systemImage: "doc.on.clipboard") }
                    .disabled(cannotAdd)
            } footer: {
                if (project?.documents.count ?? 0) >= 50 {
                    Text("已达到 50 份资料上限，可以编辑已有资料或删除不再需要的资料。")
                } else if (project?.includedCharacters ?? 0) >= ChatProject.documentCharacterLimit {
                    Text("启用资料已达到 10 万字上限。导入新资料前，请先关闭部分资料的引用开关。")
                } else {
                    Text("支持 UTF-8 文字和 Markdown，每份最多 10 万字；导入文件需小于 1 MB。")
                }
            }
            }
        }
        .font(TypeScale.body)
        .tint(Ink.seal)
        .searchable(text: $search, prompt: "搜索资料名称或正文")
        .scrollContentBackground(.hidden)
        .background(AppBackground())
        .navigationTitle("项目资料")
        .navigationBarTitleDisplayMode(.inline)
        .sheet(item: $editingDocument) { document in
            ProjectDocumentEditor(projectID: projectID, document: document).environmentObject(store)
        }
        .fileImporter(isPresented: $importing, allowedContentTypes: [.plainText, .text, UTType(filenameExtension: "md") ?? .plainText],
                      allowsMultipleSelection: true) { result in
            do {
                var added: [ProjectDocument] = []
                for url in try result.get() {
                    let scoped = url.startAccessingSecurityScopedResource()
                    defer { if scoped { url.stopAccessingSecurityScopedResource() } }
                    let size = try url.resourceValues(forKeys: [.fileSizeKey]).fileSize ?? 0
                    guard size <= 1024 * 1024 else { throw ChatError.server("请选择小于 1 MB 的文字文件。") }
                    let text = try String(contentsOf: url, encoding: .utf8)
                    guard text.count <= ChatProject.documentCharacterLimit else { throw ChatError.server("这份资料超过 10 万字，请拆开再导入。") }
                    added.append(ProjectDocument(name: url.deletingPathExtension().lastPathComponent, text: text))
                }
                updateDocuments { $0.append(contentsOf: added) }
            } catch { store.errorMessage = error.localizedDescription }
        }
        .errorAlert(store)
    }

    private func updateDocuments(_ change: (inout [ProjectDocument]) -> Void) {
        guard !store.isLocked(projectID), store.canPersist, var latest = store.project(projectID) else {
            store.errorMessage = "项目暂时无法修改，请返回后重新打开。"
            return
        }
        change(&latest.documents)
        guard latest.documents.count <= 50 else {
            store.errorMessage = "每个项目最多保存 50 份资料，请减少本次导入数量或先删除部分资料。"
            return
        }
        _ = store.updateProject(latest)
    }

    private func removeDocuments(_ offsets: IndexSet) {
        let shown = visibleDocuments
        let ids = Set(offsets.compactMap { shown.indices.contains($0) ? shown[$0].id : nil })
        updateDocuments { $0.removeAll { ids.contains($0.id) } }
    }

    private func pasteDocument() {
        guard let text = UIPasteboard.general.string, !text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            store.errorMessage = "剪贴板里没有可导入的文字。"
            return
        }
        guard text.count <= ChatProject.documentCharacterLimit else {
            store.errorMessage = "这份资料超过 10 万字，请拆开再粘贴；内容没有被截断。"
            return
        }
        updateDocuments { documents in
            documents.append(ProjectDocument(name: "粘贴的资料 \(documents.count + 1)", text: text))
        }
    }
}

@MainActor
private struct ProjectDocumentEditor: View {
    @EnvironmentObject private var store: AppStore
    @Environment(\.dismiss) private var dismiss
    let projectID: UUID
    let document: ProjectDocument
    @State private var name: String
    @State private var text: String
    @State private var isIncluded: Bool
    @State private var saveError: String?
    @State private var shareURL: URL?

    init(projectID: UUID, document: ProjectDocument) {
        self.projectID = projectID; self.document = document
        _name = State(initialValue: document.name)
        _text = State(initialValue: document.text)
        _isIncluded = State(initialValue: document.isIncluded)
    }

    private var project: ChatProject? { store.isLocked(projectID) ? nil : store.project(projectID) }
    private var changed: Bool { name != document.name || text != document.text || isIncluded != document.isIncluded }
    private var cleanName: String { name.trimmingCharacters(in: .whitespacesAndNewlines) }
    private var includedCharacters: Int {
        let other = (project?.documents ?? []).filter { $0.id != document.id && $0.isIncluded }.reduce(0) { $0 + $1.text.count }
        return other + (isIncluded ? text.count : 0)
    }
    private var validationMessage: String? {
        guard let project, project.documents.contains(where: { $0.id == document.id }) else { return "资料已不存在或项目已上锁，请返回后重新打开。" }
        guard store.canPersist else { return "当前暂时不能保存，请稍后重试。" }
        guard !cleanName.isEmpty else { return "请填写资料名称。" }
        guard cleanName.count <= 200 else { return "资料名称最多 200 字。" }
        guard text.count <= ChatProject.documentCharacterLimit else { return "正文最多 10 万字，请删减或拆成多份资料；保存不会截断内容。" }
        guard includedCharacters <= ChatProject.documentCharacterLimit else { return "启用的资料合计超过 10 万字，请关闭这份资料的引用开关或缩短正文后保存。" }
        return nil
    }

    var body: some View {
        NavigationStack {
            Form {
                if project == nil {
                    Text("项目已上锁或不存在，请返回后重新打开。").foregroundStyle(Ink.ink3)
                } else {
                    Section("资料名称") {
                        TextField("名称", text: $name).accessibilityIdentifier("project-document-name")
                    }
                    Section {
                        TextEditor(text: $text).frame(minHeight: 300).font(TypeScale.serif(15)).scrollContentBackground(.hidden)
                            .accessibilityIdentifier("project-document-text")
                    } header: { Text("正文 · \(text.count.formatted()) / \(ChatProject.documentCharacterLimit.formatted()) 字") }
                    Section {
                        Toggle("提问时引用这份资料", isOn: $isIncluded)
                    } footer: {
                        Text("保存后启用资料合计：\(includedCharacters.formatted()) / \(ChatProject.documentCharacterLimit.formatted()) 字。关闭引用仍会保留资料。")
                    }
                    if let validationMessage {
                        Text(validationMessage).font(TypeScale.label).foregroundStyle(.red)
                    }
                    if let saveError {
                        Text(saveError).font(TypeScale.label).foregroundStyle(.red)
                    }
                }
            }
            .font(TypeScale.body).scrollContentBackground(.hidden).background(AppBackground())
            .navigationTitle("查看与编辑资料").navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("取消") { dismiss() } }
                ToolbarItemGroup(placement: .topBarTrailing) {
                    Menu {
                        Button("复制正文", systemImage: "doc.on.doc") { UIPasteboard.general.string = text }
                        Button("分享文字文件", systemImage: "square.and.arrow.up") { shareDocument() }
                    } label: { Image(systemName: "ellipsis") }
                        .accessibilityLabel("资料操作").disabled(project == nil)
                    Button("保存") { save() }.disabled(!changed || validationMessage != nil)
                }
            }
        }
        .tint(Ink.seal)
        .interactiveDismissDisabled(changed)
        .sheet(isPresented: Binding(get: { shareURL != nil }, set: { if !$0 { shareURL = nil } })) {
            if let url = shareURL { ShareSheet(items: [url]) }
        }
    }

    private func save() {
        guard validationMessage == nil, !store.isLocked(projectID), var latest = store.project(projectID),
              let index = latest.documents.firstIndex(where: { $0.id == document.id }) else {
            saveError = validationMessage ?? "资料暂时无法保存，请重新打开后再试。"
            return
        }
        // Merge only this document into the latest project, preserving newer memory and other files.
        latest.documents[index].name = cleanName
        latest.documents[index].text = text
        latest.documents[index].isIncluded = isIncluded
        if store.updateProject(latest) { dismiss() }
        else { saveError = store.errorMessage ?? "资料未能保存，请稍后再试。" }
    }

    private func shareDocument() {
        guard project != nil else { return }
        do {
            let directory = FileManager.default.temporaryDirectory.appendingPathComponent("Sermo-Document-\(UUID().uuidString)", isDirectory: true)
            try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
            let banned = CharacterSet(charactersIn: "/\\:*?\"<>|\n\r")
            let base = cleanName.components(separatedBy: banned).joined()
            let fileName = String((base.isEmpty ? "项目资料" : base).prefix(80)) + ".md"
            let url = directory.appendingPathComponent(fileName)
            try Data(text.utf8).write(to: url, options: [.atomic, .completeFileProtection])
            shareURL = url
        } catch {
            saveError = "文字文件没能导出：\(error.localizedDescription)"
        }
    }
}

@MainActor
struct ProjectInstructionsView: View {
    @EnvironmentObject private var store: AppStore
    @Environment(\.dismiss) private var dismiss
    let projectID: UUID
    @State private var text = ""

    var body: some View {
        NavigationStack {
            VStack(alignment: .leading, spacing: 12) {
                Text("这个项目里的对话只用这段指令，不叠加设置里的系统提示词。可以写身份、语气和规矩，比如「你是一位研究明史的老教授……」。")
                    .font(TypeScale.caption).foregroundStyle(Ink.ink3)
                TextEditor(text: $text).font(TypeScale.serif(16)).scrollContentBackground(.hidden)
                    .padding(12).background(Ink.raised, in: InkRounded(radius: 20))
                    .accessibilityIdentifier("project-instructions")
            }
            .padding(20).background(Ink.paper)
            .navigationTitle("指令").navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) { Button("取消") { dismiss() } }
                ToolbarItem(placement: .topBarTrailing) {
                    Button("保存") {
                        guard var project = store.project(projectID) else { dismiss(); return }
                        project.instructions = text
                        if store.updateProject(project) { dismiss() }
                    }.fontWeight(.semibold)
                }
            }
            .errorAlert(store)
        }
        .tint(Ink.ink)
        .onAppear { text = store.project(projectID)?.instructions ?? "" }
    }
}
// "查看全部": every conversation that may be shown, with multi-select to move or delete in bulk.
@MainActor
struct AllChatsView: View {
    @EnvironmentObject private var store: AppStore
    @Environment(\.dismiss) private var dismiss
    let opened: () -> Void
    @State private var search = ""
    @State private var editMode: EditMode = .inactive
    @State private var selection = Set<UUID>()
    @State private var naming = false
    @State private var newName = ""
    @State private var confirmDelete = false
    private var editing: Bool { editMode.isEditing }
    private var shown: [ChatThread] {
        store.browsableThreads.filter { thread in
            search.isEmpty || thread.title.localizedCaseInsensitiveContains(search) ||
                thread.messages.contains(where: { $0.content.localizedCaseInsensitiveContains(search) })
        }
    }

    var body: some View {
        NavigationStack {
            List(selection: $selection) {
                ForEach(shown) { thread in
                    if editing { rowLabel(thread).tag(thread.id) }
                    else {
                        Button { store.select(thread.id); opened() } label: { rowLabel(thread) }
                            .buttonStyle(.plain).tag(thread.id)
                    }
                }
                .listRowBackground(Color.clear)
            }
            .listStyle(.plain)
            .scrollContentBackground(.hidden)
            .background(AppBackground())
            .environment(\.editMode, $editMode)
            .searchable(text: $search, prompt: "搜索对话")
            .navigationTitle("全部对话")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) { Button("完成") { dismiss() } }
                ToolbarItem(placement: .topBarTrailing) {
                    Button(editing ? "取消" : "选择") {
                        withAnimation { editMode = editing ? .inactive : .active }
                        selection = []
                    }.accessibilityIdentifier("all-chats-select")
                }
                if editing {
                    ToolbarItemGroup(placement: .bottomBar) {
                        Button(selection.count == shown.count && !shown.isEmpty ? "全不选" : "全选") {
                            selection = selection.count == shown.count ? [] : Set(shown.map(\.id))
                        }.accessibilityIdentifier("all-chats-select-all")
                        Spacer()
                        Menu("移到项目") {
                            ForEach(store.projects.filter { !store.isLocked($0.id) }) { project in
                                Button(project.name) { move(to: project.id) }
                            }
                            Button("新建项目…", systemImage: "folder.badge.plus") { newName = ""; naming = true }
                            Button("移出项目", systemImage: "tray.and.arrow.up") { move(to: nil) }
                        }
                        .disabled(selection.isEmpty)
                        .accessibilityIdentifier("all-chats-move")
                        Spacer()
                        Button("删除", role: .destructive) { confirmDelete = true }.disabled(selection.isEmpty)
                    }
                }
            }
            .alert("新建项目", isPresented: $naming) {
                TextField("项目名称", text: $newName)
                Button("取消", role: .cancel) { }
                Button("创建并移入") { if let id = store.createProject(name: newName) { move(to: id) } }
            }
            .confirmationDialog("删除选中的 \(selection.count) 个对话？", isPresented: $confirmDelete, titleVisibility: .visible) {
                Button("删除", role: .destructive) {
                    for id in selection where id != store.generatingThreadID { store.deleteThread(id) }
                    selection = []; editMode = .inactive
                }
            } message: { Text("附带的图片会一起删除，用量记录不受影响。") }
            .errorAlert(store)
        }
        .tint(Ink.ink)
    }

    private func rowLabel(_ thread: ChatThread) -> some View {
        VStack(alignment: .leading, spacing: 3) {
            Text(thread.title).font(TypeScale.serif(16)).foregroundStyle(Ink.ink).lineLimit(1)
            HStack(spacing: 6) {
                if let project = store.project(thread.projectID) { Text(project.name) }
                Text(thread.updatedAt.formatted(date: .abbreviated, time: .omitted))
            }.font(TypeScale.tiny).foregroundStyle(Ink.ink3)
        }
        .padding(.vertical, 4)
        .frame(maxWidth: .infinity, alignment: .leading).contentShape(Rectangle())
        .accessibilityIdentifier("all-chats-row")
    }

    private func move(to projectID: UUID?) {
        store.moveThreads(selection, to: projectID)
        selection = []
        withAnimation { editMode = .inactive }
    }
}
