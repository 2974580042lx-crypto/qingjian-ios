import SwiftUI
import UniformTypeIdentifiers

@MainActor
struct NovelLibraryView: View {
    @EnvironmentObject private var app: AppStore
    @EnvironmentObject private var novels: NovelStore
    @Environment(\.dismiss) private var dismiss
    @State private var path: [UUID] = []
    @State private var edit: NovelEditRequest?
    @State private var deleteTarget: NovelProject?
    @State private var search = ""

    private var visible: [NovelProject] {
        novels.projects.filter { search.isEmpty || $0.title.localizedCaseInsensitiveContains(search) }
            .sorted { $0.updatedAt > $1.updatedAt }
    }

    var body: some View {
        NavigationStack(path: $path) {
            List {
                Section {
                    VStack(alignment: .leading, spacing: 10) {
                        Text("让故事记得已经发生的事。")
                            .font(TypeScale.subject).foregroundStyle(Ink.ink)
                        Text("人物状态、谁知道什么、时间线与伏笔，随已确认的章节积累。逐章创作，也可以连续起草后再审阅。")
                            .font(TypeScale.body).foregroundStyle(Ink.ink2).lineSpacing(5)
                        Button("开始一本新书", systemImage: "plus") { newProject() }
                            .font(TypeScale.body).tint(Ink.seal)
                    }.padding(.vertical, 10)
                }.listRowBackground(Color.clear)
                if let run = novels.running {
                    Section {
                        Button { path.append(run.projectID) } label: {
                            HStack {
                                ProgressView()
                                VStack(alignment: .leading, spacing: 4) {
                                    Text(run.title).font(TypeScale.body)
                                    Text(run.detail).font(TypeScale.caption).foregroundStyle(Ink.ink2)
                                }
                            }
                        }
                    }.listRowBackground(Ink.raised)
                }
                Section("我的作品") {
                    if visible.isEmpty {
                        Text(search.isEmpty ? "从一句创意开始，人物、设定和章节都会留在这里。" : "没有找到这部作品")
                            .font(TypeScale.body).foregroundStyle(Ink.ink3).padding(.vertical, 12)
                            .listRowBackground(Color.clear)
                    }
                    ForEach(visible) { project in
                        NavigationLink(value: project.id) {
                            VStack(alignment: .leading, spacing: 8) {
                                Text(project.title).font(TypeScale.subject).foregroundStyle(Ink.ink)
                                if !project.brief.isEmpty {
                                    Text(project.brief).font(TypeScale.label).foregroundStyle(Ink.ink2).lineLimit(2)
                                }
                                Text("\(project.chapters.count) 章 · \(project.confirmedCount) 章定稿 · \(project.wordCount) 字")
                                    .font(TypeScale.caption).foregroundStyle(Ink.ink3)
                            }.padding(.vertical, 8)
                        }
                        .listRowBackground(Color.clear)
                        .swipeActions {
                            Button("删除", role: .destructive) { deleteTarget = project }
                        }
                    }
                }
            }
            .listStyle(.plain).scrollContentBackground(.hidden).background(AppBackground())
            .searchable(text: $search, prompt: "搜索作品")
            .navigationTitle("小说创作")
            .toolbar {
                ToolbarItem(placement: .topBarLeading) { Button("完成") { dismiss() } }
                ToolbarItem(placement: .topBarTrailing) {
                    Menu {
                        Button("新建小说", systemImage: "plus") { newProject() }
                        Button("导入小说备份", systemImage: "square.and.arrow.down") {
                            DocumentPicker.present([.json], asCopy: false) { url in
                                if let id = novels.importBackup(url) { path.append(id) }
                            }
                        }.disabled(novels.isGenerating)
                    } label: { Image(systemName: "plus") }
                    .accessibilityLabel("新建或导入小说")
                }
            }
            .navigationDestination(for: UUID.self) { id in NovelWorkspaceView(projectID: id) }
            .sheet(item: $edit) { NovelEditorSheet(request: $0).environmentObject(novels) }
            .alert("删除这部作品？", isPresented: Binding(get: { deleteTarget != nil }, set: { if !$0 { deleteTarget = nil } })) {
                Button("取消", role: .cancel) { deleteTarget = nil }
                Button("删除", role: .destructive) {
                    if let project = deleteTarget { novels.deleteProject(project.id) }
                    deleteTarget = nil
                }
            } message: { Text("将移除本机的章节、候选稿和版本记录。已导出的备份与书架副本会保留。") }
            .novelErrorAlert(novels, enabled: path.isEmpty && edit == nil)
        }.tint(Ink.ink)
    }

    private func newProject() {
        edit = NovelEditRequest(title: "新建小说", fields: [
            NovelEditField(title: "书名", text: "", multiline: false),
            NovelEditField(title: "创作简报", text: "")
        ], note: "写下题材、主角、核心冲突和你想要的篇幅。还没想好的地方可以留白。") { values in
            guard let id = novels.create(title: values[0], brief: values[1]) else { return false }
            path.append(id); return true
        }
    }
}

extension View {
    @MainActor func novelErrorAlert(_ novels: NovelStore, enabled: Bool = true) -> some View {
        alert("暂时没有完成", isPresented: Binding(get: { enabled && novels.errorMessage != nil }, set: { if !$0 && enabled { novels.errorMessage = nil } })) {
            if novels.saveRecoveryAvailable { Button("重试保存") { _ = novels.retrySave() } }
            Button("知道了", role: .cancel) { novels.errorMessage = nil }
        } message: { Text(novels.errorMessage ?? "") }
    }
}
