import SwiftUI
import UIKit

@MainActor
struct NovelWorkspaceView: View {
    let projectID: UUID
    @EnvironmentObject private var app: AppStore
    @EnvironmentObject private var novels: NovelStore
    @State private var edit: NovelEditRequest?
    @State private var candidate: NovelCandidate?
    @State private var shareURL: URL?
    @State private var batchCount = 2
    @State private var showBatch = false
    @State private var published = false
    @State private var publishing = false
    @State private var visible = false

    private var generator: NovelTextGenerator {
        { system, prompt, onText in try await app.generateNovelText(system: system, prompt: prompt, onText: onText) }
    }

    var body: some View {
        Group {
            if let project = novels.project(projectID) { workspace(project) }
            else { ContentUnavailableView("作品已移除", systemImage: "doc") }
        }
        .sheet(item: $edit) { NovelEditorSheet(request: $0).environmentObject(novels) }
        .sheet(item: $candidate) { NovelCandidateSheet(projectID: projectID, candidateID: $0.id).environmentObject(novels) }
        .sheet(isPresented: Binding(get: { shareURL != nil }, set: { if !$0 { shareURL = nil } })) {
            if let shareURL { ShareSheet(items: [shareURL]) }
        }
        .sheet(isPresented: $showBatch) { batchSheet }
        .alert("已放到书架", isPresented: $published) {
            Button("好", role: .cancel) { }
        } message: { Text("已将可用定稿另存为一本书。回到侧栏的书架即可阅读。") }
        .onAppear { visible = true }.onDisappear { visible = false }
        .novelErrorAlert(novels, enabled: visible && edit == nil && candidate == nil && shareURL == nil && !showBatch)
    }

    private func workspace(_ project: NovelProject) -> some View {
        List {
            Section {
                Text("每章按需读取人物状态、知情边界、时间线与伏笔。正文确认后，先检查提取的记忆，再定稿写入账本。")
                    .font(TypeScale.body).foregroundStyle(Ink.ink2).lineSpacing(5)
                Text("默认逐章确认。模型仍可能记错，记忆可以随时查看和纠正。")
                    .font(TypeScale.caption).foregroundStyle(Ink.ink3)
            }.listRowBackground(Color.clear)
            Section {
                NavigationLink {
                    NovelLedgerView(projectID: projectID)
                } label: {
                    Label("小说记忆账本", systemImage: "list.bullet.rectangle.portrait")
                        .font(TypeScale.subject)
                }
                Text("查看每条事实的来源章节，纠正误记，也能固定你确认的重要设定。")
                    .font(TypeScale.caption).foregroundStyle(Ink.ink2)
            }.listRowBackground(Color.clear)
            if let run = novels.running?.projectID == projectID ? novels.running : project.lastRun {
                Section {
                    VStack(alignment: .leading, spacing: 10) {
                        HStack {
                            if run.status == .running { ProgressView() }
                            Text(run.title).font(TypeScale.body)
                            Spacer()
                            if run.status == .running {
                                Button("暂停") { novels.stop() }
                            } else if run.status == .paused || run.status == .failed {
                                Button("继续") { novels.resume(projectID: projectID, generator: generator) }
                                    .disabled(novels.isGenerating)
                            }
                        }
                        Text(run.detail).font(TypeScale.caption).foregroundStyle(Ink.ink2)
                        if run.status == .running {
                            Text("请保持应用在前台，退到后台会暂停并保留进度。")
                                .font(TypeScale.caption).foregroundStyle(Ink.ink3)
                        }
                    }.padding(.vertical, 4)
                }.listRowBackground(Ink.raised)
            }
            if novels.saveRecoveryAvailable {
                Section {
                    Button("重试保存进度", systemImage: "arrow.clockwise") { _ = novels.retrySave() }
                    Text("也可以先从右上角导出备份，保留当前内容。")
                        .font(TypeScale.caption).foregroundStyle(Ink.ink2)
                }
            }
            Section("全书依据") {
                referenceRow("创作简报", text: project.brief) { editProject(project, field: "brief") }
                referenceRow("世界设定", text: project.world, action: .world) { editProject(project, field: "world") }
                referenceRow("人物档案", text: project.characters, action: .characters) { editProject(project, field: "characters") }
                referenceRow("全书大纲", text: project.outline, action: .outline) { editProject(project, field: "outline") }
            }.listRowBackground(Color.clear)
            let setupCandidates = project.candidates.filter { $0.chapterID == nil }
            if !setupCandidates.isEmpty {
                Section("资料候选") {
                    ForEach(setupCandidates) { candidateRow($0) }
                }.listRowBackground(Color.clear)
            }
            Section {
                ForEach(project.chapters) { chapter in
                    NavigationLink {
                        NovelChapterView(projectID: projectID, chapterID: chapter.id)
                    } label: {
                        VStack(alignment: .leading, spacing: 7) {
                            Text(chapter.title).font(TypeScale.subject).foregroundStyle(Ink.ink)
                            HStack(spacing: 10) {
                                Text(chapter.needsReview ? "待复核" : chapter.status.title)
                                Text("\(chapter.wordCount) 字")
                                let count = project.candidates.filter { $0.chapterID == chapter.id }.count
                                if count > 0 { Text("\(count) 份候选") }
                            }.font(TypeScale.caption).foregroundStyle(Ink.ink3)
                        }.padding(.vertical, 5)
                    }
                }
                Button("添加一章", systemImage: "plus") { _ = novels.addChapter(projectID: projectID) }
                    .disabled(novels.isGenerating)
                Button("连续起草…", systemImage: "text.badge.plus") { showBatch = true }
                    .disabled(novels.isGenerating)
            } header: {
                Text("章节 · \(project.confirmedCount)/\(project.chapters.count) 章定稿")
            } footer: {
                Text("修改前文或设定后，受影响章节会标为待复核，重新确认后再作为后文记忆。")
            }.listRowBackground(Color.clear)
        }
        .listStyle(.insetGrouped).scrollContentBackground(.hidden).background(AppBackground())
        .navigationTitle(project.title).navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Menu {
                    Button("修改书名", systemImage: "pencil") { editProject(project, field: "title") }
                    Button("正文与候选 · TXT", systemImage: "doc.text") { shareURL = novels.exportText(projectID: projectID, markdown: false) }
                    Button("正文与候选 · Markdown", systemImage: "doc.richtext") { shareURL = novels.exportText(projectID: projectID, markdown: true) }
                    Button("完整备份 · JSON", systemImage: "externaldrive") { shareURL = novels.exportBackup(projectID: projectID) }
                    Button("把定稿放到书架", systemImage: "books.vertical") { publish(project) }
                        .disabled(project.confirmedCount == 0 || publishing)
                } label: { Image(systemName: "ellipsis.circle") }.accessibilityLabel("作品操作与导出")
            }
        }
    }

    private func referenceRow(_ title: String, text: String, action: NovelAction? = nil, edit: @escaping () -> Void) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text(title).font(TypeScale.subject)
                Spacer()
                Button("编辑", action: edit).font(TypeScale.label)
            }
            Text(text.isEmpty ? "尚未填写" : text).font(TypeScale.body).foregroundStyle(text.isEmpty ? Ink.ink3 : Ink.ink2)
                .lineLimit(3).lineSpacing(4)
            if let action {
                Button(action.title, systemImage: "sparkles") {
                    novels.generate(projectID: projectID, action: action, generator: generator)
                }.font(TypeScale.label).tint(Ink.seal).disabled(novels.isGenerating)
            }
        }.padding(.vertical, 5)
    }

    private func candidateRow(_ value: NovelCandidate) -> some View {
        Button { candidate = value } label: {
            VStack(alignment: .leading, spacing: 5) {
                Text(value.action.title + (value.isComplete ? " · 待采纳" : " · 未完成"))
                    .font(TypeScale.body).foregroundStyle(Ink.seal)
                Text(value.text.isEmpty ? "等待模型返回…" : value.text)
                    .font(TypeScale.caption).foregroundStyle(Ink.ink2).lineLimit(2)
            }
        }
    }

    private func editProject(_ project: NovelProject, field: String) {
        let titles = ["title": "书名", "brief": "创作简报", "world": "世界设定", "characters": "人物档案", "outline": "全书大纲"]
        let values = ["title": project.title, "brief": project.brief, "world": project.world, "characters": project.characters, "outline": project.outline]
        let label = titles[field] ?? "资料"
        edit = NovelEditRequest(title: label, fields: [NovelEditField(title: label, text: values[field] ?? "", multiline: field != "title")],
            note: project.chapters.isEmpty ? "" : "保存修改后，已有定稿会标为待复核。") { values in
            var copy = project
            switch field {
            case "title": copy.title = values[0]
            case "brief": copy.brief = values[0]
            case "world": copy.world = values[0]
            case "characters": copy.characters = values[0]
            default: copy.outline = values[0]
            }
            return novels.update(copy)
        }
    }

    private var batchSheet: some View {
        NavigationStack {
            Form {
                Section {
                    Stepper("新增 \(batchCount) 章", value: $batchCount, in: 1...5)
                    Text("从现有章节末尾新增并连续起草。所有结果先存为候选，需要你逐章采纳、审阅和定稿；不会填入已有的空章。")
                        .font(TypeScale.body).foregroundStyle(Ink.ink2).lineSpacing(5)
                    Text("每章会调用模型，费用沿用当前模型的计费。请保持应用在前台，可随时暂停。")
                        .font(TypeScale.caption).foregroundStyle(Ink.ink3)
                }
                Button("开始连续起草") {
                    showBatch = false
                    novels.draftBatch(projectID: projectID, count: batchCount, generator: generator)
                }.disabled(novels.isGenerating)
            }
            .scrollContentBackground(.hidden).background(AppBackground())
            .navigationTitle("连续起草").navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .cancellationAction) { Button("取消") { showBatch = false } } }
        }.presentationDetents([.medium, .large])
    }

    private func publish(_ project: NovelProject) {
        let chapters = project.chapters.filter { $0.status == .confirmed && !$0.needsReview }
        let text = chapters.map { $0.title + "\n\n" + $0.body }.joined(separator: "\n\n")
        publishing = true
        Task {
            let id = await app.books.publishNovel(title: project.title, text: text)
            publishing = false
            if id != nil { published = true }
            else { novels.errorMessage = app.books.errorMessage ?? "未能保存到书架，请稍后重试。" }
        }
    }
}

@MainActor
private struct NovelChapterView: View {
    let projectID: UUID
    let chapterID: UUID
    @EnvironmentObject private var app: AppStore
    @EnvironmentObject private var novels: NovelStore
    @State private var edit: NovelEditRequest?
    @State private var candidate: NovelCandidate?
    @State private var version: NovelRevision?
    @State private var showConfirm = false
    @State private var visible = false

    private var generator: NovelTextGenerator {
        { system, prompt, onText in try await app.generateNovelText(system: system, prompt: prompt, onText: onText) }
    }

    var body: some View {
        Group {
            if let project = novels.project(projectID), let chapter = project.chapters.first(where: { $0.id == chapterID }) {
                chapterPage(project, chapter)
            } else { ContentUnavailableView("章节已移除", systemImage: "doc") }
        }
        .sheet(item: $edit) { NovelEditorSheet(request: $0).environmentObject(novels) }
        .sheet(item: $candidate) { NovelCandidateSheet(projectID: projectID, candidateID: $0.id).environmentObject(novels) }
        .sheet(item: $version) { value in
            NovelVersionSheet(projectID: projectID, chapterID: chapterID, version: value).environmentObject(novels)
        }
        .confirmationDialog("从当前正文提取记忆？", isPresented: $showConfirm, titleVisibility: .visible) {
            Button("提取本章记忆") {
                novels.confirmChapter(projectID: projectID, chapterID: chapterID, generator: generator)
            }
        } message: { Text("将提取人物状态、知情边界、时间线和伏笔。下一步会先展示结果，确认后才定稿并更新账本。") }
        .onAppear { visible = true }.onDisappear { visible = false }
        .novelErrorAlert(novels, enabled: visible && edit == nil && candidate == nil && version == nil)
    }

    private func chapterPage(_ project: NovelProject, _ chapter: NovelChapter) -> some View {
        List {
            Section {
                HStack {
                    Text(chapter.needsReview ? "待复核" : chapter.status.title).foregroundStyle(Ink.seal)
                    Spacer()
                    Text("\(chapter.wordCount) 字").foregroundStyle(Ink.ink3)
                }.font(TypeScale.label)
                if chapter.needsReview {
                    Text("正文、设定或前文已有变化，请核对后重新定稿。")
                        .font(TypeScale.caption).foregroundStyle(Ink.ink2)
                }
                Button("编辑章名、提纲与正文", systemImage: "pencil") { editChapter(chapter) }
            }.listRowBackground(Color.clear)
            Section("本章提纲") { readable(chapter.plan, empty: "先确定本章要发生什么。") }.listRowBackground(Color.clear)
            Section("正文") { readable(chapter.body, empty: "还没有正文，可以自己写，也可以先生成候选稿。") }.listRowBackground(Color.clear)
            Section("创作与审阅") {
                actionButton(.plan, chapter: chapter)
                actionButton(.draft, chapter: chapter)
                actionButton(.review, chapter: chapter)
                actionButton(.polish, chapter: chapter)
                Button("提取本章记忆，准备定稿", systemImage: "checkmark.seal") { showConfirm = true }
                    .disabled(novels.isGenerating || chapter.body.isEmpty || (chapter.status == .confirmed && !chapter.needsReview))
            }.listRowBackground(Color.clear)
            if chapter.memoryCandidate != nil {
                Section {
                    NavigationLink {
                        NovelMemoryCandidateView(projectID: projectID, chapterID: chapterID)
                    } label: {
                        VStack(alignment: .leading, spacing: 7) {
                            Label("审阅记忆并确认定稿", systemImage: "checkmark.seal")
                                .font(TypeScale.subject).foregroundStyle(Ink.seal)
                            Text("先核对提取出的事实、人物知情和伏笔变化。")
                                .font(TypeScale.caption).foregroundStyle(Ink.ink2)
                        }
                    }
                }.listRowBackground(Ink.raised)
            }
            if novels.running?.projectID == projectID {
                Section {
                    HStack {
                        ProgressView()
                        Text(novels.running?.title ?? "正在生成").font(TypeScale.body)
                        Spacer()
                        Button("暂停") { novels.stop() }
                    }
                }.listRowBackground(Ink.raised)
            } else if let run = project.lastRun, run.chapterID == chapterID, run.status == .paused || run.status == .failed {
                Section {
                    Text(run.detail).font(TypeScale.caption).foregroundStyle(Ink.ink2)
                    Button("继续上次任务") { novels.resume(projectID: projectID, generator: generator) }.disabled(novels.isGenerating)
                }.listRowBackground(Color.clear)
            }
            let candidates = project.candidates.filter { $0.chapterID == chapterID }
            if !candidates.isEmpty {
                Section("候选与半稿") {
                    ForEach(candidates) { value in
                        Button { candidate = value } label: {
                            VStack(alignment: .leading, spacing: 6) {
                                Text(value.action.title + (value.isComplete ? " · 查看并采纳" : " · 未完成"))
                                    .font(TypeScale.body).foregroundStyle(Ink.seal)
                                Text(value.text.isEmpty ? "等待模型返回…" : value.text)
                                    .font(TypeScale.caption).foregroundStyle(Ink.ink2).lineLimit(3)
                            }
                        }
                    }
                }.listRowBackground(Color.clear)
            }
            if !chapter.review.isEmpty {
                Section("审阅意见") { readable(chapter.review) }.listRowBackground(Color.clear)
            }
            Section {
                if chapter.summary.isEmpty {
                    Text("定稿后，这里会留下后续写作使用的记忆。")
                        .font(TypeScale.body).foregroundStyle(Ink.ink3)
                } else {
                    memoryBlock("前情摘要", text: chapter.summary)
                    memoryBlock("人物状态与已知信息", text: chapter.characterState)
                    memoryBlock("伏笔与未决问题", text: chapter.foreshadowing)
                    if chapter.status == .confirmed {
                        Button("编辑本章摘要", systemImage: "pencil") { editMemory(chapter) }.disabled(novels.isGenerating)
                    }
                }
                NavigationLink("查看与纠正事实账本") { NovelLedgerView(projectID: projectID) }
            } header: { Text("定稿摘要") }
              footer: { Text("摘要便于回看。人物、知情边界和伏笔等正式事实请在记忆账本中纠正。") }
              .listRowBackground(Color.clear)
            if !chapter.versions.isEmpty {
                Section("保留的旧稿") {
                    ForEach(chapter.versions.reversed()) { value in
                        Button { version = value } label: {
                            VStack(alignment: .leading, spacing: 5) {
                                Text(value.label).font(TypeScale.body)
                                Text(value.createdAt, style: .date).font(TypeScale.caption).foregroundStyle(Ink.ink3)
                            }
                        }
                    }
                }.listRowBackground(Color.clear)
            }
        }
        .listStyle(.insetGrouped).scrollContentBackground(.hidden).background(AppBackground())
        .navigationTitle(chapter.title).navigationBarTitleDisplayMode(.inline)
    }

    private func readable(_ text: String, empty: String = "尚无内容") -> some View {
        Text(text.isEmpty ? empty : text).font(TypeScale.answer).foregroundStyle(text.isEmpty ? Ink.ink3 : Ink.ink)
            .lineSpacing(7).textSelection(.enabled).padding(.vertical, 5)
    }

    private func memoryBlock(_ title: String, text: String) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(title).font(TypeScale.label).foregroundStyle(Ink.seal)
            readable(text, empty: "无")
        }
    }

    private func actionButton(_ action: NovelAction, chapter: NovelChapter) -> some View {
        Button(action.title, systemImage: action == .review ? "checkmark.bubble" : "sparkles") {
            novels.generate(projectID: projectID, chapterID: chapterID, action: action, generator: generator)
        }
        .disabled(novels.isGenerating || ((action == .review || action == .polish) && chapter.body.isEmpty))
    }

    private func editChapter(_ chapter: NovelChapter) {
        edit = NovelEditRequest(title: "编辑章节", fields: [
            NovelEditField(title: "章名", text: chapter.title, multiline: false),
            NovelEditField(title: "本章提纲", text: chapter.plan),
            NovelEditField(title: "正文", text: chapter.body),
            NovelEditField(title: "审阅意见 / 改写要求", text: chapter.review)
        ], note: "手动保存后生效。正文改动前的版本会保留。") { values in
            var copy = chapter
            copy.title = values[0]; copy.plan = values[1]; copy.body = values[2]; copy.review = values[3]
            return novels.updateChapter(projectID: projectID, chapter: copy)
        }
    }

    private func editMemory(_ chapter: NovelChapter) {
        edit = NovelEditRequest(title: "编辑本章摘要", fields: [
            NovelEditField(title: "前情摘要", text: chapter.summary),
            NovelEditField(title: "人物状态与已知信息", text: chapter.characterState),
            NovelEditField(title: "伏笔与未决问题", text: chapter.foreshadowing)
        ], note: "摘要供回看和补充上下文，不会改写事实账本。正式事实纠错请使用‘查看与纠正事实账本’。") { values in
            novels.updateChapterMemory(projectID: projectID, chapterID: chapterID, summary: values[0],
                characterState: values[1], foreshadowing: values[2], expectedRevision: chapter.revision)
        }
    }
}

@MainActor
private struct NovelCandidateSheet: View {
    let projectID: UUID
    let candidateID: UUID
    @EnvironmentObject private var novels: NovelStore
    @Environment(\.dismiss) private var dismiss
    @State private var discard = false
    @State private var copied = false

    var body: some View {
        NavigationStack {
            if let project = novels.project(projectID), let value = project.candidates.first(where: { $0.id == candidateID }) {
                let stale = value.sourceRevision != project.revision || !NovelWorkflow.dependenciesMatch(value, project: project) ||
                    (value.chapterID != nil && value.chapterRevision != project.chapters.first(where: { $0.id == value.chapterID })?.revision)
                ScrollView {
                    VStack(alignment: .leading, spacing: 18) {
                        if value.action == .confirm {
                            Text("这是记忆提取的原始记录。提取成功后，回到章节审阅结构化记忆，再确认定稿。")
                                .font(TypeScale.label).foregroundStyle(Ink.ink2)
                        } else if !value.isComplete {
                            Text("这份内容尚未完整返回，已收到的文字会保留。")
                                .font(TypeScale.label).foregroundStyle(Ink.ink2)
                        } else if stale {
                            Text("生成后，依据或正文已有变化。这份候选已过期，可复制所需内容，核对后手动合入。")
                                .font(TypeScale.label).foregroundStyle(Ink.seal)
                        } else {
                            Text("采纳后才会写入当前资料或手稿；正文仍需另行确认定稿。")
                                .font(TypeScale.label).foregroundStyle(Ink.ink2)
                        }
                        Text(value.text.isEmpty ? "等待模型返回…" : value.text)
                            .font(TypeScale.answer).foregroundStyle(Ink.ink).lineSpacing(7).textSelection(.enabled)
                        if let memory = value.memoryDescription, !memory.isEmpty {
                            DisclosureGroup("本次使用的记忆") {
                                Text(memory).font(TypeScale.label).foregroundStyle(Ink.ink2)
                                    .lineSpacing(4).textSelection(.enabled).padding(.top, 8)
                            }.font(TypeScale.body)
                        }
                    }.frame(maxWidth: .infinity, alignment: .leading).padding(22)
                }.background(AppBackground())
                .navigationTitle(value.action.title).navigationBarTitleDisplayMode(.inline)
                .toolbar {
                    ToolbarItem(placement: .cancellationAction) { Button("关闭") { dismiss() } }
                    ToolbarItem(placement: .confirmationAction) {
                        Button("采纳") {
                            if novels.acceptCandidate(projectID: projectID, candidateID: candidateID) { dismiss() }
                        }.disabled(!value.isComplete || stale || novels.isGenerating || value.action == .confirm)
                    }
                    ToolbarItemGroup(placement: .bottomBar) {
                        Button(copied ? "已复制" : "复制全文", systemImage: "doc.on.doc") {
                            UIPasteboard.general.string = value.text; copied = true
                        }
                        Spacer()
                        Button("移除候选", systemImage: "trash", role: .destructive) { discard = true }
                            .disabled(novels.running?.candidateID == candidateID)
                    }
                }
                .confirmationDialog("移除这份候选？", isPresented: $discard, titleVisibility: .visible) {
                    Button("移除", role: .destructive) {
                        if novels.discardCandidate(projectID: projectID, candidateID: candidateID) { dismiss() }
                    }
                }
            } else { ContentUnavailableView("候选已处理", systemImage: "checkmark") }
        }.tint(Ink.ink).novelErrorAlert(novels)
    }
}

@MainActor
private struct NovelVersionSheet: View {
    let projectID: UUID
    let chapterID: UUID
    let version: NovelRevision
    @EnvironmentObject private var novels: NovelStore
    @Environment(\.dismiss) private var dismiss
    @State private var restore = false

    var body: some View {
        NavigationStack {
            ScrollView {
                Text(version.body).font(TypeScale.answer).foregroundStyle(Ink.ink).lineSpacing(7)
                    .textSelection(.enabled).frame(maxWidth: .infinity, alignment: .leading).padding(22)
            }.background(AppBackground()).navigationTitle("历史正文").navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("关闭") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) { Button("恢复这版") { restore = true }.disabled(novels.isGenerating) }
            }
            .confirmationDialog("恢复这版正文？", isPresented: $restore, titleVisibility: .visible) {
                Button("恢复为草稿") {
                    if novels.restoreVersion(projectID: projectID, chapterID: chapterID, versionID: version.id) { dismiss() }
                }
            } message: { Text("当前正文会保留为旧稿。恢复后需要重新审阅和定稿。") }
            .novelErrorAlert(novels)
        }.tint(Ink.ink)
    }
}
