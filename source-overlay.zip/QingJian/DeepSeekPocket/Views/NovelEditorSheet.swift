import SwiftUI

struct NovelEditField: Identifiable {
    var id = UUID()
    var title: String
    var text: String
    var multiline = true
}

struct NovelEditRequest: Identifiable {
    var id = UUID()
    var title: String
    var fields: [NovelEditField]
    var note = ""
    var save: ([String]) -> Bool
}

@MainActor
struct NovelEditorSheet: View {
    let request: NovelEditRequest
    @EnvironmentObject private var novels: NovelStore
    @Environment(\.dismiss) private var dismiss
    @State private var fields: [NovelEditField]
    @State private var discard = false
    @State private var saveFailed = false

    init(request: NovelEditRequest) {
        self.request = request
        _fields = State(initialValue: request.fields)
    }

    private var changed: Bool { fields.map(\.text) != request.fields.map(\.text) }

    var body: some View {
        NavigationStack {
            Form {
                if !request.note.isEmpty {
                    Section {
                        Text(request.note).font(TypeScale.label).foregroundStyle(Ink.ink2).lineSpacing(4)
                    }.listRowBackground(Color.clear)
                }
                ForEach($fields) { $field in
                    Section(field.title) {
                        if field.multiline {
                            TextEditor(text: $field.text)
                                .font(TypeScale.answer).foregroundStyle(Ink.ink).lineSpacing(6)
                                .scrollContentBackground(.hidden).frame(minHeight: 200)
                        } else {
                            TextField(field.title, text: $field.text)
                                .font(TypeScale.subject).foregroundStyle(Ink.ink)
                        }
                    }.listRowBackground(Ink.raised)
                }
                if saveFailed {
                    Section {
                        Text(novels.errorMessage ?? "未能保存，请稍后重试。")
                            .font(TypeScale.label).foregroundStyle(Ink.seal)
                        Text("编辑中的文字仍在这里，可以复制保留。")
                            .font(TypeScale.caption).foregroundStyle(Ink.ink2)
                    }.listRowBackground(Color.clear)
                }
            }
            .scrollContentBackground(.hidden).background(AppBackground())
            .navigationTitle(request.title).navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("取消") { if changed { discard = true } else { dismiss() } }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("保存") {
                        if request.save(fields.map(\.text)) { dismiss() }
                        else { saveFailed = true }
                    }
                }
            }
            .confirmationDialog("放弃未保存的修改？", isPresented: $discard, titleVisibility: .visible) {
                Button("放弃修改", role: .destructive) { dismiss() }
                Button("继续编辑", role: .cancel) { }
            }
        }
        .tint(Ink.ink).interactiveDismissDisabled(changed)
    }
}
