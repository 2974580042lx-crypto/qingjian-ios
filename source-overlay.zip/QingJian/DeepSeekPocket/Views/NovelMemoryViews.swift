import SwiftUI

@MainActor
struct NovelLedgerView: View {
    let projectID: UUID
    @EnvironmentObject private var novels: NovelStore
    @State private var edit: NovelEditRequest?
    @State private var visible = false
    @State private var invalidating: NovelFact?

    var body: some View {
        Group {
            if let project = novels.project(projectID) {
                let result = Result { try NovelMemory.replay(project: project) }
                switch result {
                case .success(let canon):
                List {
                    Section {
                        Text("这些是已确认章节留下的事实。新章生成时按需取用，并保留来源；未来的大纲不会提前变成已经发生的事。")
                            .font(TypeScale.body).foregroundStyle(Ink.ink2).lineSpacing(5)
                        Text("记忆推进至第 \(canon.throughChapter) 章 · \(canon.activeFacts.count) 条有效记录 · \(canon.openHooks.count) 条未结伏笔")
                            .font(TypeScale.caption).foregroundStyle(Ink.ink3)
                        let staleCount = project.chapters.filter { canon.invalidatedChapterIDs.contains($0.id) && $0.memoryDelta != nil }.count
                        if staleCount > 0 {
                            Text("有 \(staleCount) 章记忆需要重新核对。先处理较早章节，再推进后文。")
                                .font(TypeScale.label).foregroundStyle(Ink.seal)
                        }
                    }.listRowBackground(Color.clear)
                    if canon.activeFacts.isEmpty {
                        Section {
                            Text("尚无确认的记忆。写好一章后，提取并审阅记忆，再确认定稿。")
                                .font(TypeScale.body).foregroundStyle(Ink.ink3)
                        }.listRowBackground(Color.clear)
                    }
                    Section("当前有效事实") {
                        ForEach(canon.activeFacts) { fact in
                            VStack(alignment: .leading, spacing: 12) {
                                NovelFactContent(fact: fact, project: project)
                                HStack {
                                    Button("纠正这条记录", systemImage: "pencil") { correct(fact) }
                                        .font(TypeScale.label).disabled(novels.isGenerating)
                                    if fact.locked {
                                        Spacer()
                                        Button("取消固定") {
                                            _ = novels.correctFact(projectID: projectID, factID: fact.id,
                                                value: fact.value, note: fact.correctionNote ?? "取消固定", locked: false)
                                        }.font(TypeScale.label).disabled(novels.isGenerating)
                                    }
                                }
                                Button("这条记忆不成立", role: .destructive) { invalidating = fact }
                                    .font(TypeScale.caption).disabled(novels.isGenerating)
                            }.padding(.vertical, 6)
                        }
                    }.listRowBackground(Color.clear)
                    let historical = canon.facts.filter { old in !canon.activeFacts.contains(where: { $0.id == old.id }) }
                    if !historical.isEmpty {
                        Section("已结束的状态与已处理伏笔") {
                            DisclosureGroup("展开 \(historical.count) 条历史记录") {
                                ForEach(historical) { fact in
                                    NovelFactContent(fact: fact, project: project).padding(.vertical, 8)
                                }
                            }.font(TypeScale.body)
                        }.listRowBackground(Color.clear)
                    }
                }
                .listStyle(.insetGrouped).scrollContentBackground(.hidden).background(AppBackground())
                case .failure(let error):
                    ContentUnavailableView("暂时无法读取记忆", systemImage: "doc.text.magnifyingglass",
                        description: Text(error.localizedDescription + "\n原文和已有记录仍然保留。"))
                }
            } else {
                ContentUnavailableView("作品已移除", systemImage: "doc")
            }
        }
        .navigationTitle("小说记忆账本").navigationBarTitleDisplayMode(.inline)
        .sheet(item: $edit) { NovelEditorSheet(request: $0).environmentObject(novels) }
        .onAppear { visible = true }.onDisappear { visible = false }
        .confirmationDialog("标记这条记忆不成立？", isPresented: Binding(get: { invalidating != nil }, set: { if !$0 { invalidating = nil } }), titleVisibility: .visible) {
            Button("作废这条记忆", role: .destructive) {
                if let fact = invalidating {
                    _ = novels.invalidateFact(projectID: projectID, factID: fact.id, note: "作者确认这条记忆不成立")
                }
                invalidating = nil
            }
        } message: { Text("记录和来源会保留在历史中，后续写作不再把它当作有效事实。相关章节会标为待复核。") }
        .novelErrorAlert(novels, enabled: visible && edit == nil)
    }

    private func correct(_ fact: NovelFact) {
        edit = NovelEditRequest(title: "纠正事实", fields: [
            NovelEditField(title: fact.subject + " · " + fact.predicate, text: fact.value),
            NovelEditField(title: "纠正说明", text: fact.correctionNote ?? "")
        ], note: "原文出处会保留，修改标记为你的校正并固定。模型不能自行覆盖固定记录；后续受影响章节会待复核。") { values in
            novels.correctFact(projectID: projectID, factID: fact.id, value: values[0], note: values[1], locked: true)
        }
    }
}

@MainActor
struct NovelMemoryCandidateView: View {
    let projectID: UUID
    let chapterID: UUID
    @EnvironmentObject private var novels: NovelStore
    @Environment(\.dismiss) private var dismiss
    @State private var showDiscard = false

    var body: some View {
        Group {
            if let project = novels.project(projectID),
               let chapter = project.chapters.first(where: { $0.id == chapterID }),
               let delta = chapter.memoryCandidate {
                List {
                    Section {
                        Text("核对下面的变化是否来自本章正文。确认后才会定稿，并把这些事实交给下一章。发现提取有误，可先舍弃、调整正文后重新提取；定稿后也能在账本纠正。")
                            .font(TypeScale.body).foregroundStyle(Ink.ink2).lineSpacing(5)
                    }.listRowBackground(Color.clear)
                    Section("本章摘要") {
                        Text(delta.summary).font(TypeScale.body).lineSpacing(6).textSelection(.enabled)
                    }.listRowBackground(Color.clear)
                    Section("新增或更新的事实") {
                        if delta.updates.isEmpty {
                            Text("本章没有提取到新的结构化事实。")
                                .font(TypeScale.body).foregroundStyle(Ink.ink3)
                        }
                        ForEach(delta.updates) { fact in
                            NovelFactContent(fact: fact, project: project).padding(.vertical, 6)
                        }
                    }.listRowBackground(Color.clear)
                    if !delta.resolveIDs.isEmpty || !delta.expireIDs.isEmpty {
                        Section("即将结束或回收") {
                            let facts = (try? NovelMemory.replay(project: project, beforeChapterID: chapterID))?.facts ?? []
                            ForEach(delta.resolveIDs + delta.expireIDs, id: \.self) { id in
                                VStack(alignment: .leading, spacing: 7) {
                                    if let fact = facts.first(where: { $0.id == id }) {
                                        Text(fact.subject + " · " + fact.predicate).font(TypeScale.body)
                                        Text(fact.value).font(TypeScale.label).foregroundStyle(Ink.ink2)
                                    } else { Text("关联记录").font(TypeScale.body) }
                                    Text(delta.resolveIDs.contains(id) ? "伏笔已回收" : "旧状态结束")
                                        .font(TypeScale.caption).foregroundStyle(Ink.seal)
                                    if let evidence = delta.removalEvidence[id] {
                                        Text("本章依据：" + evidence).font(TypeScale.caption).foregroundStyle(Ink.ink3)
                                    }
                                }.padding(.vertical, 5)
                            }
                        }.listRowBackground(Color.clear)
                    }
                    Section {
                        Button("确认记忆并定稿", systemImage: "checkmark.seal") {
                            if novels.acceptMemoryCandidate(projectID: projectID, chapterID: chapterID) { dismiss() }
                        }.disabled(novels.isGenerating)
                        Button("舍弃这次记忆提取", role: .destructive) { showDiscard = true }.disabled(novels.isGenerating)
                    }.listRowBackground(Color.clear)
                }
                .listStyle(.insetGrouped).scrollContentBackground(.hidden).background(AppBackground())
            } else {
                ContentUnavailableView("记忆候选已处理", systemImage: "checkmark.seal")
            }
        }
        .navigationTitle("审阅本章记忆").navigationBarTitleDisplayMode(.inline)
        .confirmationDialog("舍弃这次记忆提取？", isPresented: $showDiscard, titleVisibility: .visible) {
            Button("舍弃候选", role: .destructive) {
                if novels.discardMemoryCandidate(projectID: projectID, chapterID: chapterID) { dismiss() }
            }
        } message: { Text("章节正文保留，可以重新提取。") }
        .novelErrorAlert(novels)
    }
}

@MainActor
private struct NovelFactContent: View {
    let fact: NovelFact
    let project: NovelProject

    private var source: String {
        if let index = project.chapters.firstIndex(where: { $0.id == fact.sourceChapterID }) {
            return "来源：第 \(index + 1) 章 · " + project.chapters[index].title
        }
        return "来源章节已不可用"
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text(fact.kind.title).font(TypeScale.caption).foregroundStyle(Ink.seal)
                if fact.locked { Label("已固定", systemImage: "pin.fill").font(TypeScale.caption).foregroundStyle(Ink.ink2) }
                if fact.origin == .user { Text("作者校正").font(TypeScale.caption).foregroundStyle(Ink.ink2) }
            }
            Text(fact.subject + " · " + fact.predicate).font(TypeScale.subject).foregroundStyle(Ink.ink)
            Text(fact.value).font(TypeScale.body).foregroundStyle(Ink.ink).lineSpacing(5).textSelection(.enabled)
            Text(source).font(TypeScale.caption).foregroundStyle(Ink.ink3)
            if !fact.evidence.isEmpty {
                Text("原文依据：" + fact.evidence).font(TypeScale.label).foregroundStyle(Ink.ink2)
                    .lineSpacing(4).textSelection(.enabled)
            }
            if let note = fact.correctionNote, !note.isEmpty {
                Text("校正说明：" + note).font(TypeScale.caption).foregroundStyle(Ink.ink2)
            }
            if let until = fact.validUntilChapter {
                if until < fact.validFromChapter {
                    Text("作者已作废").font(TypeScale.caption).foregroundStyle(Ink.seal)
                } else {
                    Text("有效范围：第 \(fact.validFromChapter) 至 \(until) 章")
                        .font(TypeScale.caption).foregroundStyle(Ink.ink3)
                }
            }
        }
    }
}
