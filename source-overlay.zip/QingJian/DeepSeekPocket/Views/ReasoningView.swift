import SwiftUI

// Thinking, after the Claude app: one quiet line in the conversation, and the
// full thinking in a half-height sheet, laid out as a timeline of paragraphs.
enum ThinkingSteps {
    static func split(_ text: String) -> [String] {
        text.components(separatedBy: "\n\n").map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }.filter { !$0.isEmpty }
    }
    // Longer paragraphs are cut to four lines in the timeline and open in full.
    static func isLong(_ step: String) -> Bool { step.count > 70 }
}

// Holds no store, so finished messages do not redraw while another answer streams.
struct ThinkingRow: View {
    let message: ChatMessage
    let open: () -> Void
    private var live: Bool { message.state == .streaming && message.content.isEmpty }
    // Only the tail is looked at: splitting the whole thinking text on every redraw
    // costs more the longer it thinks.
    private var snippet: String {
        let tail = String(message.reasoning.suffix(400))
        let last = tail.components(separatedBy: "\n\n").map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }.last { !$0.isEmpty } ?? ""
        return String((last.components(separatedBy: .newlines).first ?? last).prefix(80))
    }

    var body: some View {
        Button(action: open) {
            HStack(spacing: 8) {
                ThinkingMark(live: live)
                if live {
                    TimelineView(.periodic(from: .now, by: 1)) { timeline in
                        line(head: "思考中 · \(max(0, Int(timeline.date.timeIntervalSince(message.createdAt)))) 秒")
                    }
                } else {
                    line(head: message.thinkingSeconds.map { "已思考 \($0) 秒" } ?? "思考过程")
                }
                Image(systemName: "chevron.right").font(.system(size: 10, weight: .semibold))
            }
            .font(TypeScale.caption).foregroundStyle(Ink.ink3)
            .frame(minHeight: 36).contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .accessibilityLabel(live ? "正在思考，打开思考过程" : "打开思考过程")
        .accessibilityIdentifier("thinking-row")
    }

    // Only how long it thought; the raw first words of the reasoning read as noise.
    // The whole timeline opens with a tap.
    private func line(head: String) -> some View {
        Text(head).foregroundStyle(Ink.ink2).monospacedDigit()
    }
}

/// Sermo's thinking mark: five small terracotta petals round a seed. While it thinks
/// the petals turn slowly and breathe one after another; when it is done they settle
/// into a still little flower. Motion stops when Reduce Motion is on.
struct ThinkingMark: View {
    var live: Bool
    var size: CGFloat = 18
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    var body: some View {
        Group {
            if live && !reduceMotion {
                TimelineView(.animation) { timeline in
                    petals(time: timeline.date.timeIntervalSinceReferenceDate)
                }
            } else {
                petals(time: nil)
            }
        }
        .frame(width: size, height: size)
        .accessibilityHidden(true)
    }

    private func petals(time: Double?) -> some View {
        let dot = size * 0.26
        let ring = size * 0.34
        let turn = (time ?? 0) * 70
        return ZStack {
            ForEach(0..<5, id: \.self) { index in
                let wave = time.map { 0.72 + 0.28 * (0.5 + 0.5 * sin($0 * 3.2 - Double(index) * 1.25)) } ?? 1
                Circle().fill(Ink.seal)
                    .frame(width: dot * wave, height: dot * wave)
                    .opacity(time == nil ? 0.9 : 0.55 + 0.45 * wave)
                    .offset(y: -ring)
                    .rotationEffect(.degrees(Double(index) * 72 + turn))
            }
            Circle().fill(Ink.seal).frame(width: dot * 0.7, height: dot * 0.7)
        }
    }
}

struct ThinkingTarget: Identifiable, Equatable {
    let threadID: UUID
    let messageID: UUID
    var id: UUID { messageID }
}

@MainActor
struct ThinkingSheet: View {
    @EnvironmentObject private var store: AppStore
    @Environment(\.dismiss) private var dismiss
    let target: ThinkingTarget
    @State private var display: Display = ProcessInfo.processInfo.arguments.contains("--preview-reasoning-bilingual") ? .bilingual : .translated
    private enum Display: String, CaseIterable { case original = "原文", translated = "中文", bilingual = "双语" }
    private var message: ChatMessage? {
        store.threads.first(where: { $0.id == target.threadID })?.messages.first(where: { $0.id == target.messageID })
    }
    private var busy: Bool { store.isTranslating(threadID: target.threadID, messageID: target.messageID) }

    var body: some View {
        NavigationStack {
            Group {
                if let stored = message {
                  LiveMessageRow(live: store.live, message: stored) { message in
                    let live = message.state == .streaming && message.content.isEmpty
                    ScrollView {
                        VStack(alignment: .leading, spacing: 0) {
                            if message.state != .streaming { tools(message) }
                            content(message, live: live)
                        }
                        .padding(.horizontal, 22).padding(.top, 6).padding(.bottom, 32)
                    }
                    // While it thinks, new paragraphs keep the newest one in view.
                    .defaultScrollAnchor(live ? .bottom : nil, for: .sizeChanges)
                    .toolbar {
                        ToolbarItem(placement: .topBarTrailing) {
                            Text(status(message, live: live)).font(TypeScale.tiny).foregroundStyle(Ink.ink3).monospacedDigit()
                        }
                    }
                  }
                } else {
                    Text("这条回答已经不在了。").font(TypeScale.caption).foregroundStyle(Ink.ink3)
                }
            }
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button { dismiss() } label: { Image(systemName: "xmark") }.accessibilityLabel("关闭思考过程")
                }
                ToolbarItem(placement: .principal) {
                    Text("思考过程").font(TypeScale.serif(17).weight(.semibold)).foregroundStyle(Ink.ink)
                }
            }
            .navigationBarTitleDisplayMode(.inline)
            .navigationDestination(for: ThinkingStepPage.self) { page in
                ScrollView {
                    Text(page.text).readingStyle(adjustment: -2).lineSpacing(7).foregroundStyle(Ink.ink2)
                        .textSelection(.enabled).frame(maxWidth: .infinity, alignment: .leading)
                        .padding(.horizontal, 22).padding(.vertical, 10)
                }
                .navigationTitle("第 \(page.index + 1) 段").navigationBarTitleDisplayMode(.inline)
            }
        }
        .tint(Ink.ink)
        .presentationDetents([.medium, .large])
        .presentationDragIndicator(.visible)
        .accessibilityIdentifier("thinking-sheet")
        .onChange(of: message?.reasoningTranslation) { old, new in
            if old == nil && new != nil { display = .translated }
        }
    }

    private func status(_ message: ChatMessage, live: Bool) -> String {
        if live { return "思考中" }
        return message.thinkingSeconds.map { "已思考 \($0) 秒" } ?? ""
    }

    @ViewBuilder private func tools(_ message: ChatMessage) -> some View {
        HStack(spacing: 12) {
            if message.reasoningTranslation != nil {
                Picker("显示方式", selection: $display) {
                    ForEach(Display.allCases, id: \.self) { Text($0.rawValue).tag($0) }
                }.pickerStyle(.segmented).frame(maxWidth: 220)
            }
            Spacer(minLength: 8)
            if busy {
                ProgressView().controlSize(.mini)
                Text("翻译中")
                Button("取消") { store.cancelTranslation() }
            } else if message.reasoningTranslation == nil {
                Button {
                    store.translateReasoning(threadID: target.threadID, messageID: target.messageID)
                } label: {
                    Label(store.translationError(threadID: target.threadID, messageID: target.messageID) == nil ? "翻译" : "重试", systemImage: "translate")
                }
                .disabled(store.isTranslating || !store.canPersist)
                .accessibilityLabel("将思考过程翻译成中文")
            }
        }
        .font(TypeScale.caption).foregroundStyle(Ink.ink3).buttonStyle(.plain)
        .frame(minHeight: 36).padding(.bottom, 14)
        if let error = store.translationError(threadID: target.threadID, messageID: target.messageID) {
            Text(error).font(TypeScale.tiny).foregroundStyle(Ink.ink3).padding(.bottom, 12)
        }
    }

    @ViewBuilder private func content(_ message: ChatMessage, live: Bool) -> some View {
        if let translated = message.reasoningTranslation, display != .original {
            if display == .bilingual {
                caption("原文")
                ThinkingTimeline(steps: ThinkingSteps.split(message.reasoning), live: false)
                caption("中文译文").padding(.top, 8)
            }
            ThinkingTimeline(steps: ThinkingSteps.split(translated), live: false)
        } else {
            ThinkingTimeline(steps: ThinkingSteps.split(message.reasoning), live: live)
        }
    }

    private func caption(_ value: String) -> some View {
        Text(value).font(TypeScale.tiny.weight(.medium)).foregroundStyle(Ink.ink2).padding(.bottom, 10)
    }
}

struct ThinkingStepPage: Hashable {
    let index: Int
    let text: String
}

// Paragraphs joined by a hairline down the left, each with a small dot.
struct ThinkingTimeline: View {
    let steps: [String]
    let live: Bool
    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            ForEach(Array(steps.enumerated()), id: \.offset) { index, step in
                let last = index == steps.count - 1
                Group {
                    if ThinkingSteps.isLong(step) {
                        NavigationLink(value: ThinkingStepPage(index: index, text: step)) { row(step, last: last, chevron: true) }
                    } else {
                        row(step, last: last, chevron: false)
                    }
                }
                .buttonStyle(.plain)
            }
        }
        .accessibilityElement(children: .contain)
        .accessibilityIdentifier("thinking-timeline")
    }

    private func row(_ step: String, last: Bool, chevron: Bool) -> some View {
        HStack(alignment: .top, spacing: 14) {
            Group {
                if live && last { PulseDot(size: 9) } else { Circle().fill(Ink.line).frame(width: 9, height: 9) }
            }
            .frame(width: 9).padding(.top, 8)
            Text(step).font(TypeScale.serif(15)).lineSpacing(6).foregroundStyle(Ink.ink2)
                .lineLimit(4).multilineTextAlignment(.leading)
                .frame(maxWidth: .infinity, alignment: .leading)
            if chevron {
                Image(systemName: "chevron.right").font(.system(size: 11, weight: .semibold)).foregroundStyle(Ink.ink3)
                    .padding(.top, 8)
            }
        }
        .padding(.bottom, last ? 0 : 22)
        .background(alignment: .topLeading) {
            if !last { Rectangle().fill(Ink.line).frame(width: 1).padding(.top, 22).padding(.leading, 4) }
        }
        .contentShape(Rectangle())
    }
}
