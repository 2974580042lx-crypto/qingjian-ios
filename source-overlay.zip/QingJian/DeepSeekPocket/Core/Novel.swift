import Foundation

enum NovelChapterStatus: String, Codable, CaseIterable, Sendable {
    case draft, confirmed
    var title: String { self == .confirmed ? "已定稿" : "草稿" }
}

enum NovelAction: String, Codable, CaseIterable, Identifiable, Sendable {
    case world, characters, outline, plan, draft, review, polish, confirm
    var id: String { rawValue }
    var title: String {
        switch self {
        case .world: return "完善世界设定"
        case .characters: return "设计人物"
        case .outline: return "规划全书大纲"
        case .plan: return "拟定本章提纲"
        case .draft: return "起草正文"
        case .review: return "审阅本章"
        case .polish: return "润色本章"
        case .confirm: return "整理定稿记忆"
        }
    }
    var needsChapter: Bool { [.plan, .draft, .review, .polish, .confirm].contains(self) }
}

struct NovelRevision: Codable, Equatable, Identifiable, Sendable {
    var id = UUID()
    var createdAt = Date()
    var body: String
    var label: String
}

struct NovelChapter: Codable, Equatable, Identifiable, Sendable {
    var id = UUID()
    var title: String
    var plan = ""
    var body = ""
    var review = ""
    var summary = ""
    var characterState = ""
    var foreshadowing = ""
    var status: NovelChapterStatus = .draft
    var needsReview = false
    var revision = 0
    var versions: [NovelRevision] = []
    var confirmedAt: Date?
    var memoryDelta: NovelMemoryDelta?
    var memoryCandidate: NovelMemoryDelta?
    var updatedAt = Date()
    var wordCount: Int { body.filter { !$0.isWhitespace }.count }
}

struct NovelCandidate: Codable, Equatable, Identifiable, Sendable {
    var id = UUID()
    var action: NovelAction
    var chapterID: UUID?
    var text = ""
    var isComplete = false
    var sourceRevision: Int
    var chapterRevision: Int?
    var dependencies: [NovelDependency]?
    var memoryDescription: String?
    var createdAt = Date()
}

struct NovelDependency: Codable, Equatable, Sendable {
    var chapterID: UUID
    var fingerprint: String
}

enum NovelRunStatus: String, Codable, Sendable {
    case running, paused, failed, completed
    var title: String {
        switch self {
        case .running: return "正在生成"
        case .paused: return "已暂停"
        case .failed: return "待重试"
        case .completed: return "已完成"
        }
    }
}

struct NovelRun: Codable, Equatable, Identifiable, Sendable {
    var id = UUID()
    var projectID: UUID
    var chapterID: UUID?
    var action: NovelAction
    var status: NovelRunStatus = .running
    var isBatch = false
    var requestedCount = 1
    var completedCount = 0
    var candidateID: UUID?
    var chapterIDs: [UUID] = []
    var startedAt = Date()
    var updatedAt = Date()
    var issue: String?
    var title: String { isBatch ? "连续起草" : action.title }
    var detail: String {
        let progress = isBatch ? " · 已完成 \(completedCount)/\(requestedCount) 章" : ""
        return status.title + progress + (issue.map { " · " + $0 } ?? "")
    }
}

struct NovelProject: Codable, Equatable, Identifiable, Sendable {
    var id = UUID()
    var title: String
    var brief = ""
    var world = ""
    var characters = ""
    var outline = ""
    var chapters: [NovelChapter] = []
    var candidates: [NovelCandidate] = []
    var revision = 0
    var createdAt = Date()
    var updatedAt = Date()
    var lastRun: NovelRun?
    var memoryCorrections: [NovelFactCorrection]?
    var wordCount: Int { chapters.reduce(0) { $0 + $1.wordCount } }
    var confirmedCount: Int { chapters.filter { $0.status == .confirmed && !$0.needsReview }.count }

    func validate() throws {
        guard !title.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty, title.count <= 120,
              brief.count <= 20000, world.count <= 100000, characters.count <= 100000, outline.count <= 100000,
              chapters.count <= 1000, candidates.count <= 2000,
              Set(chapters.map(\.id)).count == chapters.count,
              Set(candidates.map(\.id)).count == candidates.count else {
            throw NovelError.message("小说名称、资料长度或章节数量超出范围，未保存。")
        }
        let chapterIDs = Set(chapters.map(\.id))
        for chapter in chapters {
            guard !chapter.title.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty, chapter.title.count <= 160,
                  chapter.plan.count <= 100000, chapter.body.count <= 200000, chapter.review.count <= 100000,
                  chapter.summary.count <= 20000, chapter.characterState.count <= 20000, chapter.foreshadowing.count <= 20000,
                  chapter.versions.count <= 1000, Set(chapter.versions.map(\.id)).count == chapter.versions.count,
                  chapter.versions.allSatisfy({ $0.body.count <= 200000 && $0.label.count <= 200 }) else {
                throw NovelError.message("章节或历史版本过长，未保存；请先拆分章节。")
            }
            if chapter.status == .confirmed && (chapter.body.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || chapter.summary.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty) {
                throw NovelError.message("定稿章节缺少正文或摘要，无法读取此项目。")
            }
            for delta in [chapter.memoryDelta, chapter.memoryCandidate].compactMap({ $0 }) {
                try NovelMemory.validateShape(delta, chapterID: chapter.id)
            }
        }
        guard (memoryCorrections ?? []).count <= 10000,
              (memoryCorrections ?? []).allSatisfy({ chapterIDs.contains($0.sourceChapterID) && $0.value.count <= 2000 && $0.note.count <= 2000 }) else {
            throw NovelError.message("记忆纠正记录过多或对应章节缺失。")
        }
        guard candidates.allSatisfy({ $0.text.count <= 200000 && ($0.chapterID.map { chapterIDs.contains($0) } ?? true) && ($0.dependencies ?? []).allSatisfy({ chapterIDs.contains($0.chapterID) }) }) else {
            throw NovelError.message("候选稿过长或对应章节缺失。")
        }
        if let run = lastRun {
            guard run.projectID == id, (1...5).contains(run.requestedCount), run.completedCount >= 0,
                  run.completedCount <= run.requestedCount,
                  run.chapterID.map({ chapterIDs.contains($0) }) ?? !run.action.needsChapter,
                  run.chapterIDs.allSatisfy({ chapterIDs.contains($0) }),
                  Set(run.chapterIDs).count == run.chapterIDs.count,
                  run.candidateID.map({ candidateID in candidates.contains { $0.id == candidateID } }) ?? true,
                  !run.isBatch || (run.action == .draft && run.chapterIDs.count == run.requestedCount),
                  run.isBatch || (run.requestedCount == 1 && run.chapterIDs.isEmpty) else {
                throw NovelError.message("小说任务断点不完整，未保存。")
            }
        }
    }
}

struct NovelArchive: Codable, Sendable {
    var format = "sermo.novel"
    var version = 1
    var exportedAt = Date()
    var project: NovelProject
}

enum NovelError: LocalizedError {
    case message(String)
    var errorDescription: String? { if case .message(let value) = self { return value }; return nil }
}

typealias NovelTextGenerator = @MainActor (_ system: String, _ prompt: String,
    _ onText: @escaping @MainActor (String) -> Void) async throws -> String

enum NovelFactKind: String, Codable, CaseIterable, Identifiable, Sendable {
    case fact, characterState, characterKnowledge, timeline, foreshadow
    var id: String { rawValue }
    var title: String {
        switch self {
        case .fact: return "设定事实"
        case .characterState: return "人物状态"
        case .characterKnowledge: return "人物知情"
        case .timeline: return "时间线"
        case .foreshadow: return "伏笔"
        }
    }
}

enum NovelFactOrigin: String, Codable, Sendable { case extracted, user }

struct NovelFact: Codable, Equatable, Identifiable, Sendable {
    var id = UUID()
    var kind: NovelFactKind
    var subject: String
    var predicate: String
    var value: String
    var sourceChapterID: UUID
    var sourceBodyFingerprint: String
    var evidence: String
    var validFromChapter: Int
    var validUntilChapter: Int?
    var origin: NovelFactOrigin = .extracted
    var locked = false
    var correctionNote: String?
    var isActive: Bool { validUntilChapter == nil }
}

struct NovelMemoryDelta: Codable, Equatable, Identifiable, Sendable {
    var id = UUID()
    var sourceChapterID: UUID
    var sourceBodyFingerprint: String
    var baseLedgerFingerprint: String
    var summary: String
    var characterState: String
    var foreshadowing: String
    var updates: [NovelFact]
    var resolveIDs: [UUID]
    var expireIDs: [UUID]
    var removalEvidence: [UUID: String] = [:]
    var createdAt = Date()
}

struct NovelFactCorrection: Codable, Equatable, Identifiable, Sendable {
    var id = UUID()
    var factID: UUID
    var sourceChapterID: UUID
    var sourceBodyFingerprint: String
    var value: String
    var note: String
    var locked = false
    var invalidated: Bool?
    var createdAt = Date()
}

struct NovelCanonSnapshot: Sendable {
    var facts: [NovelFact]
    var fingerprint: String
    var throughChapter = 0
    var invalidatedChapterIDs: [UUID] = []
    var activeFacts: [NovelFact] { facts.filter(\.isActive) }
    var openHooks: [NovelFact] { facts.filter { $0.kind == .foreshadow && $0.isActive } }
}
