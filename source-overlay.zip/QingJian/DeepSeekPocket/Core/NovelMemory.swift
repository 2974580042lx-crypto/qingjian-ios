import Foundation
import CryptoKit

/// The ledger is a deterministic projection of accepted chapter deltas. Model output is
/// never merged until its quotes, references and source body version have been checked.
enum NovelMemory {
    static func bodyFingerprint(_ text: String) -> String {
        SHA256.hash(data: Data(text.utf8)).map { String(format: "%02x", $0) }.joined()
    }

    private static func fingerprint(_ facts: [NovelFact]) throws -> String {
        let encoder = JSONEncoder(); encoder.outputFormatting = [.sortedKeys]
        let data = try encoder.encode(facts.sorted { $0.id.uuidString < $1.id.uuidString })
        return SHA256.hash(data: data).map { String(format: "%02x", $0) }.joined()
    }

    static func replay(project: NovelProject, beforeChapterID: UUID? = nil) throws -> NovelCanonSnapshot {
        var ledger = NovelCanonSnapshot(facts: [], fingerprint: try fingerprint([]))
        let end = beforeChapterID.flatMap { id in project.chapters.firstIndex { $0.id == id } } ?? project.chapters.count
        var invalid = false
        for (offset, chapter) in project.chapters.prefix(end).enumerated() {
            guard !invalid, chapter.status == .confirmed, !chapter.needsReview,
                  let delta = chapter.memoryDelta,
                  delta.sourceBodyFingerprint == bodyFingerprint(chapter.body) else {
                invalid = true; ledger.invalidatedChapterIDs.append(chapter.id); continue
            }
            // A previous author correction changes the base fingerprint. Later memories are
            // held back until the author reviews their chapter against that corrected history.
            guard delta.baseLedgerFingerprint == ledger.fingerprint else {
                invalid = true; ledger.invalidatedChapterIDs.append(chapter.id); continue
            }
            ledger = try applying(delta, chapter: chapter, chapterNumber: offset + 1, to: ledger)
            for correction in project.memoryCorrections ?? [] where correction.sourceChapterID == chapter.id && correction.sourceBodyFingerprint == delta.sourceBodyFingerprint {
                guard let index = ledger.facts.firstIndex(where: { $0.id == correction.factID }) else { continue }
                ledger.facts[index].value = correction.value
                ledger.facts[index].origin = .user
                ledger.facts[index].locked = correction.locked
                ledger.facts[index].correctionNote = correction.note
                if correction.invalidated == true { ledger.facts[index].validUntilChapter = max(0, ledger.facts[index].validFromChapter - 1) }
            }
            ledger.fingerprint = try fingerprint(ledger.facts)
        }
        return ledger
    }

    static func validateShape(_ delta: NovelMemoryDelta, chapterID: UUID) throws {
        guard delta.sourceChapterID == chapterID, delta.sourceBodyFingerprint.count == 64,
              delta.baseLedgerFingerprint.count == 64, delta.updates.count <= 80,
              delta.resolveIDs.count <= 80, delta.expireIDs.count <= 80,
              !delta.summary.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty,
              delta.summary.count <= 20000, delta.characterState.count <= 20000, delta.foreshadowing.count <= 20000,
              Set(delta.updates.map(\.id)).count == delta.updates.count,
              Set(delta.resolveIDs).count == delta.resolveIDs.count,
              Set(delta.expireIDs).count == delta.expireIDs.count,
              Set(delta.resolveIDs).isDisjoint(with: Set(delta.expireIDs)),
              delta.removalEvidence.count <= 160 else { throw NovelError.message("记忆候选格式、数量或来源不正确。") }
        for fact in delta.updates {
            guard !fact.subject.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty,
                  !fact.predicate.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty,
                  !fact.value.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty,
                  fact.subject.count <= 120, fact.predicate.count <= 120, fact.value.count <= 2000,
                  !fact.evidence.isEmpty, fact.evidence.count <= 1000,
                  fact.sourceChapterID == chapterID, fact.sourceBodyFingerprint == delta.sourceBodyFingerprint,
                  fact.validFromChapter >= 1, fact.validUntilChapter == nil, fact.origin == .extracted, !fact.locked else {
                throw NovelError.message("记忆条目缺少原句、人物或事实，或包含无效的来源。")
            }
        }
    }

    static func validate(delta: NovelMemoryDelta, chapter: NovelChapter, ledger: NovelCanonSnapshot) throws {
        try validateShape(delta, chapterID: chapter.id)
        guard delta.sourceBodyFingerprint == bodyFingerprint(chapter.body), delta.baseLedgerFingerprint == ledger.fingerprint else {
            throw NovelError.message("正文或前文记忆已改变，请重新提取本章记忆。")
        }
        let known = Dictionary(uniqueKeysWithValues: ledger.facts.map { ($0.id, $0) })
        var keys = Set<String>()
        for fact in delta.updates {
            guard chapter.body.contains(fact.evidence), known[fact.id] == nil else {
                throw NovelError.message("记忆条目“\(fact.subject)·\(fact.predicate)”的原句不在本章正文中，未写入正式记忆。")
            }
            if [.fact, .characterState, .characterKnowledge].contains(fact.kind) {
                let key = slot(fact)
                guard keys.insert(key).inserted else { throw NovelError.message("同一人物或事实字段有多条相互竞争的更新，请重新整理。") }
                if let locked = ledger.activeFacts.first(where: { slot($0) == key && $0.locked }) {
                    throw NovelError.message("“\(locked.subject)·\(locked.predicate)”已由作者锁定；请先核对或解除锁定，再更新。")
                }
            }
        }
        for id in delta.resolveIDs + delta.expireIDs {
            guard let fact = known[id], fact.isActive, !fact.locked else { throw NovelError.message("待关闭的事实或伏笔不存在、已关闭或已被作者锁定。") }
            guard let evidence = delta.removalEvidence[id], !evidence.isEmpty, evidence.count <= 1000,
                  chapter.body.contains(evidence) else { throw NovelError.message("关闭事实或回收伏笔缺少本章原句，未写入正式记忆。") }
            if delta.resolveIDs.contains(id), fact.kind != .foreshadow { throw NovelError.message("回收操作只能指向已有的未回收伏笔。") }
        }
    }

    private static func slot(_ fact: NovelFact) -> String {
        [fact.kind.rawValue, fact.subject, fact.predicate].map {
            $0.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        }.joined(separator: "\u{001F}")
    }

    private static func applying(_ delta: NovelMemoryDelta, chapter: NovelChapter, chapterNumber: Int,
                                 to old: NovelCanonSnapshot) throws -> NovelCanonSnapshot {
        try validate(delta: delta, chapter: chapter, ledger: old)
        guard delta.updates.allSatisfy({ $0.validFromChapter == chapterNumber }) else {
            throw NovelError.message("记忆条目的生效章节与正文不符。")
        }
        var result = old
        let removed = Set(delta.resolveIDs + delta.expireIDs)
        for index in result.facts.indices where removed.contains(result.facts[index].id) {
            result.facts[index].validUntilChapter = chapterNumber - 1
        }
        for fact in delta.updates {
            if [.fact, .characterState, .characterKnowledge].contains(fact.kind) {
                for index in result.facts.indices where result.facts[index].isActive && slot(result.facts[index]) == slot(fact) {
                    result.facts[index].validUntilChapter = chapterNumber - 1
                }
            }
            result.facts.append(fact)
        }
        result.throughChapter = chapterNumber
        result.fingerprint = try fingerprint(result.facts)
        return result
    }
}
