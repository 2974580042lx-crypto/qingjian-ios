import Foundation

/// Shared by the iOS chat path and the macOS live-model acceptance test.
/// The caller supplies the authorized project/window and the real user message.
struct StudyToolExecutor {
    let store: StudyMemoryStore
    let scope: StudyScope
    let documents: [ProjectDocument]

    func context(query: String) throws -> String {
        let context = try store.context(scope: scope, query: query)
        let catalog = documents.map { "\($0.id.uuidString) · \($0.name)" }.joined(separator: "\n")
        var result = context + (catalog.isEmpty ? "" : "\n项目资料目录\n" + catalog)
        if scope.subject == .english {
            let state = try store.wordState(scope: scope)
            if let session = state.session {
                result += "\n当前背词任务：" + String(decoding: try StudyCoding.encode(session), as: UTF8.self)
                if let word = state.currentWord { result += "\n当前词：" + String(decoding: try StudyCoding.encode(word), as: UTF8.self) }
                result += "\n此词已记录练习次数：\(state.progress?.reviewCount ?? 0)"
            }
        }
        return result
    }
    func perform(_ action: StudyToolAction, sourceMessage: ChatMessage) throws -> String {
        guard sourceMessage.role == .user else { throw StudyMemoryError.invalid("学习操作需要用户消息出处。") }
        let memory = store
        if StudyWordTools.names.contains(action.name) {
            return try performWordAction(action, message: sourceMessage)
        }
        if action.name == "study_list_memory" {
            let query = try action.text("query").trimmingCharacters(in: .whitespacesAndNewlines)
            let records = try memory.records(projectID: scope.projectID).filter { query.isEmpty || $0.text.localizedCaseInsensitiveContains(query) || $0.category.contains(query) }
            return String(decoding: try StudyCoding.encode(Array(records.prefix(30))), as: UTF8.self)
        }
        if action.name == "study_read_material" {
            let id = try action.text("document_id")
            guard let document = documents.first(where: { $0.id.uuidString.caseInsensitiveCompare(id) == .orderedSame }) else {
                throw StudyMemoryError.invalid("当前项目找不到这份资料。")
            }
            return "引用资料《\(document.name)》\n" + document.text
        }
        let command = try action.command(scope: scope, message: sourceMessage)
        // One logical change per message, action and target. A network retry or
        // regeneration must reuse it even when the provider changes its call ID.
        let operationID = StudyCoding.hash(Data((sourceMessage.id.uuidString + "/" + action.name + "/" + (command.recordID?.uuidString ?? command.category)).utf8))
        let receipt = try memory.apply(command, scope: scope, operationID: operationID)
        return String(decoding: try StudyCoding.encode(receipt), as: UTF8.self)
    }
    private func performWordAction(_ action: StudyToolAction, message: ChatMessage) throws -> String {
        guard scope.subject == .english else { throw StudyMemoryError.invalid("请在考研英语项目中背词。") }
        let memory = store
        func json<T: Encodable>(_ value: T) throws -> String { String(decoding: try StudyCoding.encode(value), as: UTF8.self) }
        if action.name == "study_word_state" {
            let state = try memory.wordState(scope: scope)
            return try json(state)
        }
        if action.name == "study_start_words" {
            guard let mode = StudyWordMode(rawValue: try action.text("mode")) else { throw StudyMemoryError.invalid("背词模式不正确。") }
            _ = try memory.startWords(scope: scope, unitID: action.text("unit_id"), count: action.integer("count", range: 1..<31), mode: mode, sourceMessageID: message.id)
            return try json(memory.wordState(scope: scope))
        }
        if action.name == "study_grade_word" {
            let source = StudySource(kind: .userStatement, threadID: scope.threadID, messageID: message.id,
                text: message.content, quote: try action.text("evidence_quote"), messageDate: message.createdAt)
            let grade = StudyWordGrade(sessionID: try action.uuid("session_id"), expectedRevision: try action.integer("expected_revision"),
                wordID: try action.text("word_id"), rating: try action.text("rating"), source: source)
            let id = StudyCoding.hash(Data((message.id.uuidString + "/word/" + grade.sessionID.uuidString + "/" + grade.wordID).utf8))
            _ = try memory.gradeWord(grade, scope: scope, operationID: id)
            return "本次回答、评分及进度已保存。周报尚未生成。\n" + (try json(memory.wordState(scope: scope)))
        }
        if action.name == "study_undo_word" {
            _ = try memory.undoWord(scope: scope, sessionID: action.uuid("session_id"), expectedRevision: action.integer("expected_revision"))
            return "已撤销最近一题评分。\n" + (try json(memory.wordState(scope: scope)))
        }
        if action.name == "study_pause_words" {
            return try json(memory.pauseWords(scope: scope, sessionID: action.uuid("session_id"), expectedRevision: action.integer("expected_revision")))
        }
        guard let pack = try memory.wordPack(projectID: scope.projectID) else { throw StudyMemoryError.invalid("请先在项目记忆页导入私人词库。") }
        let progress = try memory.wordProgress(projectID: scope.projectID)
        let lookup = Dictionary(uniqueKeysWithValues: progress.map { ($0.wordID, $0) })
        if action.name == "study_find_word" {
            let query = try action.text("query").trimmingCharacters(in: .whitespacesAndNewlines)
            guard !query.isEmpty else { throw StudyMemoryError.invalid("请提供要查的词或释义。") }
            let found = pack.cards.filter { $0.id == query || $0.word.localizedCaseInsensitiveContains(query) || $0.meaning.localizedCaseInsensitiveContains(query) || $0.translation.localizedCaseInsensitiveContains(query) }.prefix(12)
            return try json(found.map { word in StudyWordView(word: word, reviewCount: lookup[word.id]?.reviewCount ?? 0,
                lastRating: lookup[word.id]?.lastRating, lastReviewedAt: lookup[word.id]?.lastReviewedAt, due: lookup[word.id]?.due) })
        }
        var units: [String: StudyWord.Unit] = [:]
        for word in pack.cards { for unit in word.units where unit.isCore { units[unit.id] = unit } }
        let ordered = units.values.sorted { ($0.collection == "required" ? 0 : 1, $0.number) < ($1.collection == "required" ? 0 : 1, $1.number) }
        return try json(ordered.map { unit in
            let words = pack.cards.filter { $0.units.contains { $0.id == unit.id } }
            return StudyWordUnitOverview(id: unit.id, title: unit.title, total: words.count,
                learned: words.filter { (lookup[$0.id]?.reviewCount ?? 0) > 0 }.count,
                due: words.filter { lookup[$0.id].map { $0.reviewCount > 0 && $0.due <= Date() } == true }.count)
        })
    }

}
