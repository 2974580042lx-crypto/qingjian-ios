import Foundation

/// Buffer a sentence before display so a claim split across SSE chunks cannot
/// briefly appear as a completed weekly report. Actual report generation is a
/// later feature; this guard is enabled only for study conversations.
struct StudyOutputGuard {
    private var pending = ""
    mutating func consume(_ text: String, finish: Bool = false) -> String {
        pending += text
        var output = ""
        while let end = pending.firstIndex(where: { "。！？.!?".contains($0) }) {
            let after = pending.index(after: end)
            output += Self.checked(String(pending[..<after]))
            pending = String(pending[after...])
        }
        if finish || pending.count > 16_000 {
            output += Self.checked(pending); pending = ""
        }
        return output
    }
    static func checked(_ sentence: String) -> String {
        let plain = sentence.replacingOccurrences(of: #"[\s*_`]+"#, with: "", options: .regularExpression)
        let patterns = [
            #"(?:已经|已|成功|刚刚|刚才)[^。！？.!?]{0,40}(?:记入|写入|加入|记到|放进|放入|更新|生成|完成)[^。！？.!?]{0,16}(?:周报|本周总结)"#,
            #"(?:周报|本周总结)[^。！？.!?]{0,12}(?:已经|已)[^。！？.!?]{0,10}(?:生成|更新|完成|写好)"#,
            #"(?:记入|写入|加入|记到|放进|放入)[^。！？.!?]{0,16}(?:周报|本周总结)(?:里|中)?(?:了|啦)"#,
            #"(?:周报|本周总结)[^。！？.!?]{0,12}(?:生成|更新|完成|写好)了"#
        ]
        for pattern in patterns {
            guard let regex = try? NSRegularExpression(pattern: pattern) else { continue }
            for match in regex.matches(in: plain, range: NSRange(plain.startIndex..., in: plain)) {
                guard let range = Range(match.range, in: plain) else { continue }
                let prefix = String(plain[..<range.lowerBound].suffix(20))
                if prefix.range(of: #"(?:不能|不要|不会|不应)(?:说|声称|表示)?[“「\"]*$"#, options: .regularExpression) != nil { continue }
                return "周报尚未生成；学习记录的保存状态请以应用回执为准。"
            }
        }
        return sentence
    }
}
