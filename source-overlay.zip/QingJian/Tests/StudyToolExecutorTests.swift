import XCTest
@testable import DeepSeekCore

final class StudyToolExecutorTests: XCTestCase {
    func testSharedExecutorReadsWritesAndCorrectsWithTheClientScope() throws {
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent("sermo-executor-" + UUID().uuidString)
        defer { if directory.lastPathComponent.hasPrefix("sermo-executor-") { try? FileManager.default.removeItem(at: directory) } }
        let store = try StudyMemoryStore(url: directory.appendingPathComponent("memory.sqlite"))
        let scope = StudyScope(projectID: StudySubject.english.projectID, threadID: UUID(), subject: .english)
        let document = ProjectDocument(name: "合成资料", text: "Synthetic vocabulary exercise")
        let executor = StudyToolExecutor(store: store, scope: scope, documents: [document])
        func action(_ name: String, _ arguments: [String: Any]) throws -> StudyToolAction {
            try StudyToolAction(ToolCall(id: UUID().uuidString, name: name,
                arguments: String(decoding: JSONSerialization.data(withJSONObject: arguments), as: UTF8.self)))
        }
        let read = try executor.perform(action("study_read_material", ["document_id":document.id.uuidString]),
            sourceMessage: ChatMessage(role: .user, content: "读资料"))
        XCTAssertTrue(read.contains(document.text))
        let message = ChatMessage(role: .user, content: "我混淆 adapt 和 adopt，请记录")
        let save = try action("study_remember", ["category":"生词","text":"混淆 adapt/adopt","source_kind":"user_statement","evidence_quote":message.content])
        _ = try executor.perform(save, sourceMessage: message)
        _ = try executor.perform(save, sourceMessage: message)
        let first = try XCTUnwrap(store.records(projectID: scope.projectID).first)
        XCTAssertEqual(try store.events(projectID: scope.projectID).count, 1)
        let correction = ChatMessage(role: .user, content: "更正，实际是 affect 和 effect")
        _ = try executor.perform(action("study_correct", ["record_id":first.id.uuidString,"expected_revision":1,"category":"生词",
            "text":"混淆 affect/effect","source_kind":"user_statement","evidence_quote":correction.content]), sourceMessage: correction)
        XCTAssertEqual(try store.records(projectID: scope.projectID).first?.revision, 2)
        XCTAssertTrue(try executor.context(query: "affect").contains("affect/effect"))
        XCTAssertThrowsError(try executor.perform(save, sourceMessage: ChatMessage(role: .assistant, content: message.content)))
    }
}
