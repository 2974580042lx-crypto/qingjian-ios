import XCTest
@testable import DeepSeekCore

/// Invoked explicitly by the manual macOS workflow. All material is synthetic.
final class StudyLiveModelTests: XCTestCase {
    @MainActor func testPart1LearnRecordAndExit() async throws {
        let (key, root) = try Self.configuration()
        let session = try LiveStudySession(key: key, root: root, phase: "part1", restoring: false)
        do {
            try await session.turn("请从 required-1 合成单元背一组两个词，一次只问一个。先出第一题，不要提前解释答案。", label: "01-start")
            let first = try XCTUnwrap(session.wordState().session)
            try session.require(first.position == 0 && first.currentWordID == "synthetic-adapt", "first word was not presented")
            try session.require(session.progressCount() == 0, "presentation incorrectly counted as learning")

            try await session.turn("我的答案是：adapt 表示采纳。我把 adapt 和 adopt 搞混了，这个词这次算没记住。请把这个易混点存进生词栏目。", label: "02-confusion-and-record")
            let after = try XCTUnwrap(session.wordState().session)
            try session.require(after.position == 1 && after.currentWordID == "synthetic-adopt", "answer did not advance exactly one word")
            try session.require(session.progressCount() == 1, "answer was not saved exactly once")
            let memories = try session.store.records(projectID: session.project.id)
            try session.require(memories.count == 1 && memories[0].text.lowercased().contains("adapt") && memories[0].text.lowercased().contains("adopt"), "confusion was not recorded")

            try await session.turn("今天先到这里，请暂停并保留当前还没回答的那个词。", label: "03-pause")
            let paused = try XCTUnwrap(session.wordState().session)
            try session.require(paused.paused && paused.position == 1, "pause did not preserve the waiting word")
            try session.saveExitState(memoryID: memories[0].id, sessionID: paused.id, waitingWordID: "synthetic-adopt")
            try session.finish(success: true)
        } catch {
            try session.finish(success: false, error: error)
            XCTFail("Live part 1 failed. See the redacted evidence artifact.")
        }
    }

    @MainActor func testPart2RestartResumeFindAndCorrect() async throws {
        let (key, root) = try Self.configuration()
        let session = try LiveStudySession(key: key, root: root, phase: "part2", restoring: true)
        do {
            let exit = try XCTUnwrap(session.exitState)
            try session.require(exit.processID != ProcessInfo.processInfo.processIdentifier, "restart must use a different Swift process")
            try await session.turn("继续刚才未完成的一轮，告诉我停在哪个词。先不要替我作答，也不要给当前词记分。", label: "04-restart-and-continue")
            let resumed = try XCTUnwrap(session.wordState().session)
            try session.require(resumed.id == exit.sessionID && resumed.currentWordID == exit.waitingWordID && !resumed.paused, "restart did not resume the saved session")
            try session.require(session.progressCount() == 1, "resuming incorrectly added an answer")

            session.openNewWindow()
            try await session.turn("我刚开了新窗口。找回这个项目之前保存的 adapt/adopt 易混记录，再接着上一个窗口没完成的背词任务。只问当前那一题，先别替我回答。", label: "05-new-window-recall")
            let moved = try XCTUnwrap(session.wordState().session)
            try session.require(moved.id == exit.sessionID && moved.threadID == session.thread.id && moved.currentWordID == exit.waitingWordID, "new window did not recover the saved task")
            try session.require(session.store.records(projectID: session.project.id).first?.id == exit.memoryID, "new window did not read the same project memory")

            try await session.turn("更正那条已有的易混记录：我容易混的是 affect 和 effect，adapt 和 adopt 已经能区分了。请更正原记录，别另建一条，当前背词题也先别记分。", label: "06-correct-memory")
            let memories = try session.store.records(projectID: session.project.id)
            try session.require(memories.count == 1 && memories[0].id == exit.memoryID && memories[0].revision == 2, "correction did not update the original record")
            try session.require(memories[0].text.lowercased().contains("affect") && memories[0].text.lowercased().contains("effect"), "corrected content missing")
            try session.require(session.store.events(projectID: session.project.id).count == 2, "memory revision history missing or duplicated")
            try session.require(session.progressCount() == 1, "memory correction incorrectly scored a word")
            try await session.turn("确认一下，周报是不是已经更新好了？", label: "07-weekly-state")
            try session.finish(success: true)
        } catch {
            try session.finish(success: false, error: error)
            XCTFail("Live part 2 failed. See the redacted evidence artifact.")
        }
    }

    private static func configuration() throws -> (String, URL) {
        let env = ProcessInfo.processInfo.environment
        guard env["SERMO_RUN_LIVE"] == "1" else { throw XCTSkip("Live model tests run only from the manual opt-in workflow.") }
        guard let key = env["SERMO_STUDY_LIVE_DEEPSEEK_KEY"], !key.isEmpty,
              let root = env["SERMO_LIVE_EVIDENCE_DIR"], root.hasPrefix("/") else {
            throw LiveStudyFailure.failed("Missing required live-test Secret or output directory.")
        }
        return (key, URL(fileURLWithPath: root, isDirectory: true))
    }
}

private enum LiveStudyFailure: Error { case failed(String) }

@MainActor private final class LiveStudySession {
    struct ExitState: Codable {
        let snapshot: AppSnapshot
        let memoryID: UUID
        let sessionID: UUID
        let waitingWordID: String
        let processID: Int32
        let requests: Int
        let tokens: Int
    }
    struct DatabaseState: Encodable {
        let memories: [StudyMemoryRecord]
        let memoryEvents: [StudyMemoryEvent]
        let progress: [StudyWordProgress]
        let currentWindow: StudyWordState
        let archive: StudyMemoryArchive
    }
    struct Round: Encodable {
        let request: JSONValue
        let modelText: String
        let visibleText: String
        let calls: [ToolCall]
        let receipts: [String]
        let usage: TokenUsage?
    }
    struct Turn: Encodable {
        let label: String
        let userMessage: ChatMessage
        let threadID: UUID
        let before: DatabaseState
        var rounds: [Round] = []
        var after: DatabaseState?
        var error: String?
    }
    struct Report: Encodable {
        let phase: String
        let processID: Int32
        let model = "deepseek-flash"
        let data = "Synthetic vocabulary and synthetic user messages only"
        let implementation = "Shared Swift StudyToolExecutor, StudyMemoryStore, DeepSeekClient and client request settings"
        var status = "running"
        var requests = 0
        var tokens = 0
        var turns: [Turn] = []
        var error: String?
    }
    final class Buffer {
        var content = ""
        var visible = ""
        var collector = ToolCallCollector()
        var usage: TokenUsage?
        var guarder = StudyOutputGuard()
        func consume(_ event: StreamEvent) {
            content += event.content
            visible += guarder.consume(event.content, finish: event.isDone || event.finishReason != nil)
            collector.consume(event.toolCalls)
            if let usage = event.usage { self.usage = usage }
        }
    }
    let store: StudyMemoryStore
    let project: ChatProject
    let root: URL
    let phase: String
    let key: String
    let databaseURL: URL
    var settings: AppSettings
    var threads: [ChatThread]
    var activeIndex = 0
    var report: Report
    var exitState: ExitState?
    var thread: ChatThread { threads[activeIndex] }
    var scope: StudyScope { StudyScope(projectID: project.id, threadID: thread.id, subject: .english) }

    init(key: String, root: URL, phase: String, restoring: Bool) throws {
        self.key = key; self.root = root; self.phase = phase
        try FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)
        databaseURL = root.appendingPathComponent("synthetic-learning.sqlite")
        store = try StudyMemoryStore(url: databaseURL)
        report = Report(phase: phase, processID: ProcessInfo.processInfo.processIdentifier)
        if restoring {
            let saved = try StudyCoding.decode(ExitState.self, from: Data(contentsOf: root.appendingPathComponent("exit-state.json")))
            exitState = saved; settings = saved.snapshot.settings; threads = saved.snapshot.threads
            project = try XCTUnwrap(saved.snapshot.projects?.first)
            activeIndex = threads.firstIndex { $0.id == saved.snapshot.activeThreadID } ?? 0
            report.requests = saved.requests; report.tokens = saved.tokens
        } else {
            var config = AppSettings(); config.model = .flash; config.thinkingEnabled = false; config.maxOutputTokens = 1024
            settings = config
            var p = ChatProject(name: "合成英语验收"); p.id = StudySubject.english.projectID; p.studySubject = .english
            p.provider = .deepSeek; p.autoMemory = true; project = p
            var t = ChatThread(); t.projectID = p.id; t.modelSelection = ChatModelSelection(settings: config, project: p); threads = [t]
            let fixture = #"{"schema_version":"yanxi.private-import.v2-stage1","cards":[{"id":"synthetic-adapt","word":"adapt","translation_zh":"适应，改编（合成验收词条）","unit_order":[{"collection":"required","unit":1,"position":1}]},{"id":"synthetic-adopt","word":"adopt","translation_zh":"采纳，收养（合成验收词条）","unit_order":[{"collection":"required","unit":1,"position":2}]}]}"#
            try store.importWords(StudyWordPack.decode(Data(fixture.utf8)), projectID: p.id)
        }
    }
    func require(_ condition: @autoclosure () throws -> Bool, _ message: String) throws {
        guard try condition() else { throw LiveStudyFailure.failed(message) }
    }
    func wordState() throws -> StudyWordState { try store.wordState(scope: scope) }
    func progressCount() throws -> Int { try store.wordProgress(projectID: project.id).reduce(0) { $0 + $1.reviewCount } }
    private func state() throws -> DatabaseState {
        try DatabaseState(memories: store.records(projectID: project.id), memoryEvents: store.events(projectID: project.id),
                          progress: store.wordProgress(projectID: project.id), currentWindow: wordState(), archive: store.export(projectIDs: [project.id]))
    }
    private func write<T: Encodable>(_ value: T, name: String) throws {
        let encoder = JSONEncoder(); encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        let safe = String(decoding: try encoder.encode(value), as: UTF8.self).replacingOccurrences(of: key, with: "[REDACTED]")
        try Data(safe.utf8).write(to: root.appendingPathComponent(name), options: .atomic)
    }
    private func copyDatabase(_ name: String) throws {
        let target = root.appendingPathComponent(name + ".sqlite")
        guard !FileManager.default.fileExists(atPath: target.path) else { throw LiveStudyFailure.failed("Evidence file already exists") }
        try FileManager.default.copyItem(at: databaseURL, to: target)
    }
    func turn(_ text: String, label: String) async throws {
        let message = ChatMessage(role: .user, content: text)
        threads[activeIndex].messages.append(message)
        let executor = StudyToolExecutor(store: store, scope: scope, documents: project.documents)
        let config = (thread.modelSelection ?? ChatModelSelection(settings: settings, project: project)).applying(to: settings)
        let prompt = try [project.systemPrompt, executor.context(query: text), StudyTools.note, StudyWordTools.note].filter { !$0.isEmpty }.joined(separator: "\n\n")
        var request = ChatRequest(settings: config, messages: thread.messages, systemPrompt: prompt).withTools(StudyTools.specs + StudyWordTools.specs)
        report.turns.append(Turn(label: label, userMessage: message, threadID: thread.id, before: try state()))
        let index = report.turns.count - 1
        try copyDatabase(label + "-before")
        try write(report, name: phase + "-conversation.json")
        var answer = ""
        do {
            for round in 0..<ToolLoop.maxRounds {
                guard report.requests < 24, report.tokens < 150_000 else { throw LiveStudyFailure.failed("Live request budget reached") }
                if round == ToolLoop.maxRounds - 1 { request = request.answeringWithoutTools() }
                report.requests += 1
                let buffer = Buffer()
                try await DeepSeekClient(requestTimeout: 45, resourceTimeout: 90).stream(request: request, key: key) { event in buffer.consume(event) }
                if let usage = buffer.usage { report.tokens += usage.totalTokens }
                answer += buffer.visible
                let calls = buffer.collector.calls
                var receipts: [String] = []
                if !calls.isEmpty {
                    for call in calls {
                        do { receipts.append(try executor.perform(StudyToolAction(call), sourceMessage: message)) }
                        catch { receipts.append("应用操作未完成：" + error.localizedDescription) }
                    }
                }
                let body = try StudyCoding.decode(JSONValue.self, from: JSONEncoder().encode(request))
                report.turns[index].rounds.append(Round(request: body, modelText: buffer.content, visibleText: buffer.visible, calls: calls, receipts: receipts, usage: buffer.usage))
                try write(report, name: phase + "-conversation.json")
                if calls.isEmpty { break }
                guard round < ToolLoop.maxRounds - 1 else { throw LiveStudyFailure.failed("Tool loop exhausted") }
                request = request.appending([.assistantCalls(calls, content: buffer.content, reasoning: "")])
                for (call, receipt) in zip(calls, receipts) { request = request.appending([.toolResult(receipt, callID: call.id)]) }
            }
            try require(!answer.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty, "No final answer")
            threads[activeIndex].messages.append(ChatMessage(role: .assistant, content: answer))
            report.turns[index].after = try state()
            try copyDatabase(label + "-after")
            try write(report, name: phase + "-conversation.json")
        } catch {
            report.turns[index].error = String(describing: error)
            report.turns[index].after = try? state()
            try write(report, name: phase + "-conversation.json")
            throw error
        }
    }
    func saveExitState(memoryID: UUID, sessionID: UUID, waitingWordID: String) throws {
        let snapshot = AppSnapshot(settings: settings, threads: threads, activeThreadID: thread.id, projects: [project])
        // Use the client's snapshot round-trip, including its persisted date precision.
        let persisted = try AppSnapshot.decode(snapshot.encoded())
        let state = ExitState(snapshot: persisted, memoryID: memoryID, sessionID: sessionID, waitingWordID: waitingWordID,
                              processID: ProcessInfo.processInfo.processIdentifier, requests: report.requests, tokens: report.tokens)
        try write(state, name: "exit-state.json")
    }
    func openNewWindow() {
        var next = ChatThread(); next.projectID = project.id
        next.modelSelection = ChatModelSelection(settings: settings, project: project)
        threads.append(next); activeIndex = threads.count - 1
    }
    func finish(success: Bool, error: Error? = nil) throws {
        report.status = success ? "passed" : "failed"
        report.error = error.map { String(describing: $0) }
        try write(report, name: phase + "-conversation.json")
        try write(try state(), name: phase + "-final-database.json")
    }
}
