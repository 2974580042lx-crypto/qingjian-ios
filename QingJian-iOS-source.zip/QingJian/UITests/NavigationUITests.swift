import XCTest

final class NavigationUITests: XCTestCase {
    @MainActor private func launchLongChat() -> XCUIApplication {
        let app = XCUIApplication()
        app.launchArguments = ["--ui-preview", "--preview-long", "-AppleLanguages", "(zh-Hans)", "-AppleLocale", "zh_CN"]
        app.launch()
        XCTAssertTrue(app.scrollViews["chat-scroll"].waitForExistence(timeout: 8))
        return app
    }

    @MainActor private func capture(_ app: XCUIApplication, name: String) {
        let attachment = XCTAttachment(screenshot: app.screenshot())
        attachment.name = name
        attachment.lifetime = .keepAlways
        add(attachment)
    }

    @MainActor func testRightHalfSwipeOpensAndClosesSidebar() {
        let app = launchLongChat()
        let close = app.buttons["关闭历史对话"]
        XCTAssertFalse(close.isHittable, "The sidebar starts closed.")
        let start = app.coordinate(withNormalizedOffset: CGVector(dx: 0.65, dy: 0.43))
        let end = app.coordinate(withNormalizedOffset: CGVector(dx: 0.97, dy: 0.43))
        start.press(forDuration: 0.02, thenDragTo: end)
        let opened = XCTNSPredicateExpectation(predicate: NSPredicate(format: "hittable == true"), object: close)
        XCTAssertEqual(XCTWaiter.wait(for: [opened], timeout: 4), .completed, "A right-half swipe must open the sidebar without starting at the edge.")
        capture(app, name: "sidebar-opened-from-right-half")
        app.coordinate(withNormalizedOffset: CGVector(dx: 0.66, dy: 0.43))
            .press(forDuration: 0.02, thenDragTo: app.coordinate(withNormalizedOffset: CGVector(dx: 0.08, dy: 0.43)))
        let disappeared = XCTNSPredicateExpectation(predicate: NSPredicate(format: "hittable == false"), object: close)
        XCTAssertEqual(XCTWaiter.wait(for: [disappeared], timeout: 4), .completed)
        capture(app, name: "sidebar-closed-after-left-swipe")
    }

    @MainActor func testFullHeightVerticalScrollKeepsLastLineReadable() {
        let app = launchLongChat()
        let scroll = app.scrollViews["chat-scroll"]
        let composer = app.descendants(matching: .any).matching(identifier: "chat-composer-panel").firstMatch
        let navigation = app.tabBars.firstMatch
        XCTAssertTrue(composer.waitForExistence(timeout: 3))
        XCTAssertTrue(navigation.waitForExistence(timeout: 3))
        XCTAssertGreaterThan(scroll.frame.maxY, app.frame.maxY - 40, "The scroll view must continue behind the floating navigation.")
        let visibleTabTop = min(navigation.buttons["聊天"].frame.minY, navigation.buttons["设置"].frame.minY)
        XCTAssertLessThan(composer.frame.maxY, visibleTabTop + 2, "The composer must not cover native tab buttons.")

        let end = app.staticTexts["滚动检查结束"]
        for index in 0..<10 {
            if end.isHittable && end.frame.maxY < composer.frame.minY { break }
            app.coordinate(withNormalizedOffset: CGVector(dx: 0.78, dy: 0.68))
                .press(forDuration: 0.01, thenDragTo: app.coordinate(withNormalizedOffset: CGVector(dx: 0.78, dy: 0.22)))
            if index == 0 { capture(app, name: "full-height-mid-scroll") }
        }
        XCTAssertFalse(app.buttons["关闭历史对话"].isHittable, "Vertical scrolling must not open the sidebar.")
        XCTAssertTrue(end.isHittable, "The last line must be reachable.")
        XCTAssertLessThan(end.frame.maxY, composer.frame.minY, "The last line must be readable above the composer.")
        capture(app, name: "last-line-above-floating-controls")
    }

    @MainActor func testKeyboardHidesNavigationAndKeepsComposerVisible() {
        let app = launchLongChat()
        let field = app.descendants(matching: .any).matching(identifier: "chat-composer").firstMatch
        XCTAssertTrue(field.waitForExistence(timeout: 3))
        field.tap()
        let keyboard = app.keyboards.firstMatch
        XCTAssertTrue(keyboard.waitForExistence(timeout: 5))
        let composer = app.descendants(matching: .any).matching(identifier: "chat-composer-panel").firstMatch
        XCTAssertFalse(app.tabBars.firstMatch.isHittable)
        XCTAssertLessThanOrEqual(composer.frame.maxY, keyboard.frame.minY + 3)
        capture(app, name: "keyboard-and-floating-composer")
    }

    @MainActor func testSendingKeepsTheNewReplyAboveComposer() {
        let app = launchLongChat()
        let field = app.descendants(matching: .any).matching(identifier: "chat-composer").firstMatch
        field.tap()
        field.typeText("123")
        app.buttons["发送消息"].tap()
        let reply = app.staticTexts["这是界面预览中的示例回答。"]
        XCTAssertTrue(reply.waitForExistence(timeout: 5))
        XCTAssertTrue(reply.isHittable)
        let composer = app.descendants(matching: .any).matching(identifier: "chat-composer-panel").firstMatch
        XCTAssertLessThan(reply.frame.maxY, composer.frame.minY, "New replies must scroll into the readable area above the composer.")
        capture(app, name: "new-reply-above-composer")
    }

    @MainActor func testNativeTabBarSupportsPressAndDragSelection() {
        let app = launchLongChat()
        let bar = app.tabBars.firstMatch
        XCTAssertTrue(bar.waitForExistence(timeout: 3))
        let chat = bar.buttons["聊天"]
        let settings = bar.buttons["设置"]
        XCTAssertTrue(chat.isHittable && settings.isHittable)
        chat.press(forDuration: 0.4, thenDragTo: settings)
        XCTAssertTrue(app.navigationBars["设置"].waitForExistence(timeout: 4))
        capture(app, name: "native-tab-drag-to-settings")
        app.tabBars.firstMatch.buttons["设置"].press(forDuration: 0.4, thenDragTo: app.tabBars.firstMatch.buttons["聊天"])
        XCTAssertTrue(app.scrollViews["chat-scroll"].waitForExistence(timeout: 4))
        capture(app, name: "native-tab-drag-back-to-chat")
    }
}
