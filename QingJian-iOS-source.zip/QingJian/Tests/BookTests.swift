import XCTest
@testable import DeepSeekCore

final class BookTests: XCTestCase {
    private let body = String(repeating: "他推开门，看见院子里的桂花落了一地。", count: 5)

    func testHeadingsSplitChaptersAndVolumeLinesJoinTheNextTitle() {
        let text = "第一卷 风起\n第一章 雨夜\n\(body)\n第二章 来客\n\(body)\n第三回 别离\n\(body)"
        let chapters = ChapterSplitter.split(text)
        XCTAssertEqual(chapters.map(\.title), ["第一卷 风起 · 第一章 雨夜", "第二章 来客", "第三回 别离"])
        XCTAssertEqual(chapters[1].text, body)
    }

    func testTextWithoutHeadingsIsCutIntoParts() {
        let text = (0..<40).map { _ in String(repeating: "雨", count: 400) }.joined(separator: "\n")
        let chapters = ChapterSplitter.split(text)
        XCTAssertGreaterThan(chapters.count, 1)
        XCTAssertEqual(chapters.first?.title, "第 1 段")
        XCTAssertEqual(chapters.reduce(0) { $0 + $1.text.filter { $0 == "雨" }.count }, 16000)
    }

    func testSegmentsGroupChaptersAndAShortTailJoinsTheLastOne() {
        func chapters(_ sizes: [Int]) -> [BookChapter] { sizes.map { BookChapter(title: "章", text: String(repeating: "字", count: $0)) } }
        XCTAssertEqual(ChapterSplitter.segments(for: chapters([15000, 15000, 15000, 15000, 15000])),
                       [BookSegment(first: 0, last: 2), BookSegment(first: 3, last: 4)])
        XCTAssertEqual(ChapterSplitter.segments(for: chapters([40000, 5000])), [BookSegment(first: 0, last: 1)])
        XCTAssertEqual(ChapterSplitter.segments(for: chapters([3000])), [BookSegment(first: 0, last: 0)])
    }

    func testGBKTextDecodesAndIsNormalized() throws {
        let original = "林黛玉进贾府，见过了外祖母。"
        let gb = String.Encoding(rawValue: CFStringConvertEncodingToNSStringEncoding(CFStringEncoding(0x0632)))
        let data = try XCTUnwrap(original.data(using: gb))
        XCTAssertNil(String(data: data, encoding: .utf8))
        XCTAssertEqual(BookText.decode(data), original)
        XCTAssertEqual(BookText.normalized("\u{3000}\u{3000}第一段\r\n\r\n\r\n第二段  "), "第一段\n\n第二段")
        XCTAssertEqual(BookText.title(fromFileName: "《红楼梦》(精校版).txt"), "红楼梦")
    }

    func testSegmentNotesKeepOnlyQuotesAndPassagesFoundInTheText() throws {
        let chapters = [BookChapter(title: "第一章", text: "宝玉笑道：“这个妹妹我曾见过的。”\n窗外的竹影在风里摇着，一阵一阵地扫过窗纸，屋里只点着一盏灯。")]
        let answer = """
        ```json
        {"plot":"宝玉初见黛玉。","characters":[{"name":"贾宝玉","aliases":["宝玉"],"notes":"初见黛玉便说似曾相识。","quotes":["这个妹妹我曾见过的。","我从来没说过这句话呢"]}],
         "scenes":[{"title":"初见","chapter":"第1章","summary":"两人初见。","characters":["贾宝玉"]}],"terms":[],
         "excerpts":["窗外的竹影在风里摇着，一阵一阵地扫过窗纸","这一句原文里没有出现过"]}
        ```
        """
        let note = try BookReading.parseSegment(answer, segment: BookSegment(first: 0, last: 0), chapters: chapters)
        XCTAssertEqual(note.plot, "宝玉初见黛玉。")
        XCTAssertEqual(note.characters.first?.quotes, ["这个妹妹我曾见过的。"])
        XCTAssertEqual(note.characters.first?.aliases, ["宝玉"])
        XCTAssertEqual(note.scenes.first?.chapter, 0)
        XCTAssertEqual(note.excerpts.count, 1)
        XCTAssertTrue(note.excerpts[0].hasPrefix("窗外的竹影"))
        XCTAssertThrowsError(try BookReading.parseSegment("{\"characters\":[]}", segment: BookSegment(first: 0, last: 0), chapters: chapters))
    }

    func testCharactersMergeAcrossSegmentsByAlias() {
        let first = SegmentNote(segment: BookSegment(first: 0, last: 1), plot: "甲", characters: [.init(name: "贾宝玉", aliases: ["宝玉"], notes: "一")])
        let second = SegmentNote(segment: BookSegment(first: 2, last: 3), plot: "乙", characters: [.init(name: "宝玉", aliases: ["宝二爷"], notes: "二")])
        let merged = BookReading.mergedCharacters([first, second])
        XCTAssertEqual(merged.count, 1)
        XCTAssertEqual(merged[0].name, "贾宝玉")
        XCTAssertEqual(Set(merged[0].aliases), ["宝玉", "宝二爷"])
        XCTAssertEqual(merged[0].notes.map { $0.text }, ["一", "二"])
    }

    func testPassagesStayBeforeTheChapterLimit() {
        let chapters = [BookChapter(title: "一", text: "潇湘馆里竹影摇曳，黛玉独自坐着。"),
                        BookChapter(title: "二", text: "大观园里，潇湘馆的竹子被雪压弯了。")]
        let paragraphs = BookPassages.paragraphs(of: chapters)
        let early = BookPassages.find(in: "我们去潇湘馆看看", vocabulary: ["潇湘馆", "黛玉", "大观园"], paragraphs: paragraphs,
                                      upTo: 0, excluding: [])
        XCTAssertEqual(early.terms, ["潇湘馆"])
        XCTAssertEqual(early.passages, ["潇湘馆里竹影摇曳，黛玉独自坐着。"])
        let all = BookPassages.find(in: "我们去潇湘馆看看", vocabulary: ["潇湘馆"], paragraphs: paragraphs, upTo: 1, excluding: [])
        XCTAssertEqual(all.passages.first, "大观园里，潇湘馆的竹子被雪压弯了。")
        XCTAssertTrue(BookPassages.find(in: "黛玉在吗", vocabulary: ["黛玉"], paragraphs: paragraphs, upTo: 1, excluding: ["黛玉"]).passages.isEmpty)
    }

    func testStoryPromptCarriesTheCharacterAndTheUsersRole() {
        var book = Book(title: "红楼梦", characterCount: 100, chapterTitles: ["一"], segments: [BookSegment(first: 0, last: 0)], notes: [nil])
        var profile = BookProfile()
        profile.characters = [BookCharacter(name: "林黛玉", identity: "贾母的外孙女"), BookCharacter(name: "贾宝玉", identity: "荣国府公子")]
        profile.style = BookStyle(description: "白话夹文言。", excerpts: ["原文片段"])
        book.profile = profile
        book.status = .ready
        let session = StorySession(bookID: book.id, bookTitle: book.title, character: "林黛玉", userRole: "贾宝玉")
        let prompt = StoryPrompt.compose(session, book: book)
        XCTAssertTrue(prompt.contains("你扮演林黛玉"))
        XCTAssertTrue(prompt.contains("【林黛玉】"))
        XCTAssertTrue(prompt.contains("【用户扮演的贾宝玉】"))
        XCTAssertTrue(prompt.contains("白话夹文言。"))
        XCTAssertFalse(prompt.contains("- 贾宝玉："), "The user's own character is not listed again among the others.")
        XCTAssertTrue(StoryPrompt.compose(session, book: nil).contains("已从书架移除"))
    }
    func testTimePointKeepsLaterStoryOutOfThePrompt() {
        var book = Book(title: "红楼梦", characterCount: 100, chapterTitles: ["一", "二", "三", "四"],
                        segments: [BookSegment(first: 0, last: 1), BookSegment(first: 2, last: 3)], notes: [nil, nil])
        var profile = BookProfile()
        var daiyu = BookCharacter(name: "林黛玉", identity: "贾母的外孙女")
        daiyu.arc = "LATER_ARC"
        daiyu.relationships = "LATER_RELATIONS"
        daiyu.quotes = [BookQuote(text: "EARLY_LINE", chapter: 0), BookQuote(text: "LATE_LINE", chapter: 3)]
        var baochai = BookCharacter(name: "薛宝钗", identity: "薛家小姐")
        baochai.firstChapter = 3
        profile.characters = [daiyu, baochai]
        profile.summary = "WHOLE_BOOK_SUMMARY"
        profile.terms = [BookTerm(term: "潇湘馆", note: "黛玉的住处", chapter: 2), BookTerm(term: "荣国府", note: "贾府", chapter: 0)]
        book.profile = profile
        book.status = .ready
        var session = StorySession(bookID: book.id, bookTitle: book.title, character: "林黛玉")
        session.chapter = 1
        session.briefing = "BRIEFING_TEXT"
        session.instruction = "MY_RULES"
        let prompt = StoryPrompt.compose(session, book: book)
        XCTAssertTrue(prompt.contains("BRIEFING_TEXT"))
        XCTAssertTrue(prompt.contains("EARLY_LINE"))
        for hidden in ["LATE_LINE", "LATER_ARC", "LATER_RELATIONS", "WHOLE_BOOK_SUMMARY", "薛宝钗"] {
            XCTAssertFalse(prompt.contains(hidden), hidden)
        }
        XCTAssertTrue(prompt.hasSuffix("MY_RULES"), "The player's own rules come last.")
        XCTAssertEqual(StoryPrompt.vocabulary(of: profile, upTo: 1).sorted(), ["林黛玉", "荣国府"].sorted())

        session.chapter = nil
        let whole = StoryPrompt.compose(session, book: book)
        XCTAssertTrue(whole.contains("LATER_ARC") && whole.contains("WHOLE_BOOK_SUMMARY") && whole.contains("薛宝钗"))
    }

    func testGuestsAndOwnCardsJoinThePrompt() {
        var home = Book(title: "红楼梦", characterCount: 1, chapterTitles: ["一"], segments: [BookSegment(first: 0, last: 0)], notes: [nil])
        var homeProfile = BookProfile()
        homeProfile.characters = [BookCharacter(name: "林黛玉", identity: "贾母的外孙女")]
        home.profile = homeProfile
        var away = Book(title: "三国演义", characterCount: 1, chapterTitles: ["一"], segments: [BookSegment(first: 0, last: 0)], notes: [nil])
        var awayProfile = BookProfile()
        awayProfile.characters = [BookCharacter(name: "诸葛亮", identity: "蜀汉丞相")]
        away.profile = awayProfile
        var session = StorySession(bookID: home.id, bookTitle: home.title, character: "林黛玉", userRole: "阿青")
        session.guests = [StoryGuest(bookID: away.id, bookTitle: away.title, character: "诸葛亮")]
        session.userCard = "江南来的绣娘，爱笑"
        let prompt = StoryPrompt.compose(session, book: home, guestBooks: [away])
        XCTAssertTrue(prompt.contains("你扮演林黛玉、诸葛亮"))
        XCTAssertTrue(prompt.contains("【客串人物：诸葛亮（来自《三国演义》）】"))
        XCTAssertTrue(prompt.contains("蜀汉丞相"))
        XCTAssertTrue(prompt.contains("【用户扮演的阿青】\n江南来的绣娘，爱笑"))
    }

    func testBriefingReadsOnlyUpToTheStartingChapter() {
        var book = Book(title: "书", characterCount: 1, chapterTitles: ["一", "二", "三", "四"],
                        segments: [BookSegment(first: 0, last: 1), BookSegment(first: 2, last: 3)], notes: [nil, nil])
        book.notes = [SegmentNote(segment: BookSegment(first: 0, last: 1), plot: "EARLY_PLOT"),
                      SegmentNote(segment: BookSegment(first: 2, last: 3), plot: "LATE_PLOT")]
        let request = BookReading.briefingRequest(book: book, chapter: 1, character: "甲", userRole: "")
        let text = request.messages.last?.content ?? ""
        XCTAssertTrue(text.contains("EARLY_PLOT"))
        XCTAssertFalse(text.contains("LATE_PLOT"))
    }
    func testCharacterPassagesAreSpeechByThatCharacterBeforeTheLimit() {
        let chapters = [
            BookChapter(title: "一", text: "黛玉冷笑道：“我说呢，亏了绊住，不然早就飞了来了。”众人听了都笑起来，屋里一时热闹得很。"),
            BookChapter(title: "二", text: "这一日天气晴好，园子里的花开得正盛，小丫头们在廊下说笑，风吹过竹梢沙沙地响。"),
            BookChapter(title: "三", text: "黛玉道：“你又来招我。”说着便把脸转了过去，半日不肯回头，只拿帕子拭着眼角。")]
        let paragraphs = BookPassages.paragraphs(of: chapters)
        let early = BookPassages.characterPassages(names: ["林黛玉", "黛玉"], paragraphs: paragraphs, upTo: 1)
        XCTAssertEqual(early.count, 1)
        XCTAssertTrue(early[0].hasPrefix("黛玉冷笑道"))
        XCTAssertEqual(BookPassages.characterPassages(names: ["黛玉"], paragraphs: paragraphs, upTo: 2).count, 2)
    }

    func testDeepReadsKeepTheCardAndPickVerbatimExcerpts() throws {
        let card = BookCharacter(name: "林黛玉", identity: "旧身份", speech: "旧说话方式")
        let answer = #"{"personality":"敏感多思，嘴上不饶人。","behavior":"受了委屈先刺人，再独自落泪。","taboos":"不会撒娇讨好。"}"#
        let next = try BookReading.parseCharacterDeepRead(answer, into: card)
        XCTAssertEqual(next.personality, "敏感多思，嘴上不饶人。")
        XCTAssertEqual(next.identity, "旧身份", "Fields the read leaves out stay as they were.")
        XCTAssertEqual(next.behavior, "受了委屈先刺人，再独自落泪。")
        XCTAssertNotNil(next.deepReadAt)
        XCTAssertThrowsError(try BookReading.parseCharacterDeepRead("{}", into: card))

        let samples = ["第一段原文。", "第二段原文。", "第三段原文。"]
        let style = try BookReading.parseStyleDeepRead(#"{"description":"短句白描。","signatures":["多用短句"],"avoid":["仿佛"],"best":[3,"1",9]}"#,
                                                       into: BookStyle(description: "旧", excerpts: ["旧片段"]), samples: samples)
        XCTAssertEqual(style.description, "短句白描。")
        XCTAssertEqual(style.excerpts, ["第三段原文。", "第一段原文。"])
        XCTAssertEqual(style.avoid, ["仿佛"])
    }

    func testPromptCarriesCorrectionsPassagesAndStyleRules() {
        var book = Book(title: "红楼梦", characterCount: 1, chapterTitles: ["一"], segments: [BookSegment(first: 0, last: 0)], notes: [nil])
        var profile = BookProfile()
        var daiyu = BookCharacter(name: "林黛玉", identity: "贾母的外孙女")
        daiyu.taboos = "不会撒娇讨好"
        daiyu.corrections = ["她不会直说喜欢"]
        profile.characters = [daiyu]
        profile.style = BookStyle(description: "白话夹文言。", excerpts: [], signatures: ["多用短句"], avoid: ["仿佛"])
        book.profile = profile
        var session = StorySession(bookID: book.id, bookTitle: book.title, character: "林黛玉")
        session.characterPassages = ["黛玉冷笑道：“我说呢。”"]
        let prompt = StoryPrompt.compose(session, book: book)
        for expected in ["绝不会说或做的事：不会撒娇讨好", "- 她不会直说喜欢", "【原著里的林黛玉】", "黛玉冷笑道", "- 多用短句", "- 仿佛"] {
            XCTAssertTrue(prompt.contains(expected), expected)
        }
    }
    func testPriceBandSaysWhenItEnds() throws {
        var calendar = Calendar(identifier: .gregorian)
        calendar.timeZone = try XCTUnwrap(TimeZone(identifier: "Asia/Shanghai"))
        let wednesday = try XCTUnwrap(calendar.date(from: DateComponents(year: 2026, month: 10, day: 21, hour: 10, minute: 30)))
        XCTAssertEqual(Pricing.statusLabel(at: wednesday), "高峰时段 · 到 12:00 结束")
        let lunch = try XCTUnwrap(calendar.date(from: DateComponents(year: 2026, month: 10, day: 21, hour: 12, minute: 5)))
        XCTAssertEqual(Pricing.statusLabel(at: lunch), "空闲时段 · 半价，到 14:00")
        let friday = try XCTUnwrap(calendar.date(from: DateComponents(year: 2026, month: 10, day: 23, hour: 19)))
        XCTAssertEqual(Pricing.statusLabel(at: friday), "空闲时段 · 半价，到 周一 09:00")
    }

    func testBooksReadWithFlashUnlessSetToPro() {
        var book = Book(title: "书", characterCount: 1, chapterTitles: ["一"], segments: [BookSegment(first: 0, last: 0)], notes: [nil])
        let chapters = [BookChapter(title: "一", text: "正文")]
        XCTAssertEqual(BookReading.segmentRequest(book: book, segment: book.segments[0], chapters: chapters).model, DeepSeekModel.flash.rawValue)
        book.readingModel = .pro
        XCTAssertEqual(BookReading.segmentRequest(book: book, segment: book.segments[0], chapters: chapters).model, DeepSeekModel.pro.rawValue)
    }
}
