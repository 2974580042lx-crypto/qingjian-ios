import XCTest
@testable import DeepSeekCore

final class BookTests: XCTestCase {
    private let body = String(repeating: "他推开门，看见院子里的桂花落了一地。", count: 5)

    func testHeadingsSplitChaptersAndVolumeLinesJoinTheNextTitle() {
        let text = "第一卷 风起\n第一章 雨夜\n\(body)\n第二章 来客\n\(body)\n第三回 别离\n\(body)"
        let chapters = ChapterSplitter.split(text)
        XCTAssertEqual(chapters.map(\.title), ["第一卷 风起 · 第一章 雨夜", "第二章 来客", "第三回 别离"])
        XCTAssertEqual(chapters[1].text, body)
    }

    func testTextWithoutHeadingsIsCutIntoParts() {
        let text = (0..<40).map { _ in String(repeating: "雨", count: 400) }.joined(separator: "\n")
        let chapters = ChapterSplitter.split(text)
        XCTAssertGreaterThan(chapters.count, 1)
        XCTAssertEqual(chapters.first?.title, "第 1 段")
        XCTAssertEqual(chapters.reduce(0) { $0 + $1.text.filter { $0 == "雨" }.count }, 16000)
    }

    func testSegmentsGroupChaptersAndAShortTailJoinsTheLastOne() {
        func chapters(_ sizes: [Int]) -> [BookChapter] { sizes.map { BookChapter(title: "章", text: String(repeating: "字", count: $0)) } }
        XCTAssertEqual(ChapterSplitter.segments(for: chapters([15000, 15000, 15000, 15000, 15000])),
                       [BookSegment(first: 0, last: 2), BookSegment(first: 3, last: 4)])
        XCTAssertEqual(ChapterSplitter.segments(for: chapters([40000, 5000])), [BookSegment(first: 0, last: 1)])
        XCTAssertEqual(ChapterSplitter.segments(for: chapters([3000])), [BookSegment(first: 0, last: 0)])
    }

    func testGBKTextDecodesAndIsNormalized() throws {
        let original = "林黛玉进贾府，见过了外祖母。"
        let gb = String.Encoding(rawValue: CFStringConvertEncodingToNSStringEncoding(CFStringEncoding(0x0632)))
        let data = try XCTUnwrap(original.data(using: gb))
        XCTAssertNil(String(data: data, encoding: .utf8))
        XCTAssertEqual(BookText.decode(data), original)
        XCTAssertEqual(BookText.normalized("\u{3000}\u{3000}第一段\r\n\r\n\r\n第二段  "), "第一段\n\n第二段")
        XCTAssertEqual(BookText.title(fromFileName: "《红楼梦》(精校版).txt"), "红楼梦")
    }

    func testSegmentNotesKeepOnlyQuotesAndPassagesFoundInTheText() throws {
        let chapters = [BookChapter(title: "第一章", text: "宝玉笑道：“这个妹妹我曾见过的。”\n窗外的竹影在风里摇着，一阵一阵地扫过窗纸，屋里只点着一盏灯。")]
        let answer = """
        ```json
        {"plot":"宝玉初见黛玉。","characters":[{"name":"贾宝玉","aliases":["宝玉"],"notes":"初见黛玉便说似曾相识。","quotes":["这个妹妹我曾见过的。","我从来没说过这句话呢"]}],
         "scenes":[{"title":"初见","chapter":"第1章","summary":"两人初见。","characters":["贾宝玉"]}],"terms":[],
         "excerpts":["窗外的竹影在风里摇着，一阵一阵地扫过窗纸","这一句原文里没有出现过"]}
        ```
        """
        let note = try BookReading.parseSegment(answer, segment: BookSegment(first: 0, last: 0), chapters: chapters)
        XCTAssertEqual(note.plot, "宝玉初见黛玉。")
        XCTAssertEqual(note.characters.first?.quotes, ["这个妹妹我曾见过的。"])
        XCTAssertEqual(note.characters.first?.aliases, ["宝玉"])
        XCTAssertEqual(note.scenes.first?.chapter, 0)
        XCTAssertEqual(note.excerpts.count, 1)
        XCTAssertTrue(note.excerpts[0].hasPrefix("窗外的竹影"))
        XCTAssertThrowsError(try BookReading.parseSegment("{\"characters\":[]}", segment: BookSegment(first: 0, last: 0), chapters: chapters))
    }

    func testCharactersMergeAcrossSegmentsByAlias() {
        let first = SegmentNote(segment: BookSegment(first: 0, last: 1), plot: "甲", characters: [.init(name: "贾宝玉", aliases: ["宝玉"], notes: "一")])
        let second = SegmentNote(segment: BookSegment(first: 2, last: 3), plot: "乙", characters: [.init(name: "宝玉", aliases: ["宝二爷"], notes: "二")])
        let merged = BookReading.mergedCharacters([first, second])
        XCTAssertEqual(merged.count, 1)
        XCTAssertEqual(merged[0].name, "贾宝玉")
        XCTAssertEqual(Set(merged[0].aliases), ["宝玉", "宝二爷"])
        XCTAssertEqual(merged[0].notes.map { $0.text }, ["一", "二"])
    }

    func testPassagesStayBeforeTheChapterLimit() {
        let chapters = [BookChapter(title: "一", text: "潇湘馆里竹影摇曳，黛玉独自坐着。"),
                        BookChapter(title: "二", text: "大观园里，潇湘馆的竹子被雪压弯了。")]
        let paragraphs = BookPassages.paragraphs(of: chapters)
        let early = BookPassages.find(in: "我们去潇湘馆看看", vocabulary: ["潇湘馆", "黛玉", "大观园"], paragraphs: paragraphs,
                                      upTo: 0, excluding: [])
        XCTAssertEqual(early.terms, ["潇湘馆"])
        XCTAssertEqual(early.passages, ["潇湘馆里竹影摇曳，黛玉独自坐着。"])
        let all = BookPassages.find(in: "我们去潇湘馆看看", vocabulary: ["潇湘馆"], paragraphs: paragraphs, upTo: 1, excluding: [])
        XCTAssertEqual(all.passages.first, "大观园里，潇湘馆的竹子被雪压弯了。")
        XCTAssertTrue(BookPassages.find(in: "黛玉在吗", vocabulary: ["黛玉"], paragraphs: paragraphs, upTo: 1, excluding: ["黛玉"]).passages.isEmpty)
    }

    func testStoryPromptCarriesTheCharacterAndTheUsersRole() {
        var book = Book(title: "红楼梦", characterCount: 100, chapterTitles: ["一"], segments: [BookSegment(first: 0, last: 0)], notes: [nil])
        var profile = BookProfile()
        profile.characters = [BookCharacter(name: "林黛玉", identity: "贾母的外孙女"), BookCharacter(name: "贾宝玉", identity: "荣国府公子")]
        profile.style = BookStyle(description: "白话夹文言。", excerpts: ["原文片段"])
        book.profile = profile
        book.status = .ready
        let session = StorySession(bookID: book.id, bookTitle: book.title, character: "林黛玉", userRole: "贾宝玉")
        let prompt = StoryPrompt.compose(session, book: book)
        XCTAssertTrue(prompt.contains("你扮演林黛玉"))
        XCTAssertTrue(prompt.contains("【林黛玉】"))
        XCTAssertTrue(prompt.contains("【用户扮演的贾宝玉】"))
        XCTAssertTrue(prompt.contains("白话夹文言。"))
        XCTAssertFalse(prompt.contains("- 贾宝玉："), "The user's own character is not listed again among the others.")
        XCTAssertTrue(StoryPrompt.compose(session, book: nil).contains("已从书架移除"))
    }
}
