import XCTest
import Foundation
@testable import DeepSeekCore

final class TemperatureTests: XCTestCase {
    private func object(of request: ChatRequest) throws -> [String: Any] {
        let data = try JSONEncoder().encode(request)
        return try XCTUnwrap(JSONSerialization.jsonObject(with: data) as? [String: Any])
    }

    func testTemperatureIsSentWhenSet() throws {
        var settings = AppSettings()
        settings.temperature = 1.3
        let request = ChatRequest(settings: settings, messages: [ChatMessage(role: .user, content: "你好")])
        let json = try object(of: request)
        XCTAssertEqual(try XCTUnwrap(json["temperature"] as? Double), 1.3, accuracy: 0.0001)
    }

    func testTemperatureIsOmittedByDefault() throws {
        let request = ChatRequest(settings: AppSettings(), messages: [ChatMessage(role: .user, content: "你好")])
        XCTAssertNil(try object(of: request)["temperature"])
    }

    func testTemperatureIsClampedToTheSupportedRange() {
        var settings = AppSettings()
        settings.temperature = 9
        XCTAssertEqual(settings.validated().temperature ?? -1, 2, accuracy: 0.0001)
        settings.temperature = -2
        XCTAssertEqual(settings.validated().temperature ?? -1, 0, accuracy: 0.0001)
    }

    func testProjectTemperatureMustBeInRange() {
        var project = ChatProject(name: "测试")
        project.temperature = 2.5
        XCTAssertThrowsError(try project.validate())
        project.temperature = 1.1
        XCTAssertNoThrow(try project.validate())
    }
}
