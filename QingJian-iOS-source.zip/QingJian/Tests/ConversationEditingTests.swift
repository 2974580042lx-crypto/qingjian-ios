import Foundation
import XCTest
@testable import DeepSeekCore

final class ConversationEditingTests: XCTestCase {
    func testEditingUserPreservesOriginalAndCutsStaleAnswers() throws {
        var original = ChatThread()
        original.messages = [ChatMessage(role: .user, content: "三天计划"),
                             ChatMessage(role: .assistant, content: "原回答"),
                             ChatMessage(role: .user, content: "再详细一点")]
        let edited = try ConversationEditing.editedCopy(of: original, messageID: original.messages[0].id, text: "两天计划")
        XCTAssertEqual(original.messages.count, 3)
        XCTAssertEqual(original.messages[0].content, "三天计划")
        XCTAssertEqual(edited.messages.map(\.content), ["两天计划"])
        XCTAssertEqual(edited.parentThreadID, original.id)
        XCTAssertNotEqual(edited.id, original.id)
        XCTAssertNotEqual(edited.messages[0].id, original.messages[0].id)
    }

    func testAssistantEditIsSavedWithoutInventedUsageOrReasoning() throws {
        var original = ChatThread()
        original.messages = [ChatMessage(role: .user, content: "你好"),
            ChatMessage(role: .assistant, content: "原文", reasoning: "原始推理", usage: TokenUsage(promptTokens: 3, completionTokens: 4), isBookmarked: true)]
        let edited = try ConversationEditing.editedCopy(of: original, messageID: original.messages[1].id, text: "修改的正文")
        XCTAssertEqual(edited.messages.last?.role, .assistant)
        XCTAssertEqual(edited.messages.last?.content, "修改的正文")
        XCTAssertEqual(edited.messages.last?.reasoning, "")
        XCTAssertNil(edited.messages.last?.usage)
        XCTAssertFalse(edited.messages.last?.isBookmarked == true)
        XCTAssertEqual(original.messages.last?.content, "原文")
    }

    func testRetryPreservesOldAnswerAndBuildsTheSameUserContext() throws {
        var original = ChatThread()
        original.messages = [ChatMessage(role: .user, content: "问题"), ChatMessage(role: .assistant, content: "好答案")]
        let retry = try ConversationEditing.retryCopy(of: original)
        XCTAssertEqual(original.messages.last?.content, "好答案")
        XCTAssertEqual(retry.messages.map(\.content), ["问题"])
        XCTAssertEqual(ChatRequest(settings: AppSettings(), messages: retry.messages).messages.last?.content, "问题")
    }

    func testLegacyBackupWithoutNewOptionalFieldsStillLoads() throws {
        var original = ChatThread()
        original.messages = [ChatMessage(role: .user, content: "旧记录")]
        let data = try AppSnapshot(settings: AppSettings(), threads: [original], activeThreadID: original.id).encoded()
        var object = try XCTUnwrap(JSONSerialization.jsonObject(with: data) as? [String: Any])
        var threads = try XCTUnwrap(object["threads"] as? [[String: Any]])
        threads[0].removeValue(forKey: "draft")
        threads[0].removeValue(forKey: "isPinned")
        threads[0].removeValue(forKey: "parentThreadID")
        object["threads"] = threads
        let restored = try AppSnapshot.decode(JSONSerialization.data(withJSONObject: object))
        XCTAssertEqual(restored.threads[0].messages[0].content, "旧记录")
        XCTAssertNil(restored.threads[0].draft)
        XCTAssertNil(restored.threads[0].messages[0].isBookmarked)
    }
}
