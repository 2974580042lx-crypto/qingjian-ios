import SwiftUI
import UIKit

// No bottom tab bar any more: settings open from the sidebar.
enum FloatingChrome { static let navigationHeight: CGFloat = 0 }

private extension Color {
    static func adaptive(light: UInt32, dark: UInt32, lightAlpha: CGFloat = 1, darkAlpha: CGFloat = 1) -> Color {
        Color(UIColor { trait in
            let isDark = trait.userInterfaceStyle == .dark
            let hex = isDark ? dark : light
            return UIColor(red: CGFloat((hex >> 16) & 0xFF) / 255,
                           green: CGFloat((hex >> 8) & 0xFF) / 255,
                           blue: CGFloat(hex & 0xFF) / 255,
                           alpha: isDark ? darkAlpha : lightAlpha)
        })
    }
}

// 纸笺 (after the Claude app): warm paper, near-black at night, one terracotta accent,
// and the gamboge highlighter kept from the earlier design.
// 瑞士: cool grey-white, true black ink, one ultramarine accent, a black send button.
// Every value is read through `InterfaceStyle`, so switching the look redraws in place.
enum Ink {
    private static var swiss: Bool { InterfaceStyle.isSwiss }
    static var paper: Color { swiss ? Color.adaptive(light: 0xF2F2EF, dark: 0x111214) : Color.adaptive(light: 0xFAF9F5, dark: 0x171716) }
    static var sheet: Color { swiss ? Color.adaptive(light: 0xE7E7E3, dark: 0x0A0A0B) : Color.adaptive(light: 0xF2F0E9, dark: 0x121211) }
    static var raised: Color { swiss ? Color.adaptive(light: 0xFFFFFF, dark: 0x1D1E21) : Color.adaptive(light: 0xEFEDE5, dark: 0x292927) }
    static var ink: Color { swiss ? Color.adaptive(light: 0x111111, dark: 0xEDEDE9) : Color.adaptive(light: 0x1F1E1D, dark: 0xECEAE3) }
    static var ink2: Color { swiss ? Color.adaptive(light: 0x3B3B3B, dark: 0xC6C6C1) : Color.adaptive(light: 0x4F4D48, dark: 0xC2BFB6) }
    static var ink3: Color { swiss ? Color.adaptive(light: 0x5E5E5E, dark: 0x9B9B96) : Color.adaptive(light: 0x7A7872, dark: 0x9A978F) }
    static var line: Color {
        swiss ? Color.adaptive(light: 0x111111, dark: 0xEDEDE9, lightAlpha: 0.16, darkAlpha: 0.18)
            : Color.adaptive(light: 0x1F1E1D, dark: 0xECEAE3, lightAlpha: 0.10, darkAlpha: 0.12)
    }
    static var seal: Color { swiss ? Color.adaptive(light: 0x2B3DE0, dark: 0x6B79FF) : Color.adaptive(light: 0xC96442, dark: 0xD97757) }
    static var onSeal: Color { Color.adaptive(light: 0xFFFFFF, dark: 0xFFFFFF) }
    // Highlighter stroke behind emphasised words (纸笺); a pale blue wash for the
    // sidebar's selected row in the Swiss look, which has no highlighter in answers.
    static var mark: Color {
        swiss ? Color.adaptive(light: 0x2B3DE0, dark: 0x6B79FF, lightAlpha: 0.14, darkAlpha: 0.28)
            : Color.adaptive(light: 0xFFE169, dark: 0xF7C81E, darkAlpha: 0.36)
    }
    static var solid: Color { ink }
    static var onSolid: Color { paper }
    static var sendFill: Color { swiss ? ink : seal }
    static var sendGlyph: Color { swiss ? paper : onSeal }
}

enum Palette {
    static var green: Color { Ink.ink }
    static var paper: Color { Ink.paper }
    static var surface: Color { Ink.raised }
    static var softGreen: Color { Ink.line }
    static var secondary: Color { Ink.ink3 }
}

enum Space {
    static let xs: CGFloat = 4, s: CGFloat = 8, m: CGFloat = 12, l: CGFloat = 16
    static let xl: CGFloat = 24, xxl: CGFloat = 32, section: CGFloat = 40
}

enum Radius {
    static let control: CGFloat = 14, field: CGFloat = 20, sheet: CGFloat = 34
    // The page corners while the sidebar is open; the Swiss look keeps them square.
    static var pageFront: CGFloat { InterfaceStyle.isSwiss ? 0 : 42 }
    static var pageBack: CGFloat { InterfaceStyle.isSwiss ? 0 : 32 }
}

enum TypeScale {
    // Chosen in Settings (built-in serif, system PingFang, or an imported font).
    static var serifName: String { FontLibrary.regularFace }
    static func serif(_ size: CGFloat, relativeTo style: Font.TextStyle = .body) -> Font {
        .custom(serifName, size: size, relativeTo: style)
    }
    // The bold cut is optional: without the font file, headings fall back to the system heavy weight.
    static var heavyName: String { FontLibrary.boldFace }
    static var hasHeavy: Bool { UIFont(name: heavyName, size: 12) != nil }
    static func heavy(_ size: CGFloat, relativeTo style: Font.TextStyle = .body) -> Font {
        if InterfaceStyle.isSwiss { return .system(size: size, weight: .heavy) }
        return hasHeavy ? .custom(heavyName, size: size, relativeTo: style) : .system(size: size, weight: .heavy)
    }
    /// Numbers and small labels in the Swiss look: Q.01, COPY, 2026.10.20.
    static func mono(_ size: CGFloat, relativeTo style: Font.TextStyle = .caption) -> Font {
        .system(size: size, weight: .medium, design: .monospaced)
    }
    static var pageTitle: Font { serif(32, relativeTo: .largeTitle) }
    static var hero: Font { serif(30, relativeTo: .title) }
    static var subject: Font { serif(20, relativeTo: .title3) }
    static var answer: Font { serif(17) }
    static var note: Font { serif(16, relativeTo: .callout) }
    static var body: Font { serif(16) }
    static var label: Font { serif(13, relativeTo: .footnote) }
    static var caption: Font { serif(12, relativeTo: .caption) }
    static var tiny: Font { serif(11, relativeTo: .caption2) }
}

enum InkAppearance {
    @MainActor static func apply() {
        let ink = UIColor(Ink.ink)
        let large = UIFont(name: TypeScale.serifName, size: 32)
        let inline = UIFont(name: TypeScale.serifName, size: 17)
        func update(_ bar: UINavigationBar) {
            if let large {
                bar.largeTitleTextAttributes = [.font: UIFontMetrics(forTextStyle: .largeTitle).scaledFont(for: large), .foregroundColor: ink]
            }
            if let inline {
                bar.titleTextAttributes = [.font: UIFontMetrics(forTextStyle: .headline).scaledFont(for: inline), .foregroundColor: ink]
            }
        }
        update(UINavigationBar.appearance())
        // Appearance proxies affect future bars. Refresh existing bars in place
        // as well, without recreating their screens or discarding settings drafts.
        func visit(_ view: UIView) {
            if let bar = view as? UINavigationBar { update(bar) }
            for child in view.subviews { visit(child) }
        }
        for scene in UIApplication.shared.connectedScenes.compactMap({ $0 as? UIWindowScene }) {
            for window in scene.windows { visit(window) }
        }
    }
}

struct AppBackground: View { var body: some View { Ink.paper.ignoresSafeArea() } }

// Liquid glass in the paper look; a white box with a black frame in the Swiss look.
struct ClearGlass: ViewModifier {
    var radius: CGFloat = 28
    @ViewBuilder func body(content: Content) -> some View {
        if InterfaceStyle.isSwiss {
            content.background(Ink.raised).overlay(Rectangle().stroke(Ink.ink, lineWidth: 1.5).allowsHitTesting(false))
        } else {
            content.glassEffect(.regular.interactive(), in: .rect(cornerRadius: radius))
        }
    }
}

struct PageContour: Shape {
    var radius: CGFloat
    var topInset: CGFloat
    var bottomInset: CGFloat
    var animatableData: CGFloat { get { radius } set { radius = newValue } }
    func path(in rect: CGRect) -> Path {
        let page = CGRect(x: rect.minX, y: rect.minY - topInset, width: rect.width,
                          height: rect.height + topInset + bottomInset)
        return RoundedRectangle(cornerRadius: radius, style: .continuous).path(in: page)
    }
}

struct ReadingStyle: ViewModifier {
    // Observed so text redraws as soon as the font is changed in Settings.
    @AppStorage(FontLibrary.choiceKey) private var choice = ""
    @AppStorage(FontLibrary.revisionKey) private var revision = 0
    @AppStorage("qingjian.reading.size") private var size = 18.0
    var adjustment: Double = 0
    var heavy = false
    func body(content: Content) -> some View {
        content.font(font)
    }
    private var font: Font {
        let points = size + adjustment
        _ = (choice, revision)
        if heavy {
            return TypeScale.hasHeavy ? .custom(TypeScale.heavyName, size: points, relativeTo: .body)
                : .custom(TypeScale.serifName, size: points, relativeTo: .body).bold()
        }
        return .custom(TypeScale.serifName, size: points, relativeTo: .body)
    }
}

extension View {
    func readingStyle(adjustment: Double = 0, heavy: Bool = false) -> some View {
        modifier(ReadingStyle(adjustment: adjustment, heavy: heavy))
    }
    func clearGlass(radius: CGFloat = 28) -> some View { modifier(ClearGlass(radius: radius)) }
}

struct SealStamp: View {
    var text = "V"
    var size: CGFloat = 30
    var body: some View {
        Text(text).font(TypeScale.serif(size * 0.57)).fontWeight(.semibold)
            .foregroundStyle(Ink.onSeal).frame(width: size, height: size)
            .background(Ink.seal, in: RoundedRectangle(cornerRadius: size * 0.23, style: .continuous))
            .accessibilityHidden(true)
    }
}

// Sermo's own mark: a terracotta disc. Breathes while an answer is on its way.
struct PulseDot: View {
    var size: CGFloat = 9
    var pulsing = true
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var dim = false
    var body: some View {
        // A disc on paper, a small square in the Swiss look.
        RoundedRectangle(cornerRadius: InterfaceStyle.isSwiss ? 0 : size / 2, style: .continuous)
            .fill(Ink.seal).frame(width: size, height: size)
            .opacity(dim ? 0.35 : 1).scaleEffect(dim ? 0.72 : 1)
            .onAppear {
                guard pulsing && !reduceMotion else { return }
                withAnimation(.easeInOut(duration: 0.8).repeatForever(autoreverses: true)) { dim = true }
            }
            .accessibilityHidden(true)
    }
}

struct InkRule: View { var body: some View { Rectangle().fill(Ink.line).frame(height: 0.5).accessibilityHidden(true) } }

struct InkSectionHeader: View {
    let title: String
    var body: some View {
        Text(title).font(TypeScale.label.weight(.semibold)).foregroundStyle(Ink.ink2)
            .frame(maxWidth: .infinity, alignment: .leading).accessibilityAddTraits(.isHeader)
    }
}

struct InkRow: View {
    let title: String
    var detail: String? = nil
    var value: String? = nil
    var divider = true
    var body: some View {
        VStack(spacing: 0) {
            HStack(alignment: .center, spacing: Space.m) {
                VStack(alignment: .leading, spacing: 4) {
                    Text(title).font(TypeScale.subject).foregroundStyle(Ink.ink)
                    if let detail { Text(detail).font(TypeScale.caption).foregroundStyle(Ink.ink3).lineLimit(2) }
                }
                Spacer(minLength: Space.s)
                if let value { Text(value).font(TypeScale.label).foregroundStyle(Ink.ink2).monospacedDigit() }
            }
            .padding(.vertical, Space.l).frame(minHeight: 58).contentShape(Rectangle())
            if divider { InkRule() }
        }
    }
}

struct InkPrimaryButtonStyle: ButtonStyle {
    var height: CGFloat = 52
    @Environment(\.isEnabled) private var isEnabled
    func makeBody(configuration: Configuration) -> some View {
        configuration.label.font(TypeScale.serif(16).weight(.semibold)).foregroundStyle(Ink.onSolid)
            .padding(.horizontal, 22).frame(maxWidth: .infinity).frame(height: height)
            .background(Ink.solid, in: RoundedRectangle(cornerRadius: InterfaceStyle.isSwiss ? 0 : height / 2, style: .continuous))
            .opacity(isEnabled ? (configuration.isPressed ? 0.82 : 1) : 0.4)
    }
}

struct InkGlassButtonStyle: ButtonStyle {
    var height: CGFloat = 48
    func makeBody(configuration: Configuration) -> some View {
        configuration.label.font(TypeScale.serif(15)).foregroundStyle(Ink.ink)
            .padding(.horizontal, 18).frame(height: height)
            .clearGlass(radius: height / 2).opacity(configuration.isPressed ? 0.84 : 1)
    }
}

extension ButtonStyle where Self == InkPrimaryButtonStyle { static var inkPrimary: InkPrimaryButtonStyle { InkPrimaryButtonStyle() } }
extension ButtonStyle where Self == InkGlassButtonStyle { static var inkGlass: InkGlassButtonStyle { InkGlassButtonStyle() } }

struct GlassCircle: View {
    let symbol: String
    let label: String
    var action: () -> Void
    var body: some View {
        Button(action: action) {
            Image(systemName: symbol).font(.system(size: 17, weight: .medium)).foregroundStyle(Ink.ink).frame(width: 44, height: 44)
        }
        .buttonStyle(.plain).clearGlass(radius: 22)
        .accessibilityElement(children: .ignore).accessibilityLabel(label).accessibilityIdentifier(label).accessibilityAddTraits(.isButton)
    }
}

struct SidebarGlyph: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            Capsule().frame(width: 16, height: 1.8)
            Capsule().frame(width: 10, height: 1.8)
        }
        .foregroundStyle(Ink.ink)
        .frame(width: 22, height: 22, alignment: .center)
        .accessibilityHidden(true)
    }
}
