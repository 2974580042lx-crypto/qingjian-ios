import SwiftUI

enum Palette {
    static let green = Color.white
    static let paper = Color(red: 0.035, green: 0.035, blue: 0.04)
    static let surface = Color(red: 0.09, green: 0.09, blue: 0.10)
    static let softGreen = Color.white.opacity(0.09)
    static let secondary = Color.white.opacity(0.52)
}

struct AppBackground: View {
    var body: some View {
        ZStack {
            Palette.paper
            RadialGradient(colors: [Color.white.opacity(0.065), .clear], center: .bottomTrailing,
                           startRadius: 15, endRadius: 620)
        }.ignoresSafeArea()
    }
}

struct ClearGlass: ViewModifier {
    @Environment(\.accessibilityReduceTransparency) private var reduceTransparency
    var radius: CGFloat = 28
    func body(content: Content) -> some View {
        content
            .background(Color.black.opacity(0.24), in: RoundedRectangle(cornerRadius: radius))
            .glassEffect(reduceTransparency ? .regular : .clear, in: .rect(cornerRadius: radius))
    }
}

struct ReadingStyle: ViewModifier {
    @AppStorage("qingjian.reading.serif") private var serif = true
    @AppStorage("qingjian.reading.size") private var size = 18.0
    var adjustment: Double = 0
    func body(content: Content) -> some View {
        content.font(serif
            ? .custom("NotoSerifSC-Regular", size: size + adjustment, relativeTo: .body)
            : .system(size: size + adjustment))
    }
}

extension View {
    func readingStyle(adjustment: Double = 0) -> some View { modifier(ReadingStyle(adjustment: adjustment)) }
    func clearGlass(radius: CGFloat = 28) -> some View { modifier(ClearGlass(radius: radius)) }
}

struct GlassCircle: View {
    let symbol: String
    let label: String
    var action: () -> Void
    var body: some View {
        Button(action: action) {
            Image(systemName: symbol).font(.system(size: 17, weight: .medium))
                .frame(width: 44, height: 44)
        }
        .buttonStyle(.plain)
        .glassEffect(.regular.interactive(), in: .circle)
        .accessibilityLabel(label)
    }
}
