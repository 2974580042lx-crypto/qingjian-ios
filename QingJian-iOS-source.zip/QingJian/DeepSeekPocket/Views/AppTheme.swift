import SwiftUI
import UIKit

enum FloatingChrome { static let navigationHeight: CGFloat = 75 }

private extension Color {
    static func adaptive(light: UInt32, dark: UInt32, lightAlpha: CGFloat = 1, darkAlpha: CGFloat = 1) -> Color {
        Color(UIColor { trait in
            let isDark = trait.userInterfaceStyle == .dark
            let hex = isDark ? dark : light
            return UIColor(red: CGFloat((hex >> 16) & 0xFF) / 255,
                           green: CGFloat((hex >> 8) & 0xFF) / 255,
                           blue: CGFloat(hex & 0xFF) / 255,
                           alpha: isDark ? darkAlpha : lightAlpha)
        })
    }
}

enum Ink {
    static let paper = Color.adaptive(light: 0xF5F2EB, dark: 0x141311)
    static let sheet = Color.adaptive(light: 0xE9E5DB, dark: 0x1C1B18)
    static let raised = Color.adaptive(light: 0xE9E5DB, dark: 0x2A2825)
    static let ink = Color.adaptive(light: 0x1B1A17, dark: 0xECE8DF)
    static let ink2 = Color.adaptive(light: 0x4A4740, dark: 0xB5B0A5)
    static let ink3 = Color.adaptive(light: 0x6F6B62, dark: 0x8F8A7F)
    static let line = Color.adaptive(light: 0x1B1A17, dark: 0xECE8DF, lightAlpha: 0.12, darkAlpha: 0.13)
    static let seal = Color.adaptive(light: 0xB83A26, dark: 0xE0664C)
    static let onSeal = Color.adaptive(light: 0xF5F2EB, dark: 0x141311)
    static let solid = ink
    static let onSolid = paper
}

enum Palette {
    static let green = Ink.ink
    static let paper = Ink.paper
    static let surface = Ink.raised
    static let softGreen = Ink.line
    static let secondary = Ink.ink3
}

enum Space {
    static let xs: CGFloat = 4, s: CGFloat = 8, m: CGFloat = 12, l: CGFloat = 16
    static let xl: CGFloat = 24, xxl: CGFloat = 32, section: CGFloat = 40
}

enum Radius {
    static let control: CGFloat = 14, field: CGFloat = 20, sheet: CGFloat = 34
    static let pageFront: CGFloat = 42, pageBack: CGFloat = 32
}

enum TypeScale {
    static let serifName = "NotoSerifSC-Regular"
    static func serif(_ size: CGFloat, relativeTo style: Font.TextStyle = .body) -> Font {
        .custom(serifName, size: size, relativeTo: style)
    }
    static let pageTitle = serif(32, relativeTo: .largeTitle)
    static let hero = serif(30, relativeTo: .title)
    static let subject = serif(20, relativeTo: .title3)
    static let answer = serif(17)
    static let note = serif(16, relativeTo: .callout)
    static let body = serif(16)
    static let label = serif(13, relativeTo: .footnote)
    static let caption = serif(12, relativeTo: .caption)
    static let tiny = serif(11, relativeTo: .caption2)
}

enum InkAppearance {
    @MainActor static func apply() {
        let ink = UIColor(Ink.ink)
        let bar = UINavigationBar.appearance()
        if let large = UIFont(name: TypeScale.serifName, size: 32) {
            bar.largeTitleTextAttributes = [.font: UIFontMetrics(forTextStyle: .largeTitle).scaledFont(for: large), .foregroundColor: ink]
        }
        if let inline = UIFont(name: TypeScale.serifName, size: 17) {
            bar.titleTextAttributes = [.font: UIFontMetrics(forTextStyle: .headline).scaledFont(for: inline), .foregroundColor: ink]
        }
    }
}

struct AppBackground: View { var body: some View { Ink.paper.ignoresSafeArea() } }

struct ClearGlass: ViewModifier {
    var radius: CGFloat = 28
    func body(content: Content) -> some View { content.glassEffect(.regular.interactive(), in: .rect(cornerRadius: radius)) }
}

struct PageContour: Shape {
    var radius: CGFloat
    var topInset: CGFloat
    var bottomInset: CGFloat
    var animatableData: CGFloat { get { radius } set { radius = newValue } }
    func path(in rect: CGRect) -> Path {
        let page = CGRect(x: rect.minX, y: rect.minY - topInset, width: rect.width,
                          height: rect.height + topInset + bottomInset)
        return RoundedRectangle(cornerRadius: radius, style: .continuous).path(in: page)
    }
}

struct ReadingStyle: ViewModifier {
    @AppStorage("qingjian.reading.serif") private var serif = true
    @AppStorage("qingjian.reading.size") private var size = 18.0
    var adjustment: Double = 0
    func body(content: Content) -> some View {
        content.font(serif ? .custom(TypeScale.serifName, size: size + adjustment, relativeTo: .body) : .system(size: size + adjustment))
    }
}

extension View {
    func readingStyle(adjustment: Double = 0) -> some View { modifier(ReadingStyle(adjustment: adjustment)) }
    func clearGlass(radius: CGFloat = 28) -> some View { modifier(ClearGlass(radius: radius)) }
}

struct SealStamp: View {
    var text = "V"
    var size: CGFloat = 30
    var body: some View {
        Text(text).font(TypeScale.serif(size * 0.57)).fontWeight(.semibold)
            .foregroundStyle(Ink.onSeal).frame(width: size, height: size)
            .background(Ink.seal, in: RoundedRectangle(cornerRadius: size * 0.23, style: .continuous))
            .accessibilityHidden(true)
    }
}

struct InkRule: View { var body: some View { Rectangle().fill(Ink.line).frame(height: 0.5).accessibilityHidden(true) } }

struct InkSectionHeader: View {
    let title: String
    var body: some View {
        Text(title).font(TypeScale.label.weight(.semibold)).foregroundStyle(Ink.ink2)
            .frame(maxWidth: .infinity, alignment: .leading).accessibilityAddTraits(.isHeader)
    }
}

struct InkRow: View {
    let title: String
    var detail: String? = nil
    var value: String? = nil
    var divider = true
    var body: some View {
        VStack(spacing: 0) {
            HStack(alignment: .center, spacing: Space.m) {
                VStack(alignment: .leading, spacing: 4) {
                    Text(title).font(TypeScale.subject).foregroundStyle(Ink.ink)
                    if let detail { Text(detail).font(TypeScale.caption).foregroundStyle(Ink.ink3).lineLimit(2) }
                }
                Spacer(minLength: Space.s)
                if let value { Text(value).font(TypeScale.label).foregroundStyle(Ink.ink2).monospacedDigit() }
            }
            .padding(.vertical, Space.l).frame(minHeight: 58).contentShape(Rectangle())
            if divider { InkRule() }
        }
    }
}

struct InkPrimaryButtonStyle: ButtonStyle {
    var height: CGFloat = 52
    @Environment(\.isEnabled) private var isEnabled
    func makeBody(configuration: Configuration) -> some View {
        configuration.label.font(TypeScale.serif(16).weight(.semibold)).foregroundStyle(Ink.onSolid)
            .padding(.horizontal, 22).frame(maxWidth: .infinity).frame(height: height)
            .background(Ink.solid, in: Capsule()).opacity(isEnabled ? (configuration.isPressed ? 0.82 : 1) : 0.4)
    }
}

struct InkGlassButtonStyle: ButtonStyle {
    var height: CGFloat = 48
    func makeBody(configuration: Configuration) -> some View {
        configuration.label.font(TypeScale.serif(15)).foregroundStyle(Ink.ink)
            .padding(.horizontal, 18).frame(height: height)
            .glassEffect(.regular.interactive(), in: .capsule).opacity(configuration.isPressed ? 0.84 : 1)
    }
}

extension ButtonStyle where Self == InkPrimaryButtonStyle { static var inkPrimary: InkPrimaryButtonStyle { InkPrimaryButtonStyle() } }
extension ButtonStyle where Self == InkGlassButtonStyle { static var inkGlass: InkGlassButtonStyle { InkGlassButtonStyle() } }

struct GlassCircle: View {
    let symbol: String
    let label: String
    var action: () -> Void
    var body: some View {
        Button(action: action) {
            Image(systemName: symbol).font(.system(size: 17, weight: .medium)).foregroundStyle(Ink.ink).frame(width: 44, height: 44)
        }
        .buttonStyle(.plain).glassEffect(.regular.interactive(), in: .circle)
        .accessibilityElement(children: .ignore).accessibilityLabel(label).accessibilityIdentifier(label).accessibilityAddTraits(.isButton)
    }
}

struct SidebarGlyph: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            Capsule().frame(width: 16, height: 1.8)
            Capsule().frame(width: 10, height: 1.8)
        }
        .foregroundStyle(Ink.ink)
        .frame(width: 22, height: 22, alignment: .center)
        .accessibilityHidden(true)
    }
}
