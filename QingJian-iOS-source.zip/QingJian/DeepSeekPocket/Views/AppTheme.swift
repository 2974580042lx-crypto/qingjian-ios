import SwiftUI

enum Palette {
    static let green = Color.white
    static let paper = Color(red: 0.035, green: 0.035, blue: 0.04)
    static let surface = Color(red: 0.09, green: 0.09, blue: 0.10)
    static let softGreen = Color.white.opacity(0.09)
    static let secondary = Color.white.opacity(0.52)
}

struct ReadingStyle: ViewModifier {
    @AppStorage("qingjian.reading.serif") private var serif = true
    @AppStorage("qingjian.reading.size") private var size = 18.0
    var adjustment: Double = 0
    func body(content: Content) -> some View {
        content.font(serif
            ? .custom("NotoSerifSC-Regular", size: size + adjustment, relativeTo: .body)
            : .system(size: size + adjustment))
    }
}

extension View {
    func readingStyle(adjustment: Double = 0) -> some View { modifier(ReadingStyle(adjustment: adjustment)) }
}

struct GlassCircle: View {
    let symbol: String
    let label: String
    var action: () -> Void
    var body: some View {
        Button(action: action) {
            Image(systemName: symbol).font(.system(size: 17, weight: .medium))
                .frame(width: 44, height: 44)
        }
        .buttonStyle(.plain)
        .glassEffect(.regular.interactive(), in: .circle)
        .accessibilityLabel(label)
    }
}
