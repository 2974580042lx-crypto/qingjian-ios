import SwiftUI
import UIKit
import LocalAuthentication
import UniformTypeIdentifiers

enum ProjectLock {
    // Face ID, falling back to the phone passcode. Unlocks for this session only.
    @MainActor static func open(_ id: UUID, store: AppStore) async -> Bool {
        guard store.isLocked(id) else { return true }
        if store.isPreview { store.unlock(id); return true }
        let context = LAContext()
        var error: NSError?
        guard context.canEvaluatePolicy(.deviceOwnerAuthentication, error: &error) else {
            store.errorMessage = "这台手机没有设置面容 ID 或锁屏密码，暂时打不开上锁的项目。"
            return false
        }
        do {
            let ok = try await context.evaluatePolicy(.deviceOwnerAuthentication, localizedReason: "打开上锁的项目")
            if ok { store.unlock(id) }
            return ok
        } catch { return false }
    }
}

private extension View {
    func errorAlert(_ store: AppStore) -> some View {
        alert("暂时没有完成", isPresented: Binding(get: { store.errorMessage != nil }, set: { if !$0 { store.errorMessage = nil } })) {
            Button("知道了") { store.errorMessage = nil }
        } message: { Text(store.errorMessage ?? "") }
    }
}

@MainActor
struct ProjectsView: View {
    @EnvironmentObject private var store: AppStore
    @Environment(\.dismiss) private var dismiss
    // Called after a conversation was opened, so the sheet and the sidebar can close.
    let opened: () -> Void
    @State private var path: [UUID] = []
    @State private var creating = false
    @State private var newName = ""

    var body: some View {
        NavigationStack(path: $path) {
            List {
                if store.projects.isEmpty {
                    Text("项目有自己的指令、资料和默认模型。项目里的对话只在项目中出现，不会进侧栏的「最近」。")
                        .font(TypeScale.serif(15)).foregroundStyle(Ink.ink3).listRowBackground(Color.clear)
                }
                ForEach(store.projects) { project in
                    Button { open(project.id) } label: {
                        HStack(spacing: 14) {
                            Image(systemName: project.isLocked ? "lock" : "folder").font(.system(size: 17)).foregroundStyle(Ink.ink2).frame(width: 24)
                            VStack(alignment: .leading, spacing: 3) {
                                Text(project.name).font(TypeScale.serif(17)).foregroundStyle(Ink.ink)
                                Text(project.isLocked && store.isLocked(project.id) ? "已上锁" : "\(store.threads(in: project.id).count) 个对话")
                                    .font(TypeScale.tiny).foregroundStyle(Ink.ink3)
                            }
                            Spacer()
                            Image(systemName: "chevron.right").font(.system(size: 12)).foregroundStyle(Ink.ink3)
                        }.padding(.vertical, 6).contentShape(Rectangle())
                    }
                    .buttonStyle(.plain)
                    .listRowBackground(Color.clear)
                    .accessibilityIdentifier("project-row")
                }
            }
            .listStyle(.plain)
            .scrollContentBackground(.hidden)
            .background(AppBackground())
            .navigationTitle("项目")
            .toolbar {
                ToolbarItem(placement: .topBarLeading) { Button("完成") { dismiss() } }
                ToolbarItem(placement: .topBarTrailing) {
                    Button { newName = ""; creating = true } label: { Image(systemName: "plus") }.accessibilityLabel("新建项目")
                }
            }
            .navigationDestination(for: UUID.self) { id in ProjectDetailView(projectID: id, opened: opened) }
            .alert("新建项目", isPresented: $creating) {
                TextField("项目名称", text: $newName)
                Button("取消", role: .cancel) { }
                Button("创建") { if let id = store.createProject(name: newName) { path.append(id) } }
            }
            .errorAlert(store)
        }
        .tint(Ink.ink)
        .onAppear {
            if ProcessInfo.processInfo.arguments.contains("--preview-project"), let first = store.projects.first { path = [first.id] }
        }
    }

    private func open(_ id: UUID) {
        Task { if await ProjectLock.open(id, store: store) { path.append(id) } }
    }
}

@MainActor
struct ProjectDetailView: View {
    @EnvironmentObject private var store: AppStore
    @Environment(\.dismiss) private var dismiss
    let projectID: UUID
    let opened: () -> Void
    @State private var draft = ChatProject(name: "")
    @State private var loaded = false
    @State private var importing = false
    @State private var confirmDelete = false
    private var changed: Bool { loaded && store.project(projectID) != draft }

    var body: some View {
        Form {
            Section("名称") {
                TextField("项目名称", text: $draft.name)
            }
            Section {
                TextEditor(text: $draft.instructions).frame(minHeight: 160).scrollContentBackground(.hidden)
                    .accessibilityIdentifier("project-instructions")
            } header: { Text("指令") } footer: {
                Text("这个项目里的对话只用这段指令，不叠加设置里的系统提示词。可以写身份、语气和规矩，比如「你是一位研究明史的老教授……」。")
            }
            Section {
                ForEach($draft.documents) { $document in
                    Toggle(isOn: $document.isIncluded) {
                        VStack(alignment: .leading, spacing: 2) {
                            Text(document.name).lineLimit(1)
                            Text("\(document.text.count.formatted()) 字").font(TypeScale.tiny).foregroundStyle(Ink.ink3)
                        }
                    }
                }
                .onDelete { draft.documents.remove(atOffsets: $0) }
                Button { importing = true } label: { Label("导入文字文件", systemImage: "doc.badge.plus") }
                Button {
                    if let text = UIPasteboard.general.string, !text.isEmpty {
                        draft.documents.append(ProjectDocument(name: "粘贴的资料 \(draft.documents.count + 1)", text: String(text.prefix(ChatProject.documentCharacterLimit))))
                    }
                } label: { Label("粘贴文字作为资料", systemImage: "doc.on.clipboard") }
            } header: { Text("资料") } footer: {
                Text("打开的资料每次提问都会一起发给模型，会多花一些 token；关掉就不带。已打开 \(draft.includedCharacters.formatted()) / \(ChatProject.documentCharacterLimit.formatted()) 字。左滑可删除。")
            }
            Section {
                Picker("模型", selection: Binding(get: { draft.model?.rawValue ?? "follow" },
                                                set: { draft.model = DeepSeekModel(rawValue: $0) })) {
                    Text("跟随当前").tag("follow")
                    ForEach(DeepSeekModel.allCases) { Text($0.title).tag($0.rawValue) }
                }
                Picker("思考", selection: Binding(get: {
                    guard let thinking = draft.thinkingEnabled else { return "follow" }
                    return thinking ? (draft.effort ?? .high).rawValue : "off"
                }, set: { value in
                    switch value {
                    case "follow": draft.thinkingEnabled = nil; draft.effort = nil
                    case "off": draft.thinkingEnabled = false
                    default: draft.thinkingEnabled = true; draft.effort = ThinkingEffort(rawValue: value)
                    }
                })) {
                    Text("跟随当前").tag("follow")
                    Text("Off").tag("off")
                    ForEach(ThinkingEffort.allCases) { Text($0.title).tag($0.rawValue) }
                }
            } header: { Text("默认模型与思考") } footer: {
                Text("在项目里新建会话时自动切换到这里的设置。")
            }
            Section {
                Toggle("面容 ID 锁", isOn: $draft.isLocked)
            } header: { Text("隐私") } footer: {
                Text("上锁后，打开项目和搜索里面的对话都要先验证；离开 App 后会重新上锁。项目里的对话本来就不进侧栏的「最近」。")
            }
            Section("对话") {
                Button {
                    save()
                    store.createThread(in: projectID)
                    opened()
                } label: { Label("在这个项目里新建会话", systemImage: "plus") }
                    .accessibilityIdentifier("project-new-chat")
                ForEach(store.threads(in: projectID)) { thread in
                    Button {
                        save()
                        store.select(thread.id)
                        opened()
                    } label: {
                        VStack(alignment: .leading, spacing: 2) {
                            Text(thread.title).foregroundStyle(Ink.ink).lineLimit(1)
                            Text(thread.updatedAt.formatted(date: .abbreviated, time: .omitted)).font(TypeScale.tiny).foregroundStyle(Ink.ink3)
                        }
                    }
                    .swipeActions {
                        Button("移出") { store.moveThreads([thread.id], to: nil) }.tint(Ink.ink3)
                    }
                }
            }
            Section {
                Button("删除项目", role: .destructive) { confirmDelete = true }
            }
        }
        .font(TypeScale.body)
        .scrollContentBackground(.hidden)
        .background(AppBackground())
        .navigationTitle(draft.name.isEmpty ? "项目" : draft.name)
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button(changed ? "保存" : "已保存") { save() }.fontWeight(.semibold).disabled(!changed)
            }
        }
        .fileImporter(isPresented: $importing, allowedContentTypes: [.plainText, .text, UTType(filenameExtension: "md") ?? .plainText],
                      allowsMultipleSelection: true) { result in
            do {
                for url in try result.get() {
                    let scoped = url.startAccessingSecurityScopedResource()
                    defer { if scoped { url.stopAccessingSecurityScopedResource() } }
                    let size = try url.resourceValues(forKeys: [.fileSizeKey]).fileSize ?? 0
                    guard size <= 1024 * 1024 else { throw ChatError.server("请选择小于 1 MB 的文字文件。") }
                    let text = try String(contentsOf: url, encoding: .utf8)
                    guard text.count <= ChatProject.documentCharacterLimit else { throw ChatError.server("这份资料超过 10 万字，请拆开再导入。") }
                    draft.documents.append(ProjectDocument(name: url.deletingPathExtension().lastPathComponent, text: text))
                }
            } catch { store.errorMessage = error.localizedDescription }
        }
        .confirmationDialog("删除「\(draft.name)」？", isPresented: $confirmDelete, titleVisibility: .visible) {
            Button("删除项目，对话移回「最近」") { store.deleteProject(projectID, keepConversations: true); dismiss() }
            Button("连同里面的对话一起删除", role: .destructive) { store.deleteProject(projectID, keepConversations: false); dismiss() }
        }
        .errorAlert(store)
        .onAppear {
            guard !loaded, let project = store.project(projectID) else { return }
            draft = project; loaded = true
        }
        .onDisappear { save() }
    }

    private func save() {
        guard changed else { return }
        // Take back the stored copy (with its new timestamp) so the button settles to "已保存".
        if store.updateProject(draft), let saved = store.project(projectID) { draft = saved }
    }
}

// "查看全部": every conversation that may be shown, with multi-select to move or delete in bulk.
@MainActor
struct AllChatsView: View {
    @EnvironmentObject private var store: AppStore
    @Environment(\.dismiss) private var dismiss
    let opened: () -> Void
    @State private var search = ""
    @State private var editMode: EditMode = .inactive
    @State private var selection = Set<UUID>()
    @State private var naming = false
    @State private var newName = ""
    @State private var confirmDelete = false
    private var editing: Bool { editMode.isEditing }
    private var shown: [ChatThread] {
        store.browsableThreads.filter { thread in
            search.isEmpty || thread.title.localizedCaseInsensitiveContains(search) ||
                thread.messages.contains(where: { $0.content.localizedCaseInsensitiveContains(search) })
        }
    }

    var body: some View {
        NavigationStack {
            List(selection: $selection) {
                ForEach(shown) { thread in
                    if editing { rowLabel(thread).tag(thread.id) }
                    else {
                        Button { store.select(thread.id); opened() } label: { rowLabel(thread) }
                            .buttonStyle(.plain).tag(thread.id)
                    }
                }
                .listRowBackground(Color.clear)
            }
            .listStyle(.plain)
            .scrollContentBackground(.hidden)
            .background(AppBackground())
            .environment(\.editMode, $editMode)
            .searchable(text: $search, prompt: "搜索对话")
            .navigationTitle("全部对话")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) { Button("完成") { dismiss() } }
                ToolbarItem(placement: .topBarTrailing) {
                    Button(editing ? "取消" : "选择") {
                        withAnimation { editMode = editing ? .inactive : .active }
                        selection = []
                    }.accessibilityIdentifier("all-chats-select")
                }
                if editing {
                    ToolbarItemGroup(placement: .bottomBar) {
                        Button(selection.count == shown.count && !shown.isEmpty ? "全不选" : "全选") {
                            selection = selection.count == shown.count ? [] : Set(shown.map(\.id))
                        }.accessibilityIdentifier("all-chats-select-all")
                        Spacer()
                        Menu("移到项目") {
                            ForEach(store.projects.filter { !store.isLocked($0.id) }) { project in
                                Button(project.name) { move(to: project.id) }
                            }
                            Button("新建项目…", systemImage: "folder.badge.plus") { newName = ""; naming = true }
                            Button("移出项目", systemImage: "tray.and.arrow.up") { move(to: nil) }
                        }
                        .disabled(selection.isEmpty)
                        .accessibilityIdentifier("all-chats-move")
                        Spacer()
                        Button("删除", role: .destructive) { confirmDelete = true }.disabled(selection.isEmpty)
                    }
                }
            }
            .alert("新建项目", isPresented: $naming) {
                TextField("项目名称", text: $newName)
                Button("取消", role: .cancel) { }
                Button("创建并移入") { if let id = store.createProject(name: newName) { move(to: id) } }
            }
            .confirmationDialog("删除选中的 \(selection.count) 个对话？", isPresented: $confirmDelete, titleVisibility: .visible) {
                Button("删除", role: .destructive) {
                    for id in selection where id != store.generatingThreadID { store.deleteThread(id) }
                    selection = []; editMode = .inactive
                }
            } message: { Text("附带的图片会一起删除，用量记录不受影响。") }
            .errorAlert(store)
        }
        .tint(Ink.ink)
    }

    private func rowLabel(_ thread: ChatThread) -> some View {
        VStack(alignment: .leading, spacing: 3) {
            Text(thread.title).font(TypeScale.serif(16)).foregroundStyle(Ink.ink).lineLimit(1)
            HStack(spacing: 6) {
                if let project = store.project(thread.projectID) { Text(project.name) }
                Text(thread.updatedAt.formatted(date: .abbreviated, time: .omitted))
            }.font(TypeScale.tiny).foregroundStyle(Ink.ink3)
        }
        .padding(.vertical, 4)
        .frame(maxWidth: .infinity, alignment: .leading).contentShape(Rectangle())
        .accessibilityIdentifier("all-chats-row")
    }

    private func move(to projectID: UUID?) {
        store.moveThreads(selection, to: projectID)
        selection = []
        withAnimation { editMode = .inactive }
    }
}
