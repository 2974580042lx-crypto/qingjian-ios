import SwiftUI
import UIKit

@MainActor
struct LocalNovelReader: View {
    @EnvironmentObject private var books: BookStore
    @EnvironmentObject private var store: AppStore
    @Environment(\.colorScheme) private var colorScheme
    @Environment(\.scenePhase) private var scenePhase
    let bookID: UUID
    let initialChapter: Int
    let initialParagraph: Int?
    let close: () -> Void
    let opened: () -> Void
    @AppStorage("sermo.reader.font") private var fontChoice = "follow"
    @AppStorage("sermo.reader.size") private var fontSize = 21.0
    @AppStorage("sermo.reader.line") private var lineGap = 8.0
    @AppStorage("sermo.reader.paragraph") private var paragraphGap = 13.0
    @AppStorage("sermo.reader.margin") private var margin = 26.0
    @AppStorage("sermo.reader.palette") private var palette = "follow"
    @AppStorage("sermo.reader.mode") private var mode = "scroll"
    @AppStorage("sermo.reader.spread") private var spread = true
    @AppStorage("sermo.reader.indent") private var indent = true
    @AppStorage("sermo.reader.orientation") private var orientation = "device"
    @StateObject private var volumeKeys = ReaderVolumeKeys()
    @AppStorage("sermo.reader.volumeKeys") private var volumeEnabled = false
    @AppStorage("sermo.reader.volumeReverse") private var volumeReverse = false
    @State private var chapter = 0
    @State private var currentOffset = 0
    @State private var jump = ReaderJump(offset: 0)
    @State private var chrome = false
    @State private var sheet: ReaderPanel?
    @State private var prepared = false
    @State private var saveTask: Task<Void, Never>?
    @State private var originalBrightness: CGFloat?
    @State private var slider = 0.0
    @State private var sliding = false
    @State private var page = 1
    @State private var pageCount = 1
    @State private var markToast = false
    @State private var playScene: BookScene?
    private var book: Book? { books.book(bookID) }
    private var chapters: [BookChapter] { books.chapters(of: bookID) }
    private var document: NovelDocument {
        NovelDocument(chapter: chapter, text: chapters.indices.contains(chapter) ? chapters[chapter].text : "")
    }
    private var totalCharacters: Double { Double(max(1, chapters.reduce(0) { $0 + ($1.text as NSString).length })) }
    private var progress: Double {
        let before = chapters.prefix(chapter).reduce(0) { $0 + ($1.text as NSString).length }
        let local = Double(currentOffset) / Double(max(1, document.length))
        let length = chapters.indices.contains(chapter) ? (chapters[chapter].text as NSString).length : 0
        return min(1, (Double(before) + local * Double(length)) / totalCharacters)
    }
    private var paper: (UInt32, UInt32) {
        switch palette {
        case "white": return (0xFFFFFF, 0x242424)
        case "warm": return (0xF1E7D0, 0x392F25)
        case "green": return (0xDDE8D8, 0x263A2A)
        case "night": return (0x161719, 0xBFC0BB)
        default:
            if colorScheme == .dark { return InterfaceStyle.isSwiss ? (0x111214, 0xEDEDE9) : (0x171716, 0xECEAE3) }
            return InterfaceStyle.isSwiss ? (0xF2F2EF, 0x111111) : (0xFAF9F5, 0x1F1E1D)
        }
    }
    private var readerFont: String {
        switch fontChoice {
        case "song": return "NotoSerifSC-Regular"
        case "sans": return "PingFangSC-Regular"
        case "custom": return FontLibrary.regularName ?? "NotoSerifSC-Regular"
        default: return FontLibrary.regularFace
        }
    }
    private var style: ReaderPageStyle {
        ReaderPageStyle(fontName: readerFont, size: fontSize, lineGap: lineGap, paragraphGap: paragraphGap, margin: margin,
                        paged: mode == "pages", spreads: spread, background: paper.0, foreground: paper.1, firstLineIndent: indent)
    }
    private var ink: Color { Color(ReaderPageStyle.color(paper.1)) }
    var body: some View {
        ZStack {
            Color(ReaderPageStyle.color(paper.0)).ignoresSafeArea()
            VStack(spacing: 0) {
                HStack {
                    Text(book?.chapterLabel(chapter) ?? "").lineLimit(1)
                    Spacer(minLength: 8)
                    if InterfaceStyle.isSwiss { Text(String(format: "%03d", chapter + 1)).monospaced() }
                }
                .font(.system(size: 11)).foregroundStyle(ink.opacity(0.55))
                .padding(.horizontal, max(20, margin)).padding(.top, 5).frame(height: 25)
                ReaderCanvas(document: document, style: style, jump: jump,
                    tapped: { withAnimation(.easeOut(duration: 0.18)) { chrome.toggle() } },
                    moved: { offset, p, count in
                        currentOffset = offset; page = p; pageCount = count
                        if !sliding { slider = progress }
                        scheduleSave()
                    },
                    chapterStep: { step in navigate(chapter + step, offset: step < 0 ? Int.max : 0) },
                    paragraphAction: { paragraph, play in if play { startPlaying(paragraph) } else { addMark(paragraph) } },
                    canPlay: book?.isReady == true, pageCommand: volumeKeys.command)
                HStack {
                    if mode == "pages" { Text("本章 \(page) / \(pageCount)") }
                    else { Text("上下滚动 · 左右划换章") }
                    Spacer()
                    Text(String(format: "全书 %.1f%%", progress * 100)).monospacedDigit()
                }
                .font(.system(size: 10)).foregroundStyle(ink.opacity(0.55))
                .padding(.horizontal, max(20, margin)).frame(height: 25)
            }
            if chrome { controls.transition(.opacity) }
            if markToast {
                Text("书签已保存").font(TypeScale.label).padding(.horizontal, 20).padding(.vertical, 12)
                    .background(Ink.raised, in: InkRounded(radius: 16)).foregroundStyle(Ink.ink)
                    .allowsHitTesting(false)
            }
        }
        .statusBarHidden(true)
        .preferredColorScheme(palette == "night" ? .dark : nil)
        .onAppear {
            guard !prepared else { return }
            prepared = true; originalBrightness = UIScreen.main.brightness
            chapter = min(max(0, initialChapter), max(0, chapters.count - 1))
            let mark = book?.bookmark
            let doc = NovelDocument(chapter: chapter, text: chapters.indices.contains(chapter) ? chapters[chapter].text : "")
            let paragraph = initialParagraph ?? 0
            let offset = mark?.chapter == chapter && mark?.paragraph == paragraph ? mark?.characterOffset : nil
            currentOffset = offset ?? (doc.starts.indices.contains(paragraph) ? doc.starts[paragraph] : 0)
            jump = ReaderJump(offset: currentOffset)
            ReaderAppDelegate.setReaderOrientation(orientation)
            volumeKeys.configure(enabled: volumeEnabled, reverse: volumeReverse)
        }
        .onDisappear {
            saveTask?.cancel(); savePosition()
            volumeKeys.stop()
            ReaderAppDelegate.setReaderOrientation(nil)
            if let brightness = originalBrightness { UIScreen.main.brightness = brightness }
        }
        .onChange(of: orientation) { _, value in ReaderAppDelegate.setReaderOrientation(value) }
        .onChange(of: scenePhase) { _, value in
            if value != .active { saveTask?.cancel(); savePosition(); volumeKeys.stop() }
            else { volumeKeys.configure(enabled: volumeEnabled, reverse: volumeReverse) }
        }
        .onChange(of: volumeEnabled) { _, value in volumeKeys.configure(enabled: value, reverse: volumeReverse) }
        .onChange(of: volumeReverse) { _, value in volumeKeys.configure(enabled: volumeEnabled, reverse: value) }
        .onChange(of: sheet?.rawValue) { _, _ in volumeKeys.suspended = sheet != nil || playScene != nil }
        .onChange(of: playScene?.id) { _, _ in volumeKeys.suspended = sheet != nil || playScene != nil }
        .sheet(item: $sheet) { panel in
            switch panel {
            case .settings: ReaderSettingsView().environmentObject(volumeKeys)
            case .contents: ReaderContentsView(bookID: bookID, selected: chapter) { c, p in navigate(c, paragraph: p); sheet = nil }
            case .bookmarks: ReaderBookmarksView(bookID: bookID) { c, p in navigate(c, paragraph: p); sheet = nil }
            case .search: ReaderSearchView(bookID: bookID) { c, p in navigate(c, paragraph: p); sheet = nil }
            }
        }
        .sheet(item: $playScene) { scene in
            if let book, let profile = book.profile {
                StartStoryView(book: book, profile: profile, initialScene: scene) {
                    savePosition(); ReaderAppDelegate.setReaderOrientation(nil); close(); opened()
                }.environmentObject(store).environmentObject(books)
            }
        }
    }
    private var controls: some View {
        VStack(spacing: 0) {
            HStack {
                Button { savePosition(); close() } label: { Image(systemName: "chevron.left").frame(width: 44, height: 44) }.accessibilityLabel("退出阅读")
                VStack(alignment: .leading, spacing: 3) {
                    Text(book?.title ?? "阅读").font(TypeScale.body).lineLimit(1)
                    Text(book?.chapterLabel(chapter) ?? "").font(TypeScale.tiny).foregroundStyle(Ink.ink3).lineLimit(1)
                }
                Spacer()
                Button { addMark(document.paragraph(at: currentOffset)) } label: { Image(systemName: "bookmark.badge.plus").frame(width: 44, height: 44) }.accessibilityLabel("添加书签")
            }.padding(.horizontal, 8).background(Ink.paper)
            Rectangle().fill(Ink.line).frame(height: InterfaceStyle.isSwiss ? 1 : 0.5)
            Spacer()
            VStack(spacing: 12) {
                HStack {
                    Button("上一章") { navigate(chapter - 1) }.disabled(chapter <= 0)
                    Spacer()
                    Text(String(format: "%.1f%%", sliding ? slider * 100 : progress * 100)).monospacedDigit()
                    Spacer()
                    Button("下一章") { navigate(chapter + 1) }.disabled(chapter + 1 >= chapters.count)
                }.font(TypeScale.label)
                Slider(value: $slider, in: 0...1, onEditingChanged: { value in
                    sliding = value
                    if !value { seek(slider) }
                }).accessibilityLabel("全书阅读进度")
                HStack {
                    panelButton("目录", icon: "list.bullet", panel: .contents)
                    panelButton("书签", icon: "bookmark", panel: .bookmarks)
                    panelButton("搜索", icon: "magnifyingglass", panel: .search)
                    panelButton("排版", icon: "textformat.size", panel: .settings)
                }
            }
            .padding(20).background(Ink.paper, in: InkRounded(radius: 22))
            .overlay(alignment: .top) { Rectangle().fill(Ink.line).frame(height: InterfaceStyle.isSwiss ? 1 : 0) }
        }.foregroundStyle(Ink.ink).tint(Ink.seal)
    }
    private func panelButton(_ title: String, icon: String, panel: ReaderPanel) -> some View {
        Button { sheet = panel } label: {
            VStack(spacing: 7) { Image(systemName: icon).font(.system(size: 19)); Text(title).font(TypeScale.tiny) }
                .frame(maxWidth: .infinity).frame(minHeight: 48)
        }
    }
    private func scheduleSave() {
        saveTask?.cancel()
        saveTask = Task { @MainActor in
            do { try await Task.sleep(nanoseconds: 850_000_000) } catch { return }
            savePosition()
        }
    }
    private func savePosition() {
        guard prepared, chapters.indices.contains(chapter) else { return }
        books.setBookmark(BookBookmark(chapter: chapter, paragraph: document.paragraph(at: currentOffset), characterOffset: currentOffset), in: bookID)
    }
    private func navigate(_ value: Int, offset: Int = 0, paragraph: Int? = nil) {
        guard chapters.indices.contains(value) else { return }
        saveTask?.cancel(); savePosition()
        let doc = NovelDocument(chapter: value, text: chapters[value].text)
        let target = paragraph.flatMap { doc.starts.indices.contains($0) ? doc.starts[$0] : nil } ?? offset
        chapter = value; currentOffset = min(max(0, target), max(0, doc.length - 1))
        jump = ReaderJump(offset: currentOffset); slider = progress
        savePosition()
    }
    private func seek(_ fraction: Double) {
        let target = fraction * totalCharacters
        var cursor = 0
        for (index, value) in chapters.enumerated() {
            let size = (value.text as NSString).length
            if Double(cursor + size) >= target || index == chapters.count - 1 {
                let ratio = max(0, min(1, (target - Double(cursor)) / Double(max(1, size))))
                let doc = NovelDocument(chapter: index, text: value.text)
                navigate(index, offset: Int(ratio * Double(max(0, doc.length - 1))))
                return
            }
            cursor += size
        }
    }
    private func addMark(_ paragraph: Int) {
        guard document.paragraphs.indices.contains(paragraph) else { return }
        books.addReaderMark(chapter: chapter, paragraph: paragraph, excerpt: String(document.paragraphs[paragraph].prefix(150)), in: bookID)
        markToast = true
        Task { @MainActor in try? await Task.sleep(nanoseconds: 1_200_000_000); markToast = false }
    }
    private func startPlaying(_ paragraph: Int) {
        guard document.paragraphs.indices.contains(paragraph) else { return }
        var scene = BookScene(title: "原文选段", chapter: chapter, summary: "", characters: [])
        scene.paragraph = paragraph
        scene.anchor = String(document.paragraphs[paragraph].prefix(60))
        playScene = scene
    }
}

enum ReaderPanel: String, Identifiable { case settings, contents, bookmarks, search; var id: String { rawValue } }

@MainActor
struct ReaderSettingsView: View {
    @EnvironmentObject private var volumeKeys: ReaderVolumeKeys
    @AppStorage("sermo.reader.volumeKeys") private var volumeEnabled = false
    @AppStorage("sermo.reader.volumeReverse") private var volumeReverse = false
    @Environment(\.dismiss) private var dismiss
    @AppStorage("sermo.reader.font") private var font = "follow"
    @AppStorage("sermo.reader.size") private var size = 21.0
    @AppStorage("sermo.reader.line") private var line = 8.0
    @AppStorage("sermo.reader.paragraph") private var paragraph = 13.0
    @AppStorage("sermo.reader.margin") private var margin = 26.0
    @AppStorage("sermo.reader.palette") private var palette = "follow"
    @AppStorage("sermo.reader.mode") private var mode = "scroll"
    @AppStorage("sermo.reader.spread") private var spread = true
    @AppStorage("sermo.reader.indent") private var indent = true
    @AppStorage("sermo.reader.orientation") private var orientation = "device"
    @State private var brightness = Double(UIScreen.main.brightness)
    var body: some View {
        NavigationStack {
            Form {
                Section("阅读方式") {
                    Picker("翻页方式", selection: $mode) { Text("上下滚动").tag("scroll"); Text("左右翻页").tag("pages") }
                    Picker("屏幕方向", selection: $orientation) {
                        Text("跟随设备").tag("device"); Text("锁定竖屏").tag("portrait"); Text("锁定横屏").tag("landscape")
                    }
                    if UIDevice.current.userInterfaceIdiom == .pad {
                        Toggle("横屏宽屏时双页显示", isOn: $spread).disabled(mode != "pages")
                    }
                }
                Section {
                    Toggle("音量键翻页（兼容模式）", isOn: $volumeEnabled)
                    if volumeEnabled { Toggle("反转上下键", isOn: $volumeReverse) }
                    if let issue = volumeKeys.issue { Text(issue).font(TypeScale.tiny).foregroundStyle(Ink.ink3) }
                } header: { Text("音量键") } footer: {
                    Text("默认音量＋上一页、音量－下一页；滚动模式翻动一屏。只在阅读正文时生效。系统音量也会随按键变化，到最大或最小时继续按同一键可能无法翻页。")
                }
                Section("正文排版") {
                    Picker("字体", selection: $font) {
                        Text("跟随界面主题").tag("follow"); Text("宋体").tag("song"); Text("黑体").tag("sans")
                        if FontLibrary.regularName != nil { Text("已导入的字体").tag("custom") }
                    }
                    slider("字号", value: $size, range: 15...34)
                    slider("行距", value: $line, range: 0...20)
                    slider("段间距", value: $paragraph, range: 0...30)
                    slider("左右留白", value: $margin, range: 16...60)
                    Toggle("首行缩进两字", isOn: $indent)
                }
                Section("阅读纸色") {
                    Picker("纸色", selection: $palette) {
                        Text("跟随纸笺／瑞士主题").tag("follow"); Text("纯白").tag("white")
                        Text("米黄").tag("warm"); Text("浅绿").tag("green"); Text("夜间").tag("night")
                    }
                }
                Section {
                    HStack { Image(systemName: "sun.min"); Slider(value: $brightness, in: 0.05...1); Image(systemName: "sun.max") }
                        .onChange(of: brightness) { _, value in UIScreen.main.brightness = CGFloat(value) }
                } header: { Text("阅读亮度") } footer: { Text("退出阅读时恢复原来的亮度。字体和纸色只影响正文，菜单沿用当前界面主题。") }
            }
            .font(TypeScale.body).scrollContentBackground(.hidden).background(AppBackground())
            .navigationTitle("阅读设置").navigationBarTitleDisplayMode(.inline)
            .toolbar { Button("完成") { dismiss() } }
        }.tint(Ink.seal).presentationDetents([.medium, .large]).presentationDragIndicator(.visible)
    }
    private func slider(_ label: String, value: Binding<Double>, range: ClosedRange<Double>) -> some View {
        VStack(alignment: .leading, spacing: 5) {
            HStack { Text(label); Spacer(); Text("\(Int(value.wrappedValue))").monospacedDigit().foregroundStyle(Ink.ink3) }
            Slider(value: value, in: range, step: 1).accessibilityLabel(label)
        }
    }
}

@MainActor
struct ReaderContentsView: View {
    @EnvironmentObject private var books: BookStore
    @Environment(\.dismiss) private var dismiss
    let bookID: UUID
    let selected: Int
    let jump: (Int, Int) -> Void
    @State private var search = ""
    var body: some View {
        NavigationStack {
            ScrollViewReader { proxy in
                List {
                    ForEach(Array((books.book(bookID)?.chapterTitles ?? []).enumerated()), id: \.offset) { index, title in
                        if search.isEmpty || title.localizedCaseInsensitiveContains(search) {
                            Button { jump(index, 0) } label: {
                                HStack(alignment: .firstTextBaseline, spacing: 12) {
                                    Text(String(format: "%03d", index + 1)).monospaced().font(TypeScale.tiny).foregroundStyle(Ink.ink3)
                                    Text(title).font(TypeScale.body).foregroundStyle(index == selected ? Ink.seal : Ink.ink)
                                    Spacer()
                                    if index == selected { Image(systemName: "speaker.wave.1").foregroundStyle(Ink.seal) }
                                }
                            }.id(index)
                        }
                    }
                }.onAppear { proxy.scrollTo(selected, anchor: .center) }
            }
            .searchable(text: $search, prompt: "搜索章节")
            .scrollContentBackground(.hidden).background(AppBackground()).navigationTitle("目录")
            .toolbar { Button("完成") { dismiss() } }
        }.tint(Ink.seal)
    }
}

@MainActor
struct ReaderBookmarksView: View {
    @EnvironmentObject private var books: BookStore
    @Environment(\.dismiss) private var dismiss
    let bookID: UUID
    let jump: (Int, Int) -> Void
    var body: some View {
        NavigationStack {
            List {
                let marks = books.book(bookID)?.readerMarks ?? []
                if marks.isEmpty { Text("轻点阅读菜单的书签按钮，或长按一段原文添加书签。").foregroundStyle(Ink.ink3) }
                ForEach(marks.sorted { $0.createdAt > $1.createdAt }) { mark in
                    Button { jump(mark.chapter, mark.paragraph) } label: {
                        VStack(alignment: .leading, spacing: 6) {
                            Text(books.book(bookID)?.chapterLabel(mark.chapter) ?? "").font(TypeScale.body).foregroundStyle(Ink.ink)
                            Text(mark.excerpt).font(TypeScale.label).foregroundStyle(Ink.ink2).lineLimit(3)
                            Text(mark.createdAt.formatted(date: .abbreviated, time: .shortened)).font(TypeScale.tiny).foregroundStyle(Ink.ink3)
                        }.multilineTextAlignment(.leading)
                    }.swipeActions { Button("删除", role: .destructive) { books.deleteReaderMark(mark.id, in: bookID) } }
                }
            }
            .scrollContentBackground(.hidden).background(AppBackground()).navigationTitle("书签")
            .toolbar { Button("完成") { dismiss() } }
        }.tint(Ink.seal)
    }
}

struct ReaderSearchHit: Identifiable, Sendable {
    var id: String
    var chapter: Int
    var paragraph: Int
    var excerpt: String
}

@MainActor
struct ReaderSearchView: View {
    @EnvironmentObject private var books: BookStore
    @Environment(\.dismiss) private var dismiss
    let bookID: UUID
    let jump: (Int, Int) -> Void
    @State private var query = ""
    @State private var results: [ReaderSearchHit] = []
    @State private var searching = false
    var body: some View {
        NavigationStack {
            List {
                if searching { ProgressView("正在本地查找…") }
                if query.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty { Text("输入人名、句子或关键词，搜索整本原文。").foregroundStyle(Ink.ink3) }
                else if !searching && results.isEmpty { Text("没有找到匹配的原文。").foregroundStyle(Ink.ink3) }
                ForEach(results) { hit in
                    Button { jump(hit.chapter, hit.paragraph) } label: {
                        VStack(alignment: .leading, spacing: 6) {
                            Text(books.book(bookID)?.chapterLabel(hit.chapter) ?? "").font(TypeScale.tiny).foregroundStyle(Ink.seal)
                            Text(hit.excerpt).font(TypeScale.body).foregroundStyle(Ink.ink).lineLimit(4)
                        }.multilineTextAlignment(.leading)
                    }
                }
                if results.count >= 200 { Text("显示前200处匹配，可输入更完整的关键词。").font(TypeScale.tiny).foregroundStyle(Ink.ink3) }
            }
            .searchable(text: $query, prompt: "搜索整本原文")
            .scrollContentBackground(.hidden).background(AppBackground()).navigationTitle("全文搜索")
            .toolbar { Button("完成") { dismiss() } }
            .task(id: query) {
                let term = query.trimmingCharacters(in: .whitespacesAndNewlines)
                results = []
                guard !term.isEmpty else { searching = false; return }
                searching = true
                do { try await Task.sleep(nanoseconds: 300_000_000) } catch { return }
                let chapters = books.chapters(of: bookID)
                let work = Task.detached(priority: .userInitiated) { () -> [ReaderSearchHit] in
                    var found: [ReaderSearchHit] = []
                    for (chapter, value) in chapters.enumerated() {
                        if Task.isCancelled { return [] }
                        for (paragraph, line) in BookScenes.paragraphs(value.text).enumerated() where line.localizedCaseInsensitiveContains(term) {
                            let source = line as NSString
                            let match = source.range(of: term, options: [.caseInsensitive, .diacriticInsensitive])
                            let start = max(0, match.location == NSNotFound ? 0 : match.location - 35)
                            let snippet = source.substring(with: NSRange(location: start, length: min(180, source.length - start)))
                            found.append(ReaderSearchHit(id: "\(chapter):\(paragraph)", chapter: chapter, paragraph: paragraph, excerpt: snippet))
                            if found.count == 200 { return found }
                        }
                    }
                    return found
                }
                let found = await withTaskCancellationHandler(operation: { await work.value }, onCancel: { work.cancel() })
                guard !Task.isCancelled else { return }
                results = found; searching = false
            }
        }.tint(Ink.seal)
    }
}

struct ReaderBookCover: View {
    let title: String
    var body: some View {
        ZStack(alignment: .leading) {
            Ink.raised
            Rectangle().fill(Ink.seal.opacity(0.7)).frame(width: 3)
            VStack(alignment: .leading, spacing: 4) {
                Text(title).font(TypeScale.serif(12)).lineLimit(3).foregroundStyle(Ink.ink)
                Spacer(minLength: 0)
                Text(InterfaceStyle.isSwiss ? "BOOK" : "藏书").font(TypeScale.mono(8)).foregroundStyle(Ink.seal)
            }.padding(8)
        }.frame(width: 52, height: 74).clipShape(InkRounded(radius: 5))
            .overlay(InkRounded(radius: 5).stroke(Ink.line, lineWidth: 0.5))
    }
}

