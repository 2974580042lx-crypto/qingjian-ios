import SwiftUI
import UIKit

/// UIKit owns the keyboard attachment; SwiftUI owns the content. This avoids
/// safe-area height lag when an input accessory grows and shrinks in one focus.
@MainActor
struct KeyboardChatLayout<Transcript: View, Composer: View>: UIViewControllerRepresentable {
    let transcript: Transcript
    let composer: Composer

    init(@ViewBuilder transcript: () -> Transcript, @ViewBuilder composer: () -> Composer) {
        self.transcript = transcript()
        self.composer = composer()
    }

    func makeUIViewController(context: Context) -> Controller {
        Controller(transcript: transcript, composer: composer)
    }

    func updateUIViewController(_ controller: Controller, context: Context) {
        controller.transcriptHost.rootView = transcript
        controller.composerHost.rootView = composer
        controller.composerHost.view.invalidateIntrinsicContentSize()
        controller.view.setNeedsLayout()
    }

    final class Controller: UIViewController {
        let transcriptHost: UIHostingController<Transcript>
        let composerHost: UIHostingController<Composer>

        init(transcript: Transcript, composer: Composer) {
            transcriptHost = UIHostingController(rootView: transcript)
            composerHost = UIHostingController(rootView: composer)
            super.init(nibName: nil, bundle: nil)
        }
        required init?(coder: NSCoder) { fatalError("init(coder:) is unavailable") }

        override func viewDidLoad() {
            super.viewDidLoad()
            view.backgroundColor = .clear
            // Do not let either hosting controller apply keyboard avoidance a
            // second time: the constraints below are the sole vertical owner.
            transcriptHost.safeAreaRegions = []
            composerHost.safeAreaRegions = []
            composerHost.sizingOptions = [.intrinsicContentSize]
            for host in [transcriptHost as UIViewController, composerHost as UIViewController] {
                addChild(host)
                host.view.backgroundColor = .clear
                host.view.translatesAutoresizingMaskIntoConstraints = false
                view.addSubview(host.view)
                host.didMove(toParent: self)
            }
            composerHost.view.setContentHuggingPriority(.required, for: .vertical)
            composerHost.view.setContentCompressionResistancePriority(.required, for: .vertical)
            NSLayoutConstraint.activate([
                transcriptHost.view.topAnchor.constraint(equalTo: view.topAnchor),
                transcriptHost.view.leadingAnchor.constraint(equalTo: view.leadingAnchor),
                transcriptHost.view.trailingAnchor.constraint(equalTo: view.trailingAnchor),
                transcriptHost.view.bottomAnchor.constraint(equalTo: composerHost.view.topAnchor),
                composerHost.view.leadingAnchor.constraint(equalTo: view.leadingAnchor),
                composerHost.view.trailingAnchor.constraint(equalTo: view.trailingAnchor),
                composerHost.view.bottomAnchor.constraint(equalTo: view.keyboardLayoutGuide.topAnchor)
            ])
        }
    }
}
