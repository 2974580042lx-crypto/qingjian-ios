import SwiftUI
import UIKit

// Laid out like the Claude app's sidebar: wordmark and search on top, Projects,
// recent conversations with "查看全部", and at the bottom your avatar (settings)
// and a new-conversation button.
@MainActor
struct HistorySidebar: View {
    @AppStorage(HighlightStyle.key) private var highlightHex = ""
    @Environment(\.colorScheme) private var colorScheme
    @EnvironmentObject private var store: AppStore
    @EnvironmentObject private var profile: ProfileStore
    let close: () -> Void
    let openSettings: () -> Void
    let openProjects: () -> Void
    let openAllChats: () -> Void
    var openBooks: () -> Void = {}
    @State private var searching = false
    @State private var search = ""
    @FocusState private var searchFocused: Bool
    @State private var renameID: UUID?
    @State private var renameText = ""
    @State private var deleteTarget: ChatThread?
    // Pinned projects folded open in the sidebar.
    @State private var expanded: Set<UUID> = []
    private static let recentLimit = 12

    private var results: [ChatThread] {
        store.browsableThreads.filter { thread in
            thread.title.localizedCaseInsensitiveContains(search) ||
                thread.messages.contains(where: { $0.content.localizedCaseInsensitiveContains(search) })
        }
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            HStack {
                Text("Sermo").font(TypeScale.heavy(30, relativeTo: .largeTitle)).foregroundStyle(Ink.ink)
                    .accessibilityAddTraits(.isHeader).accessibilityIdentifier("history-title")
                Spacer()
                GlassCircle(symbol: searching ? "xmark" : "magnifyingglass", label: searching ? "关闭搜索" : "搜索对话") {
                    withAnimation(.easeOut(duration: 0.2)) { searching.toggle() }
                    if searching { searchFocused = true } else { search = ""; searchFocused = false }
                }
            }
            .padding(.bottom, 18)
            if searching {
                TextField("搜索对话", text: $search).font(TypeScale.serif(16)).autocorrectionDisabled()
                    .focused($searchFocused)
                    .padding(.horizontal, 14).frame(height: 44).clearGlass(radius: 22)
                    .padding(.bottom, 12)
            }
            ScrollView {
                LazyVStack(alignment: .leading, spacing: 0) {
                    if searching && !search.isEmpty {
                        groupLabel(results.isEmpty ? "没有找到相关对话" : "搜索结果")
                        ForEach(results) { row($0) }
                    } else {
                        navRow("项目", symbol: "folder", identifier: "sidebar-projects") { openProjects() }
                        navRow("书架", symbol: "books.vertical", identifier: "sidebar-books") { openBooks() }
                        ForEach(store.projects.filter { $0.isPinned == true }) { projectGroup($0) }
                        groupLabel("最近")
                        let recent = store.recentThreads
                        if recent.isEmpty {
                            Text("还没有对话").font(TypeScale.serif(14)).foregroundStyle(Ink.ink3).padding(.vertical, 10)
                        }
                        ForEach(recent.prefix(Self.recentLimit)) { row($0) }
                        Button { openAllChats() } label: {
                            HStack(spacing: 6) {
                                Text("查看全部")
                                Image(systemName: "chevron.right").font(.system(size: 12, weight: .medium))
                            }
                            .font(TypeScale.serif(16)).foregroundStyle(Ink.ink2)
                            .padding(.vertical, 14).contentShape(Rectangle())
                        }
                        .buttonStyle(.plain).accessibilityIdentifier("sidebar-all-chats")
                    }
                }
            }
            .scrollDismissesKeyboard(.interactively)
            .contentMargins(.bottom, 90, for: .scrollContent)
            .contentMargins(.bottom, 90, for: .scrollIndicators)
            .overlay(alignment: .bottom) { footer }
        }
        .padding(.horizontal, 20).padding(.top, 16)
        .foregroundStyle(Ink.ink)
        .alert("重命名对话", isPresented: Binding(get: { renameID != nil }, set: { if !$0 { renameID = nil } })) {
            TextField("对话名称", text: $renameText)
            Button("取消", role: .cancel) { renameID = nil }
            Button("保存") { if let id = renameID { store.renameThread(id, title: renameText) }; renameID = nil }
        }
        .alert("删除这个对话？", isPresented: Binding(get: { deleteTarget != nil }, set: { if !$0 { deleteTarget = nil } })) {
            Button("取消", role: .cancel) { deleteTarget = nil }
            Button("删除", role: .destructive) { if let thread = deleteTarget { store.deleteThread(thread.id) }; deleteTarget = nil }
        } message: { Text("同时移除这个对话关联的旧版重试记录和附带的图片。已导出的备份和用量记录不受影响。") }
    }

    private var footer: some View {
        HStack(spacing: 12) {
            Button {
                UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
                openSettings()
            } label: {
                HStack(spacing: 10) {
                    ProfileAvatar(image: profile.avatar, size: 46, initial: profile.name.first.map(String.init))
                        .glassEffect(.regular.interactive(), in: .circle)
                    if let balance = store.balanceText {
                        Text("余额 \(balance)").font(TypeScale.serif(13)).monospacedDigit().foregroundStyle(Ink.ink2).lineLimit(1)
                    }
                }.contentShape(Rectangle())
            }
            .buttonStyle(.plain)
            .accessibilityLabel("个人资料与设置")
            .accessibilityIdentifier("sidebar-profile")
            Spacer(minLength: 8)
            Button { store.createNewChat(); finish() } label: {
                HStack(spacing: 8) {
                    Image(systemName: "plus").font(.system(size: 15, weight: .medium))
                    Text("新建会话").font(TypeScale.serif(16).weight(.semibold))
                }
                .foregroundStyle(Ink.onSolid)
                .padding(.horizontal, 20).frame(height: 48)
                .background(Ink.solid, in: InkCapsule())
                .contentShape(Capsule())
            }
            .buttonStyle(.plain)
            .accessibilityIdentifier("sidebar-new-chat")
        }
        .padding(.bottom, 10)
    }

    private func groupLabel(_ title: String) -> some View {
        Text(title).font(TypeScale.serif(14)).foregroundStyle(Ink.ink3)
            .padding(.top, 22).padding(.bottom, 6)
    }

    private func navRow(_ title: String, symbol: String, identifier: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            HStack(spacing: 14) {
                Image(systemName: symbol).font(.system(size: 18)).frame(width: 24)
                Text(title).font(TypeScale.serif(18))
            }
            .foregroundStyle(Ink.ink).padding(.vertical, 12)
            .frame(maxWidth: .infinity, alignment: .leading).contentShape(Rectangle())
        }
        .buttonStyle(.plain).accessibilityIdentifier(identifier)
    }

    // A pinned project: tap to fold its conversations out underneath, like a drawer.
    @ViewBuilder private func projectGroup(_ project: ChatProject) -> some View {
        let open = expanded.contains(project.id) && !store.isLocked(project.id)
        Button {
            if open { withAnimation(.easeOut(duration: 0.2)) { _ = expanded.remove(project.id) }; return }
            Task {
                if await ProjectLock.open(project.id, store: store) {
                    withAnimation(.easeOut(duration: 0.2)) { _ = expanded.insert(project.id) }
                }
            }
        } label: {
            HStack(spacing: 14) {
                Image(systemName: open ? "chevron.down" : "chevron.right")
                    .font(.system(size: 12, weight: .semibold)).foregroundStyle(Ink.ink3).frame(width: 24)
                Text(project.name).font(TypeScale.serif(17)).lineLimit(1)
                Spacer(minLength: 8)
                if project.isLocked { Image(systemName: "lock").font(.system(size: 12)).foregroundStyle(Ink.ink3) }
            }
            .foregroundStyle(Ink.ink).padding(.vertical, 10)
            .frame(maxWidth: .infinity, alignment: .leading).contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .accessibilityIdentifier("sidebar-pinned-project")
        .accessibilityValue(open ? "展开" : "收起")
        if open {
            let members = store.threads(in: project.id)
            if members.isEmpty {
                Text("还没有对话").font(TypeScale.serif(14)).foregroundStyle(Ink.ink3)
                    .padding(.leading, 38).padding(.vertical, 6)
            }
            ForEach(members) { row($0, showProject: false).padding(.leading, 24) }
            Button { store.createThread(in: project.id); finish() } label: {
                Label("在此项目新建会话", systemImage: "plus").font(TypeScale.serif(14)).foregroundStyle(Ink.ink2)
                    .padding(.leading, 38).padding(.vertical, 8)
                    .frame(maxWidth: .infinity, alignment: .leading).contentShape(Rectangle())
            }
            .buttonStyle(.plain)
        }
    }

    private func row(_ thread: ChatThread, showProject: Bool = true) -> some View {
        let active = thread.id == store.activeThreadID
        return Button { store.select(thread.id); finish() } label: {
            HStack(spacing: 14) {
                Image(systemName: thread.isPinned == true ? "pin" : "bubble.left")
                    .font(.system(size: 16)).foregroundStyle(Ink.ink2).frame(width: 24)
                    .accessibilityHidden(true)
                Text(thread.title).font(TypeScale.serif(17)).lineLimit(1)
                    .background(alignment: .bottom) {
                        if active { Rectangle().fill(HighlightStyle.color(highlightHex, scheme: colorScheme)).frame(height: 9).padding(.horizontal, -2) }
                    }
                Spacer(minLength: 8)
                if thread.id == store.generatingThreadID { PulseDot(size: 7) }
                else if showProject, let project = store.project(thread.projectID) {
                    Text(project.name).font(TypeScale.tiny).foregroundStyle(Ink.ink3).lineLimit(1)
                }
            }
            .padding(.vertical, 11)
            .frame(maxWidth: .infinity, alignment: .leading)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .accessibilityIdentifier("history-thread-row")
        .accessibilityAddTraits(active ? .isSelected : [])
        .contextMenu {
            Button(thread.isPinned == true ? "取消置顶" : "置顶", systemImage: "pin") { store.togglePinned(thread.id) }
            Button("重命名", systemImage: "pencil") { renameText = thread.title; renameID = thread.id }
            Menu("移到项目", systemImage: "folder") {
                ForEach(store.projects.filter { !store.isLocked($0.id) }) { project in
                    Button(project.name) { store.moveThreads([thread.id], to: project.id) }
                }
                if thread.projectID != nil {
                    Button("移出项目", systemImage: "tray.and.arrow.up") { store.moveThreads([thread.id], to: nil) }
                }
            }
            Button("删除对话", systemImage: "trash", role: .destructive) { deleteTarget = thread }
                .disabled(thread.id == store.generatingThreadID)
        }
    }

    private func finish() {
        UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
        searching = false; search = ""
        close()
    }
}
