import SwiftUI
import UIKit

@MainActor
struct HistorySidebar: View {
    @EnvironmentObject private var store: AppStore
    let close: () -> Void
    @State private var search = ""
    @State private var renameID: UUID?
    @State private var renameText = ""
    @State private var deleteTarget: ChatThread?
    private var filtered: [ChatThread] {
        store.sortedThreads.filter {
            search.isEmpty || $0.title.localizedCaseInsensitiveContains(search) ||
                $0.messages.contains(where: { $0.content.localizedCaseInsensitiveContains(search) })
        }
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 22) {
            HStack {
                Text("你的对话").font(.custom("NotoSerifSC-Regular", size: 25)).accessibilityIdentifier("history-title")
                Spacer()
                GlassCircle(symbol: "xmark", label: "关闭历史对话") { finish() }
            }
            HStack(spacing: 10) {
                Image(systemName: "magnifyingglass").foregroundStyle(Palette.secondary)
                TextField("搜索对话", text: $search).font(.system(size: 14))
                    .autocorrectionDisabled()
                if !search.isEmpty {
                    Button { search = "" } label: { Image(systemName: "xmark.circle.fill") }
                        .foregroundStyle(Palette.secondary).accessibilityLabel("清除搜索")
                }
            }.padding(13).background(Color.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 16))
            Button {
                store.createThread(); finish()
            } label: {
                Label("新建对话", systemImage: "square.and.pencil")
                    .font(.system(size: 14, weight: .medium)).frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.horizontal, 4).padding(.vertical, 10)
            }.buttonStyle(.plain)
            Divider().overlay(Color.white.opacity(0.04))
            ScrollView {
                LazyVStack(alignment: .leading, spacing: 8) {
                    if filtered.isEmpty {
                        Text("没有找到相关对话").font(.system(size: 13)).foregroundStyle(Palette.secondary).padding(.top, 24)
                    }
                    ForEach(filtered) { thread in
                        Button { store.select(thread.id); finish() } label: {
                            VStack(alignment: .leading, spacing: 9) {
                                HStack(spacing: 6) {
                                    if thread.isPinned == true { Image(systemName: "pin.fill").font(.system(size: 10)) }
                                    Text(thread.title).font(.system(size: 14, weight: .medium)).lineLimit(1)
                                    Spacer(minLength: 2)
                                    if thread.id == store.generatingThreadID { ProgressView().controlSize(.mini) }
                                    else if thread.id == store.activeThreadID { Circle().fill(.white).frame(width: 5, height: 5) }
                                }
                                Text(thread.preview).font(.system(size: 12)).foregroundStyle(Palette.secondary).lineLimit(2)
                                Text(thread.updatedAt, format: .dateTime.month().day())
                                    .font(.system(size: 10)).foregroundStyle(Color.white.opacity(0.30))
                            }.padding(14).frame(maxWidth: .infinity, alignment: .leading)
                                .background(thread.id == store.activeThreadID ? Color.white.opacity(0.08) : .clear,
                                            in: RoundedRectangle(cornerRadius: 18))
                        }.buttonStyle(.plain)
                            .contextMenu {
                                Button(thread.isPinned == true ? "取消置顶" : "置顶", systemImage: "pin") { store.togglePinned(thread.id) }
                                Button("重命名", systemImage: "pencil") { renameText = thread.title; renameID = thread.id }
                                Button("删除对话", systemImage: "trash", role: .destructive) { deleteTarget = thread }
                                    .disabled(thread.id == store.generatingThreadID)
                            }
                    }
                }
            }.scrollDismissesKeyboard(.interactively)
        }
        .padding(.horizontal, 18).padding(.top, 20)
        .background(Palette.paper)
        .alert("重命名对话", isPresented: Binding(get: { renameID != nil }, set: { if !$0 { renameID = nil } })) {
            TextField("对话名称", text: $renameText)
            Button("取消", role: .cancel) { renameID = nil }
            Button("保存") { if let id = renameID { store.renameThread(id, title: renameText) }; renameID = nil }
        }
        .alert("删除这个对话？", isPresented: Binding(get: { deleteTarget != nil }, set: { if !$0 { deleteTarget = nil } })) {
            Button("取消", role: .cancel) { deleteTarget = nil }
            Button("删除", role: .destructive) { if let thread = deleteTarget { store.deleteThread(thread.id) }; deleteTarget = nil }
        } message: { Text("已导出的备份不受影响。") }
    }
    private func finish() {
        UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
        close()
    }
}
