import SwiftUI
import UIKit

@MainActor
struct HistorySidebar: View {
    @EnvironmentObject private var store: AppStore
    @EnvironmentObject private var profile: ProfileStore
    let close: () -> Void
    let openSettings: () -> Void
    @State private var search = ""
    @State private var renameID: UUID?
    @State private var renameText = ""
    @State private var deleteTarget: ChatThread?
    private var filtered: [ChatThread] {
        store.sortedThreads.filter {
            search.isEmpty || $0.title.localizedCaseInsensitiveContains(search) ||
                $0.messages.contains(where: { $0.content.localizedCaseInsensitiveContains(search) })
        }
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 18) {
            HStack {
                Text("对话").font(.custom("NotoSerifSC-Regular", size: 26)).accessibilityIdentifier("history-title")
                Spacer()
                GlassCircle(symbol: "xmark", label: "关闭历史对话") { finish() }
            }
            HStack(spacing: 9) {
                Image(systemName: "magnifyingglass").foregroundStyle(Palette.secondary)
                TextField("搜索对话", text: $search).font(.system(size: 14)).autocorrectionDisabled()
                if !search.isEmpty {
                    Button { search = "" } label: { Image(systemName: "xmark.circle.fill") }
                        .foregroundStyle(Palette.secondary).accessibilityLabel("清除搜索")
                }
            }.padding(12).clearGlass(radius: 18)
            Button {
                store.createThread(); finish()
            } label: {
                Label("新建对话", systemImage: "square.and.pencil")
                    .font(.system(size: 15, weight: .medium))
                    .frame(maxWidth: .infinity, alignment: .leading).padding(.vertical, 10).padding(.horizontal, 4)
            }.buttonStyle(.plain)
            ScrollView {
                LazyVStack(alignment: .leading, spacing: 5) {
                    if filtered.isEmpty {
                        Text(search.isEmpty ? "暂无对话" : "没有找到相关对话")
                            .font(.system(size: 13)).foregroundStyle(Palette.secondary).padding(.top, 12)
                    } else if !search.isEmpty {
                        section("搜索结果", threads: filtered)
                    } else {
                        let pinned = filtered.filter { $0.isPinned == true }
                        let recent = filtered.filter { $0.isPinned != true }
                        if !pinned.isEmpty { section("置顶", threads: pinned) }
                        if !recent.isEmpty { section("最近", threads: recent) }
                    }
                }.padding(.top, 3)
            }
            .scrollDismissesKeyboard(.interactively)
            .contentMargins(.bottom, 78, for: .scrollContent)
            .contentMargins(.bottom, 78, for: .scrollIndicators)
            .overlay(alignment: .bottom) {
                Button {
                    UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
                    openSettings()
                } label: {
                    HStack(spacing: 10) {
                        ProfileAvatar(image: profile.avatar, size: 32)
                        Text(profile.name).font(.system(size: 14, weight: .medium)).lineLimit(1)
                        Spacer(minLength: 8)
                        Image(systemName: "gearshape").font(.system(size: 16)).foregroundStyle(Palette.secondary)
                    }.padding(.horizontal, 12).padding(.vertical, 10)
                }
                .buttonStyle(.plain).clearGlass(radius: 24)
                .accessibilityLabel("个人资料与设置")
                .padding(.bottom, 10)
            }
        }
        .padding(.horizontal, 16).padding(.top, 16)
        .alert("重命名对话", isPresented: Binding(get: { renameID != nil }, set: { if !$0 { renameID = nil } })) {
            TextField("对话名称", text: $renameText)
            Button("取消", role: .cancel) { renameID = nil }
            Button("保存") { if let id = renameID { store.renameThread(id, title: renameText) }; renameID = nil }
        }
        .alert("删除这个对话？", isPresented: Binding(get: { deleteTarget != nil }, set: { if !$0 { deleteTarget = nil } })) {
            Button("取消", role: .cancel) { deleteTarget = nil }
            Button("删除", role: .destructive) { if let thread = deleteTarget { store.deleteThread(thread.id) }; deleteTarget = nil }
        } message: { Text("已导出的备份不受影响。") }
    }

    private func section(_ title: String, threads: [ChatThread]) -> some View {
        Group {
            Text(title).font(.system(size: 12, weight: .medium)).foregroundStyle(Palette.secondary)
                .padding(.horizontal, 8).padding(.top, 16).padding(.bottom, 8)
            ForEach(threads) { thread in row(thread) }
        }
    }

    private func row(_ thread: ChatThread) -> some View {
        Button { store.select(thread.id); finish() } label: {
            HStack(spacing: 11) {
                Image(systemName: "bubble.left").font(.system(size: 17, weight: .regular)).foregroundStyle(.white.opacity(0.75))
                    .frame(width: 23)
                Text(thread.title).font(.system(size: 15, weight: .medium)).lineLimit(1)
                Spacer(minLength: 2)
                if thread.id == store.generatingThreadID { ProgressView().controlSize(.mini) }
            }
            .padding(.horizontal, 10).padding(.vertical, 12)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(thread.id == store.activeThreadID ? Color.white.opacity(0.13) : .clear, in: RoundedRectangle(cornerRadius: 14))
        }
        .buttonStyle(.plain)
        .accessibilityAddTraits(thread.id == store.activeThreadID ? .isSelected : [])
        .contextMenu {
            Button(thread.isPinned == true ? "取消置顶" : "置顶", systemImage: "pin") { store.togglePinned(thread.id) }
            Button("重命名", systemImage: "pencil") { renameText = thread.title; renameID = thread.id }
            Button("删除对话", systemImage: "trash", role: .destructive) { deleteTarget = thread }
                .disabled(thread.id == store.generatingThreadID)
        }
    }

    private func finish() {
        UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
        close()
    }
}
