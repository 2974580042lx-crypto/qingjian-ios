import SwiftUI

@MainActor
struct HistoryView: View {
    @EnvironmentObject private var store: AppStore
    @Environment(\.dismiss) private var dismiss
    @State private var search = ""
    @State private var pendingDelete: UUID?
    private var filtered: [ChatThread] {
        store.sortedThreads.filter { search.isEmpty || $0.title.localizedCaseInsensitiveContains(search) || $0.messages.contains(where: { $0.content.localizedCaseInsensitiveContains(search) }) }
    }
    var body: some View {
        NavigationStack {
            List {
                ForEach(filtered) { thread in
                    Button { store.select(thread.id); dismiss() } label: {
                        VStack(alignment: .leading, spacing: 8) {
                            HStack {
                                Text(thread.title).font(.system(size: 16, weight: .medium)).foregroundStyle(.primary).lineLimit(1)
                                Spacer()
                                if thread.id == store.generatingThreadID { ProgressView().controlSize(.small) }
                                else if thread.id == store.activeThreadID { Image(systemName: "checkmark").foregroundStyle(Palette.green) }
                            }
                            Text(thread.preview).font(.system(size: 13)).foregroundStyle(.secondary).lineLimit(2)
                            Text(thread.updatedAt, format: .dateTime.month().day().hour().minute())
                                .font(.system(size: 11)).foregroundStyle(.tertiary)
                        }.padding(.vertical, 6)
                    }
                    .swipeActions {
                        if thread.id != store.generatingThreadID {
                            Button { pendingDelete = thread.id } label: { Label("删除", systemImage: "trash") }
                                .tint(.red)
                        }
                    }
                }
            }
            .searchable(text: $search, prompt: "搜索对话")
            .navigationTitle("留过的想法")
            .toolbar {
                ToolbarItem(placement: .topBarLeading) { Button("完成") { dismiss() } }
                ToolbarItem(placement: .topBarTrailing) {
                    Button { store.createThread(); dismiss() } label: { Image(systemName: "square.and.pencil") }
                }
            }
            .alert("删除这个对话？", isPresented: Binding(get: { pendingDelete != nil }, set: { if !$0 { pendingDelete = nil } }), presenting: pendingDelete) { id in
                Button("取消", role: .cancel) { pendingDelete = nil }
                Button("删除", role: .destructive) {
                    store.deleteThread(id)
                    pendingDelete = nil
                }
            } message: { _ in Text("已导出的备份不受影响。") }
        }
    }
}
