import SwiftUI
import Observation

/// The whole look of the app, chosen in Settings → 阅读与外观 → 界面风格.
/// 纸笺: warm paper, Songti, highlighter strokes, liquid glass.
/// 瑞士: grey-white sheet, black sans, blue bold emphasis, ruled grid, square edges.
/// Colours and fonts read it through `StyleAppearance`, so a switch redraws the
/// app in place, keeping open sheets and unsaved drafts, the way a font change does.
enum InterfaceStyle: String, CaseIterable, Identifiable, Sendable {
    case paper, swiss

    static let key = "sermo.interface.style"

    var id: String { rawValue }
    var title: String {
        switch self {
        case .paper: return "纸笺"
        case .swiss: return "瑞士"
        }
    }
    var detail: String {
        switch self {
        case .paper: return "暖纸色、宋体、荧光高光、液态玻璃"
        case .swiss: return "灰白底、黑体、蓝色粗体、网格线与方角"
        }
    }

    /// The look views draw with. Reading it inside a view's body subscribes that view to changes.
    static var current: InterfaceStyle { StyleAppearance.shared.style }
    static var isSwiss: Bool { current == .swiss }

    /// What is saved in Settings.
    static var stored: InterfaceStyle {
        InterfaceStyle(rawValue: UserDefaults.standard.string(forKey: key) ?? "") ?? .paper
    }
}

/// Observable holder for the current look; `reload()` after the setting changes.
@Observable
final class StyleAppearance {
    static let shared = StyleAppearance()
    private(set) var style: InterfaceStyle
    init() {
        let arguments = ProcessInfo.processInfo.arguments
        if arguments.contains("--ui-preview") {
            // Preview runs start from their launch flag, so a value left in the
            // simulator never changes a screenshot; the picker can still switch.
            let flagged: InterfaceStyle = arguments.contains("--preview-swiss") ? .swiss : .paper
            UserDefaults.standard.set(flagged.rawValue, forKey: InterfaceStyle.key)
        }
        style = InterfaceStyle.stored
    }
    func reload() {
        let value = InterfaceStyle.stored
        if value != style { style = value }
    }
}

/// Settings row: pick the look. Saved at once; the app redraws in place.
@MainActor
struct InterfaceStylePicker: View {
    @AppStorage(InterfaceStyle.key) private var stored = InterfaceStyle.paper.rawValue
    var body: some View {
        Picker("界面风格", selection: $stored) {
            ForEach(InterfaceStyle.allCases) { style in
                Text(style.title).tag(style.rawValue)
            }
        }
        .accessibilityIdentifier("interface-style")
        .accessibilityValue((InterfaceStyle(rawValue: stored) ?? .paper).title)
        // The app also listens for this key; reloading here as well makes the switch immediate.
        .onChange(of: stored) { _, _ in StyleAppearance.shared.reload(); InkAppearance.apply() }
        Text((InterfaceStyle(rawValue: stored) ?? .paper).detail + "。切换后整个 App 立刻换样式，对话和设置都不受影响。瑞士风格固定使用系统黑体，不显示荧光高光。")
            .font(TypeScale.serif(12)).foregroundStyle(.secondary)
    }
}

// MARK: - Swiss pieces shared by several screens

/// Small monospaced label: Q.01, A.01, COPY, FLASH / HIGH.
struct MonoLabel: View {
    let text: String
    var color: Color = Ink.ink3
    var size: CGFloat = 11
    var body: some View {
        Text(text).font(TypeScale.mono(size)).tracking(0.4).foregroundStyle(color)
    }
}

/// Full-width rule; the Swiss look separates with lines instead of space and shadow.
struct SwissRule: View {
    var weight: CGFloat = 1
    var strong = false
    var body: some View {
        Rectangle().fill(strong ? Ink.ink : Ink.line).frame(height: weight).accessibilityHidden(true)
    }
}

/// The big title block that opens a conversation in the Swiss look.
struct SwissThreadHeader: View {
    let title: String
    let date: Date
    let model: String
    let rounds: Int
    private static let dateFormat: DateFormatter = {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "zh_CN")
        formatter.dateFormat = "yyyy.MM.dd"
        return formatter
    }()
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text(title)
                .font(TypeScale.heavy(30, relativeTo: .largeTitle))
                .tracking(-0.4).lineSpacing(2)
                .foregroundStyle(Ink.ink)
                .fixedSize(horizontal: false, vertical: true)
                .accessibilityAddTraits(.isHeader)
            HStack {
                MonoLabel(text: Self.dateFormat.string(from: date))
                Spacer(minLength: 8)
                MonoLabel(text: model.uppercased()).lineLimit(1)
                Spacer(minLength: 8)
                MonoLabel(text: String(format: "%02d 轮", rounds))
            }
            SwissRule(weight: 2, strong: true)
        }
        .accessibilityElement(children: .combine)
    }
}

/// A capsule in the paper look, a plain rectangle in the Swiss look.
/// The look is captured when the view is built, so a switch redraws the shape.
struct InkCapsule: Shape {
    var swiss = InterfaceStyle.isSwiss
    func path(in rect: CGRect) -> Path {
        swiss ? Path(rect) : Capsule(style: .continuous).path(in: rect)
    }
}

/// Rounded corners in the paper look, square in the Swiss look.
struct InkRounded: Shape {
    var radius: CGFloat
    var swiss = InterfaceStyle.isSwiss
    func path(in rect: CGRect) -> Path {
        RoundedRectangle(cornerRadius: swiss ? 0 : radius, style: .continuous).path(in: rect)
    }
}
