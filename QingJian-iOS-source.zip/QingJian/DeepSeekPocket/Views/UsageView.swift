import SwiftUI

// Daily use as a grid of weeks, darker on busier days, like the Claude Code and Codex stats.
@MainActor
struct UsageCalendarView: View {
    let ledger: UsageLedger
    @State private var selected = Date()
    private let calendar: Calendar = {
        var value = Calendar(identifier: .gregorian)
        value.firstWeekday = 2
        return value
    }()
    private let cell: CGFloat = 13, gap: CGFloat = 3, labelWidth: CGFloat = 16

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack(spacing: 0) {
                stat("今天", ledger.day(Date(), calendar: calendar))
                Rectangle().fill(Ink.line).frame(width: 0.5, height: 34).padding(.horizontal, 14)
                stat("本月", ledger.month(containing: Date(), calendar: calendar))
            }
            GeometryReader { proxy in
                grid(weeks: max(8, min(26, Int((proxy.size.width - labelWidth) / (cell + gap)))))
            }
            .frame(height: 16 + 7 * cell + 6 * gap)
            HStack(spacing: 3) {
                Spacer()
                Text("少")
                ForEach(0..<5, id: \.self) { shade($0).frame(width: 10, height: 10).clipShape(RoundedRectangle(cornerRadius: 2)) }
                Text("多")
            }.font(TypeScale.serif(10)).foregroundStyle(Ink.ink3)
            let day = ledger.day(selected, calendar: calendar)
            HStack(spacing: 8) {
                Text(selected.formatted(.dateTime.month().day().weekday(.abbreviated))).fontWeight(.semibold)
                Text("\(day.tokens.formatted()) tokens · \(Pricing.label(day.cost)) · \(day.requests) 次").foregroundStyle(Ink.ink2)
            }
            .font(TypeScale.serif(13)).monospacedDigit()
            .padding(.top, 10).overlay(alignment: .top) { InkRule() }
            .accessibilityIdentifier("usage-selected-day")
            HStack(alignment: .top) {
                fact("连续使用", "\(ledger.streak(endingAt: Date(), calendar: calendar)) 天")
                Spacer()
                fact("最多的一天", ledger.busiestDay.map(shortDay) ?? "—")
                Spacer()
                fact("常用模型", ledger.favouriteModel?.title ?? "—")
            }
        }
        .padding(.vertical, 6)
        .accessibilityElement(children: .contain)
        .accessibilityIdentifier("usage-calendar")
    }

    private func grid(weeks: Int) -> some View {
        let today = calendar.startOfDay(for: Date())
        let thisWeek = calendar.dateInterval(of: .weekOfYear, for: today)?.start ?? today
        let starts = (0..<weeks).compactMap { calendar.date(byAdding: .day, value: -7 * (weeks - 1 - $0), to: thisWeek) }
        let peak = starts.flatMap { start in (0..<7).compactMap { calendar.date(byAdding: .day, value: $0, to: start) } }
            .map { ledger.day($0, calendar: calendar).tokens }.max() ?? 0
        return VStack(alignment: .leading, spacing: 4) {
            HStack(spacing: gap) {
                Color.clear.frame(width: labelWidth - gap, height: 12)
                ForEach(Array(starts.enumerated()), id: \.offset) { index, start in
                    let month = calendar.component(.month, from: start)
                    let previous = index > 0 ? calendar.component(.month, from: starts[index - 1]) : nil
                    Text(previous != month ? "\(month)月" : "").font(TypeScale.serif(9)).foregroundStyle(Ink.ink3)
                        .fixedSize().frame(width: cell, height: 12, alignment: .leading)
                }
            }
            HStack(alignment: .top, spacing: gap) {
                VStack(alignment: .leading, spacing: gap) {
                    ForEach(Array(["一", "", "三", "", "五", "", "日"].enumerated()), id: \.offset) { _, label in
                        Text(label).font(TypeScale.serif(9)).foregroundStyle(Ink.ink3).frame(height: cell)
                    }
                }.frame(width: labelWidth - gap, alignment: .leading)
                ForEach(starts, id: \.self) { start in
                    VStack(spacing: gap) {
                        ForEach(0..<7, id: \.self) { offset in
                            let date = calendar.date(byAdding: .day, value: offset, to: start) ?? start
                            if date > today {
                                Color.clear.frame(width: cell, height: cell)
                            } else {
                                let tokens = ledger.day(date, calendar: calendar).tokens
                                shade(UsageLedger.level(tokens, peak: peak))
                                    .frame(width: cell, height: cell)
                                    .clipShape(RoundedRectangle(cornerRadius: 3))
                                    .overlay {
                                        if calendar.isDate(date, inSameDayAs: selected) {
                                            RoundedRectangle(cornerRadius: 3).stroke(Ink.ink, lineWidth: 1.5).padding(-1.5)
                                        }
                                    }
                                    .onTapGesture { selected = date }
                                    .accessibilityLabel("\(date.formatted(date: .abbreviated, time: .omitted))，\(tokens) tokens")
                            }
                        }
                    }
                }
            }
        }
    }

    private func shade(_ level: Int) -> Color {
        switch level {
        case 0: return Ink.ink.opacity(0.07)
        case 1: return Ink.seal.opacity(0.25)
        case 2: return Ink.seal.opacity(0.48)
        case 3: return Ink.seal.opacity(0.72)
        default: return Ink.seal
        }
    }

    private func stat(_ title: String, _ usage: DayUsage) -> some View {
        VStack(alignment: .leading, spacing: 3) {
            Text(title).font(TypeScale.tiny).foregroundStyle(Ink.ink3)
            HStack(alignment: .firstTextBaseline, spacing: 5) {
                Text(compact(usage.tokens)).font(TypeScale.serif(20).weight(.semibold)).monospacedDigit()
                Text(Pricing.label(usage.cost)).font(TypeScale.tiny).foregroundStyle(Ink.ink3).monospacedDigit()
            }
        }
    }

    private func fact(_ title: String, _ value: String) -> some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(title).font(TypeScale.tiny).foregroundStyle(Ink.ink3)
            Text(value).font(TypeScale.serif(13).weight(.semibold))
        }
    }

    private func compact(_ tokens: Int) -> String {
        if tokens >= 1_000_000 { return String(format: "%.2fM", Double(tokens) / 1_000_000) }
        if tokens >= 1_000 { return String(format: "%.1fK", Double(tokens) / 1_000) }
        return "\(tokens)"
    }

    private func shortDay(_ key: String) -> String {
        let parts = key.split(separator: "-")
        guard parts.count == 3, let month = Int(parts[1]), let day = Int(parts[2]) else { return key }
        return "\(month) 月 \(day) 日"
    }
}
