import SwiftUI
import UIKit
import PhotosUI
import UniformTypeIdentifiers

private func previewFlag(_ names: String...) -> Bool {
    names.contains { ProcessInfo.processInfo.arguments.contains("--preview-" + $0) }
}

@MainActor
struct ContentView: View {
    @EnvironmentObject private var store: AppStore
    @EnvironmentObject private var profile: ProfileStore
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    // Settings, projects and the full list open from the sidebar; there is no tab bar.
    @State private var showSettings = previewFlag("settings", "profile", "usage")
    @State private var showProjects = previewFlag("projects", "project")
    @State private var showAllChats = previewFlag("all-chats")
    @State private var showSidebar = previewFlag("sidebar")
    @State private var keyboardVisible = false
    @State private var composerPanelHeight: CGFloat = 130
    @State private var sidebarDrag: CGFloat = 0
    @AppStorage("qingjian.haptics") private var hapticsEnabled = true

    var body: some View {
        GeometryReader { geometry in
            let width = min(geometry.size.width * 0.82, 360)
            let position = min(width, max(0, (showSidebar ? width : 0) + sidebarDrag))
            let progress = position / width
            let frontPage = PageContour(radius: Radius.pageFront * progress, topInset: geometry.safeAreaInsets.top, bottomInset: geometry.safeAreaInsets.bottom)
            let backPage = PageContour(radius: Radius.pageBack * progress, topInset: geometry.safeAreaInsets.top, bottomInset: geometry.safeAreaInsets.bottom)
            ZStack(alignment: .leading) {
                Ink.sheet.ignoresSafeArea()
                HistorySidebar(close: { showSidebar = false },
                               openSettings: { showSettings = true },
                               openProjects: { showProjects = true },
                               openAllChats: { showAllChats = true })
                .frame(width: width)
                .background(Ink.sheet.ignoresSafeArea())
                .clipShape(backPage)
                .overlay(backPage.stroke(Ink.line.opacity(progress), lineWidth: 0.5).allowsHitTesting(false))
                .offset(x: -width * 0.2 * (1 - progress))
                .opacity(min(1, progress * 3))
                .allowsHitTesting(showSidebar)
                .accessibilityHidden(!showSidebar)

                NavigationStack {
                    ChatScreen(openHistory: { showSidebar = true }, openSettings: { showSettings = true }, keyboardVisible: $keyboardVisible,
                               composerPanelHeight: $composerPanelHeight, bottomInset: geometry.safeAreaInsets.bottom)
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .scrollDisabled(sidebarDrag != 0)
                .tint(Ink.ink)
                .background(AppBackground())
                .overlay {
                    if progress > 0 {
                        Color.clear
                            .contentShape(Rectangle())
                            .onTapGesture { showSidebar = false }
                    }
                }
                .clipShape(frontPage)
                .background(frontPage.fill(Ink.paper)
                    .shadow(color: Color.black.opacity(0.16 * progress), radius: 24, x: -8)
                    .allowsHitTesting(false))
                .overlay(frontPage.stroke(Ink.line.opacity(progress), lineWidth: 0.6).allowsHitTesting(false))
                .offset(x: position)
                .accessibilityHidden(showSidebar)
            }
            .contentShape(Rectangle())
            .animation(reduceMotion ? nil : .snappy(duration: 0.28), value: showSidebar)
            .background(SidebarPan(enabled: true, isOpen: showSidebar,
                maximumStartY: geometry.frame(in: .global).maxY - composerPanelHeight - (keyboardVisible ? 0 : FloatingChrome.navigationHeight),
                changed: { distance in
                    sidebarDrag = showSidebar ? max(-width, min(0, distance)) : min(width, max(0, distance))
                }, ended: { distance, prediction in
                    let threshold = min(65, width * 0.18)
                    let open = showSidebar ? !(distance < -threshold || prediction < -width * 0.45) :
                        (distance > threshold || prediction > width * 0.45)
                    if open {
                        UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
                    }
                    withAnimation(reduceMotion ? nil : .snappy(duration: 0.28)) { showSidebar = open; sidebarDrag = 0 }
                }, cancelled: {
                    withAnimation(reduceMotion ? nil : .snappy(duration: 0.28)) { sidebarDrag = 0 }
                }))
        }
        .onChange(of: showSidebar) { _, open in
            if hapticsEnabled { UIImpactFeedbackGenerator(style: .soft).impactOccurred(intensity: 0.65) }
            if open { store.refreshBalance() }
        }
        .sheet(isPresented: $showSettings) { SettingsView().environmentObject(store).environmentObject(profile) }
        .sheet(isPresented: $showProjects) {
            ProjectsView(opened: { showProjects = false; showSidebar = false }).environmentObject(store).environmentObject(profile)
        }
        .sheet(isPresented: $showAllChats) {
            AllChatsView(opened: { showAllChats = false; showSidebar = false }).environmentObject(store).environmentObject(profile)
        }
        .onAppear {
            if store.isPreview {
                let result = "QINGJIAN_SONGTI_LOADED=\(UIFont(name: "NotoSerifSC-Regular", size: 18) != nil)\n"
                FileHandle.standardOutput.write(Data(result.utf8))
            }
        }
    }

}

struct PendingImage: Identifiable {
    let id = UUID()
    let data: Data
    let preview: UIImage
}

private struct PendingSuggestedReply {
    let threadID: UUID
    let messageID: UUID
    let text: String
}

@MainActor
struct ChatScreen: View {
    @EnvironmentObject private var store: AppStore
    @EnvironmentObject private var profile: ProfileStore
    let openHistory: () -> Void
    let openSettings: () -> Void
    @Binding var keyboardVisible: Bool
    @Binding var composerPanelHeight: CGFloat
    let bottomInset: CGFloat
    @FocusState private var composerFocused: Bool
    @State private var previewComposerFocused = false
    @StateObject private var keyboardBoundary = KeyboardBoundary()
    @State private var composerFrame = CGRect.zero
    @State private var keyboardLift: CGFloat = 0
    private var isComposerFocused: Bool { composerFocused || previewComposerFocused }
    private var usesPreviewKeyboard: Bool { store.isPreview && ProcessInfo.processInfo.arguments.contains("--preview-tall-keyboard") }
    private func focusComposer(_ focused: Bool) {
        if usesPreviewKeyboard { previewComposerFocused = focused } else { composerFocused = focused }
    }
    private func updateKeyboardLift() {
        guard isComposerFocused, let top = keyboardBoundary.top, composerFrame != .zero else {
            if keyboardLift != 0 { keyboardLift = 0 }
            return
        }
        // Subtract the previous correction from the observation so this cannot
        // keep adding the same overlap on successive layout passes.
        let originalBottom = composerFrame.maxY + keyboardLift
        let required = max(0, originalBottom - top + 8)
        if abs(required - keyboardLift) > 0.5 { keyboardLift = required }
    }
    @State private var editedMessage: ChatMessage?
    @State private var thinkingTarget: ThinkingTarget?
    @State private var pendingSuggestedReply: PendingSuggestedReply?
    @State private var followsOutput = true
    @State private var nearBottom = true
    @State private var importingText = false
    @State private var pickingPhotos = false
    @State private var photoSelection: [PhotosPickerItem] = []
    @State private var pendingImages: [PendingImage] = []
    @State private var loadingPhotos = false
    @State private var renaming = false
    @State private var renameText = ""
    @State private var exportURL: URL?
    private var isEmptyPage: Bool { store.activeThread?.messages.isEmpty != false }
    private var hasInput: Bool {
        !store.activeDraft.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || !pendingImages.isEmpty
    }
    @State private var scrollPosition = ScrollPosition(edge: .top)
    @State private var visibleMessageCount = 100
    @State private var hasPositionedInitially = false
    private var visibleMessages: [ChatMessage] { Array((store.activeThread?.messages ?? []).suffix(visibleMessageCount)) }
    private var navigationSpace: CGFloat { 0 }
    private var scrollBottomSpace: CGFloat { composerPanelHeight + bottomInset + 12 }

    private var draft: Binding<String> { Binding(get: { store.activeDraft }, set: { store.setDraft($0) }) }
    private var errorPresented: Binding<Bool> {
        Binding(get: { store.errorMessage != nil && editedMessage == nil },
                set: { if !$0 { store.errorMessage = nil } })
    }

    var body: some View {
        Group {
            if isEmptyPage {
                VStack(spacing: 0) {
                    Spacer(minLength: 12)
                    WelcomeView(name: profile.name, page: store.activeThreadID ?? UUID(), projectName: store.activeProject?.name)
                        .id(store.activeThreadID)
                    Spacer(minLength: 12)
                    liftedComposer.padding(.bottom, navigationSpace)
                }
            } else {
            ZStack(alignment: .bottom) {
            ScrollView {
                VStack(alignment: .leading, spacing: 30) {
                    if (store.activeThread?.messages.count ?? 0) > visibleMessageCount {
                        Button("查看更早消息") {
                            visibleMessageCount += 100
                            scrollPosition.scrollTo(edge: .top)
                        }.font(TypeScale.caption).foregroundStyle(Palette.secondary)
                            .frame(maxWidth: .infinity)
                    }
                    messageRows
                    Color.clear.frame(height: 2)
                }
                .scrollTargetLayout()
                .padding(.horizontal, 24).padding(.top, 10).padding(.bottom, 22)
            }
            .accessibilityIdentifier("chat-scroll")
            // Text fades softly under the floating buttons instead of a solid band.
            .scrollEdgeEffectStyle(.soft, for: .top)
            .scrollPosition($scrollPosition)
            .contentMargins(.bottom, scrollBottomSpace, for: .scrollContent)
            .contentMargins(.bottom, scrollBottomSpace, for: .scrollIndicators)
            .ignoresSafeArea(.container, edges: .bottom)
            .scrollDismissesKeyboard(.interactively)
            .onAppear {
                if !hasPositionedInitially && !store.isPreview {
                    DispatchQueue.main.async { scrollPosition.scrollTo(edge: .bottom) }
                }
                hasPositionedInitially = true
            }
            .onScrollGeometryChange(for: Bool.self) { g in
                g.contentSize.height + g.contentInsets.bottom - g.contentOffset.y - g.containerSize.height < 80
            } action: { _, value in nearBottom = value }
            .onScrollPhaseChange { _, phase in
                if phase == .interacting { followsOutput = false }
                if phase == .idle && nearBottom { followsOutput = true }
            }
            .onChange(of: store.activeThread?.messages.count) { _, _ in
                if followsOutput { scrollPosition.scrollTo(edge: .bottom) }
            }
            .onChange(of: store.activeThread?.messages.last?.content) { _, _ in
                if followsOutput && store.generatingThreadID == store.activeThreadID {
                    scrollPosition.scrollTo(edge: .bottom)
                }
            }
            .onChange(of: store.activeThreadID) { _, _ in
                pendingSuggestedReply = nil
                visibleMessageCount = 100
                followsOutput = true
                DispatchQueue.main.async { scrollPosition.scrollTo(edge: .bottom) }
            }
            .onChange(of: store.activeThread?.messages.last?.replySuggestions) { _, _ in
                if followsOutput { scrollPosition.scrollTo(edge: .bottom) }
            }
            liftedComposer.padding(.bottom, navigationSpace)
            }
            .overlay(alignment: .bottomTrailing) {
                if !isComposerFocused && !nearBottom && store.activeThread?.messages.isEmpty == false {
                    GlassCircle(symbol: "arrow.down", label: "回到最新消息") {
                        followsOutput = true
                        withAnimation(.easeOut(duration: 0.2)) { scrollPosition.scrollTo(edge: .bottom) }
                    }.padding(.trailing, 22).padding(.bottom, composerPanelHeight + navigationSpace + 12)
                }
            }
            }
        }
        .background(AppBackground())
        .navigationTitle("Vox")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .topBarLeading) {
                Button { focusComposer(false); openHistory() } label: { SidebarGlyph() }
                    .accessibilityLabel("打开历史对话")
            }
            // Like the Claude app: no title in the bar, only the two glass controls.
            // In a conversation the right one holds new-page and a "⋯" menu with the title.
            ToolbarItemGroup(placement: .topBarTrailing) {
                // A new page stays in the project you are in.
                Button { store.createThread(in: store.activeThread?.projectID); followsOutput = true } label: { Image(systemName: "square.and.pencil") }
                    .accessibilityLabel("新建对话")
                if !isEmptyPage { titleMenu }
            }
        }
        .toolbarBackgroundVisibility(.hidden, for: .navigationBar)
        .background(KeyboardWindowProbe(boundary: keyboardBoundary))
        .alert("重命名对话", isPresented: $renaming) {
            TextField("对话名称", text: $renameText)
            Button("取消", role: .cancel) { }
            Button("保存") { if let id = store.activeThreadID { store.renameThread(id, title: renameText) } }
        }
        .sheet(isPresented: Binding(get: { exportURL != nil }, set: { if !$0 { exportURL = nil } })) {
            if let url = exportURL { ShareSheet(items: [url]) }
        }
        .onChange(of: isComposerFocused) { _, focused in keyboardVisible = focused; updateKeyboardLift() }
        .onChange(of: keyboardBoundary.top) { _, _ in updateKeyboardLift() }
        .onDisappear { keyboardVisible = false }
        .sheet(item: $editedMessage) { message in EditMessageView(message: message) }
        .sheet(item: $thinkingTarget) { target in ThinkingSheet(target: target).environmentObject(store) }
        .alert("替换输入框里的文字？", isPresented: Binding(
            get: { pendingSuggestedReply != nil },
            set: { if !$0 { pendingSuggestedReply = nil } })) {
            Button("取消", role: .cancel) { pendingSuggestedReply = nil }
            Button("替换") {
                if let selection = pendingSuggestedReply { applySuggestedReply(selection) }
                pendingSuggestedReply = nil
            }
        } message: { Text("你已经写了些内容。替换后仍可以编辑，再自己发送。") }
        .photosPicker(isPresented: $pickingPhotos, selection: $photoSelection, maxSelectionCount: 4, matching: .images)
        .onChange(of: photoSelection) { _, items in
            guard !items.isEmpty else { return }
            photoSelection = []
            loadingPhotos = true
            Task {
                for item in items {
                    guard pendingImages.count < 4 else { break }
                    do {
                        guard let raw = try await item.loadTransferable(type: Data.self) else { continue }
                        let data = try await Task.detached { try ImageStore.prepared(raw) }.value
                        if let preview = UIImage(data: data) {
                            pendingImages.append(PendingImage(data: data, preview: preview))
                        }
                    } catch { store.errorMessage = "有一张图片没能读取，请换一张试试。" }
                }
                loadingPhotos = false
            }
        }
        .fileImporter(isPresented: $importingText, allowedContentTypes: [.plainText, .text]) { result in
            do {
                let url = try result.get()
                let scoped = url.startAccessingSecurityScopedResource()
                defer { if scoped { url.stopAccessingSecurityScopedResource() } }
                let size = try url.resourceValues(forKeys: [.fileSizeKey]).fileSize ?? 0
                guard size <= 1024 * 1024 else { throw ChatError.server("请选择小于 1 MB 的文字文件。") }
                let text = try String(contentsOf: url, encoding: .utf8)
                store.setDraft(store.activeDraft.isEmpty ? text : store.activeDraft + "\n\n" + text)
                focusComposer(true)
            } catch { store.errorMessage = error.localizedDescription }
        }
        .alert("暂时没有完成", isPresented: errorPresented) {
            Button("知道了") { store.errorMessage = nil }
        } message: { Text(store.errorMessage ?? "") }
        .task {
            if ProcessInfo.processInfo.arguments.contains("--preview-multiline-keyboard") {
                store.setDraft("第一行输入\n第二行输入\n第三行输入\n第四行输入\n第五行输入\n第六行输入")
            }
            if ProcessInfo.processInfo.arguments.contains("--preview-keyboard") || ProcessInfo.processInfo.arguments.contains("--preview-multiline-keyboard") {
                try? await Task.sleep(nanoseconds: 350_000_000)
                focusComposer(true)
            }
            if ProcessInfo.processInfo.arguments.contains("--preview-edit") {
                editedMessage = store.activeThread?.messages.last
            }
            if ProcessInfo.processInfo.arguments.contains(where: { $0.hasPrefix("--preview-reasoning") }),
               let threadID = store.activeThreadID, let last = store.activeThread?.messages.last {
                try? await Task.sleep(nanoseconds: 400_000_000)
                thinkingTarget = ThinkingTarget(threadID: threadID, messageID: last.id)
            }
        }
    }

    // Kept out of body so the compiler can type-check the page in reasonable time.
    private var messageRows: some View {
        let lastID = store.activeThread?.messages.last?.id, threadID = store.activeThreadID
        return ForEach(visibleMessages) { message in
            // Equatable: only the message that changed redraws while an answer streams.
            messageRow(message, threadID: threadID, isLast: message.id == lastID)
        }
    }

    private func messageRow(_ message: ChatMessage, threadID: UUID?, isLast: Bool) -> some View {
        MessageView(message: message, threadID: threadID, isLast: isLast,
                    isGenerating: store.isGenerating, canRegenerate: store.canChat,
                    showsSuggestions: store.settings.shouldSuggestReplies,
                    edit: { focusComposer(false); editedMessage = message },
                    regenerate: { store.regenerate() },
                    openThinking: { if let threadID { thinkingTarget = ThinkingTarget(threadID: threadID, messageID: message.id) } },
                    useSuggestedReply: { text in prepareSuggestedReply(text, messageID: message.id) })
            .equatable().id(message.id)
    }

    private func prepareSuggestedReply(_ text: String, messageID: UUID) {
        guard let threadID = store.activeThreadID else { return }
        let selection = PendingSuggestedReply(threadID: threadID, messageID: messageID, text: text)
        if !store.activeDraft.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty && store.activeDraft != text {
            pendingSuggestedReply = selection
        } else { applySuggestedReply(selection) }
    }

    private func applySuggestedReply(_ selection: PendingSuggestedReply) {
        if store.useReplySuggestion(selection.text, threadID: selection.threadID, messageID: selection.messageID) {
            followsOutput = true
            focusComposer(true)
        }
    }

    // "⋯" for the open conversation. Its title (and project) head the menu.
    private var titleMenu: some View {
        Menu {
            if let thread = store.activeThread {
                Text(store.activeProject.map { thread.title + " · " + $0.name } ?? thread.title)
                Divider()
                Button("重命名", systemImage: "pencil") { renameText = thread.title; renaming = true }
                Button(thread.isPinned == true ? "取消置顶" : "置顶", systemImage: "pin") { store.togglePinned(thread.id) }
                Menu("移到项目", systemImage: "folder") {
                    ForEach(store.projects.filter { !store.isLocked($0.id) }) { project in
                        Button(project.name) { store.moveThreads([thread.id], to: project.id) }
                            .disabled(project.id == thread.projectID)
                    }
                    if thread.projectID != nil {
                        Button("移出项目", systemImage: "tray.and.arrow.up") { store.moveThreads([thread.id], to: nil) }
                    }
                }.disabled(store.projects.isEmpty && thread.projectID == nil)
                Button("导出为 Markdown", systemImage: "square.and.arrow.up") {
                    exportURL = store.exportConversation(thread.id, userName: profile.name)
                }
            }
        } label: {
            Image(systemName: "ellipsis")
        }
        .accessibilityLabel("对话选项")
        .accessibilityIdentifier("chat-title-menu")
    }

    private var liftedComposer: some View {
        composer
            .fixedSize(horizontal: false, vertical: true)
            .onGeometryChange(for: CGRect.self) { $0.frame(in: .global) } action: { frame in
                composerFrame = frame
                keyboardBoundary.refresh()
                updateKeyboardLift()
            }
            .offset(y: -keyboardLift)
    }

    private var composer: some View {
        VStack(spacing: 8) {
            if !store.canChat {
                Button { focusComposer(false); openSettings() } label: {
                    Label(store.activeProvider == .chatGPT ? "在设置里登录 ChatGPT 订阅，就能用这个项目" : "在设置里填好 DeepSeek API Key，就能开始聊天",
                          systemImage: store.activeProvider == .chatGPT ? "person.crop.circle" : "key")
                        .font(TypeScale.caption).foregroundStyle(Ink.ink3)
                }.padding(.bottom, 2)
            }
            VStack(alignment: .leading, spacing: 14) {
                if !pendingImages.isEmpty || loadingPhotos {
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 10) {
                            ForEach(pendingImages) { item in
                                Image(uiImage: item.preview).resizable().scaledToFill()
                                    .frame(width: 64, height: 64)
                                    .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                                    .overlay(alignment: .topTrailing) {
                                        Button { pendingImages.removeAll { $0.id == item.id } } label: {
                                            Image(systemName: "xmark").font(.system(size: 9, weight: .bold))
                                                .foregroundStyle(Ink.onSolid)
                                                .frame(width: 20, height: 20).background(Ink.solid, in: Circle())
                                                .padding(3).contentShape(Rectangle())
                                        }.buttonStyle(.plain).accessibilityLabel("移除这张图片")
                                    }
                            }
                            if loadingPhotos { ProgressView().frame(width: 64, height: 64) }
                        }
                    }
                }
                Group {
                    if usesPreviewKeyboard {
                        PreviewKeyboardField(text: draft, isFocused: previewComposerFocused, focusChanged: { previewComposerFocused = $0 })
                    } else {
                        TextField("与 Vox 对话", text: draft, axis: .vertical)
                            .readingStyle(adjustment: -1).lineLimit(1...5)
                            .focused($composerFocused).tint(Ink.ink)
                    }
                }
                    .disabled(!store.canPersist)
                    .accessibilityIdentifier("chat-composer")
                HStack(spacing: 10) {
                    Menu {
                        Button("从相册选图片", systemImage: "photo") { focusComposer(false); pickingPhotos = true }
                        Button("导入文字文件", systemImage: "doc.text") { importingText = true }
                        Button("粘贴文字", systemImage: "doc.on.clipboard") {
                            if let text = UIPasteboard.general.string { store.setDraft(store.activeDraft + text) }
                        }
                    } label: {
                        Image(systemName: "plus").font(.system(size: 16, weight: .regular)).foregroundStyle(Ink.ink)
                            .frame(width: 38, height: 38)
                            .overlay(Circle().stroke(Ink.line, lineWidth: 0.8))
                            .contentShape(Circle())
                    }
                    .accessibilityLabel("更多输入操作")
                    // Model and thinking level in one pill, like "Haiku 5.5 中等" in the Claude app.
                    Menu {
                        if store.activeProvider == .chatGPT {
                            Section("ChatGPT 订阅") {
                                Picker("模型", selection: Binding(get: { store.settings.subscriptionModel }, set: { store.setSubscriptionModel($0) })) {
                                    if !store.subscription.models.contains(where: { $0.slug == store.settings.subscriptionModel }) {
                                        Text(store.settings.subscriptionModel).tag(store.settings.subscriptionModel)
                                    }
                                    ForEach(store.subscription.models) { model in Text(model.displayName).tag(model.slug) }
                                }
                            }
                            Section("思考") {
                                Picker("思考", selection: Binding(get: { store.settings.selectedSubscriptionEffort }, set: { store.setSubscriptionEffort($0) })) {
                                    ForEach(SubscriptionEffort.allCases) { effort in Text(effort.title).tag(effort) }
                                }
                            }
                        } else {
                        Section("模型") {
                            Picker("模型", selection: Binding(get: { store.settings.model }, set: { store.setModel($0) })) {
                                ForEach(DeepSeekModel.allCases) { model in Text(model.title).tag(model) }
                            }
                        }
                        Section("思考") {
                            Picker("思考", selection: Binding(get: { store.settings.thinkingEnabled ? store.settings.effort.rawValue : "off" },
                                                            set: { value in
                                if let effort = ThinkingEffort(rawValue: value) { store.setThinkingEffort(effort) }
                                else if store.settings.thinkingEnabled { store.toggleThinking() }
                            })) {
                                Text("Off").tag("off")
                                ForEach(ThinkingEffort.allCases) { effort in Text(effort.title).tag(effort.rawValue) }
                            }
                        }
                        }
                    } label: {
                        HStack(spacing: 6) {
                            Text(store.pillModelTitle).foregroundStyle(Ink.ink).lineLimit(1)
                            Text(store.pillEffortTitle).foregroundStyle(Ink.ink3)
                        }
                        .font(TypeScale.serif(14)).monospacedDigit()
                        .padding(.horizontal, 14).frame(height: 38)
                        .background(Ink.raised, in: Capsule())
                        .contentShape(Capsule())
                    }
                    .accessibilityLabel("选择模型和思考档位")
                    .accessibilityValue("\(store.pillModelTitle) \(store.pillEffortTitle)")
                    .accessibilityIdentifier("model-effort-pill")
                    Spacer(minLength: 0)
                    Button {
                        if store.isGenerating { store.stopGeneration() }
                        else {
                            followsOutput = true
                            if store.send(store.activeDraft, images: pendingImages.map(\.data)) {
                                pendingImages = []
                                focusComposer(false)
                            }
                        }
                    } label: {
                        Image(systemName: store.isGenerating ? "stop.fill" : "arrow.up")
                            .font(.system(size: 15, weight: .bold)).foregroundStyle(Ink.sendGlyph)
                            .frame(width: 38, height: 38).background(Ink.sendFill, in: Circle()).contentShape(Circle())
                    }
                    .buttonStyle(.plain)
                    .disabled(!store.isGenerating && (!store.canChat || !hasInput || !store.canPersist))
                    .opacity(!store.isGenerating && !hasInput ? 0.35 : 1)
                    .accessibilityLabel(store.isGenerating ? "停止生成" : "发送消息")
                }
            }
            .padding(.horizontal, 14).padding(.top, 16).padding(.bottom, 12)
            .clearGlass(radius: 28)
            if store.isGenerating && store.generatingThreadID != store.activeThreadID {
                Text("另一个对话正在生成，右侧按钮可停止。")
                    .font(TypeScale.tiny).foregroundStyle(Ink.ink3)
            }
        }
        .padding(.horizontal, 14).padding(.top, 8).padding(.bottom, 10)
        .accessibilityElement(children: .contain).accessibilityIdentifier("chat-composer-panel")
        .onGeometryChange(for: CGFloat.self) { $0.size.height } action: { composerPanelHeight = $0 }
    }
}

// Holds no store: everything it shows comes in as values, so with .equatable()
// only the message that changed redraws while an answer streams.
@MainActor
struct MessageView: View, Equatable {
    @AppStorage("qingjian.reading.aiBubble") private var aiBubble = false
    let message: ChatMessage
    let threadID: UUID?
    let isLast: Bool
    let isGenerating: Bool
    let canRegenerate: Bool
    let showsSuggestions: Bool
    let edit: () -> Void
    let regenerate: () -> Void
    let openThinking: () -> Void
    let useSuggestedReply: (String) -> Void
    @State private var copied = false

    nonisolated static func == (lhs: MessageView, rhs: MessageView) -> Bool {
        lhs.message == rhs.message && lhs.threadID == rhs.threadID && lhs.isLast == rhs.isLast
            && lhs.isGenerating == rhs.isGenerating && lhs.canRegenerate == rhs.canRegenerate
            && lhs.showsSuggestions == rhs.showsSuggestions
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            if message.role == .user {
                // Your side of the talk: a soft bubble on the right, as in the Claude app.
                VStack(alignment: .trailing, spacing: 10) {
                    if let names = message.images, !names.isEmpty { AttachmentRow(names: names) }
                    Text(message.content).readingStyle(adjustment: -1).lineSpacing(5).textSelection(.enabled)
                        .foregroundStyle(Ink.ink)
                        .padding(.horizontal, 15).padding(.vertical, 10)
                        .background(Ink.raised, in: RoundedRectangle(cornerRadius: 20, style: .continuous))
                }
                .frame(maxWidth: .infinity, alignment: .trailing)
                .padding(.leading, 52)
            } else {
                if !message.reasoning.isEmpty {
                    ThinkingRow(message: message, open: openThinking)
                }
                if !message.content.isEmpty {
                    MarkdownAnswer(content: message.content).equatable()
                        .padding(aiBubble ? 16 : 0)
                        .background(aiBubble ? Ink.raised : .clear, in: RoundedRectangle(cornerRadius: 20, style: .continuous))
                }
                if message.state == .streaming {
                    StreamActivityView(message: message)
                } else {
                    HStack(spacing: 22) {
                        Button {
                            UIPasteboard.general.string = message.content; copied = true
                        } label: { Image(systemName: copied ? "checkmark" : "doc.on.doc") }
                            .accessibilityLabel("复制回答")
                        Button { edit() } label: { Image(systemName: "pencil") }
                            .disabled(isGenerating).accessibilityLabel("编辑回答")
                        if isLast {
                            Button { regenerate() } label: { Image(systemName: "arrow.clockwise") }
                                .disabled(isGenerating || !canRegenerate).accessibilityLabel("重新生成")
                        }
                        Spacer(minLength: 4)
                        if let usage = message.usage {
                            Text(usageLabel(usage)).font(TypeScale.serif(11)).monospacedDigit()
                                .accessibilityLabel("本次请求共 \(usage.totalTokens) 个 Token")
                        }
                    }.font(.system(size: 13)).foregroundStyle(Ink.ink3).buttonStyle(.plain).padding(.top, 2)
                }
            }
            if let note = message.note {
                Text(note).font(TypeScale.tiny).foregroundStyle(Ink.ink3)
                    .frame(maxWidth: .infinity, alignment: message.role == .user ? .trailing : .leading)
            }
            if isLast, message.role == .assistant, message.state == .complete, showsSuggestions, let threadID {
                ReplySuggestionPanel(message: message, threadID: threadID, use: useSuggestedReply)
            }
        }
        .contextMenu {
            Button("复制", systemImage: "doc.on.doc") { UIPasteboard.general.string = message.content }
            Button("编辑文字", systemImage: "pencil") { edit() }.disabled(isGenerating)
            if isLast && message.role == .assistant {
                Button("重新生成", systemImage: "arrow.clockwise") { regenerate() }
                    .disabled(isGenerating || !canRegenerate)
            }
        }
    }

    // Tokens come from the server; the price is our estimate from the official list.
    // The ChatGPT plan has no price per answer, so it shows tokens and the plan.
    private func usageLabel(_ usage: TokenUsage) -> String {
        let tokens = "\(usage.totalTokens.formatted()) Tokens"
        if message.isSubscription { return tokens + " · 订阅额度" }
        guard let model = message.model else { return tokens }
        return tokens + " · " + Pricing.label(Pricing.cost(model: model, usage: usage, at: message.createdAt))
    }
}

// Reads like a short table of contents under the answer: number, line, hairline.
// Only the last answer has one, so its store updates touch nothing else.
@MainActor
struct ReplySuggestionPanel: View {
    @EnvironmentObject private var store: AppStore
    let message: ChatMessage
    let threadID: UUID
    let use: (String) -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            Text("猜你回复").font(TypeScale.caption).foregroundStyle(Ink.ink3).padding(.bottom, 4)
            if let batch = message.replySuggestions {
                ForEach(Array(batch.replies.prefix(3).enumerated()), id: \.offset) { index, reply in
                    Button { use(reply) } label: {
                        HStack(alignment: .firstTextBaseline, spacing: 12) {
                            Text(String(format: "%02d", index + 1))
                                .font(TypeScale.serif(11)).monospacedDigit().foregroundStyle(Ink.ink3)
                            Text(reply).font(TypeScale.serif(15)).foregroundStyle(Ink.ink2)
                                .multilineTextAlignment(.leading)
                                .frame(maxWidth: .infinity, alignment: .leading)
                        }
                        .padding(.vertical, 12)
                        .contentShape(Rectangle())
                        .overlay(alignment: .bottom) { if index < min(batch.replies.count, 3) - 1 { InkRule() } }
                    }
                    .buttonStyle(.plain).disabled(store.isGenerating)
                    .accessibilityLabel("使用回复建议 \(index + 1)：\(reply)")
                    .accessibilityIdentifier("reply-suggestion-\(index)")
                }
                if let usage = batch.usage {
                    Text("建议 \(usage.totalTokens.formatted()) Tokens · " + suggestionCost(batch, usage))
                        .font(TypeScale.serif(10)).monospacedDigit().foregroundStyle(Ink.ink3).padding(.top, 2)
                }
            } else if store.isSuggesting(threadID: threadID, messageID: message.id) {
                HStack(spacing: 8) {
                    PulseDot(size: 7)
                    Text("正在想几种回复…").font(TypeScale.caption).foregroundStyle(Ink.ink3)
                }.padding(.vertical, 8).accessibilityIdentifier("reply-suggestions-loading")
            } else {
                if let error = store.suggestionError(threadID: threadID, messageID: message.id) {
                    Text(error).font(TypeScale.tiny).foregroundStyle(Ink.ink3)
                }
                Button("生成回复建议") { store.generateReplySuggestions(threadID: threadID, messageID: message.id) }
                    .font(TypeScale.caption).foregroundStyle(Ink.ink2).buttonStyle(.plain).disabled(store.isGenerating)
                    .padding(.vertical, 8)
            }
        }
        .padding(.top, 10)
        // Without .contain the panel's identifier would replace each suggestion button's own.
        .accessibilityElement(children: .contain)
        .accessibilityIdentifier("reply-suggestions-panel")
    }

    private func suggestionCost(_ batch: ReplySuggestionBatch, _ usage: TokenUsage) -> String {
        batch.provider == .chatGPT ? "订阅额度" : Pricing.label(Pricing.cost(model: batch.pricedModel, usage: usage, at: batch.createdAt))
    }
}

struct AttachmentRow: View {
    let names: [String]
    private var side: CGFloat { names.count == 1 ? 168 : (names.count == 2 ? 120 : 76) }
    var body: some View {
        HStack(spacing: 8) {
            ForEach(names, id: \.self) { name in
                Group {
                    if let image = ImageStore.thumbnail(named: name) {
                        Image(uiImage: image).resizable().scaledToFill().accessibilityLabel("附带的图片")
                    } else {
                        Ink.raised.overlay(Image(systemName: "photo").foregroundStyle(Ink.ink3))
                            .accessibilityLabel("图片文件已不在这台手机上")
                    }
                }
                .frame(width: side, height: side)
                .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
            }
        }
    }
}

// Equatable so finished answers are not re-parsed while a new one streams in.
// Paragraphs are Equatable too: while text arrives only the last one is parsed again.
struct MarkdownAnswer: View, Equatable {
    let content: String
    nonisolated static func == (lhs: MarkdownAnswer, rhs: MarkdownAnswer) -> Bool { lhs.content == rhs.content }
    private var segments: [String] { content.components(separatedBy: "```") }
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            ForEach(Array(segments.enumerated()), id: \.offset) { index, segment in
                if index.isMultiple(of: 2) {
                    ForEach(Array(segment.components(separatedBy: "\n\n").enumerated()), id: \.offset) { _, paragraph in
                        if !paragraph.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                            MarkdownParagraph(text: paragraph).equatable()
                        }
                    }
                } else {
                    VStack(alignment: .leading, spacing: 8) {
                        HStack {
                            Text("代码").font(TypeScale.tiny).foregroundStyle(Ink.ink3)
                            Spacer()
                            Button { UIPasteboard.general.string = Self.codeBody(segment) } label: { Image(systemName: "doc.on.doc") }
                                .font(.system(size: 11)).accessibilityLabel("复制代码")
                        }
                        ScrollView(.horizontal) {
                            Text(Self.codeBody(segment)).font(.system(size: 13, design: .monospaced)).textSelection(.enabled)
                        }
                    }.padding(14).background(Ink.raised, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                }
            }
        }.frame(maxWidth: .infinity, alignment: .leading)
    }
    private static func codeBody(_ segment: String) -> String {
        guard let newline = segment.firstIndex(of: "\n") else { return segment }
        let first = segment[..<newline].trimmingCharacters(in: .whitespaces)
        return first.isEmpty || (!first.contains(" ") && first.count < 24) ? String(segment[segment.index(after: newline)...]) : segment
    }
}

struct MarkdownParagraph: View, Equatable {
    let text: String
    nonisolated static func == (lhs: MarkdownParagraph, rhs: MarkdownParagraph) -> Bool { lhs.text == rhs.text }
    var body: some View {
        if text.hasPrefix("#") {
            Text(text.drop(while: { $0 == "#" || $0 == " " }))
                .readingStyle(adjustment: 1, heavy: true).padding(.top, 6)
        } else {
            Text(Self.attributed(text)).readingStyle().lineSpacing(7).textSelection(.enabled)
                .foregroundStyle(Ink.ink)
        }
    }
    private static func attributed(_ text: String) -> AttributedString {
        guard var value = try? AttributedString(markdown: text, options: .init(interpretedSyntax: .inlineOnlyPreservingWhitespace)) else {
            return AttributedString(text)
        }
        // Bold in an answer is drawn as a highlighter stroke.
        for run in value.runs where run.inlinePresentationIntent?.contains(.stronglyEmphasized) == true {
            value[run.range].swiftUI.backgroundColor = Ink.mark
        }
        return value
    }
}

@MainActor
struct EditMessageView: View {
    @EnvironmentObject private var store: AppStore
    @Environment(\.dismiss) private var dismiss
    let message: ChatMessage
    @State private var text = ""
    var body: some View {
        NavigationStack {
            VStack(alignment: .leading, spacing: 16) {
                Text(message.role == .user ? "保存会直接修改这条消息；重新发送会替换其后的内容。" : "直接修改当前回答，不新建对话。")
                    .font(TypeScale.caption).foregroundStyle(Ink.ink3)
                TextEditor(text: $text).readingStyle().scrollContentBackground(.hidden)
                    .padding(12).background(Ink.raised, in: RoundedRectangle(cornerRadius: 20, style: .continuous))
                    .accessibilityIdentifier("message-editor")
                if message.role == .user {
                    Button {
                        if store.editMessage(message.id, text: text, resend: true) { dismiss() }
                    } label: {
                        Text("保存并重新发送").frame(maxWidth: .infinity).padding(.vertical, 8)
                    }.buttonStyle(.inkPrimary)
                        .disabled(text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                }
            }.padding(20).background(Ink.paper)
                .navigationTitle(message.role == .user ? "编辑你的消息" : "编辑回答")
                .navigationBarTitleDisplayMode(.inline)
                .toolbar {
                    ToolbarItem(placement: .topBarLeading) { Button("取消") { dismiss() } }
                    ToolbarItem(placement: .topBarTrailing) {
                        Button("保存") {
                            if store.editMessage(message.id, text: text, resend: false) { dismiss() }
                        }.disabled(text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                    }
                }
        }.presentationDragIndicator(.visible)
            .onAppear { text = message.content }
            .alert("暂时没有完成", isPresented: Binding(get: { store.errorMessage != nil }, set: { if !$0 { store.errorMessage = nil } })) {
                Button("知道了") { store.errorMessage = nil }
            } message: { Text(store.errorMessage ?? "") }
    }
}
