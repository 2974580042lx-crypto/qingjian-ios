import SwiftUI
import UIKit

enum Palette {
    static let green = Color(red: 0.12, green: 0.42, blue: 0.32)
    static let softGreen = Color(red: 0.90, green: 0.95, blue: 0.91)
    static let paper = Color(uiColor: .systemGroupedBackground)
    static let surface = Color(uiColor: .secondarySystemGroupedBackground)
}

@MainActor
struct ContentView: View {
    @EnvironmentObject private var store: AppStore
    @State private var draft = ""
    @State private var showSettings = false
    @State private var showHistory = false
    @FocusState private var composerFocused: Bool

    var body: some View {
        NavigationStack {
            ScrollViewReader { proxy in
                ScrollView {
                    LazyVStack(alignment: .leading, spacing: 22) {
                        if store.activeThread?.messages.isEmpty != false { welcome }
                        ForEach(store.activeThread?.messages ?? []) { message in
                            MessageView(message: message).id(message.id)
                        }
                        Color.clear.frame(height: 1).id("conversation-bottom")
                    }
                    .padding(.horizontal, 20).padding(.top, 24).padding(.bottom, 12)
                }
                .scrollDismissesKeyboard(.interactively)
                .onChange(of: store.activeThread?.messages.count) { _, _ in
                    proxy.scrollTo("conversation-bottom", anchor: .bottom)
                }
                .onChange(of: store.activeThread?.messages.last?.content) { _, _ in
                    if store.generatingThreadID == store.activeThreadID {
                        proxy.scrollTo("conversation-bottom", anchor: .bottom)
                    }
                }
            }
            .background(Palette.paper)
            .navigationTitle("青笺")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button { composerFocused = false; showHistory = true } label: {
                        Image(systemName: "line.3.horizontal").font(.system(size: 18, weight: .medium))
                    }.accessibilityLabel("历史对话")
                }
                ToolbarItemGroup(placement: .topBarTrailing) {
                    Button { store.createThread(); draft = "" } label: { Image(systemName: "square.and.pencil") }
                        .accessibilityLabel("新建对话")
                    Button { composerFocused = false; showSettings = true } label: { Image(systemName: "gearshape") }
                        .accessibilityLabel("设置")
                }
            }
            .safeAreaInset(edge: .bottom, spacing: 0) { composer }
            .sheet(isPresented: $showSettings) { SettingsView() }
            .sheet(isPresented: $showHistory) { HistoryView() }
            .alert("暂时没有完成", isPresented: errorPresented) {
                Button("知道了") { store.errorMessage = nil }
            } message: { Text(store.errorMessage ?? "") }
        }
    }

    private var welcome: some View {
        VStack(alignment: .leading, spacing: 22) {
            ZStack {
                RoundedRectangle(cornerRadius: 22).fill(Palette.green.gradient).frame(width: 72, height: 72)
                Image(systemName: "leaf").font(.system(size: 32, weight: .light)).foregroundStyle(.white)
            }.padding(.top, 36)
            VStack(alignment: .leading, spacing: 12) {
                Text("把想法，\n慢慢聊清楚。")
                    .font(.system(size: 34, weight: .semibold, design: .serif)).lineSpacing(5)
                Text("聊天、读书、理清思路。\n这一页，留给你。")
                    .font(.system(size: 16)).foregroundStyle(.secondary).lineSpacing(5)
            }
            VStack(spacing: 10) {
                suggestion("讲清一个概念", subtitle: "从一个小例子开始", icon: "lightbulb", text: "我想弄懂一个概念，请先让我告诉你是什么，再用生活例子帮我讲清楚。")
                suggestion("梳理一段文字", subtitle: "找出重点和逻辑", icon: "text.alignleft", text: "我会发给你一段文字，请帮我梳理它的重点、逻辑和需要核验的地方。")
                suggestion("陪我聊一会儿", subtitle: "从今天的一件小事聊起", icon: "bubble.left", text: "我们随意聊一会儿吧。你可以先问我今天有什么想说的事。")
            }.padding(.top, 8)
        }.frame(maxWidth: .infinity, alignment: .leading).padding(.bottom, 24)
    }
    private func suggestion(_ title: String, subtitle: String, icon: String, text: String) -> some View {
        Button { draft = text; composerFocused = true } label: {
            HStack(spacing: 14) {
                Image(systemName: icon).font(.system(size: 19)).frame(width: 26).foregroundStyle(Palette.green)
                VStack(alignment: .leading, spacing: 4) {
                    Text(title).font(.system(size: 15, weight: .medium)).foregroundStyle(.primary)
                    Text(subtitle).font(.system(size: 12)).foregroundStyle(.secondary)
                }
                Spacer()
                Image(systemName: "arrow.up.left").font(.system(size: 12)).foregroundStyle(.tertiary)
            }.padding(16).background(Palette.surface, in: RoundedRectangle(cornerRadius: 17))
        }.buttonStyle(.plain)
    }

    private var composer: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Button { store.toggleThinking() } label: {
                    HStack(spacing: 6) {
                        Image(systemName: "sparkles")
                        Text("深度思考")
                        if store.settings.thinkingEnabled { Image(systemName: "checkmark").font(.system(size: 10, weight: .bold)) }
                    }
                    .font(.system(size: 12, weight: .medium)).padding(.horizontal, 12).padding(.vertical, 8)
                    .foregroundStyle(store.settings.thinkingEnabled ? Palette.green : Color.secondary)
                    .background(store.settings.thinkingEnabled ? Palette.softGreen : Palette.surface, in: Capsule())
                }.buttonStyle(.plain)
                Spacer()
                Text(store.settings.model.title).font(.system(size: 11)).foregroundStyle(.secondary)
            }
            if !store.hasKey {
                Button { composerFocused = false; showSettings = true } label: {
                    Label("填写 API Key，开始聊天", systemImage: "key")
                        .font(.system(size: 13, weight: .medium)).frame(maxWidth: .infinity).padding(.vertical, 12)
                }.buttonStyle(.bordered)
            }
            HStack(alignment: .bottom, spacing: 10) {
                TextField("写下一个想法…", text: $draft, axis: .vertical)
                    .lineLimit(1...6).font(.system(size: 16)).focused($composerFocused)
                    .padding(.vertical, 12).padding(.leading, 15)
                    .disabled(!store.canPersist)
                Button {
                    if store.isGenerating { store.stopGeneration() }
                    else if store.send(draft) { draft = ""; composerFocused = false }
                } label: {
                    Image(systemName: store.isGenerating ? "stop.fill" : "arrow.up")
                        .font(.system(size: 17, weight: .semibold)).foregroundStyle(.white)
                        .frame(width: 38, height: 38)
                        .background(Palette.green, in: RoundedRectangle(cornerRadius: 12))
                }
                .disabled(!store.isGenerating && (!store.hasKey || draft.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || !store.canPersist))
                .opacity(!store.isGenerating && draft.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? 0.45 : 1)
                .padding(.trailing, 7).padding(.bottom, 7)
                .accessibilityLabel(store.isGenerating ? "停止生成" : "发送")
            }
            .background(Palette.surface, in: RoundedRectangle(cornerRadius: 20))
            .overlay(RoundedRectangle(cornerRadius: 20).stroke(Color.primary.opacity(0.06), lineWidth: 1))
            if store.isGenerating && store.generatingThreadID != store.activeThreadID {
                Text("另一个对话正在生成，右侧按钮可以停止。")
                    .font(.caption2).foregroundStyle(.secondary)
            }
        }
        .padding(.horizontal, 16).padding(.top, 12).padding(.bottom, 8)
        .background(.ultraThinMaterial)
    }
    private var errorPresented: Binding<Bool> {
        Binding(get: { store.errorMessage != nil && !showSettings }, set: { if !$0 { store.errorMessage = nil } })
    }
}

@MainActor
struct MessageView: View {
    @EnvironmentObject private var store: AppStore
    let message: ChatMessage
    @State private var reasoningExpanded = false
    @State private var copied = false
    private var isLast: Bool { store.activeThread?.messages.last?.id == message.id }
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(spacing: 7) {
                Image(systemName: message.role == .user ? "person.crop.circle" : "leaf.circle.fill")
                    .foregroundStyle(message.role == .user ? Color.secondary : Palette.green)
                Text(message.role == .user ? "你" : "DeepSeek").font(.system(size: 12, weight: .semibold))
                Spacer()
                Text(message.createdAt, style: .time).font(.system(size: 10)).foregroundStyle(.tertiary)
            }
            if message.role == .user {
                Text(message.content).font(.system(size: 16)).lineSpacing(5).textSelection(.enabled)
                    .frame(maxWidth: .infinity, alignment: .leading).padding(16)
                    .background(Palette.green.opacity(0.09), in: RoundedRectangle(cornerRadius: 18))
            } else {
                if !message.reasoning.isEmpty {
                    DisclosureGroup(isExpanded: $reasoningExpanded) {
                        Text(message.reasoning).font(.system(size: 13)).lineSpacing(4)
                            .foregroundStyle(.secondary).textSelection(.enabled).padding(.top, 8)
                    } label: {
                        Label(message.state == .streaming && message.content.isEmpty ? "正在思考" : "思考过程", systemImage: "sparkles")
                            .font(.system(size: 12, weight: .medium)).foregroundStyle(.secondary)
                    }.padding(13).background(Palette.surface, in: RoundedRectangle(cornerRadius: 14))
                }
                if !message.content.isEmpty { MarkdownAnswer(content: message.content) }
                if message.state == .streaming {
                    HStack(spacing: 8) {
                        ProgressView().controlSize(.small)
                        Text(message.content.isEmpty ? "正在准备回答…" : "正在回答…")
                            .font(.system(size: 12)).foregroundStyle(.secondary)
                    }.padding(.vertical, 4)
                }
                if let note = message.note {
                    Text(note).font(.system(size: 12)).foregroundStyle(.secondary).padding(.vertical, 4)
                }
                if message.state != .streaming {
                    HStack(spacing: 16) {
                        if !message.content.isEmpty {
                            Button {
                                UIPasteboard.general.string = message.content
                                copied = true
                            } label: { Label(copied ? "已复制" : "复制", systemImage: copied ? "checkmark" : "doc.on.doc") }
                        }
                        if isLast {
                            Button { store.regenerate() } label: { Label("重新生成", systemImage: "arrow.clockwise") }
                                .disabled(store.isGenerating || !store.hasKey)
                        }
                        Spacer()
                    }.font(.system(size: 11)).foregroundStyle(.secondary).buttonStyle(.plain)
                    if let usage = message.usage {
                        Text("输入 \(usage.promptTokens) · 输出 \(usage.completionTokens) tokens")
                            .font(.system(size: 10)).foregroundStyle(.tertiary)
                    }
                }
            }
        }.frame(maxWidth: .infinity, alignment: .leading)
    }
}

struct MarkdownAnswer: View {
    let content: String
    private var segments: [String] { content.components(separatedBy: "```") }
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            ForEach(Array(segments.enumerated()), id: \.offset) { index, segment in
                if index.isMultiple(of: 2) {
                    Text(attributed(segment)).font(.system(size: 16)).lineSpacing(6).textSelection(.enabled)
                        .frame(maxWidth: .infinity, alignment: .leading)
                } else {
                    ScrollView(.horizontal) {
                        Text(codeBody(segment)).font(.system(size: 13, design: .monospaced))
                            .textSelection(.enabled).padding(14)
                    }.background(Palette.surface, in: RoundedRectangle(cornerRadius: 12))
                }
            }
        }
    }
    private func attributed(_ text: String) -> AttributedString {
        (try? AttributedString(markdown: text,
                              options: .init(interpretedSyntax: .inlineOnlyPreservingWhitespace))) ?? AttributedString(text)
    }
    private func codeBody(_ segment: String) -> String {
        guard let newline = segment.firstIndex(of: "\n") else { return segment }
        let firstLine = String(segment[..<newline]).trimmingCharacters(in: .whitespaces)
        if firstLine.isEmpty || (!firstLine.contains(" ") && firstLine.count <= 20) {
            return String(segment[segment.index(after: newline)...])
        }
        return segment
    }
}
