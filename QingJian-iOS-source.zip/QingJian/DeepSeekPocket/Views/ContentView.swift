import SwiftUI
import UIKit
import UniformTypeIdentifiers

enum MainTab: Hashable { case chat, saved, settings }

@MainActor
struct ContentView: View {
    @EnvironmentObject private var store: AppStore
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var tab: MainTab = ProcessInfo.processInfo.arguments.contains("--preview-settings") ? .settings :
        (ProcessInfo.processInfo.arguments.contains("--preview-saved") ? .saved : .chat)
    @State private var showSidebar = ProcessInfo.processInfo.arguments.contains("--preview-sidebar")

    var body: some View {
        GeometryReader { geometry in
            let width = min(geometry.size.width * 0.82, 340)
            ZStack(alignment: .leading) {
                Palette.paper.ignoresSafeArea()
                HistorySidebar {
                    tab = .chat
                    showSidebar = false
                }
                .frame(width: width)
                .offset(x: showSidebar ? 0 : -width * 0.2)
                .opacity(showSidebar ? 1 : 0)
                .allowsHitTesting(showSidebar)
                .accessibilityHidden(!showSidebar)

                TabView(selection: $tab) {
                    NavigationStack {
                        ChatScreen(openHistory: { showSidebar = true }, openSettings: { tab = .settings })
                    }
                    .tabItem { Label("聊天", systemImage: "bubble.left.and.bubble.right") }.tag(MainTab.chat)
                    NavigationStack {
                        SavedMessagesView { threadID in
                            store.select(threadID); tab = .chat
                        }
                    }
                    .tabItem { Label("收藏", systemImage: "bookmark") }.tag(MainTab.saved)
                    SettingsView(embedded: true)
                        .tabItem { Label("设置", systemImage: "slider.horizontal.3") }.tag(MainTab.settings)
                }
                .tint(.white)
                .background(Palette.paper)
                .overlay {
                    if showSidebar {
                        Color.black.opacity(0.38)
                            .contentShape(Rectangle())
                            .onTapGesture { showSidebar = false }
                    }
                }
                // Native tab bars extend into the home-indicator safe area.
                // Clipping this container cuts off the bottom of the glass capsule.
                .scaleEffect(showSidebar && !reduceMotion ? 0.94 : 1, anchor: .trailing)
                .offset(x: showSidebar ? width : 0)
                .shadow(color: .black.opacity(showSidebar ? 0.5 : 0), radius: 30, x: -8)
                .accessibilityHidden(showSidebar)
            }
            .animation(reduceMotion ? nil : .snappy(duration: 0.28), value: showSidebar)
            .simultaneousGesture(DragGesture(minimumDistance: 35).onEnded { value in
                if showSidebar && value.translation.width < -65 { showSidebar = false }
                else if !showSidebar && tab == .chat && value.startLocation.x < 24 && value.translation.width > 90 {
                    UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
                    showSidebar = true
                }
            })
        }
        .preferredColorScheme(.dark)
        .onAppear {
            if store.isPreview {
                let result = "QINGJIAN_SONGTI_LOADED=\(UIFont(name: "NotoSerifSC-Regular", size: 18) != nil)\n"
                FileHandle.standardOutput.write(Data(result.utf8))
            }
        }
    }
}

@MainActor
struct ChatScreen: View {
    @EnvironmentObject private var store: AppStore
    let openHistory: () -> Void
    let openSettings: () -> Void
    @FocusState private var composerFocused: Bool
    @State private var editedMessage: ChatMessage?
    @State private var followsOutput = true
    @State private var nearBottom = true
    @State private var importingText = false

    private var draft: Binding<String> { Binding(get: { store.activeDraft }, set: { store.setDraft($0) }) }
    private var errorPresented: Binding<Bool> {
        Binding(get: { store.errorMessage != nil && editedMessage == nil },
                set: { if !$0 { store.errorMessage = nil } })
    }

    var body: some View {
        ScrollViewReader { proxy in
            ScrollView {
                LazyVStack(alignment: .leading, spacing: 30) {
                    if store.activeThread?.messages.isEmpty != false { welcome }
                    if let parent = store.activeThread?.parentThreadID,
                       store.threads.contains(where: { $0.id == parent }) {
                        Button { store.select(parent) } label: {
                            Label("原对话已保留", systemImage: "arrow.uturn.backward")
                                .font(.system(size: 12)).foregroundStyle(Palette.secondary)
                        }.buttonStyle(.plain)
                    }
                    ForEach(store.activeThread?.messages ?? []) { message in
                        MessageView(message: message) {
                            composerFocused = false
                            editedMessage = message
                        }.id(message.id)
                    }
                    Color.clear.frame(height: 2).id("conversation-bottom")
                }
                .padding(.horizontal, 22).padding(.top, 24).padding(.bottom, 22)
            }
            .scrollDismissesKeyboard(.interactively)
            .onScrollGeometryChange(for: Bool.self) { g in
                g.contentSize.height - g.contentOffset.y - g.containerSize.height < 100
            } action: { _, value in nearBottom = value }
            .onScrollPhaseChange { _, phase in
                if phase == .interacting { followsOutput = false }
                if phase == .idle && nearBottom { followsOutput = true }
            }
            .onChange(of: store.activeThread?.messages.count) { _, _ in
                if followsOutput { proxy.scrollTo("conversation-bottom", anchor: .bottom) }
            }
            .onChange(of: store.activeThread?.messages.last?.content) { _, _ in
                if followsOutput && store.generatingThreadID == store.activeThreadID {
                    proxy.scrollTo("conversation-bottom", anchor: .bottom)
                }
            }
            .onChange(of: store.activeThreadID) { _, _ in
                followsOutput = true
                DispatchQueue.main.async { proxy.scrollTo("conversation-bottom", anchor: .bottom) }
            }
            .overlay(alignment: .bottomTrailing) {
                if !nearBottom && store.activeThread?.messages.isEmpty == false {
                    GlassCircle(symbol: "arrow.down", label: "回到最新消息") {
                        followsOutput = true
                        withAnimation(.easeOut(duration: 0.2)) { proxy.scrollTo("conversation-bottom", anchor: .bottom) }
                    }.padding(.trailing, 22).padding(.bottom, 12)
                }
            }
            .safeAreaInset(edge: .bottom, spacing: 0) { composer }
        }
        .background(Palette.paper)
        .navigationTitle("青笺")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .topBarLeading) {
                Button { composerFocused = false; openHistory() } label: { Image(systemName: "line.3.horizontal") }
                    .accessibilityLabel("打开历史对话")
            }
            ToolbarItem(placement: .principal) {
                Text("青笺").font(.custom("NotoSerifSC-Regular", size: 21)).foregroundStyle(.white)
            }
            ToolbarItem(placement: .topBarTrailing) {
                Button { store.createThread(); followsOutput = true } label: { Image(systemName: "square.and.pencil") }
                    .accessibilityLabel("新建对话")
            }
        }
        .toolbar(composerFocused ? .hidden : .visible, for: .tabBar)
        .sheet(item: $editedMessage) { message in EditMessageView(message: message) }
        .fileImporter(isPresented: $importingText, allowedContentTypes: [.plainText, .text]) { result in
            do {
                let url = try result.get()
                let scoped = url.startAccessingSecurityScopedResource()
                defer { if scoped { url.stopAccessingSecurityScopedResource() } }
                let size = try url.resourceValues(forKeys: [.fileSizeKey]).fileSize ?? 0
                guard size <= 1024 * 1024 else { throw ChatError.server("请选择小于 1 MB 的文字文件。") }
                let text = try String(contentsOf: url, encoding: .utf8)
                store.setDraft(store.activeDraft.isEmpty ? text : store.activeDraft + "\n\n" + text)
                composerFocused = true
            } catch { store.errorMessage = error.localizedDescription }
        }
        .alert("暂时没有完成", isPresented: errorPresented) {
            Button("知道了") { store.errorMessage = nil }
        } message: { Text(store.errorMessage ?? "") }
        .task {
            if ProcessInfo.processInfo.arguments.contains("--preview-keyboard") {
                try? await Task.sleep(nanoseconds: 350_000_000)
                composerFocused = true
            }
            if ProcessInfo.processInfo.arguments.contains("--preview-edit") {
                editedMessage = store.activeThread?.messages.last
            }
        }
    }

    private var welcome: some View {
        VStack(alignment: .leading, spacing: 24) {
            Image(systemName: "sparkle").font(.system(size: 30, weight: .ultraLight))
                .foregroundStyle(Color.white.opacity(0.55)).padding(.bottom, 8)
            Text("这一页，\n留给你。")
                .font(.custom("NotoSerifSC-Regular", size: 34)).lineSpacing(12)
                .foregroundStyle(Color.white.opacity(0.94))
            Text("把想法慢慢聊清楚。")
                .font(.system(size: 14)).foregroundStyle(Palette.secondary)
            HStack(spacing: 10) {
                suggestion("随便聊聊", text: "我们随意聊一会儿吧。")
                suggestion("理清思路", text: "我有一个想法，想请你帮我理清思路。")
            }.padding(.top, 8)
        }.padding(.top, 74).padding(.bottom, 48)
            .frame(maxWidth: .infinity, alignment: .leading)
    }

    private func suggestion(_ label: String, text: String) -> some View {
        Button { store.setDraft(text); composerFocused = true } label: {
            Text(label).font(.system(size: 13)).padding(.horizontal, 14).padding(.vertical, 10)
        }.buttonStyle(.plain).glassEffect(.regular.interactive(), in: .capsule)
    }

    private var composer: some View {
        VStack(spacing: 8) {
            if !store.hasKey {
                Button { composerFocused = false; openSettings() } label: {
                    Label("连接 DeepSeek，开始聊天", systemImage: "key")
                        .font(.system(size: 12)).foregroundStyle(Palette.secondary)
                }.padding(.bottom, 2)
            }
            VStack(alignment: .leading, spacing: 14) {
                TextField("写下一个想法…", text: draft, axis: .vertical)
                    .readingStyle(adjustment: -1).lineLimit(1...5)
                    .focused($composerFocused).tint(.white)
                    .disabled(!store.canPersist)
                    .accessibilityIdentifier("chat-composer")
                HStack(spacing: 16) {
                    Menu {
                        Button("导入文字文件", systemImage: "doc.text") { importingText = true }
                        Button("粘贴文字", systemImage: "doc.on.clipboard") {
                            if let text = UIPasteboard.general.string { store.setDraft(store.activeDraft + text) }
                        }
                        Button("系统提示词", systemImage: "text.alignleft") { composerFocused = false; openSettings() }
                    } label: {
                        Image(systemName: "plus").font(.system(size: 17, weight: .medium))
                            .frame(width: 34, height: 40).contentShape(Rectangle())
                    }
                    .accessibilityLabel("更多输入操作")
                    Menu {
                        Picker("模型", selection: Binding(get: { store.settings.model }, set: { store.setModel($0) })) {
                            ForEach(DeepSeekModel.allCases) { model in Text(model.title).tag(model) }
                        }
                    } label: {
                        HStack(spacing: 5) {
                            Text(store.settings.model.title)
                            Image(systemName: "chevron.down").font(.system(size: 9, weight: .semibold))
                        }.font(.system(size: 12)).foregroundStyle(Palette.secondary).frame(minHeight: 40)
                    }.accessibilityLabel("选择模型")
                    Button { store.toggleThinking() } label: {
                        HStack(spacing: 4) {
                            Image(systemName: "sparkle")
                            Text("思考")
                            if store.settings.thinkingEnabled { Image(systemName: "checkmark").font(.system(size: 8)) }
                        }.font(.system(size: 12)).frame(minHeight: 40).contentShape(Rectangle())
                            .foregroundStyle(store.settings.thinkingEnabled ? Color.white : Palette.secondary)
                    }.buttonStyle(.plain).accessibilityLabel(store.settings.thinkingEnabled ? "关闭深度思考" : "开启深度思考")
                    Spacer(minLength: 0)
                    Button {
                        if store.isGenerating { store.stopGeneration() }
                        else {
                            followsOutput = true
                            if store.send(store.activeDraft) { composerFocused = false }
                        }
                    } label: {
                        Image(systemName: store.isGenerating ? "stop.fill" : "arrow.up")
                            .font(.system(size: 15, weight: .semibold)).foregroundStyle(.black)
                            .frame(width: 36, height: 36).background(.white, in: Circle()).padding(4).contentShape(Rectangle())
                    }
                    .buttonStyle(.plain)
                    .disabled(!store.isGenerating && (!store.hasKey || store.activeDraft.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || !store.canPersist))
                    .opacity(!store.isGenerating && store.activeDraft.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? 0.35 : 1)
                    .accessibilityLabel(store.isGenerating ? "停止生成" : "发送消息")
                }
            }
            .padding(.horizontal, 17).padding(.top, 16).padding(.bottom, 12)
            .glassEffect(.regular, in: .rect(cornerRadius: 28))
            if store.isGenerating && store.generatingThreadID != store.activeThreadID {
                Text("另一个对话正在生成，右侧按钮可停止。")
                    .font(.system(size: 10)).foregroundStyle(Palette.secondary)
            }
        }
        .padding(.horizontal, 14).padding(.top, 8).padding(.bottom, 10)
    }
}

@MainActor
struct MessageView: View {
    @EnvironmentObject private var store: AppStore
    @AppStorage("qingjian.reading.aiBubble") private var aiBubble = false
    let message: ChatMessage
    let edit: () -> Void
    @State private var copied = false
    @State private var expandedReasoning = false
    private var isLast: Bool { store.activeThread?.messages.last?.id == message.id }

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            if message.role == .user {
                HStack {
                    Spacer(minLength: 36)
                    Text(message.content).readingStyle().lineSpacing(6).textSelection(.enabled)
                        .padding(.horizontal, 17).padding(.vertical, 14)
                        .background(Color.white.opacity(0.075), in: RoundedRectangle(cornerRadius: 22))
                }
            } else {
                HStack(spacing: 7) {
                    Image(systemName: "sparkle").font(.system(size: 12))
                    Text("DeepSeek").font(.system(size: 11, weight: .medium))
                    if message.isBookmarked == true { Image(systemName: "bookmark.fill").font(.system(size: 9)) }
                }.foregroundStyle(Palette.secondary)
                if !message.reasoning.isEmpty {
                    DisclosureGroup(isExpanded: $expandedReasoning) {
                        Text(message.reasoning).readingStyle(adjustment: -3).lineSpacing(5)
                            .textSelection(.enabled).foregroundStyle(Palette.secondary).padding(.top, 8)
                    } label: {
                        Text(message.state == .streaming && message.content.isEmpty ? "正在思考" : "思考过程")
                            .font(.system(size: 12)).foregroundStyle(Palette.secondary)
                    }
                }
                if !message.content.isEmpty {
                    MarkdownAnswer(content: message.content)
                        .padding(aiBubble ? 16 : 0)
                        .background(aiBubble ? Color.white.opacity(0.05) : .clear, in: RoundedRectangle(cornerRadius: 20))
                }
                if message.state == .streaming {
                    HStack(spacing: 8) {
                        ProgressView().controlSize(.small)
                        Text(message.content.isEmpty ? "正在准备回答" : "正在回答")
                            .font(.system(size: 11)).foregroundStyle(Palette.secondary)
                    }.padding(.vertical, 4)
                } else {
                    HStack(spacing: 22) {
                        Button {
                            UIPasteboard.general.string = message.content; copied = true
                        } label: { Image(systemName: copied ? "checkmark" : "doc.on.doc") }
                            .accessibilityLabel("复制回答")
                        Button { edit() } label: { Image(systemName: "pencil") }
                            .disabled(store.isGenerating).accessibilityLabel("编辑回答")
                        if isLast {
                            Button { store.regenerate() } label: { Image(systemName: "arrow.clockwise") }
                                .disabled(store.isGenerating || !store.hasKey).accessibilityLabel("重新生成")
                        }
                        Button { bookmark() } label: {
                            Image(systemName: message.isBookmarked == true ? "bookmark.fill" : "bookmark")
                        }.accessibilityLabel(message.isBookmarked == true ? "取消收藏" : "收藏回答")
                    }.font(.system(size: 12)).foregroundStyle(Palette.secondary).buttonStyle(.plain).padding(.top, 2)
                }
            }
            if let note = message.note {
                Text(note).font(.system(size: 11)).foregroundStyle(Palette.secondary)
                    .frame(maxWidth: .infinity, alignment: message.role == .user ? .trailing : .leading)
            }
        }
        .contextMenu {
            Button("复制", systemImage: "doc.on.doc") { UIPasteboard.general.string = message.content }
            Button("编辑文字", systemImage: "pencil") { edit() }.disabled(store.isGenerating)
            Button(message.isBookmarked == true ? "取消收藏" : "收藏", systemImage: "bookmark") { bookmark() }
            if isLast && message.role == .assistant {
                Button("重新生成", systemImage: "arrow.clockwise") { store.regenerate() }
                    .disabled(store.isGenerating || !store.hasKey)
            }
        }
    }
    private func bookmark() {
        if let id = store.activeThreadID { store.toggleBookmark(threadID: id, messageID: message.id) }
    }
}

struct MarkdownAnswer: View {
    let content: String
    private var segments: [String] { content.components(separatedBy: "```") }
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            ForEach(Array(segments.enumerated()), id: \.offset) { index, segment in
                if index.isMultiple(of: 2) {
                    ForEach(Array(segment.components(separatedBy: "\n\n").enumerated()), id: \.offset) { _, paragraph in
                        if !paragraph.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                            if paragraph.hasPrefix("#") {
                                Text(paragraph.drop(while: { $0 == "#" || $0 == " " }))
                                    .readingStyle(adjustment: 1).padding(.top, 6)
                            } else {
                                Text(attributed(paragraph)).readingStyle().lineSpacing(7).textSelection(.enabled)
                                    .foregroundStyle(Color.white.opacity(0.89))
                            }
                        }
                    }
                } else {
                    VStack(alignment: .leading, spacing: 8) {
                        HStack {
                            Text("代码").font(.system(size: 10)).foregroundStyle(Palette.secondary)
                            Spacer()
                            Button { UIPasteboard.general.string = codeBody(segment) } label: { Image(systemName: "doc.on.doc") }
                                .font(.system(size: 11)).accessibilityLabel("复制代码")
                        }
                        ScrollView(.horizontal) {
                            Text(codeBody(segment)).font(.system(size: 13, design: .monospaced)).textSelection(.enabled)
                        }
                    }.padding(14).background(Palette.surface, in: RoundedRectangle(cornerRadius: 16))
                }
            }
        }.frame(maxWidth: .infinity, alignment: .leading)
    }
    private func attributed(_ text: String) -> AttributedString {
        (try? AttributedString(markdown: text, options: .init(interpretedSyntax: .inlineOnlyPreservingWhitespace))) ?? AttributedString(text)
    }
    private func codeBody(_ segment: String) -> String {
        guard let newline = segment.firstIndex(of: "\n") else { return segment }
        let first = segment[..<newline].trimmingCharacters(in: .whitespaces)
        return first.isEmpty || (!first.contains(" ") && first.count < 24) ? String(segment[segment.index(after: newline)...]) : segment
    }
}

@MainActor
struct EditMessageView: View {
    @EnvironmentObject private var store: AppStore
    @Environment(\.dismiss) private var dismiss
    let message: ChatMessage
    @State private var text = ""
    var body: some View {
        NavigationStack {
            VStack(alignment: .leading, spacing: 16) {
                Text("修改会另存一个对话，原内容仍在历史里。")
                    .font(.system(size: 12)).foregroundStyle(Palette.secondary)
                TextEditor(text: $text).readingStyle().scrollContentBackground(.hidden)
                    .padding(12).background(Palette.surface, in: RoundedRectangle(cornerRadius: 20))
                    .accessibilityIdentifier("message-editor")
                if message.role == .user {
                    Button {
                        if store.editMessage(message.id, text: text, resend: true) { dismiss() }
                    } label: {
                        Text("保存并重新发送").frame(maxWidth: .infinity).padding(.vertical, 8)
                    }.buttonStyle(.glassProminent).tint(.white).foregroundStyle(.black)
                        .disabled(text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                }
            }.padding(20).background(Palette.paper)
                .navigationTitle(message.role == .user ? "编辑你的消息" : "编辑回答")
                .navigationBarTitleDisplayMode(.inline)
                .toolbar {
                    ToolbarItem(placement: .topBarLeading) { Button("取消") { dismiss() } }
                    ToolbarItem(placement: .topBarTrailing) {
                        Button("保存") {
                            if store.editMessage(message.id, text: text, resend: false) { dismiss() }
                        }.disabled(text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                    }
                }
        }.preferredColorScheme(.dark).presentationDragIndicator(.visible)
            .onAppear { text = message.content }
            .alert("暂时没有完成", isPresented: Binding(get: { store.errorMessage != nil }, set: { if !$0 { store.errorMessage = nil } })) {
                Button("知道了") { store.errorMessage = nil }
            } message: { Text(store.errorMessage ?? "") }
    }
}

@MainActor
struct SavedMessagesView: View {
    @EnvironmentObject private var store: AppStore
    let openThread: (UUID) -> Void
    private struct SavedItem: Identifiable {
        let thread: ChatThread
        let message: ChatMessage
        var id: String { thread.id.uuidString + message.id.uuidString }
    }
    private var saved: [SavedItem] {
        store.sortedThreads.flatMap { thread in thread.messages.filter { $0.isBookmarked == true }.map { SavedItem(thread: thread, message: $0) } }
    }
    var body: some View {
        Group {
            if saved.isEmpty {
                ContentUnavailableView("留住值得回看的话", systemImage: "bookmark", description: Text("长按一条消息，或点回答下方的收藏按钮。"))
            } else {
                ScrollView {
                    LazyVStack(alignment: .leading, spacing: 14) {
                        ForEach(saved) { item in
                            VStack(alignment: .leading, spacing: 12) {
                                Text(item.thread.title).font(.system(size: 11)).foregroundStyle(Palette.secondary)
                                Text(item.message.content).readingStyle(adjustment: -1).lineSpacing(5).lineLimit(7)
                                HStack {
                                    Button("打开对话") { openThread(item.thread.id) }
                                    Spacer()
                                    Button { store.toggleBookmark(threadID: item.thread.id, messageID: item.message.id) } label: {
                                        Image(systemName: "bookmark.slash")
                                    }.accessibilityLabel("取消收藏")
                                }.font(.system(size: 12)).foregroundStyle(Palette.secondary)
                            }.padding(18).background(Palette.surface, in: RoundedRectangle(cornerRadius: 22))
                        }
                    }.padding(20)
                }
            }
        }.background(Palette.paper).navigationTitle("收藏")
            .alert("暂时没有完成", isPresented: Binding(get: { store.errorMessage != nil }, set: { if !$0 { store.errorMessage = nil } })) {
                Button("知道了") { store.errorMessage = nil }
            } message: { Text(store.errorMessage ?? "") }
    }
}
