import SwiftUI
import UIKit
import PhotosUI
import UniformTypeIdentifiers

private func previewFlag(_ names: String...) -> Bool {
    names.contains { ProcessInfo.processInfo.arguments.contains("--preview-" + $0) }
}

@MainActor
struct ContentView: View {
    @EnvironmentObject private var store: AppStore
    @EnvironmentObject private var profile: ProfileStore
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    // Settings, projects and the full list open from the sidebar; there is no tab bar.
    @State private var showSettings = previewFlag("settings", "profile", "usage")
    @State private var showProjects = previewFlag("projects", "project")
    @State private var showAllChats = previewFlag("all-chats")
    @State private var showBooks = previewFlag("books")
    @State private var showSidebar = previewFlag("sidebar")
    @State private var keyboardVisible = false
    @State private var composerPanelHeight: CGFloat = 130
    @State private var sidebarDrag: CGFloat = 0
    @AppStorage("qingjian.haptics") private var hapticsEnabled = true

    var body: some View {
        GeometryReader { geometry in
            let width = min(geometry.size.width * 0.82, 360)
            let position = min(width, max(0, (showSidebar ? width : 0) + sidebarDrag))
            let progress = position / width
            let frontPage = PageContour(radius: Radius.pageFront * progress, topInset: geometry.safeAreaInsets.top, bottomInset: geometry.safeAreaInsets.bottom)
            let backPage = PageContour(radius: Radius.pageBack * progress, topInset: geometry.safeAreaInsets.top, bottomInset: geometry.safeAreaInsets.bottom)
            ZStack(alignment: .leading) {
                Ink.sheet.ignoresSafeArea()
                // Not built while closed, so it does not redraw with every streamed chunk.
                Group {
                    if progress > 0 || showSidebar {
                        HistorySidebar(close: { showSidebar = false },
                                       openSettings: { showSettings = true },
                                       openProjects: { showProjects = true },
                                       openAllChats: { showAllChats = true },
                                       openBooks: { showBooks = true })
                    } else { Color.clear }
                }
                .frame(width: width)
                .background(Ink.sheet.ignoresSafeArea())
                .clipShape(backPage)
                .overlay(backPage.stroke(Ink.line.opacity(progress), lineWidth: 0.5).allowsHitTesting(false))
                .offset(x: -width * 0.2 * (1 - progress))
                .opacity(min(1, progress * 3))
                .allowsHitTesting(showSidebar)
                .accessibilityHidden(!showSidebar)

                NavigationStack {
                    ChatScreen(openHistory: { showSidebar = true }, openSettings: { showSettings = true }, keyboardVisible: $keyboardVisible,
                               composerPanelHeight: $composerPanelHeight, bottomInset: geometry.safeAreaInsets.bottom)
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .scrollDisabled(sidebarDrag != 0)
                .tint(Ink.ink)
                .background(AppBackground())
                .overlay {
                    if progress > 0 {
                        Color.clear
                            .contentShape(Rectangle())
                            .onTapGesture { showSidebar = false }
                    }
                }
                .clipShape(frontPage)
                .background(frontPage.fill(Ink.paper)
                    .shadow(color: Color.black.opacity(0.16 * progress), radius: 24, x: -8)
                    .allowsHitTesting(false))
                .overlay(frontPage.stroke(Ink.line.opacity(progress), lineWidth: 0.6).allowsHitTesting(false))
                .offset(x: position)
                .accessibilityHidden(showSidebar)
            }
            .contentShape(Rectangle())
            .animation(reduceMotion ? nil : .snappy(duration: 0.28), value: showSidebar)
            .background(SidebarPan(enabled: true, isOpen: showSidebar,
                maximumStartY: geometry.frame(in: .global).maxY - composerPanelHeight - (keyboardVisible ? 0 : FloatingChrome.navigationHeight),
                changed: { distance in
                    sidebarDrag = showSidebar ? max(-width, min(0, distance)) : min(width, max(0, distance))
                }, ended: { distance, prediction in
                    let threshold = min(65, width * 0.18)
                    let open = showSidebar ? !(distance < -threshold || prediction < -width * 0.45) :
                        (distance > threshold || prediction > width * 0.45)
                    if open {
                        UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
                    }
                    withAnimation(reduceMotion ? nil : .snappy(duration: 0.28)) { showSidebar = open; sidebarDrag = 0 }
                }, cancelled: {
                    withAnimation(reduceMotion ? nil : .snappy(duration: 0.28)) { sidebarDrag = 0 }
                }))
        }
        .ignoresSafeArea(.keyboard, edges: .bottom)
        .onChange(of: showSidebar) { _, open in
            if hapticsEnabled { UIImpactFeedbackGenerator(style: .soft).impactOccurred(intensity: 0.65) }
            if open { store.refreshBalance() }
        }
        .sheet(isPresented: $showSettings) { SettingsView().environmentObject(store).environmentObject(profile) }
        .sheet(isPresented: $showProjects) {
            ProjectsView(opened: { showProjects = false; showSidebar = false }).environmentObject(store).environmentObject(profile)
        }
        .sheet(isPresented: $showBooks) {
            BookshelfView(opened: { showBooks = false; showSidebar = false }).environmentObject(store).environmentObject(store.books)
        }
        .sheet(isPresented: $showAllChats) {
            AllChatsView(opened: { showAllChats = false; showSidebar = false }).environmentObject(store).environmentObject(profile)
        }
        .onChange(of: profile.name) { _, name in store.userName = name }
        .onAppear {
            store.userName = profile.name
            if store.isPreview {
                let result = "QINGJIAN_SONGTI_LOADED=\(UIFont(name: "NotoSerifSC-Regular", size: 18) != nil)\n"
                FileHandle.standardOutput.write(Data(result.utf8))
            }
        }
    }

}

struct PendingImage: Identifiable {
    let id = UUID()
    let data: Data
    let preview: UIImage
}

private struct PendingSuggestedReply {
    let threadID: UUID
    let messageID: UUID
    let text: String
}

@MainActor
struct ChatScreen: View {
    @EnvironmentObject private var store: AppStore
    @EnvironmentObject private var profile: ProfileStore
    let openHistory: () -> Void
    let openSettings: () -> Void
    @Binding var keyboardVisible: Bool
    @Binding var composerPanelHeight: CGFloat
    let bottomInset: CGFloat
    @FocusState private var composerFocused: Bool
    @State private var previewComposerFocused = false
    private var isComposerFocused: Bool { composerFocused || previewComposerFocused }
    private var usesPreviewKeyboard: Bool { store.isPreview && ProcessInfo.processInfo.arguments.contains("--preview-tall-keyboard") }
    private func focusComposer(_ focused: Bool) {
        if usesPreviewKeyboard { previewComposerFocused = focused } else { composerFocused = focused }
    }
    @State private var editedMessage: ChatMessage?
    @State private var thinkingTarget: ThinkingTarget?
    @State private var pendingSuggestedReply: PendingSuggestedReply?
    @State private var followsOutput = true
    @State private var nearBottom = true
    @State private var importingText = false
    @State private var pickingPhotos = false
    @State private var photoSelection: [PhotosPickerItem] = []
    @State private var pendingImages: [PendingImage] = []
    @State private var loadingPhotos = false
    @State private var renaming = false
    @State private var renameText = ""
    @State private var exportURL: URL?
    private var isEmptyPage: Bool { store.activeThread?.messages.isEmpty != false }
    private var composerPlaceholder: String {
        guard let story = store.activeThread?.story else { return "与 Sermo 对话" }
        return "对\(story.character)说…"
    }
    private var hasInput: Bool {
        !store.activeDraft.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || !pendingImages.isEmpty
    }
    @State private var scrollPosition = ScrollPosition(edge: .top)
    @State private var visibleMessageCount = 100
    @State private var hasPositionedInitially = false
    private var visibleMessages: [ChatMessage] { Array((store.activeThread?.messages ?? []).suffix(visibleMessageCount)) }
    private var navigationSpace: CGFloat { 0 }
    // Read in body, so switching the look in Settings redraws this page.
    private var style: InterfaceStyle { InterfaceStyle.current }
    private var swiss: Bool { style == .swiss }

    private var draft: Binding<String> { Binding(get: { store.activeDraft }, set: { store.setDraft($0) }) }
    private var errorPresented: Binding<Bool> {
        Binding(get: { store.errorMessage != nil && editedMessage == nil },
                set: { if !$0 { store.errorMessage = nil } })
    }

    private var transcript: some View {
        Group {
            if isEmptyPage {
                VStack(spacing: 0) {
                    Spacer(minLength: 12)
                    WelcomeView(name: profile.name, page: store.activeThreadID ?? UUID(), projectName: store.activeProject?.name)
                        .id(store.activeThreadID)
                    Spacer(minLength: 12)
                }.padding(.bottom, composerPanelHeight)
            } else {
            ZStack(alignment: .bottom) {
            ScrollView {
                VStack(alignment: .leading, spacing: swiss ? 0 : 30) {
                    if swiss, let thread = store.activeThread {
                        SwissThreadHeader(title: thread.title, date: thread.createdAt,
                                          model: store.pillModelTitle + " / " + store.pillEffortTitle,
                                          rounds: thread.messages.filter { $0.role == .user }.count)
                            .padding(.top, 6)
                    }
                    if (store.activeThread?.messages.count ?? 0) > visibleMessageCount {
                        Button("查看更早消息") {
                            visibleMessageCount += 100
                            scrollPosition.scrollTo(edge: .top)
                        }.font(TypeScale.caption).foregroundStyle(Palette.secondary)
                            .frame(maxWidth: .infinity)
                    }
                    messageRows
                    Color.clear.frame(height: 2)
                }
                .scrollTargetLayout()
                .padding(.horizontal, swiss ? 20 : 24).padding(.top, 10).padding(.bottom, 22)
            }
            .accessibilityIdentifier("chat-scroll")
            // Text fades softly under the floating buttons instead of a solid band.
            .scrollEdgeEffectStyle(.soft, for: .top)
            .scrollPosition($scrollPosition)
            .contentMargins(.bottom, composerPanelHeight + bottomInset + 12, for: .scrollContent)
            .contentMargins(.bottom, composerPanelHeight + bottomInset + 12, for: .scrollIndicators)
            .scrollDismissesKeyboard(.interactively)
            .onAppear {
                if !hasPositionedInitially && !store.isPreview {
                    DispatchQueue.main.async { scrollPosition.scrollTo(edge: .bottom) }
                }
                hasPositionedInitially = true
            }
            .onScrollGeometryChange(for: Bool.self) { g in
                g.contentSize.height + g.contentInsets.bottom - g.contentOffset.y - g.containerSize.height < 80
            } action: { _, value in nearBottom = value }
            .onScrollPhaseChange { _, phase in
                if phase == .interacting { followsOutput = false }
                if phase == .idle && nearBottom { followsOutput = true }
            }
            .onChange(of: store.activeThread?.messages.count) { _, _ in
                if followsOutput { scrollPosition.scrollTo(edge: .bottom) }
            }
            .onChange(of: store.activeThread?.messages.last?.content) { _, _ in
                if followsOutput && store.generatingThreadID == store.activeThreadID {
                    scrollPosition.scrollTo(edge: .bottom)
                }
            }
            .onChange(of: store.activeThreadID) { _, _ in
                store.webSearchEnabled = false
                pendingSuggestedReply = nil
                visibleMessageCount = 100
                followsOutput = true
                DispatchQueue.main.async { scrollPosition.scrollTo(edge: .bottom) }
            }
            .onChange(of: store.activeThread?.messages.last?.replySuggestions) { _, _ in
                if followsOutput { scrollPosition.scrollTo(edge: .bottom) }
            }
            }
            .overlay(alignment: .bottomTrailing) {
                if !isComposerFocused && !nearBottom && store.activeThread?.messages.isEmpty == false {
                    GlassCircle(symbol: "arrow.down", label: "回到最新消息") {
                        followsOutput = true
                        withAnimation(.easeOut(duration: 0.2)) { scrollPosition.scrollTo(edge: .bottom) }
                    }.padding(.trailing, 22).padding(.bottom, 12)
                }
            }
            }
        }
    }

    var body: some View {
        KeyboardChatLayout {
            transcript.environmentObject(store).environmentObject(profile)
        } composer: {
            composer.fixedSize(horizontal: false, vertical: true)
                .environmentObject(store).environmentObject(profile)
        }
        .background(AppBackground())
        .navigationTitle("Sermo")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .topBarLeading) {
                Button { focusComposer(false); openHistory() } label: { SidebarGlyph() }
                    .accessibilityLabel("打开历史对话")
            }
            // Like the Claude app: no title in the bar, only the two glass controls.
            // In a conversation the right one holds new-page and a "⋯" menu with the title.
            ToolbarItemGroup(placement: .topBarTrailing) {
                // A new page stays in the project you are in.
                Button { store.createThread(in: store.activeThread?.projectID); followsOutput = true } label: { Image(systemName: "square.and.pencil") }
                    .accessibilityLabel("新建对话")
                if !isEmptyPage { titleMenu }
            }
        }
        .toolbarBackgroundVisibility(.hidden, for: .navigationBar)
        .alert("重命名对话", isPresented: $renaming) {
            TextField("对话名称", text: $renameText)
            Button("取消", role: .cancel) { }
            Button("保存") { if let id = store.activeThreadID { store.renameThread(id, title: renameText) } }
        }
        .sheet(isPresented: Binding(get: { exportURL != nil }, set: { if !$0 { exportURL = nil } })) {
            if let url = exportURL { ShareSheet(items: [url]) }
        }
        .onChange(of: isComposerFocused) { _, focused in
            keyboardVisible = focused
            if focused && followsOutput { scrollPosition.scrollTo(edge: .bottom) }
        }
        .onDisappear { keyboardVisible = false }
        .sheet(item: $editedMessage) { message in EditMessageView(message: message) }
        .sheet(item: $thinkingTarget) { target in ThinkingSheet(target: target).environmentObject(store) }
        // A Drive write the model asked for waits here; closing the sheet counts as "no".
        .sheet(item: Binding(get: { store.pendingApproval }, set: { if $0 == nil { store.resolveApproval(false) } })) { approval in
            ToolApprovalSheet(approval: approval) { store.resolveApproval($0) }
        }
        .alert("替换输入框里的文字？", isPresented: Binding(
            get: { pendingSuggestedReply != nil },
            set: { if !$0 { pendingSuggestedReply = nil } })) {
            Button("取消", role: .cancel) { pendingSuggestedReply = nil }
            Button("替换") {
                if let selection = pendingSuggestedReply { applySuggestedReply(selection) }
                pendingSuggestedReply = nil
            }
        } message: { Text("你已经写了些内容。替换后仍可以编辑，再自己发送。") }
        .photosPicker(isPresented: $pickingPhotos, selection: $photoSelection, maxSelectionCount: 4, matching: .images)
        .onChange(of: photoSelection) { _, items in
            guard !items.isEmpty else { return }
            photoSelection = []
            loadingPhotos = true
            Task {
                for item in items {
                    guard pendingImages.count < 4 else { break }
                    do {
                        guard let raw = try await item.loadTransferable(type: Data.self) else { continue }
                        let data = try await Task.detached { try ImageStore.prepared(raw) }.value
                        if let preview = UIImage(data: data) {
                            pendingImages.append(PendingImage(data: data, preview: preview))
                        }
                    } catch { store.errorMessage = "有一张图片没能读取，请换一张试试。" }
                }
                loadingPhotos = false
            }
        }
        .fileImporter(isPresented: $importingText, allowedContentTypes: [.plainText, .text]) { result in
            do {
                let url = try result.get()
                let scoped = url.startAccessingSecurityScopedResource()
                defer { if scoped { url.stopAccessingSecurityScopedResource() } }
                let size = try url.resourceValues(forKeys: [.fileSizeKey]).fileSize ?? 0
                guard size <= 1024 * 1024 else { throw ChatError.server("请选择小于 1 MB 的文字文件。") }
                let text = try String(contentsOf: url, encoding: .utf8)
                store.setDraft(store.activeDraft.isEmpty ? text : store.activeDraft + "\n\n" + text)
                focusComposer(true)
            } catch { store.errorMessage = error.localizedDescription }
        }
        .alert("暂时没有完成", isPresented: errorPresented) {
            Button("知道了") { store.errorMessage = nil }
        } message: { Text(store.errorMessage ?? "") }
        .task {
            if ProcessInfo.processInfo.arguments.contains("--preview-multiline-keyboard") {
                store.setDraft("第一行输入\n第二行输入\n第三行输入\n第四行输入\n第五行输入\n第六行输入")
            }
            if ProcessInfo.processInfo.arguments.contains("--preview-keyboard") || ProcessInfo.processInfo.arguments.contains("--preview-multiline-keyboard") {
                try? await Task.sleep(nanoseconds: 350_000_000)
                focusComposer(true)
            }
            if ProcessInfo.processInfo.arguments.contains("--preview-edit") {
                editedMessage = store.activeThread?.messages.last
            }
            if ProcessInfo.processInfo.arguments.contains(where: { $0.hasPrefix("--preview-reasoning") }),
               let threadID = store.activeThreadID, let last = store.activeThread?.messages.last {
                try? await Task.sleep(nanoseconds: 400_000_000)
                thinkingTarget = ThinkingTarget(threadID: threadID, messageID: last.id)
            }
        }
    }

    // Kept out of body so the compiler can type-check the page in reasonable time.
    private var messageRows: some View {
        let lastID = store.activeThread?.messages.last?.id, threadID = store.activeThreadID
        let rounds = Self.roundNumbers(store.activeThread?.messages ?? [])
        let look = self.style
        return ForEach(visibleMessages) { message in
            // Equatable: only the message that changed redraws while an answer streams.
            messageRow(message, threadID: threadID, isLast: message.id == lastID, round: rounds[message.id] ?? 1, style: look)
        }
    }

    /// Exchange numbers: each message of yours starts a new one, the answers after it share it.
    static func roundNumbers(_ messages: [ChatMessage]) -> [UUID: Int] {
        var result: [UUID: Int] = [:]
        var round = 0
        for message in messages {
            if message.role == .user { round += 1 }
            result[message.id] = max(round, 1)
        }
        return result
    }

    @ViewBuilder private func messageRow(_ message: ChatMessage, threadID: UUID?, isLast: Bool, round: Int, style: InterfaceStyle) -> some View {
        if message.state == .streaming {
            // The answer being written redraws on its own, without the rest of the page.
            LiveMessageRow(live: store.live, message: message, onGrow: followLiveText) { shown in
                messageBody(shown, threadID: threadID, isLast: isLast, round: round, style: style)
            }.id(message.id)
        } else {
            messageBody(message, threadID: threadID, isLast: isLast, round: round, style: style).id(message.id)
        }
    }

    private func messageBody(_ message: ChatMessage, threadID: UUID?, isLast: Bool, round: Int, style: InterfaceStyle) -> some View {
        MessageView(message: message, threadID: threadID, isLast: isLast,
                    isGenerating: store.isGenerating, canRegenerate: store.canChat,
                    showsSuggestions: store.settings.shouldSuggestReplies,
                    edit: { focusComposer(false); editedMessage = message },
                    regenerate: { store.regenerate() },
                    openThinking: { if let threadID { thinkingTarget = ThinkingTarget(threadID: threadID, messageID: message.id) } },
                    useSuggestedReply: { text in prepareSuggestedReply(text, messageID: message.id) },
                    signInDrive: { store.drive.signIn() }, round: round, style: style)
            .equatable()
    }

    private func followLiveText() {
        if followsOutput && store.generatingThreadID == store.activeThreadID {
            scrollPosition.scrollTo(edge: .bottom)
        }
    }

    private func prepareSuggestedReply(_ text: String, messageID: UUID) {
        guard let threadID = store.activeThreadID else { return }
        let selection = PendingSuggestedReply(threadID: threadID, messageID: messageID, text: text)
        if !store.activeDraft.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty && store.activeDraft != text {
            pendingSuggestedReply = selection
        } else { applySuggestedReply(selection) }
    }

    private func applySuggestedReply(_ selection: PendingSuggestedReply) {
        if store.useReplySuggestion(selection.text, threadID: selection.threadID, messageID: selection.messageID) {
            followsOutput = true
            focusComposer(true)
        }
    }

    // "⋯" for the open conversation. Its title (and project) head the menu.
    // A folder button while the page has no project, the project's name once it has
    // one. Locked projects ask for Face ID first. The pick is remembered for new chats.
    private var projectPill: some View {
        let current = store.activeProject
        let radius: CGFloat = swiss ? 0 : 19
        let strokeWidth: CGFloat = swiss ? 1 : (current == nil ? 0.8 : 0)
        return Menu {
            Picker("项目", selection: Binding(get: { store.activeThread?.projectID }, set: { chooseProject($0) })) {
                Label("无项目", systemImage: "bubble.left").tag(UUID?.none)
                ForEach(store.projects) { project in
                    Label(project.name, systemImage: project.isLocked ? "lock" : "folder").tag(Optional(project.id))
                }
            }
        } label: {
            HStack(spacing: 5) {
                Image(systemName: current == nil ? "folder" : "folder.fill").font(.system(size: 14))
                if let name = current?.name {
                    Text(name).lineLimit(1).frame(maxWidth: 84, alignment: .leading)
                }
            }
            .font(swiss ? TypeScale.mono(11) : TypeScale.serif(14))
            .foregroundStyle(current == nil ? Ink.ink3 : Ink.ink)
            .padding(.horizontal, current == nil ? 0 : 12)
            .frame(minWidth: 38, minHeight: 38)
            .background(current == nil ? Color.clear : Ink.raised,
                        in: RoundedRectangle(cornerRadius: radius, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: radius, style: .continuous)
                .stroke(swiss ? Ink.ink : Ink.line, lineWidth: strokeWidth))
            .contentShape(Rectangle())
        }
        .disabled(!store.canPersist)
        .accessibilityLabel("选择项目")
        .accessibilityValue(current?.name ?? "无项目")
        .accessibilityIdentifier("project-pill")
    }

    private func chooseProject(_ id: UUID?) {
        guard let id, store.isLocked(id) else { store.chooseProjectForNewChat(id); return }
        Task { if await ProjectLock.open(id, store: store) { store.chooseProjectForNewChat(id) } }
    }

    private var titleMenu: some View {
        Menu {
            if let thread = store.activeThread {
                Text(store.activeProject.map { thread.title + " · " + $0.name } ?? thread.title)
                if let story = thread.story {
                    Text("书架 ·《\(story.bookTitle)》" + (story.userRole.isEmpty ? "" : " · 你是\(story.userRole)"))
                }
                Divider()
                Button("重命名", systemImage: "pencil") { renameText = thread.title; renaming = true }
                Button(thread.isPinned == true ? "取消置顶" : "置顶", systemImage: "pin") { store.togglePinned(thread.id) }
                Menu("移到项目", systemImage: "folder") {
                    ForEach(store.projects.filter { !store.isLocked($0.id) }) { project in
                        Button(project.name) { store.moveThreads([thread.id], to: project.id) }
                            .disabled(project.id == thread.projectID)
                    }
                    if thread.projectID != nil {
                        Button("移出项目", systemImage: "tray.and.arrow.up") { store.moveThreads([thread.id], to: nil) }
                    }
                }.disabled(store.projects.isEmpty && thread.projectID == nil)
                Button("导出为 Markdown", systemImage: "square.and.arrow.up") {
                    exportURL = store.exportConversation(thread.id, userName: profile.name)
                }
            }
        } label: {
            Image(systemName: "ellipsis")
        }
        .accessibilityLabel("对话选项")
        .accessibilityIdentifier("chat-title-menu")
    }

    // The model pill: a capsule on paper, a plain monospaced FLASH / HIGH ▾ in the Swiss look.
    @ViewBuilder private var modelPillLabel: some View {
        if swiss {
            Text((store.pillModelTitle + " / " + store.pillEffortTitle).uppercased() + " ▾")
                .font(TypeScale.mono(11)).foregroundStyle(Ink.ink).lineLimit(1)
                .frame(height: 38).contentShape(Rectangle())
        } else {
            HStack(spacing: 6) {
                Text(store.pillModelTitle).foregroundStyle(Ink.ink).lineLimit(1)
                Text(store.pillEffortTitle).foregroundStyle(Ink.ink3)
            }
            .font(TypeScale.serif(14)).monospacedDigit()
            .padding(.horizontal, 14).frame(height: 38)
            .background(Ink.raised, in: Capsule())
            .contentShape(Capsule())
        }
    }

    // The web switch: a globe that grows into a 联网 pill, or WEB: ON / OFF in the Swiss look.
    @ViewBuilder private var webToggleLabel: some View {
        if swiss {
            Text(store.webSearchEnabled ? "WEB: ON" : "WEB: OFF")
                .font(TypeScale.mono(11))
                .foregroundStyle(store.webSearchEnabled ? Ink.seal : Ink.ink3)
                .frame(minWidth: 38, minHeight: 38).contentShape(Rectangle())
        } else {
            HStack(spacing: 5) {
                Image(systemName: "globe")
                if store.webSearchEnabled { Text("联网").font(TypeScale.serif(14)) }
            }
            .foregroundStyle(store.webSearchEnabled ? Ink.ink : Ink.ink3)
            .padding(.horizontal, store.webSearchEnabled ? 12 : 0)
            .frame(minWidth: 38, minHeight: 38)
            .background(store.webSearchEnabled ? Ink.raised : Color.clear, in: Capsule())
            .contentShape(Capsule())
        }
    }

    private var composer: some View {
        VStack(spacing: 8) {
            if store.searchingThreadID == store.activeThreadID && store.isGenerating {
                HStack { ProgressView(); Text("正在联网搜索…").font(TypeScale.caption) }
                    .accessibilityIdentifier("web-search-progress")
            }

            if !store.canChat {
                Button { focusComposer(false); openSettings() } label: {
                    Label(store.activeProvider == .chatGPT ? "在设置里登录 ChatGPT 订阅，就能用这个项目" : "在设置里填好 DeepSeek API Key，就能开始聊天",
                          systemImage: store.activeProvider == .chatGPT ? "person.crop.circle" : "key")
                        .font(TypeScale.caption).foregroundStyle(Ink.ink3)
                }.padding(.bottom, 2)
            }
            VStack(alignment: .leading, spacing: 14) {
                if !pendingImages.isEmpty || loadingPhotos {
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 10) {
                            ForEach(pendingImages) { item in
                                Image(uiImage: item.preview).resizable().scaledToFill()
                                    .frame(width: 64, height: 64)
                                    .clipShape(RoundedRectangle(cornerRadius: swiss ? 0 : 12, style: .continuous))
                                    .overlay(alignment: .topTrailing) {
                                        Button { pendingImages.removeAll { $0.id == item.id } } label: {
                                            Image(systemName: "xmark").font(.system(size: 9, weight: .bold))
                                                .foregroundStyle(Ink.onSolid)
                                                .frame(width: 20, height: 20).background(Ink.solid, in: Circle())
                                                .padding(3).contentShape(Rectangle())
                                        }.buttonStyle(.plain).accessibilityLabel("移除这张图片")
                                    }
                            }
                            if loadingPhotos { ProgressView().frame(width: 64, height: 64) }
                        }
                    }
                }
                Group {
                    if usesPreviewKeyboard {
                        PreviewKeyboardField(text: draft, isFocused: previewComposerFocused, focusChanged: { previewComposerFocused = $0 })
                    } else {
                        TextField(composerPlaceholder, text: draft, axis: .vertical)
                            .readingStyle(adjustment: -1).lineLimit(1...5)
                            .focused($composerFocused).tint(Ink.ink)
                    }
                }
                    .disabled(!store.canPersist)
                    .accessibilityIdentifier("chat-composer")
                HStack(spacing: 10) {
                    Menu {
                        Button("从相册选图片", systemImage: "photo") { focusComposer(false); pickingPhotos = true }
                        Button("导入文字文件", systemImage: "doc.text") { importingText = true }
                        Button("粘贴文字", systemImage: "doc.on.clipboard") {
                            if let text = UIPasteboard.general.string { store.setDraft(store.activeDraft + text) }
                        }
                    } label: {
                        Image(systemName: "plus").font(.system(size: 16, weight: swiss ? .medium : .regular)).foregroundStyle(Ink.ink)
                            .frame(width: 38, height: 38)
                            .overlay(RoundedRectangle(cornerRadius: swiss ? 0 : 19, style: .continuous)
                                .stroke(swiss ? Ink.ink : Ink.line, lineWidth: swiss ? 1 : 0.8))
                            .contentShape(Rectangle())
                    }
                    .accessibilityLabel("更多输入操作")
                    // Before the first message a page can still pick its project here.
                    if store.canChooseProject { projectPill }
                    // Model and thinking level in one pill, like "Haiku 5.5 中等" in the Claude app.
                    Menu {
                        if store.activeProvider == .chatGPT {
                            Section("ChatGPT 订阅") {
                                Picker("模型", selection: Binding(get: { store.settings.subscriptionModel }, set: { store.setSubscriptionModel($0) })) {
                                    if !store.subscription.models.contains(where: { $0.slug == store.settings.subscriptionModel }) {
                                        Text(store.settings.subscriptionModel).tag(store.settings.subscriptionModel)
                                    }
                                    ForEach(store.subscription.models) { model in Text(model.displayName).tag(model.slug) }
                                }
                            }
                            Section("思考") {
                                Picker("思考", selection: Binding(get: { store.settings.selectedSubscriptionEffort }, set: { store.setSubscriptionEffort($0) })) {
                                    ForEach(SubscriptionEffort.allCases) { effort in Text(effort.title).tag(effort) }
                                }
                            }
                        } else {
                        Section("模型") {
                            Picker("模型", selection: Binding(get: { store.settings.model }, set: { store.setModel($0) })) {
                                ForEach(DeepSeekModel.allCases) { model in Text(model.title).tag(model) }
                            }
                        }
                        Section("思考") {
                            Picker("思考", selection: Binding(get: { store.settings.thinkingEnabled ? store.settings.effort.rawValue : "off" },
                                                            set: { value in
                                if let effort = ThinkingEffort(rawValue: value) { store.setThinkingEffort(effort) }
                                else if store.settings.thinkingEnabled { store.toggleThinking() }
                            })) {
                                Text("Off").tag("off")
                                ForEach(ThinkingEffort.allCases) { effort in Text(effort.title).tag(effort.rawValue) }
                            }
                        }
                        }
                    } label: {
                        modelPillLabel
                    }
                    .accessibilityLabel("选择模型和思考档位")
                    .accessibilityValue("\(store.pillModelTitle) \(store.pillEffortTitle)")
                    .accessibilityIdentifier("model-effort-pill")
                    if store.activeProvider == .deepSeek {
                        // On, the button itself says so; no hint line over the conversation.
                        Button { store.webSearchEnabled.toggle() } label: {
                            webToggleLabel
                        }
                        .disabled(store.isGenerating)
                        .accessibilityLabel("联网搜索")
                        .accessibilityValue(store.webSearchEnabled ? "已开启" : "已关闭")
                        .accessibilityIdentifier("web-search-toggle")
                    }

                    Spacer(minLength: 0)
                    Button {
                        if store.isGenerating { store.stopGeneration() }
                        else {
                            followsOutput = true
                            if store.send(store.activeDraft, images: pendingImages.map(\.data)) {
                                pendingImages = []
                                focusComposer(false)
                            }
                        }
                    } label: {
                        Image(systemName: store.isGenerating ? "stop.fill" : "arrow.up")
                            .font(.system(size: 15, weight: .bold)).foregroundStyle(Ink.sendGlyph)
                            .frame(width: 38, height: 38)
                            .background(Ink.sendFill, in: RoundedRectangle(cornerRadius: swiss ? 0 : 19, style: .continuous))
                            .contentShape(Rectangle())
                    }
                    .buttonStyle(.plain)
                    .disabled(!store.isGenerating && (!store.canChat || !hasInput || !store.canPersist))
                    .opacity(!store.isGenerating && !hasInput ? 0.35 : 1)
                    .accessibilityLabel(store.isGenerating ? "停止生成" : "发送消息")
                }
            }
            .padding(.horizontal, 14).padding(.top, swiss ? 14 : 16).padding(.bottom, swiss ? 10 : 12)
            .clearGlass(radius: 28)
            if store.isGenerating && store.generatingThreadID != store.activeThreadID {
                Text("另一个对话正在生成，右侧按钮可停止。")
                    .font(TypeScale.tiny).foregroundStyle(Ink.ink3)
            }
        }
        .padding(.horizontal, 14).padding(.top, 8).padding(.bottom, 10)
        .accessibilityElement(children: .contain).accessibilityIdentifier("chat-composer-panel")
        .onGeometryChange(for: CGFloat.self) { $0.size.height } action: { composerPanelHeight = $0 }
    }
}

// Holds no store: everything it shows comes in as values, so with .equatable()
// only the message that changed redraws while an answer streams.
@MainActor
struct MessageView: View, Equatable {
    @AppStorage("qingjian.reading.aiBubble") private var aiBubble = false
    let message: ChatMessage
    let threadID: UUID?
    let isLast: Bool
    let isGenerating: Bool
    let canRegenerate: Bool
    let showsSuggestions: Bool
    let edit: () -> Void
    let regenerate: () -> Void
    let openThinking: () -> Void
    let useSuggestedReply: (String) -> Void
    var signInDrive: () -> Void = {}
    // Which exchange this is (Q.01 / A.01 in the Swiss look) and the look itself,
    // part of equality so a style switch redraws rows the stream would skip.
    var round = 1
    var style: InterfaceStyle = .paper
    @State private var copied = false
    @State private var selecting = false

    nonisolated static func == (lhs: MessageView, rhs: MessageView) -> Bool {
        lhs.message == rhs.message && lhs.threadID == rhs.threadID && lhs.isLast == rhs.isLast
            && lhs.isGenerating == rhs.isGenerating && lhs.canRegenerate == rhs.canRegenerate
            && lhs.showsSuggestions == rhs.showsSuggestions && lhs.round == rhs.round && lhs.style == rhs.style
    }

    var body: some View {
        Group {
            if let label = message.directive {
                // A request the app sent on your behalf: a quiet marker instead of a message.
                Text("— \(label) —").font(TypeScale.caption).foregroundStyle(Ink.ink3)
                    .frame(maxWidth: .infinity, alignment: .center).padding(.vertical, 6)
                    .accessibilityLabel(label)
            } else if style == .swiss { swissContent } else { paperContent }
        }
        .contextMenu {
            Button("复制", systemImage: "doc.on.doc") { UIPasteboard.general.string = message.content }
            // Answers draw their highlights with a custom renderer, which inline text
            // selection would bypass; selecting part of an answer happens in a sheet.
            Button("选择文字", systemImage: "selection.pin.in.out") { selecting = true }
            Button("编辑文字", systemImage: "pencil") { edit() }.disabled(isGenerating)
            if isLast && message.role == .assistant {
                Button("重新生成", systemImage: "arrow.clockwise") { regenerate() }
                    .disabled(isGenerating || !canRegenerate)
            }
        }
        .sheet(isPresented: $selecting) { SelectableTextSheet(text: message.content) }
    }

    // 纸笺: one column; your note set off by a thin rule, the answer as plain text.
    private var paperContent: some View {
        VStack(alignment: .leading, spacing: 12) {
            if message.role == .user {
                // Your side of the talk reads down the same left edge as the
                // answer: a note set off by a thin rounded rule, a step quieter
                // than the answer below it, so the page reads as one column.
                VStack(alignment: .leading, spacing: 8) {
                    if let names = message.images, !names.isEmpty { AttachmentRow(names: names) }
                    Text(message.content).readingStyle(adjustment: -1).lineSpacing(5).textSelection(.enabled)
                        .foregroundStyle(Ink.ink2)
                    Text(MessageTime.label(message.createdAt)).font(TypeScale.serif(11)).monospacedDigit().foregroundStyle(Ink.ink3)
                }
                .padding(.leading, 14)
                .overlay(alignment: .leading) {
                    Capsule().fill(Ink.ink3.opacity(0.45)).frame(width: 2.5)
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.trailing, 28)
            } else {
                answerParts
                if message.state == .streaming {
                    StreamActivityView(message: message)
                } else {
                    HStack(spacing: 22) {
                        Button {
                            UIPasteboard.general.string = message.content; copied = true
                        } label: { Image(systemName: copied ? "checkmark" : "doc.on.doc") }
                            .accessibilityLabel("复制回答")
                        Button { edit() } label: { Image(systemName: "pencil") }
                            .disabled(isGenerating).accessibilityLabel("编辑回答")
                        if isLast {
                            Button { regenerate() } label: { Image(systemName: "arrow.clockwise") }
                                .disabled(isGenerating || !canRegenerate).accessibilityLabel("重新生成")
                        }
                        Spacer(minLength: 4)
                        Text(MessageTime.label(message.createdAt)).font(TypeScale.serif(11)).monospacedDigit()
                        if let usage = message.usage {
                            Text(usageLabel(usage)).font(TypeScale.serif(11)).monospacedDigit()
                                .accessibilityLabel("本次请求共 \(usage.totalTokens) 个 Token")
                        }
                    }.font(.system(size: 13)).foregroundStyle(Ink.ink3).buttonStyle(.plain).padding(.top, 2)
                }
            }
            trailingParts
        }
    }

    // 瑞士: a ruled grid. A narrow column of numbers (Q.01, A.01) on the left,
    // the text on the right, a rule between exchanges, small monospaced controls.
    private var swissContent: some View {
        VStack(alignment: .leading, spacing: 0) {
            if message.role == .user {
                if round > 1 { SwissRule(weight: 1, strong: true) }
                HStack(alignment: .firstTextBaseline, spacing: 0) {
                    MonoLabel(text: String(format: "Q.%02d", round)).frame(width: 46, alignment: .leading)
                    VStack(alignment: .leading, spacing: 8) {
                        if let names = message.images, !names.isEmpty { AttachmentRow(names: names) }
                        Text(message.content).readingStyle(adjustment: -2).fontWeight(.medium).lineSpacing(5)
                            .textSelection(.enabled).foregroundStyle(Ink.ink)
                        MonoLabel(text: MessageTime.label(message.createdAt))
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                }
                .padding(.vertical, 16)
                SwissRule()
            } else {
                HStack(alignment: .firstTextBaseline, spacing: 0) {
                    MonoLabel(text: String(format: "A.%02d", round), color: Ink.seal).frame(width: 46, alignment: .leading)
                    VStack(alignment: .leading, spacing: 12) {
                        answerParts
                        if message.state == .streaming {
                            StreamActivityView(message: message)
                        } else {
                            swissActions
                        }
                        trailingParts
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                }
                .padding(.top, 16).padding(.bottom, 22)
            }
        }
    }

    private var swissActions: some View {
        VStack(alignment: .leading, spacing: 4) {
            HStack(spacing: 18) {
                Button {
                    UIPasteboard.general.string = message.content; copied = true
                } label: { MonoLabel(text: copied ? "COPIED" : "COPY", color: Ink.ink).frame(minHeight: 32) }
                    .accessibilityLabel("复制回答")
                Button { edit() } label: { MonoLabel(text: "EDIT", color: Ink.ink).frame(minHeight: 32) }
                    .disabled(isGenerating).accessibilityLabel("编辑回答")
                if isLast {
                    Button { regenerate() } label: { MonoLabel(text: "RETRY", color: Ink.ink).frame(minHeight: 32) }
                        .disabled(isGenerating || !canRegenerate).accessibilityLabel("重新生成")
                }
                Spacer(minLength: 4)
                MonoLabel(text: MessageTime.label(message.createdAt), size: 10)
            }
            if let usage = message.usage {
                MonoLabel(text: usageLabel(usage), size: 10)
                    .accessibilityLabel("本次请求共 \(usage.totalTokens) 个 Token")
            }
        }
        .buttonStyle(.plain)
    }

    // Thinking, tool calls and the answer text: the same in both looks.
    @ViewBuilder private var answerParts: some View {
        if !message.reasoning.isEmpty {
            ThinkingRow(message: message, open: openThinking)
        }
        if let tools = message.toolActivity, !tools.isEmpty {
            ToolActivityList(items: tools, signIn: signInDrive)
        }
        if !message.content.isEmpty {
            let bubble = aiBubble && style == .paper
            MarkdownAnswer(content: message.content, style: style).equatable()
                .padding(bubble ? 16 : 0)
                .background(bubble ? Ink.raised : .clear, in: RoundedRectangle(cornerRadius: 20, style: .continuous))
        }
    }

    // Sources, notes and reply suggestions under an answer.
    @ViewBuilder private var trailingParts: some View {
        if let sources = message.webSources, !sources.isEmpty {
            DisclosureGroup("联网来源（\(sources.count)）") {
                VStack(alignment: .leading, spacing: 10) {
                    ForEach(Array(sources.enumerated()), id: \.element.id) { index, source in
                        if let url = URL(string: source.url) {
                            Link("[\(index + 1)] \(source.title)", destination: url)
                                .font(TypeScale.caption)
                        }
                    }
                    if let usage = message.searchUsage {
                        Text("搜索 \(usage.totalTokens) Tokens；搜索费用以服务商账单为准，未计入聊天金额估算。")
                            .font(TypeScale.tiny).foregroundStyle(Ink.ink3)
                    }
                }.frame(maxWidth: .infinity, alignment: .leading).padding(.top, 8)
            }.font(TypeScale.caption).accessibilityIdentifier("web-search-sources")
        }
        if let note = message.note {
            Text(note).font(TypeScale.tiny).foregroundStyle(Ink.ink3)
                .frame(maxWidth: .infinity, alignment: .leading)
        }
        if isLast, message.role == .assistant, message.state == .complete, showsSuggestions, let threadID {
            ReplySuggestionPanel(message: message, threadID: threadID, use: useSuggestedReply)
        }
    }

    // Tokens come from the server; the price is our estimate from the official list.
    // The ChatGPT plan has no price per answer, so it shows tokens and the plan.
    private func usageLabel(_ usage: TokenUsage) -> String {
        let tokens = "\(usage.totalTokens.formatted()) Tokens"
        if message.isSubscription { return tokens + " · 订阅额度" }
        guard let model = message.model else { return tokens }
        return tokens + " · " + Pricing.label(Pricing.cost(model: model, usage: usage, at: message.createdAt))
    }
}

// Reads like a short table of contents under the answer: number, line, hairline.
// Only the last answer has one, so its store updates touch nothing else.
@MainActor
struct ReplySuggestionPanel: View {
    @EnvironmentObject private var store: AppStore
    let message: ChatMessage
    let threadID: UUID
    let use: (String) -> Void

    var body: some View {
        // The Swiss look: a monospaced header, numbers in the accent, ruled top and bottom.
        let swiss = InterfaceStyle.isSwiss
        VStack(alignment: .leading, spacing: 0) {
            if swiss {
                MonoLabel(text: "猜你回复 / REPLIES").padding(.bottom, 6)
                SwissRule(strong: true)
            } else {
                Text("猜你回复").font(TypeScale.caption).foregroundStyle(Ink.ink3).padding(.bottom, 4)
            }
            if let batch = message.replySuggestions {
                ForEach(Array(batch.replies.prefix(3).enumerated()), id: \.offset) { index, reply in
                    Button { use(reply) } label: {
                        HStack(alignment: .firstTextBaseline, spacing: 12) {
                            Text(String(format: "%02d", index + 1))
                                .font(swiss ? TypeScale.mono(11) : TypeScale.serif(11)).monospacedDigit()
                                .foregroundStyle(swiss ? Ink.seal : Ink.ink3)
                            Text(reply).font(TypeScale.serif(15)).foregroundStyle(swiss ? Ink.ink : Ink.ink2)
                                .multilineTextAlignment(.leading)
                                .frame(maxWidth: .infinity, alignment: .leading)
                        }
                        .padding(.vertical, 12)
                        .contentShape(Rectangle())
                        .overlay(alignment: .bottom) {
                            if swiss { SwissRule() } else if index < min(batch.replies.count, 3) - 1 { InkRule() }
                        }
                    }
                    .buttonStyle(.plain).disabled(store.isGenerating)
                    .accessibilityLabel("使用回复建议 \(index + 1)：\(reply)")
                    .accessibilityIdentifier("reply-suggestion-\(index)")
                }
                if let usage = batch.usage {
                    Text("建议 \(usage.totalTokens.formatted()) Tokens · " + suggestionCost(batch, usage))
                        .font(TypeScale.serif(10)).monospacedDigit().foregroundStyle(Ink.ink3).padding(.top, 2)
                }
            } else if store.isSuggesting(threadID: threadID, messageID: message.id) {
                HStack(spacing: 8) {
                    PulseDot(size: 7)
                    Text("正在想几种回复…").font(TypeScale.caption).foregroundStyle(Ink.ink3)
                }.padding(.vertical, 8).accessibilityIdentifier("reply-suggestions-loading")
            } else {
                if let error = store.suggestionError(threadID: threadID, messageID: message.id) {
                    Text(error).font(TypeScale.tiny).foregroundStyle(Ink.ink3)
                }
                Button("生成回复建议") { store.generateReplySuggestions(threadID: threadID, messageID: message.id) }
                    .font(TypeScale.caption).foregroundStyle(Ink.ink2).buttonStyle(.plain).disabled(store.isGenerating)
                    .padding(.vertical, 8)
            }
        }
        .padding(.top, 10)
        // Without .contain the panel's identifier would replace each suggestion button's own.
        .accessibilityElement(children: .contain)
        .accessibilityIdentifier("reply-suggestions-panel")
    }

    private func suggestionCost(_ batch: ReplySuggestionBatch, _ usage: TokenUsage) -> String {
        batch.provider == .chatGPT ? "订阅额度" : Pricing.label(Pricing.cost(model: batch.pricedModel, usage: usage, at: batch.createdAt))
    }
}

struct AttachmentRow: View {
    let names: [String]
    private var side: CGFloat { names.count == 1 ? 168 : (names.count == 2 ? 120 : 76) }
    var body: some View {
        HStack(spacing: 8) {
            ForEach(names, id: \.self) { name in
                Group {
                    if let image = ImageStore.thumbnail(named: name) {
                        Image(uiImage: image).resizable().scaledToFill().accessibilityLabel("附带的图片")
                    } else {
                        Ink.raised.overlay(Image(systemName: "photo").foregroundStyle(Ink.ink3))
                            .accessibilityLabel("图片文件已不在这台手机上")
                    }
                }
                .frame(width: side, height: side)
                .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
            }
        }
    }
}

// Equatable so finished answers are not re-parsed while a new one streams in.
// Paragraphs are Equatable too: while text arrives only the last one is parsed again.
struct MarkdownAnswer: View, Equatable {
    let content: String
    var style: InterfaceStyle = .paper
    nonisolated static func == (lhs: MarkdownAnswer, rhs: MarkdownAnswer) -> Bool { lhs.content == rhs.content && lhs.style == rhs.style }
    private var swiss: Bool { style == .swiss }
    // Paragraphs, headings, lists, quotes, dividers and code, each text block told
    // how many of the answer's highlighter marks it may still draw.
    private var blocks: [MarkdownBlock] { MarkdownBlock.parse(content) }
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            ForEach(Array(blocks.enumerated()), id: \.offset) { _, block in
                switch block {
                case .paragraph(let text, let marks):
                    MarkdownParagraph(text: text, marks: marks, style: style).equatable()
                case .heading(let text, let level):
                    Text(Self.inline(text)).readingStyle(adjustment: level <= 2 ? 2 : 1, heavy: true)
                        .foregroundStyle(Ink.ink).padding(.top, 6)
                case .list(let items):
                    VStack(alignment: .leading, spacing: 8) {
                        ForEach(Array(items.enumerated()), id: \.offset) { _, item in
                            HStack(alignment: .firstTextBaseline, spacing: 8) {
                                if swiss {
                                    // Bullets become dashes, numbers go monospaced, both in the accent.
                                    Text(item.marker == "•" ? "—" : item.marker == "◦" ? "–" : item.marker)
                                        .font(TypeScale.mono(13)).foregroundStyle(Ink.seal)
                                        .frame(minWidth: 24, alignment: .leading)
                                } else {
                                    Text(item.marker).readingStyle().monospacedDigit().foregroundStyle(Ink.ink3)
                                        .frame(minWidth: item.marker.count > 1 ? 22 : 12, alignment: .leading)
                                }
                                MarkdownParagraph(text: item.text, marks: item.marks, style: style).equatable()
                            }
                            .padding(.leading, CGFloat(item.level) * 20)
                        }
                    }
                case .quote(let text, let marks):
                    MarkdownParagraph(text: text, marks: marks, style: style).equatable()
                        .opacity(0.85)
                        .padding(.leading, 14)
                        .overlay(alignment: .leading) {
                            RoundedRectangle(cornerRadius: swiss ? 0 : 1.25, style: .continuous)
                                .fill(swiss ? Ink.ink : Ink.ink3.opacity(0.45)).frame(width: swiss ? 3 : 2.5)
                        }
                case .table(let header, let rows, let alignments):
                    // Wide tables scroll sideways inside the answer instead of squeezing.
                    ScrollView(.horizontal, showsIndicators: false) {
                        Grid(alignment: .leading, horizontalSpacing: 0, verticalSpacing: 0) {
                            GridRow {
                                ForEach(Array(header.enumerated()), id: \.offset) { column, cell in
                                    TableCell(text: cell, header: true, alignment: alignments[min(column, alignments.count - 1)])
                                }
                            }
                            ForEach(Array(rows.enumerated()), id: \.offset) { _, row in
                                GridRow {
                                    ForEach(Array(row.enumerated()), id: \.offset) { column, cell in
                                        TableCell(text: cell, header: false, alignment: alignments[min(column, alignments.count - 1)])
                                    }
                                }
                            }
                        }
                        .overlay(RoundedRectangle(cornerRadius: swiss ? 0 : 12, style: .continuous)
                            .stroke(swiss ? Ink.ink : Ink.line, lineWidth: 1))
                        .clipShape(RoundedRectangle(cornerRadius: swiss ? 0 : 12, style: .continuous))
                    }
                case .divider:
                    Rectangle().fill(swiss ? Ink.ink : Ink.line).frame(height: 1).padding(.vertical, 4)
                case .code(let segment):
                    VStack(alignment: .leading, spacing: 8) {
                        HStack {
                            Text(swiss ? "CODE" : "代码").font(swiss ? TypeScale.mono(10) : TypeScale.tiny).foregroundStyle(Ink.ink3)
                            Spacer()
                            Button { UIPasteboard.general.string = Self.codeBody(segment) } label: { Image(systemName: "doc.on.doc") }
                                .font(.system(size: 11)).accessibilityLabel("复制代码")
                        }
                        ScrollView(.horizontal) {
                            Text(Self.codeBody(segment)).font(.system(size: 13, design: .monospaced)).textSelection(.enabled)
                        }
                    }.padding(14).background(Ink.raised, in: RoundedRectangle(cornerRadius: swiss ? 0 : 16, style: .continuous))
                        .overlay(Rectangle().stroke(swiss ? Ink.line : Color.clear, lineWidth: 1).allowsHitTesting(false))
                }
            }
        }.frame(maxWidth: .infinity, alignment: .leading)
    }
    private static func inline(_ text: String) -> AttributedString {
        (try? AttributedString(markdown: text, options: .init(interpretedSyntax: .inlineOnlyPreservingWhitespace))) ?? AttributedString(text)
    }
    private static func codeBody(_ segment: String) -> String {
        guard let newline = segment.firstIndex(of: "\n") else { return segment }
        let first = segment[..<newline].trimmingCharacters(in: .whitespaces)
        return first.isEmpty || (!first.contains(" ") && first.count < 24) ? String(segment[segment.index(after: newline)...]) : segment
    }
}

// One table cell: inline Markdown, wrapped past a comfortable width, a hairline below.
struct TableCell: View {
    let text: String
    let header: Bool
    let alignment: TableAlignment
    private var frameAlignment: Alignment {
        switch alignment {
        case .leading: return .leading
        case .center: return .center
        case .trailing: return .trailing
        }
    }
    var body: some View {
        Text((try? AttributedString(markdown: text, options: .init(interpretedSyntax: .inlineOnlyPreservingWhitespace))) ?? AttributedString(text))
            .readingStyle(adjustment: -2, heavy: header)
            .foregroundStyle(header ? Ink.ink : Ink.ink2)
            .multilineTextAlignment(alignment == .center ? .center : alignment == .trailing ? .trailing : .leading)
            .frame(minWidth: 56, maxWidth: 240, alignment: frameAlignment)
            .padding(.horizontal, 12).padding(.vertical, 9)
            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: frameAlignment)
            .background(header ? Ink.raised : Color.clear)
            .overlay(alignment: .bottom) { Rectangle().fill(Ink.line).frame(height: 0.5) }
    }
}

struct MarkdownParagraph: View, Equatable {
    @AppStorage(HighlightStyle.key) private var highlightHex = ""
    @Environment(\.colorScheme) private var colorScheme
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var sweep = 1.0
    let text: String
    /// How many bold phrases here are drawn as highlighter marks; the rest stay bold.
    var marks = HighlightMarks.perAnswer
    /// The Swiss look draws bold in the accent colour instead of a highlighter.
    var style: InterfaceStyle = .paper
    nonisolated static func == (lhs: MarkdownParagraph, rhs: MarkdownParagraph) -> Bool {
        lhs.text == rhs.text && lhs.marks == rhs.marks && lhs.style == rhs.style
    }
    private var parsed: AttributedString {
        (try? AttributedString(markdown: text, options: .init(interpretedSyntax: .inlineOnlyPreservingWhitespace))) ?? AttributedString(text)
    }
    var body: some View {
        if text.hasPrefix("#") {
            Text(text.drop(while: { $0 == "#" || $0 == " " }))
                .readingStyle(adjustment: 1, heavy: true).padding(.top, 6)
        } else if style == .swiss {
            Text(markdown: parsed, emphasis: Ink.seal).readingStyle(adjustment: -1).lineSpacing(6)
                .foregroundStyle(Ink.ink)
        } else {
            let value = parsed
            let shown = min(marks, HighlightMarks.boldRanges(in: value).count)
            let color = HighlightStyle.color(highlightHex, scheme: colorScheme)
            // Bold in an answer is drawn as a half-height highlighter stroke.
            // When a new mark appears (its closing ** arrives while the answer
            // streams in), the strokes sweep in from the left. Old answers and
            // reopened chats show them at once; Reduce Motion skips the sweep.
            // No .textSelection here: selectable Text appears to be drawn by the system
            // without custom renderers, the likely reason highlights vanished in 1.5.6–1.5.7.
            // "选择文字" in the long-press menu opens the answer for selecting instead.
            Text(markdown: value, marks: shown).readingStyle().lineSpacing(7)
                .foregroundStyle(Ink.ink)
                .textRenderer(MarkerRenderer(color: color, progress: sweep))
                .onChange(of: shown) { old, new in
                    guard new > old, !reduceMotion else { return }
                    sweep = 0
                    // Next run loop, so the stroke is drawn at zero before it sweeps in.
                    DispatchQueue.main.async { withAnimation(.easeOut(duration: 0.38)) { sweep = 1 } }
                }
        }
    }
}

@MainActor
struct EditMessageView: View {
    @EnvironmentObject private var store: AppStore
    @Environment(\.dismiss) private var dismiss
    let message: ChatMessage
    @State private var text = ""
    var body: some View {
        NavigationStack {
            VStack(alignment: .leading, spacing: 16) {
                Text(message.role == .user ? "保存会直接修改这条消息；重新发送会替换其后的内容。" : "直接修改当前回答，不新建对话。")
                    .font(TypeScale.caption).foregroundStyle(Ink.ink3)
                TextEditor(text: $text).readingStyle().scrollContentBackground(.hidden)
                    .padding(12).background(Ink.raised, in: RoundedRectangle(cornerRadius: 20, style: .continuous))
                    .accessibilityIdentifier("message-editor")
                if message.role == .user {
                    Button {
                        if store.editMessage(message.id, text: text, resend: true) { dismiss() }
                    } label: {
                        Text("保存并重新发送").frame(maxWidth: .infinity).padding(.vertical, 8)
                    }.buttonStyle(.inkPrimary)
                        .disabled(text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                }
            }.padding(20).background(Ink.paper)
                .navigationTitle(message.role == .user ? "编辑你的消息" : "编辑回答")
                .navigationBarTitleDisplayMode(.inline)
                .toolbar {
                    ToolbarItem(placement: .topBarLeading) { Button("取消") { dismiss() } }
                    ToolbarItem(placement: .topBarTrailing) {
                        Button("保存") {
                            if store.editMessage(message.id, text: text, resend: false) { dismiss() }
                        }.disabled(text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                    }
                }
        }.presentationDragIndicator(.visible)
            .onAppear { text = message.content }
            .alert("暂时没有完成", isPresented: Binding(get: { store.errorMessage != nil }, set: { if !$0 { store.errorMessage = nil } })) {
                Button("知道了") { store.errorMessage = nil }
            } message: { Text(store.errorMessage ?? "") }
    }
}

// "10月13日 14:32"; the year is added only for another year.
enum MessageTime {
    private static let sameYear: DateFormatter = make("M月d日 HH:mm")
    private static let otherYear: DateFormatter = make("yyyy年M月d日 HH:mm")
    private static func make(_ format: String) -> DateFormatter {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "zh_CN")
        formatter.dateFormat = format
        return formatter
    }
    static func label(_ date: Date) -> String {
        let calendar = Calendar.current
        return (calendar.isDate(date, equalTo: Date(), toGranularity: .year) ? sameYear : otherYear).string(from: date)
    }
}
