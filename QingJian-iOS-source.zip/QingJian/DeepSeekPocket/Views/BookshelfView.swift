import SwiftUI
import UniformTypeIdentifiers
import UIKit

private extension View {
    // Both stores report errors; show whichever has one.
    func bookAlerts(_ store: AppStore, _ books: BookStore) -> some View {
        alert("暂时没有完成", isPresented: Binding(get: { books.errorMessage != nil || store.errorMessage != nil },
                                              set: { if !$0 { books.errorMessage = nil; store.errorMessage = nil } })) {
            Button("知道了") { books.errorMessage = nil; store.errorMessage = nil }
        } message: { Text(books.errorMessage ?? store.errorMessage ?? "") }
    }
}

// The bookshelf: import a novel as TXT, let it be read once, then talk with its people.
@MainActor
struct BookshelfView: View {
    @EnvironmentObject private var store: AppStore
    @EnvironmentObject private var books: BookStore
    @Environment(\.dismiss) private var dismiss
    let opened: () -> Void
    @State private var path: [UUID] = []
    @State private var managingPersonas = false

    var body: some View {
        NavigationStack(path: $path) {
            List {
                if books.books.isEmpty {
                    VStack(alignment: .leading, spacing: 16) {
                        Text("导入一本小说的 TXT 文件，Sermo 会分段读完全书，整理出人物档案、作者笔触和名场面。读完之后，选一个人物就能开聊。")
                            .font(TypeScale.serif(15)).foregroundStyle(Ink.ink3)
                        Button { pickBook() } label: { Label("导入 TXT", systemImage: "doc.badge.plus") }
                            .buttonStyle(.borderless)
                            .accessibilityIdentifier("book-import")
                    }
                    .padding(.vertical, 8)
                    .listRowBackground(Color.clear)
                }
                ForEach(books.books) { book in
                    NavigationLink(value: book.id) {
                        HStack(spacing: 14) {
                            Image(systemName: book.isReady ? "book.closed" : "book").font(.system(size: 17))
                                .foregroundStyle(Ink.ink2).frame(width: 24)
                            VStack(alignment: .leading, spacing: 3) {
                                Text(book.title).font(TypeScale.serif(17)).foregroundStyle(Ink.ink).lineLimit(1)
                                Text(BookStatusText.short(book, reading: books.readingBookID == book.id))
                                    .font(TypeScale.tiny).foregroundStyle(Ink.ink3)
                            }
                        }.padding(.vertical, 6)
                    }
                    .listRowBackground(Color.clear)
                    .accessibilityIdentifier("book-row")
                }
            }
            .listStyle(.plain)
            .scrollContentBackground(.hidden)
            .background(AppBackground())
            .overlay {
                if books.isImporting {
                    VStack(spacing: 12) {
                        ProgressView()
                        Text("正在导入并分章…").font(TypeScale.label).foregroundStyle(Ink.ink2)
                    }
                    .padding(24)
                    .background(Ink.raised, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                }
            }
            .navigationTitle("书架")
            .toolbar {
                ToolbarItem(placement: .topBarLeading) { Button("完成") { dismiss() } }
                ToolbarItem(placement: .topBarTrailing) {
                    Button { managingPersonas = true } label: { Image(systemName: "person.crop.square") }.accessibilityLabel("我的人物卡")
                }
                ToolbarItem(placement: .topBarTrailing) {
                    Button { pickBook() } label: { Image(systemName: "plus") }.accessibilityLabel("导入小说")
                        .disabled(books.isImporting)
                }
            }
            .navigationDestination(for: UUID.self) { id in BookDetailView(bookID: id, opened: opened) }
            .bookAlerts(store, books)
            .sheet(isPresented: $managingPersonas) { PersonaListView().environmentObject(books) }
        }
        .tint(Ink.ink)
    }

    // SwiftUI's .fileImporter does not open from this sheet while the chat page
    // underneath has one of its own, so the system picker is presented directly.
    private func pickBook() {
        DocumentPicker.presentMany([.plainText, .text, UTType(filenameExtension: "txt") ?? .plainText], asCopy: true) { urls in
            Task {
                var imported: [UUID] = []
                for url in urls {
                    if let id = await books.importBook(from: url) { imported.append(id) }
                }
                // One book opens straight away; several stay on the shelf to choose from.
                if imported.count == 1, let id = imported.first { path.append(id) }
            }
        }
    }
}

enum BookStatusText {
    static func short(_ book: Book, reading: Bool) -> String {
        let size = "\(wan(book.characterCount)) · \(book.chapterTitles.count) 章"
        if reading { return size + " · 正在读 \(book.readCount)/\(book.segments.count)" }
        switch book.status {
        case .ready: return size + " · \(book.profile?.characters.count ?? 0) 个人物"
        case .failed: return size + " · 没有读完"
        case .reading, .imported:
            return size + (book.readCount == 0 ? " · 还没读" : " · 读到 \(book.readCount)/\(book.segments.count)")
        }
    }
    static func wan(_ count: Int) -> String {
        count >= 10000 ? String(format: "%.1f 万字", Double(count) / 10000) : "\(count) 字"
    }
}

@MainActor
struct BookDetailView: View {
    @EnvironmentObject private var store: AppStore
    @EnvironmentObject private var books: BookStore
    @Environment(\.dismiss) private var dismiss
    let bookID: UUID
    let opened: () -> Void
    @State private var starting = false
    @State private var renaming = false
    @State private var renameText = ""
    @State private var confirmDelete = false
    @State private var confirmReset = false
    private var book: Book? { books.book(bookID) }
    private var isReading: Bool { books.readingBookID == bookID }

    var body: some View {
        Form {
            if let book {
                Section {
                    LabeledContent("字数", value: BookStatusText.wan(book.characterCount))
                    LabeledContent("章节", value: "\(book.chapterTitles.count) 章，分 \(book.segments.count) 段读")
                    NavigationLink { ChapterListView(bookID: bookID, opened: opened) } label: { Text("读原文") }
                        .accessibilityIdentifier("book-read-text")
                    if let cost = book.cost {
                        LabeledContent("已花费", value: Pricing.label(cost) + "（估算）")
                    }
                }
                readingSection(book)
                if let profile = book.profile, book.isReady { readySections(book, profile) }
            }
        }
        .font(TypeScale.body)
        .tint(Ink.seal)
        .scrollContentBackground(.hidden)
        .background(AppBackground())
        .navigationTitle(book?.title ?? "书")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Menu {
                    Button("重命名", systemImage: "pencil") { renameText = book?.title ?? ""; renaming = true }
                    if book?.readCount == book?.segments.count && book?.segments.isEmpty == false {
                        Button("重新整理档案", systemImage: "arrow.triangle.2.circlepath") { books.rebuildProfile(bookID) }
                            .disabled(books.isReading)
                    }
                    if (book?.readCount ?? 0) > 0 {
                        Button("从头重读", systemImage: "arrow.counterclockwise") { confirmReset = true }.disabled(books.isReading)
                    }
                    Button("从书架删除", systemImage: "trash", role: .destructive) { confirmDelete = true }
                } label: { Image(systemName: "ellipsis") }
                .accessibilityLabel("书的选项")
            }
        }
        .alert("重命名", isPresented: $renaming) {
            TextField("书名", text: $renameText)
            Button("取消", role: .cancel) { }
            Button("保存") { books.rename(bookID, to: renameText) }
        }
        .alert("从书架删除这本书？", isPresented: $confirmDelete) {
            Button("取消", role: .cancel) { }
            Button("删除", role: .destructive) { books.delete(bookID); dismiss() }
        } message: { Text("会删除正文、读书笔记和人物档案。已经开始的对话会保留，但之后不再带档案。") }
        .alert("从头重读？", isPresented: $confirmReset) {
            Button("取消", role: .cancel) { }
            Button("清空并重读", role: .destructive) { books.resetReading(bookID) }
        } message: { Text("会清空已有的读书笔记和人物档案（包括你手动改过的内容），之后需要重新阅读，会再次产生费用。") }
        .sheet(isPresented: $starting) {
            if let book, let profile = book.profile {
                StartStoryView(book: book, profile: profile) { opened() }
                    .environmentObject(store).environmentObject(books)
            }
        }
        .bookAlerts(store, books)
    }

    @ViewBuilder private func readingSection(_ book: Book) -> some View {
        let total = max(1, book.segments.count)
        if isReading {
            Section {
                ProgressView(value: Double(book.readCount), total: Double(total))
                Text(book.readCount == book.segments.count ? "全书读完了，正在整理人物档案…" : "正在读第 \(book.readCount + 1) 段，共 \(book.segments.count) 段")
                    .font(TypeScale.label).foregroundStyle(Ink.ink2)
                Button("暂停") { books.pause() }
            } footer: {
                Text("读的时候请让 Sermo 留在前台。切到后台一会儿后会暂停，读过的部分不会丢，回来点「继续阅读」即可。")
            }
        } else if !book.isReady {
            Section {
                if let issue = book.issue {
                    Text(issue).font(TypeScale.label).foregroundStyle(Ink.ink2)
                }
                if book.readCount > 0 {
                    ProgressView(value: Double(book.readCount), total: Double(total))
                }
                Picker("做笔记用", selection: Binding(get: { book.notesModel }, set: { books.setReadingModel($0, in: bookID) })) {
                    Text("Flash").tag(DeepSeekModel.flash)
                    Text("V4 Pro").tag(DeepSeekModel.pro)
                }
                .pickerStyle(.segmented)
                .accessibilityIdentifier("book-reading-model")
                Button(book.readCount == 0 ? "开始阅读" : "继续阅读") { books.startReading(bookID) }
                    .disabled(books.isReading)
                    .accessibilityIdentifier("book-start-reading")
            } header: {
                Text(book.readCount == 0 ? "还没读" : "读到 \(book.readCount)/\(book.segments.count) 段")
            } footer: {
                Text("用 \(book.notesModel.title) 每次读几章做笔记，最后用 V4 Pro 整理成档案。按这本书的长度，现在读完预计约 \(Pricing.label(books.estimatedCost(of: book)))，实际以用量记录为准。V4 Pro 做的笔记更细，人名、关系和台词更准，价格约为 Flash 的四倍。\n\n现在是\(Pricing.statusLabel())。空闲时段（工作日 9–12 点、14–18 点以外，以及周末）价格减半。" +
                     (books.isReading && !isReading ? "\n另一本书正在读，读完后再开始这本。" : ""))
            }
        }
    }

    @ViewBuilder private func readySections(_ book: Book, _ profile: BookProfile) -> some View {
        Section {
            Button { starting = true } label: {
                Label("选一个人物开聊", systemImage: "bubble.left.and.text.bubble.right")
            }
            .disabled(!store.hasKey || store.isGenerating)
            .accessibilityIdentifier("book-start-story")
        } footer: {
            if !profile.summary.isEmpty { Text(profile.summary) }
        }
        Section("人物") {
            ForEach(profile.characters) { character in
                NavigationLink {
                    CharacterEditView(bookID: bookID, character: character)
                } label: {
                    VStack(alignment: .leading, spacing: 2) {
                        Text(character.name)
                        if !character.identity.isEmpty {
                            Text(character.identity).font(TypeScale.tiny).foregroundStyle(Ink.ink3).lineLimit(2)
                        }
                    }
                }
            }
        }
        Section {
            NavigationLink { StyleEditView(bookID: bookID, text: profile.style.description) } label: {
                Text(profile.style.description.isEmpty ? "还没有文风描述" : profile.style.description)
                    .font(TypeScale.label).foregroundStyle(Ink.ink2).lineLimit(4)
            }
            ForEach(Array(profile.style.excerpts.enumerated()), id: \.offset) { _, excerpt in
                Text(excerpt).font(TypeScale.label).foregroundStyle(Ink.ink3)
            }
        } header: { Text("作者笔触") } footer: { Text("聊天时会带上这段描述和几段原文，让回答更像原著。") }
        if !profile.scenes.isEmpty {
            Section("名场面") {
                ForEach(profile.scenes) { scene in
                    VStack(alignment: .leading, spacing: 4) {
                        HStack {
                            Text(scene.title)
                            Spacer()
                            Text(book.chapterLabel(scene.chapter)).font(TypeScale.tiny).foregroundStyle(Ink.ink3).lineLimit(1)
                        }
                        Text(scene.summary).font(TypeScale.tiny).foregroundStyle(Ink.ink3)
                    }.padding(.vertical, 2)
                }
            }
        }
    }
}

// One character's card, editable. Changes apply to conversations from the next answer on.
@MainActor
struct CharacterEditView: View {
    @EnvironmentObject private var books: BookStore
    @Environment(\.dismiss) private var dismiss
    let bookID: UUID
    let originalName: String
    @State private var draft: BookCharacter

    init(bookID: UUID, character: BookCharacter) {
        self.bookID = bookID
        self.originalName = character.name
        _draft = State(initialValue: character)
    }

    private var reading: Bool { books.isDeepReading(originalName, in: bookID) }

    var body: some View {
        Form {
            Section {
                Button {
                    Task {
                        if await books.deepReadCharacter(originalName, in: bookID),
                           let fresh = books.book(bookID)?.profile?.characters.first(where: { $0.name == originalName }) {
                            draft = fresh
                        }
                    }
                } label: {
                    HStack {
                        Label(draft.deepReadAt == nil ? "精读这个人物" : "重新精读", systemImage: "text.magnifyingglass")
                        Spacer()
                        if reading { ProgressView() }
                    }
                }
                .disabled(books.deepReading != nil)
            } footer: {
                Text((draft.deepReadAt.map { "已精读：\($0.formatted(date: .abbreviated, time: .shortened))。" } ?? "") +
                     "用 V4 Pro 把这个人物的全部笔记、台词和原文片段再读一遍，写出更细的人物卡：不同情境下的反应、对不同人的态度、绝不会说或做的事。大约几毛钱，只需做一次。现在是\(Pricing.statusLabel())。")
            }
            Section("名字") {
                TextField("名字", text: $draft.name)
                TextField("其他称呼，用顿号隔开", text: Binding(
                    get: { draft.aliases.joined(separator: "、") },
                    set: { draft.aliases = $0.components(separatedBy: CharacterSet(charactersIn: "、,，")).map { $0.trimmingCharacters(in: .whitespaces) }.filter { !$0.isEmpty } }))
            }
            field("身份", $draft.identity)
            field("性格", $draft.personality)
            field("说话方式", $draft.speech)
            field("不同情境下的反应", optional($draft.behavior))
            field("对不同人的态度", optional($draft.attitudes))
            field("绝不会说或做的事", optional($draft.taboos))
            field("人物关系", $draft.relationships)
            Section {
                TextField("经历", text: $draft.arc, axis: .vertical).lineLimit(3...12)
            } header: { Text("经历") } footer: { Text("不选时间点开聊时会带上；选了时间点就改用前情提要，不带这段。") }
            if let corrections = draft.corrections, !corrections.isEmpty {
                Section {
                    ForEach(Array(corrections.enumerated()), id: \.offset) { _, line in
                        Text(line).font(TypeScale.label).foregroundStyle(Ink.ink2)
                    }
                    .onDelete { offsets in
                        var list = draft.corrections ?? []
                        list.remove(atOffsets: offsets)
                        draft.corrections = list.isEmpty ? nil : list
                    }
                } header: { Text("你纠正过的地方") } footer: { Text("在聊天里长按回答选「这里不像」加上的，每局都会带着。左滑可删除。") }
            }
            if !draft.quotes.isEmpty {
                Section("原著台词") {
                    ForEach(Array(draft.quotes.enumerated()), id: \.offset) { _, quote in
                        Text("「\(quote.text)」").font(TypeScale.label).foregroundStyle(Ink.ink2)
                    }
                    .onDelete { draft.quotes.remove(atOffsets: $0) }
                }
            }
        }
        .font(TypeScale.body)
        .tint(Ink.seal)
        .scrollContentBackground(.hidden)
        .background(AppBackground())
        .disabled(reading)
        .navigationTitle(originalName)
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button("保存") { books.updateCharacter(draft, originalName: originalName, in: bookID); dismiss() }
                    .disabled(draft.name.trimmingCharacters(in: .whitespaces).isEmpty || reading)
            }
        }
    }

    private func field(_ title: String, _ text: Binding<String>) -> some View {
        Section(title) { TextField(title, text: text, axis: .vertical).lineLimit(2...10) }
    }

    private func optional(_ value: Binding<String?>) -> Binding<String> {
        Binding(get: { value.wrappedValue ?? "" }, set: { value.wrappedValue = $0.isEmpty ? nil : $0 })
    }
}

@MainActor
struct StyleEditView: View {
    @EnvironmentObject private var books: BookStore
    @Environment(\.dismiss) private var dismiss
    let bookID: UUID
    @State var text: String
    private var style: BookStyle? { books.book(bookID)?.profile?.style }
    private var reading: Bool { books.isDeepReading("文风", in: bookID) }

    var body: some View {
        Form {
            Section {
                Button {
                    Task {
                        if await books.deepReadStyle(in: bookID), let fresh = style?.description { text = fresh }
                    }
                } label: {
                    HStack {
                        Label(style?.deepReadAt == nil ? "精读文风" : "重新精读", systemImage: "text.magnifyingglass")
                        Spacer()
                        if reading { ProgressView() }
                    }
                }
                .disabled(books.deepReading != nil)
            } footer: {
                Text("用 V4 Pro 读全书各处约 30 段原文，写出更具体的文风规则、标志性写法和「原著不会这样写」的清单，并挑出最有代表性的原文片段。大约几毛钱，只需做一次。现在是\(Pricing.statusLabel())。")
            }
            Section {
                TextField("作者笔触", text: $text, axis: .vertical).lineLimit(6...20)
            } header: { Text("文风描述") } footer: { Text("写成可以照着写的要求，例如叙述视角、句子长短、对白的写法。") }
            if let signatures = style?.signatures, !signatures.isEmpty {
                Section("标志性写法") { ForEach(signatures, id: \.self) { Text($0).font(TypeScale.label).foregroundStyle(Ink.ink2) } }
            }
            if let avoid = style?.avoid, !avoid.isEmpty {
                Section("原著不会这样写") { ForEach(avoid, id: \.self) { Text($0).font(TypeScale.label).foregroundStyle(Ink.ink2) } }
            }
        }
        .font(TypeScale.body)
        .scrollContentBackground(.hidden)
        .background(AppBackground())
        .disabled(reading)
        .navigationTitle("作者笔触")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button("保存") { books.updateStyle(text, in: bookID); dismiss() }.disabled(reading)
            }
        }
    }
}

// Pick who to talk with, who you are, where it starts and how to play.
@MainActor
struct StartStoryView: View {
    @EnvironmentObject private var store: AppStore
    @EnvironmentObject private var books: BookStore
    @Environment(\.dismiss) private var dismiss
    let book: Book
    let profile: BookProfile
    var initialChapter: Int? = nil
    var initialOpening = ""
    let opened: () -> Void
    @State private var character = ""
    @State private var userRole = ""
    @State private var personaID: UUID?
    @State private var opening = ""
    @State private var chapter: Int?
    @State private var instruction = ""
    @State private var guests: [StoryGuest] = []
    @State private var managingPersonas = false
    @State private var starting = false
    @State private var prepared = false

    private var otherBooks: [Book] { books.books.filter { $0.id != book.id && $0.isReady } }
    private var chosenPersona: PersonaCard? {
        guard let personaID, let card = books.personas.first(where: { $0.id == personaID }),
              card.name == userRole.trimmingCharacters(in: .whitespacesAndNewlines) else { return nil }
        return card
    }

    var body: some View {
        NavigationStack {
            Form {
                Section("和谁聊") {
                    Picker("人物", selection: $character) {
                        ForEach(profile.characters) { Text($0.name).tag($0.name) }
                    }
                    .accessibilityIdentifier("story-character")
                }
                Section {
                    Picker("从哪里开始", selection: $chapter) {
                        Text("不限定").tag(Int?.none)
                        ForEach(book.chapterTitles.indices, id: \.self) { index in
                            Text(book.chapterTitles[index]).tag(Optional(index))
                        }
                    }
                    .pickerStyle(.navigationLink)
                    if !profile.scenes.isEmpty {
                        Menu("从名场面开始") {
                            ForEach(profile.scenes) { scene in
                                Button(scene.title) {
                                    chapter = scene.chapter
                                    opening = "从原著「\(scene.title)」这一段开始：\(scene.summary)"
                                }
                            }
                        }
                    }
                } header: { Text("时间点") } footer: {
                    Text(chapter == nil ? "不限定时，人物知道全书发生的事。" :
                            "开聊前先写一段到这一章为止的前情提要，放在对话最上面给你看；人物只知道这之前的事，不会说漏后面的剧情。")
                }
                Section {
                    TextField("例如：贾宝玉，或「一个刚进府的小丫鬟」", text: $userRole, axis: .vertical).lineLimit(1...3)
                    Menu("从书中人物里选") {
                        ForEach(profile.characters.filter { $0.name != character }) { person in
                            Button(person.name) { userRole = person.name; personaID = nil }
                        }
                    }
                    Menu("我的人物卡") {
                        ForEach(books.personas) { card in
                            Button(card.name) { userRole = card.name; personaID = card.id }
                        }
                        Divider()
                        Button("管理人物卡…", systemImage: "person.crop.square") { managingPersonas = true }
                    }
                } header: { Text("你扮演谁") } footer: {
                    if let card = chosenPersona { Text(card.detail).lineLimit(4) } else { Text("留空就是你自己。") }
                }
                Section {
                    TextField("例如：元宵节夜里，在大观园", text: $opening, axis: .vertical).lineLimit(2...6)
                } header: { Text("开场（可选）") } footer: { Text("写时间、地点或发生了什么。留空就由人物自己开场。") }
                Section {
                    ForEach(guests, id: \.self) { guest in
                        VStack(alignment: .leading, spacing: 2) {
                            Text(guest.character)
                            Text("来自《\(guest.bookTitle)》").font(TypeScale.tiny).foregroundStyle(Ink.ink3)
                        }
                    }
                    .onDelete { guests.remove(atOffsets: $0) }
                    Menu("加一位客串人物") {
                        ForEach(otherBooks) { other in
                            Menu("《\(other.title)》") {
                                ForEach(other.profile?.characters ?? []) { person in
                                    Button(person.name) { addGuest(person.name, from: other) }
                                }
                            }
                        }
                    }
                    .disabled(otherBooks.isEmpty || guests.count >= 3)
                } header: { Text("客串人物（可选）") } footer: {
                    Text(otherBooks.isEmpty ? "书架上再读完一本书，就能把那本书里的人物带进来。" : "从别的书里请人物过来，由模型一起扮演，最多 3 位。左滑可移除。")
                }
                Section {
                    TextField("例如：用小说的笔法写，多写环境和心理描写；每次回复末尾加一行状态：时间 / 地点 / 好感度", text: $instruction, axis: .vertical)
                        .lineLimit(3...10)
                } header: { Text("本局玩法（可选）") } footer: { Text("写给模型的规矩，这一局一直有效，优先于其他设定。聊天时可以在标题旁的「⋯ → 本局设定」里修改。") }
            }
            .font(TypeScale.body)
            .tint(Ink.seal)
            .scrollContentBackground(.hidden)
            .background(AppBackground())
            .disabled(starting)
            .overlay {
                if starting {
                    VStack(spacing: 12) {
                        ProgressView()
                        Text(chapter == nil ? "正在开局…" : "正在写前情提要…").font(TypeScale.label).foregroundStyle(Ink.ink2)
                    }
                    .padding(24)
                    .background(Ink.raised, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                }
            }
            .navigationTitle("《\(book.title)》")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) { Button("取消") { dismiss() }.disabled(starting) }
                ToolbarItem(placement: .topBarTrailing) {
                    Button("开聊") { start() }
                        .disabled(character.isEmpty || store.isGenerating || starting)
                }
            }
            .sheet(isPresented: $managingPersonas) {
                PersonaListView().environmentObject(books)
            }
            .bookAlerts(store, books)
        }
        .tint(Ink.ink)
        .onAppear {
            guard !prepared else { return }
            prepared = true
            character = profile.characters.first?.name ?? ""
            chapter = initialChapter
            opening = initialOpening
        }
    }

    private func addGuest(_ name: String, from other: Book) {
        let guest = StoryGuest(bookID: other.id, bookTitle: other.title, character: name)
        if !guests.contains(guest) && guests.count < 3 { guests.append(guest) }
    }

    private func start() {
        let setup = AppStore.StorySetup(bookID: book.id, character: character, userRole: userRole,
                                        userCard: chosenPersona?.detail, opening: opening, chapter: chapter,
                                        instruction: instruction, guests: guests)
        starting = true
        Task {
            let ok = await store.startStory(setup)
            starting = false
            if ok { dismiss(); opened() }
        }
    }
}

// MARK: Your own characters

@MainActor
struct PersonaListView: View {
    @EnvironmentObject private var books: BookStore
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            List {
                if books.personas.isEmpty {
                    Text("把你常用的原创人物存在这里：名字、外貌、身份、性格、说话方式。开局时在「你扮演谁 → 我的人物卡」里一点就带上，任何一本书都能用。")
                        .font(TypeScale.serif(15)).foregroundStyle(Ink.ink3).listRowBackground(Color.clear)
                }
                ForEach(books.personas) { card in
                    NavigationLink {
                        PersonaEditView(card: card)
                    } label: {
                        VStack(alignment: .leading, spacing: 3) {
                            Text(card.name).font(TypeScale.serif(17)).foregroundStyle(Ink.ink)
                            Text(card.detail).font(TypeScale.tiny).foregroundStyle(Ink.ink3).lineLimit(2)
                        }.padding(.vertical, 4)
                    }
                    .listRowBackground(Color.clear)
                }
                .onDelete { books.deletePersonas(at: $0) }
            }
            .listStyle(.plain)
            .scrollContentBackground(.hidden)
            .background(AppBackground())
            .navigationTitle("我的人物卡")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) { Button("完成") { dismiss() } }
                ToolbarItem(placement: .topBarTrailing) {
                    NavigationLink { PersonaEditView(card: PersonaCard(name: "", detail: "")) } label: { Image(systemName: "plus") }
                        .accessibilityLabel("新建人物卡")
                }
            }
        }
        .tint(Ink.ink)
    }
}

@MainActor
struct PersonaEditView: View {
    @EnvironmentObject private var books: BookStore
    @Environment(\.dismiss) private var dismiss
    @State private var draft: PersonaCard

    init(card: PersonaCard) { _draft = State(initialValue: card) }

    var body: some View {
        Form {
            Section("名字") { TextField("名字", text: $draft.name) }
            Section {
                TextField("外貌、身份、性格、说话方式，和这个世界有什么关系…", text: $draft.detail, axis: .vertical).lineLimit(5...16)
            } header: { Text("人物卡") } footer: { Text("开局时会作为「你扮演的人物」一起发给模型。") }
        }
        .font(TypeScale.body)
        .tint(Ink.seal)
        .scrollContentBackground(.hidden)
        .background(AppBackground())
        .navigationTitle(draft.name.isEmpty ? "新人物卡" : draft.name)
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button("保存") { books.savePersona(draft); dismiss() }
                    .disabled(draft.name.trimmingCharacters(in: .whitespaces).isEmpty)
            }
        }
    }
}

// MARK: Reading the text

private struct StartPoint: Identifiable {
    let id = UUID()
    let chapter: Int
    let opening: String
}

@MainActor
struct ChapterListView: View {
    @EnvironmentObject private var books: BookStore
    let bookID: UUID
    let opened: () -> Void

    var body: some View {
        let book = books.book(bookID)
        let titles = book?.chapterTitles ?? []
        List {
            if let mark = book?.bookmark, titles.indices.contains(mark.chapter) {
                NavigationLink {
                    ChapterReaderView(bookID: bookID, chapter: mark.chapter, paragraph: mark.paragraph, opened: opened)
                } label: {
                    Label("继续阅读 · \(titles[mark.chapter])", systemImage: "bookmark.fill").foregroundStyle(Ink.ink)
                }
                .listRowBackground(Color.clear)
                .accessibilityIdentifier("book-continue-reading")
            }
            ForEach(titles.indices, id: \.self) { index in
                NavigationLink {
                    ChapterReaderView(bookID: bookID, chapter: index, opened: opened)
                } label: {
                    HStack(alignment: .firstTextBaseline, spacing: 12) {
                        Text("\(index + 1)").font(TypeScale.tiny).monospacedDigit().foregroundStyle(Ink.ink3).frame(minWidth: 28, alignment: .trailing)
                        Text(titles[index]).font(TypeScale.serif(16)).foregroundStyle(Ink.ink).lineLimit(1)
                    }
                }
                .listRowBackground(Color.clear)
            }
        }
        .listStyle(.plain)
        .scrollContentBackground(.hidden)
        .background(AppBackground())
        .navigationTitle("目录")
        .navigationBarTitleDisplayMode(.inline)
    }
}

// One chapter of the original. Long-press a paragraph to start a story there or
// leave a bookmark; opening a chapter also moves the bookmark to it.
@MainActor
struct ChapterReaderView: View {
    @EnvironmentObject private var store: AppStore
    @EnvironmentObject private var books: BookStore
    let bookID: UUID
    let opened: () -> Void
    private let startParagraph: Int?
    @State private var chapter: Int
    @State private var startPoint: StartPoint?

    init(bookID: UUID, chapter: Int, paragraph: Int? = nil, opened: @escaping () -> Void) {
        self.bookID = bookID
        self.opened = opened
        self.startParagraph = paragraph
        _chapter = State(initialValue: chapter)
    }

    private var book: Book? { books.book(bookID) }
    private var paragraphs: [String] {
        let chapters = books.chapters(of: bookID)
        guard chapters.indices.contains(chapter) else { return [] }
        return chapters[chapter].text.components(separatedBy: "\n").filter { !$0.trimmingCharacters(in: .whitespaces).isEmpty }
    }

    var body: some View {
        let count = book?.chapterTitles.count ?? 0
        let mark = book?.bookmark
        ScrollViewReader { reader in
            ScrollView {
                LazyVStack(alignment: .leading, spacing: 14) {
                    Text(book?.chapterLabel(chapter) ?? "").font(TypeScale.subject).foregroundStyle(Ink.ink).id("top")
                    Text(book?.isReady == true ? "长按任意一段：从这里开始演，或放一个书签。" : "长按任意一段可以放书签。")
                        .font(TypeScale.tiny).foregroundStyle(Ink.ink3)
                    ForEach(Array(paragraphs.enumerated()), id: \.offset) { index, paragraph in
                        HStack(alignment: .top, spacing: 8) {
                            if mark?.chapter == chapter && mark?.paragraph == index && index > 0 {
                                Image(systemName: "bookmark.fill").font(.system(size: 11)).foregroundStyle(Ink.seal).padding(.top, 5)
                            }
                            Text(paragraph).font(TypeScale.answer).foregroundStyle(Ink.ink).lineSpacing(6)
                                .frame(maxWidth: .infinity, alignment: .leading)
                        }
                        .contentShape(Rectangle())
                        .id(index)
                        .contextMenu {
                            if book?.isReady == true {
                                Button("从这里开始演", systemImage: "play") {
                                    startPoint = StartPoint(chapter: chapter, opening: "从原著这一段开始：「\(paragraph.prefix(240))」")
                                }
                            }
                            Button("在这里放书签", systemImage: "bookmark") {
                                books.setBookmark(BookBookmark(chapter: chapter, paragraph: index), in: bookID)
                            }
                            Button("复制", systemImage: "doc.on.doc") { UIPasteboard.general.string = paragraph }
                        }
                    }
                    HStack {
                        Button("上一章") { chapter -= 1; reader.scrollTo("top", anchor: .top) }.disabled(chapter <= 0)
                        Spacer()
                        Button("下一章") { chapter += 1; reader.scrollTo("top", anchor: .top) }.disabled(chapter + 1 >= count)
                    }
                    .font(TypeScale.body).padding(.vertical, 20)
                }
                .padding(.horizontal, 22).padding(.vertical, 12)
            }
            .onAppear {
                if let startParagraph, startParagraph > 0 {
                    DispatchQueue.main.async { reader.scrollTo(startParagraph, anchor: .top) }
                } else {
                    markChapter()
                }
            }
            .onChange(of: chapter) { _, _ in markChapter() }
        }
        .background(AppBackground())
        .navigationTitle("\(chapter + 1) / \(count)")
        .navigationBarTitleDisplayMode(.inline)
        .sheet(item: $startPoint) { point in
            if let book, let profile = book.profile {
                StartStoryView(book: book, profile: profile, initialChapter: point.chapter, initialOpening: point.opening) { opened() }
                    .environmentObject(store).environmentObject(books)
            }
        }
    }

    // Opening a chapter is where you are now, unless a bookmark already sits inside it.
    private func markChapter() {
        guard book?.bookmark?.chapter != chapter else { return }
        books.setBookmark(BookBookmark(chapter: chapter, paragraph: 0), in: bookID)
    }
}

// 「这里不像」: what the character would really say or do, kept on their card.
@MainActor
struct StoryCorrectionSheet: View {
    @EnvironmentObject private var store: AppStore
    @Environment(\.dismiss) private var dismiss
    let threadID: UUID
    let answer: String
    @State private var character = ""
    @State private var note = ""
    private var session: StorySession? { store.threads.first(where: { $0.id == threadID })?.story }
    private var names: [String] { session.map { [$0.character] + ($0.guests ?? []).map(\.character) } ?? [] }

    var body: some View {
        NavigationStack {
            Form {
                if names.count > 1 {
                    Picker("哪个人物", selection: $character) { ForEach(names, id: \.self) { Text($0).tag($0) } }
                }
                Section {
                    Text(String(answer.prefix(160)) + (answer.count > 160 ? "…" : "")).font(TypeScale.label).foregroundStyle(Ink.ink3)
                } header: { Text("这条回答") }
                Section {
                    TextField("例如：她不会这么直白地说喜欢，只会拐着弯刺一句", text: $note, axis: .vertical).lineLimit(3...8)
                } header: { Text("哪里不像，他会怎样") } footer: {
                    Text("会记进这个人物的人物卡，之后每一局都会带上；在书页的人物卡里可以查看和删除。想让这一条也改过来，可以接着点重新生成。")
                }
            }
            .font(TypeScale.body)
            .tint(Ink.seal)
            .scrollContentBackground(.hidden)
            .background(AppBackground())
            .navigationTitle("这里不像")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) { Button("取消") { dismiss() } }
                ToolbarItem(placement: .topBarTrailing) {
                    Button("记下") {
                        if store.correctStory(threadID: threadID, character: character, note: note, answer: answer) { dismiss() }
                    }
                    .disabled(note.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || character.isEmpty)
                }
            }
        }
        .tint(Ink.ink)
        .onAppear { if character.isEmpty { character = names.first ?? "" } }
    }
}

// MARK: This game's settings, while playing

@MainActor
struct StorySettingsSheet: View {
    @EnvironmentObject private var store: AppStore
    @Environment(\.dismiss) private var dismiss
    let threadID: UUID
    @State private var instruction = ""
    @State private var briefing = ""
    @State private var loaded = false
    private var session: StorySession? { store.threads.first(where: { $0.id == threadID })?.story }

    var body: some View {
        NavigationStack {
            Form {
                if let session {
                    Section {
                        LabeledContent("书", value: "《\(session.bookTitle)》")
                        LabeledContent("人物", value: ([session.character] + (session.guests ?? []).map(\.character)).joined(separator: "、"))
                        LabeledContent("你扮演", value: session.userRole.isEmpty ? "你自己" : session.userRole)
                        LabeledContent("时间点", value: session.chapterTitle ?? "不限定")
                    }
                    Section {
                        TextField("例如：用小说的笔法写；每次回复末尾加一行状态栏", text: $instruction, axis: .vertical).lineLimit(3...12)
                    } header: { Text("本局玩法") } footer: { Text("保存后从下一条回答开始生效。") }
                    if session.briefing != nil {
                        Section {
                            TextField("前情提要", text: $briefing, axis: .vertical).lineLimit(4...20)
                        } header: { Text("前情提要") } footer: { Text("模型按这段理解人物此刻的处境，可以手动修正。对话顶部显示的是开局时的版本。") }
                    }
                }
            }
            .font(TypeScale.body)
            .tint(Ink.seal)
            .scrollContentBackground(.hidden)
            .background(AppBackground())
            .navigationTitle("本局设定")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) { Button("取消") { dismiss() } }
                ToolbarItem(placement: .topBarTrailing) {
                    Button("保存") {
                        store.updateStory(threadID: threadID, instruction: instruction, briefing: session?.briefing == nil ? nil : briefing)
                        dismiss()
                    }
                }
            }
        }
        .tint(Ink.ink)
        .onAppear {
            guard !loaded, let session else { return }
            loaded = true
            instruction = session.instruction ?? ""
            briefing = session.briefing ?? ""
        }
    }
}
