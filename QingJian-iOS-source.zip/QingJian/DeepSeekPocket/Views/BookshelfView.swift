import SwiftUI
import UniformTypeIdentifiers
import UIKit

private extension View {
    // Both stores report errors; show whichever has one.
    func bookAlerts(_ store: AppStore, _ books: BookStore) -> some View {
        alert("暂时没有完成", isPresented: Binding(get: { books.errorMessage != nil || store.errorMessage != nil },
                                              set: { if !$0 { books.errorMessage = nil; store.errorMessage = nil } })) {
            Button("知道了") { books.errorMessage = nil; store.errorMessage = nil }
        } message: { Text(books.errorMessage ?? store.errorMessage ?? "") }
    }
}

// The bookshelf: import a novel as TXT, let it be read once, then talk with its people.
@MainActor
struct BookshelfView: View {
    @EnvironmentObject private var store: AppStore
    @EnvironmentObject private var books: BookStore
    @Environment(\.dismiss) private var dismiss
    let opened: () -> Void
    @State private var path: [UUID] = []
    @State private var managingPersonas = false

    var body: some View {
        NavigationStack(path: $path) {
            List {
                if books.books.isEmpty {
                    VStack(alignment: .leading, spacing: 16) {
                        Text("导入一本小说的 TXT 文件，Sermo 会分段读完全书，整理出人物档案、作者笔触和名场面。读完之后，选一个人物就能开聊。")
                            .font(TypeScale.serif(15)).foregroundStyle(Ink.ink3)
                        Button { pickBook() } label: { Label("导入 TXT", systemImage: "doc.badge.plus") }
                            .buttonStyle(.borderless)
                            .accessibilityIdentifier("book-import")
                    }
                    .padding(.vertical, 8)
                    .listRowBackground(Color.clear)
                }
                ForEach(books.books) { book in
                    NavigationLink(value: book.id) {
                        HStack(spacing: 14) {
                            Image(systemName: book.isReady ? "book.closed" : "book").font(.system(size: 17))
                                .foregroundStyle(Ink.ink2).frame(width: 24)
                            VStack(alignment: .leading, spacing: 3) {
                                Text(book.title).font(TypeScale.serif(17)).foregroundStyle(Ink.ink).lineLimit(1)
                                Text(BookStatusText.short(book, reading: books.readingBookID == book.id))
                                    .font(TypeScale.tiny).foregroundStyle(Ink.ink3)
                            }
                        }.padding(.vertical, 6)
                    }
                    .listRowBackground(Color.clear)
                    .accessibilityIdentifier("book-row")
                }
            }
            .listStyle(.plain)
            .scrollContentBackground(.hidden)
            .background(AppBackground())
            .overlay {
                if books.isImporting {
                    VStack(spacing: 12) {
                        ProgressView()
                        Text("正在导入并分章…").font(TypeScale.label).foregroundStyle(Ink.ink2)
                    }
                    .padding(24)
                    .background(Ink.raised, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                }
            }
            .navigationTitle("书架")
            .toolbar {
                ToolbarItem(placement: .topBarLeading) { Button("完成") { dismiss() } }
                ToolbarItem(placement: .topBarTrailing) {
                    Button { managingPersonas = true } label: { Image(systemName: "person.crop.square") }.accessibilityLabel("我的人物卡")
                }
                ToolbarItem(placement: .topBarTrailing) {
                    Button { pickBook() } label: { Image(systemName: "plus") }.accessibilityLabel("导入小说")
                        .disabled(books.isImporting)
                }
            }
            .navigationDestination(for: UUID.self) { id in BookDetailView(bookID: id, opened: opened) }
            .bookAlerts(store, books)
            .sheet(isPresented: $managingPersonas) { PersonaListView().environmentObject(books) }
        }
        .tint(Ink.ink)
    }

    // SwiftUI's .fileImporter does not open from this sheet while the chat page
    // underneath has one of its own, so the system picker is presented directly.
    private func pickBook() {
        DocumentPicker.presentMany([.plainText, .text, UTType(filenameExtension: "txt") ?? .plainText], asCopy: true) { urls in
            Task {
                var imported: [UUID] = []
                for url in urls {
                    if let id = await books.importBook(from: url) { imported.append(id) }
                }
                // One book opens straight away; several stay on the shelf to choose from.
                if imported.count == 1, let id = imported.first { path.append(id) }
            }
        }
    }
}

enum BookStatusText {
    static func short(_ book: Book, reading: Bool) -> String {
        let size = "\(wan(book.characterCount)) · \(book.chapterTitles.count) 章"
        if reading { return size + " · 正在读 \(book.readCount)/\(book.segments.count)" }
        switch book.status {
        case .ready: return size + " · \(book.profile?.characters.count ?? 0) 个人物"
        case .failed: return size + " · 没有读完"
        case .reading, .imported:
            return size + (book.readCount == 0 ? " · 还没读" : " · 读到 \(book.readCount)/\(book.segments.count)")
        }
    }
    static func wan(_ count: Int) -> String {
        count >= 10000 ? String(format: "%.1f 万字", Double(count) / 10000) : "\(count) 字"
    }
}

@MainActor
struct BookDetailView: View {
    @EnvironmentObject private var store: AppStore
    @EnvironmentObject private var books: BookStore
    @Environment(\.dismiss) private var dismiss
    let bookID: UUID
    let opened: () -> Void
    @State private var starting = false
    @State private var renaming = false
    @State private var renameText = ""
    @State private var confirmDelete = false
    @State private var confirmReset = false
    private var book: Book? { books.book(bookID) }
    private var isReading: Bool { books.readingBookID == bookID }

    var body: some View {
        Form {
            if let book {
                Section {
                    LabeledContent("字数", value: BookStatusText.wan(book.characterCount))
                    LabeledContent("章节", value: "\(book.chapterTitles.count) 章，分 \(book.segments.count) 段读")
                    NavigationLink { ChapterListView(bookID: bookID, opened: opened) } label: { Text("读原文") }
                        .accessibilityIdentifier("book-read-text")
                    if let cost = book.cost {
                        LabeledContent("已花费", value: Pricing.label(cost) + "（估算）")
                    }
                }
                readingSection(book)
                if let profile = book.profile, book.isReady { readySections(book, profile) }
            }
        }
        .font(TypeScale.body)
        .tint(Ink.seal)
        .scrollContentBackground(.hidden)
        .background(AppBackground())
        .navigationTitle(book?.title ?? "书")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Menu {
                    Button("重命名", systemImage: "pencil") { renameText = book?.title ?? ""; renaming = true }
                    if book?.readCount == book?.segments.count && book?.segments.isEmpty == false {
                        Button("重新整理档案", systemImage: "arrow.triangle.2.circlepath") { books.rebuildProfile(bookID) }
                            .disabled(books.isReading)
                    }
                    if (book?.readCount ?? 0) > 0 {
                        Button("从头重读", systemImage: "arrow.counterclockwise") { confirmReset = true }.disabled(books.isReading)
                    }
                    Button("从书架删除", systemImage: "trash", role: .destructive) { confirmDelete = true }
                } label: { Image(systemName: "ellipsis") }
                .accessibilityLabel("书的选项")
            }
        }
        .alert("重命名", isPresented: $renaming) {
            TextField("书名", text: $renameText)
            Button("取消", role: .cancel) { }
            Button("保存") { books.rename(bookID, to: renameText) }
        }
        .alert("从书架删除这本书？", isPresented: $confirmDelete) {
            Button("取消", role: .cancel) { }
            Button("删除", role: .destructive) { books.delete(bookID); dismiss() }
        } message: { Text("会删除正文、读书笔记和人物档案。已经开始的对话会保留，但之后不再带档案。") }
        .alert("从头重读？", isPresented: $confirmReset) {
            Button("取消", role: .cancel) { }
            Button("清空并重读", role: .destructive) { books.resetReading(bookID) }
        } message: { Text("会清空已有的读书笔记和人物档案（包括你手动改过的内容），之后需要重新阅读，会再次产生费用。") }
        .sheet(isPresented: $starting) {
            if let book, let profile = book.profile {
                StartStoryView(book: book, profile: profile) { opened() }
                    .environmentObject(store).environmentObject(books)
            }
        }
        .bookAlerts(store, books)
    }

    @ViewBuilder private func readingSection(_ book: Book) -> some View {
        let total = max(1, book.segments.count)
        if isReading {
            Section {
                ProgressView(value: Double(book.readCount), total: Double(total))
                Text(book.readCount == book.segments.count ? "全书读完了，正在整理人物档案…" : "正在读第 \(book.readCount + 1) 段，共 \(book.segments.count) 段")
                    .font(TypeScale.label).foregroundStyle(Ink.ink2)
                Button("暂停") { books.pause() }
            } footer: {
                Text("读的时候请让 Sermo 留在前台。切到后台一会儿后会暂停，读过的部分不会丢，回来点「继续阅读」即可。")
            }
        } else if !book.isReady {
            Section {
                if let issue = book.issue {
                    Text(issue).font(TypeScale.label).foregroundStyle(Ink.ink2)
                }
                if book.readCount > 0 {
                    ProgressView(value: Double(book.readCount), total: Double(total))
                }
                Button(book.readCount == 0 ? "开始阅读" : "继续阅读") { books.startReading(bookID) }
                    .disabled(books.isReading)
                    .accessibilityIdentifier("book-start-reading")
            } header: {
                Text(book.readCount == 0 ? "还没读" : "读到 \(book.readCount)/\(book.segments.count) 段")
            } footer: {
                Text("用 Flash 每次读几章做笔记，最后用 V4 Pro 整理成档案。按这本书的长度，读完预计约 \(Pricing.label(books.estimatedCost(of: book)))，实际以用量记录为准。" +
                     (books.isReading && !isReading ? "\n另一本书正在读，读完后再开始这本。" : ""))
            }
        }
    }

    @ViewBuilder private func readySections(_ book: Book, _ profile: BookProfile) -> some View {
        Section {
            Button { starting = true } label: {
                Label("选一个人物开聊", systemImage: "bubble.left.and.text.bubble.right")
            }
            .disabled(!store.hasKey || store.isGenerating)
            .accessibilityIdentifier("book-start-story")
        } footer: {
            if !profile.summary.isEmpty { Text(profile.summary) }
        }
        Section("人物") {
            ForEach(profile.characters) { character in
                NavigationLink {
                    CharacterEditView(bookID: bookID, character: character)
                } label: {
                    VStack(alignment: .leading, spacing: 2) {
                        Text(character.name)
                        if !character.identity.isEmpty {
                            Text(character.identity).font(TypeScale.tiny).foregroundStyle(Ink.ink3).lineLimit(2)
                        }
                    }
                }
            }
        }
        Section {
            NavigationLink { StyleEditView(bookID: bookID, text: profile.style.description) } label: {
                Text(profile.style.description.isEmpty ? "还没有文风描述" : profile.style.description)
                    .font(TypeScale.label).foregroundStyle(Ink.ink2).lineLimit(4)
            }
            ForEach(Array(profile.style.excerpts.enumerated()), id: \.offset) { _, excerpt in
                Text(excerpt).font(TypeScale.label).foregroundStyle(Ink.ink3)
            }
        } header: { Text("作者笔触") } footer: { Text("聊天时会带上这段描述和几段原文，让回答更像原著。") }
        if !profile.scenes.isEmpty {
            Section("名场面") {
                ForEach(profile.scenes) { scene in
                    VStack(alignment: .leading, spacing: 4) {
                        HStack {
                            Text(scene.title)
                            Spacer()
                            Text(book.chapterLabel(scene.chapter)).font(TypeScale.tiny).foregroundStyle(Ink.ink3).lineLimit(1)
                        }
                        Text(scene.summary).font(TypeScale.tiny).foregroundStyle(Ink.ink3)
                    }.padding(.vertical, 2)
                }
            }
        }
    }
}

// One character's card, editable. Changes apply to conversations from the next answer on.
@MainActor
struct CharacterEditView: View {
    @EnvironmentObject private var books: BookStore
    @Environment(\.dismiss) private var dismiss
    let bookID: UUID
    let originalName: String
    @State private var draft: BookCharacter

    init(bookID: UUID, character: BookCharacter) {
        self.bookID = bookID
        self.originalName = character.name
        _draft = State(initialValue: character)
    }

    var body: some View {
        Form {
            Section("名字") {
                TextField("名字", text: $draft.name)
                TextField("其他称呼，用顿号隔开", text: Binding(
                    get: { draft.aliases.joined(separator: "、") },
                    set: { draft.aliases = $0.components(separatedBy: CharacterSet(charactersIn: "、,，")).map { $0.trimmingCharacters(in: .whitespaces) }.filter { !$0.isEmpty } }))
            }
            field("身份", $draft.identity)
            field("性格", $draft.personality)
            field("说话方式", $draft.speech)
            field("人物关系", $draft.relationships)
            Section {
                TextField("经历", text: $draft.arc, axis: .vertical).lineLimit(3...12)
            } header: { Text("经历") } footer: { Text("全书的经历会一起发给模型。不想让人物知道后面的事，可以删掉后半部分。") }
            if !draft.quotes.isEmpty {
                Section("原著台词") {
                    ForEach(Array(draft.quotes.enumerated()), id: \.offset) { _, quote in
                        Text("「\(quote.text)」").font(TypeScale.label).foregroundStyle(Ink.ink2)
                    }
                    .onDelete { draft.quotes.remove(atOffsets: $0) }
                }
            }
        }
        .font(TypeScale.body)
        .tint(Ink.seal)
        .scrollContentBackground(.hidden)
        .background(AppBackground())
        .navigationTitle(originalName)
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button("保存") { books.updateCharacter(draft, originalName: originalName, in: bookID); dismiss() }
                    .disabled(draft.name.trimmingCharacters(in: .whitespaces).isEmpty)
            }
        }
    }

    private func field(_ title: String, _ text: Binding<String>) -> some View {
        Section(title) { TextField(title, text: text, axis: .vertical).lineLimit(2...10) }
    }
}

@MainActor
struct StyleEditView: View {
    @EnvironmentObject private var books: BookStore
    @Environment(\.dismiss) private var dismiss
    let bookID: UUID
    @State var text: String

    var body: some View {
        Form {
            Section {
                TextField("作者笔触", text: $text, axis: .vertical).lineLimit(6...20)
            } footer: { Text("写成可以照着写的要求，例如叙述视角、句子长短、对白的写法。") }
        }
        .font(TypeScale.body)
        .scrollContentBackground(.hidden)
        .background(AppBackground())
        .navigationTitle("作者笔触")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button("保存") { books.updateStyle(text, in: bookID); dismiss() }
            }
        }
    }
}

// Pick who to talk with, who you are, where it starts and how to play.
@MainActor
struct StartStoryView: View {
    @EnvironmentObject private var store: AppStore
    @EnvironmentObject private var books: BookStore
    @Environment(\.dismiss) private var dismiss
    let book: Book
    let profile: BookProfile
    var initialChapter: Int? = nil
    var initialOpening = ""
    let opened: () -> Void
    @State private var character = ""
    @State private var userRole = ""
    @State private var personaID: UUID?
    @State private var opening = ""
    @State private var chapter: Int?
    @State private var instruction = ""
    @State private var guests: [StoryGuest] = []
    @State private var managingPersonas = false
    @State private var starting = false
    @State private var prepared = false

    private var otherBooks: [Book] { books.books.filter { $0.id != book.id && $0.isReady } }
    private var chosenPersona: PersonaCard? {
        guard let personaID, let card = books.personas.first(where: { $0.id == personaID }),
              card.name == userRole.trimmingCharacters(in: .whitespacesAndNewlines) else { return nil }
        return card
    }

    var body: some View {
        NavigationStack {
            Form {
                Section("和谁聊") {
                    Picker("人物", selection: $character) {
                        ForEach(profile.characters) { Text($0.name).tag($0.name) }
                    }
                    .accessibilityIdentifier("story-character")
                }
                Section {
                    Picker("从哪里开始", selection: $chapter) {
                        Text("不限定").tag(Int?.none)
                        ForEach(book.chapterTitles.indices, id: \.self) { index in
                            Text(book.chapterTitles[index]).tag(Optional(index))
                        }
                    }
                    .pickerStyle(.navigationLink)
                    if !profile.scenes.isEmpty {
                        Menu("从名场面开始") {
                            ForEach(profile.scenes) { scene in
                                Button(scene.title) {
                                    chapter = scene.chapter
                                    opening = "从原著「\(scene.title)」这一段开始：\(scene.summary)"
                                }
                            }
                        }
                    }
                } header: { Text("时间点") } footer: {
                    Text(chapter == nil ? "不限定时，人物知道全书发生的事。" :
                            "开聊前先写一段到这一章为止的前情提要，放在对话最上面给你看；人物只知道这之前的事，不会说漏后面的剧情。")
                }
                Section {
                    TextField("例如：贾宝玉，或「一个刚进府的小丫鬟」", text: $userRole, axis: .vertical).lineLimit(1...3)
                    Menu("从书中人物里选") {
                        ForEach(profile.characters.filter { $0.name != character }) { person in
                            Button(person.name) { userRole = person.name; personaID = nil }
                        }
                    }
                    Menu("我的人物卡") {
                        ForEach(books.personas) { card in
                            Button(card.name) { userRole = card.name; personaID = card.id }
                        }
                        Divider()
                        Button("管理人物卡…", systemImage: "person.crop.square") { managingPersonas = true }
                    }
                } header: { Text("你扮演谁") } footer: {
                    if let card = chosenPersona { Text(card.detail).lineLimit(4) } else { Text("留空就是你自己。") }
                }
                Section {
                    TextField("例如：元宵节夜里，在大观园", text: $opening, axis: .vertical).lineLimit(2...6)
                } header: { Text("开场（可选）") } footer: { Text("写时间、地点或发生了什么。留空就由人物自己开场。") }
                Section {
                    ForEach(guests, id: \.self) { guest in
                        VStack(alignment: .leading, spacing: 2) {
                            Text(guest.character)
                            Text("来自《\(guest.bookTitle)》").font(TypeScale.tiny).foregroundStyle(Ink.ink3)
                        }
                    }
                    .onDelete { guests.remove(atOffsets: $0) }
                    Menu("加一位客串人物") {
                        ForEach(otherBooks) { other in
                            Menu("《\(other.title)》") {
                                ForEach(other.profile?.characters ?? []) { person in
                                    Button(person.name) { addGuest(person.name, from: other) }
                                }
                            }
                        }
                    }
                    .disabled(otherBooks.isEmpty || guests.count >= 3)
                } header: { Text("客串人物（可选）") } footer: {
                    Text(otherBooks.isEmpty ? "书架上再读完一本书，就能把那本书里的人物带进来。" : "从别的书里请人物过来，由模型一起扮演，最多 3 位。左滑可移除。")
                }
                Section {
                    TextField("例如：用小说的笔法写，多写环境和心理描写；每次回复末尾加一行状态：时间 / 地点 / 好感度", text: $instruction, axis: .vertical)
                        .lineLimit(3...10)
                } header: { Text("本局玩法（可选）") } footer: { Text("写给模型的规矩，这一局一直有效，优先于其他设定。聊天时可以在标题旁的「⋯ → 本局设定」里修改。") }
            }
            .font(TypeScale.body)
            .tint(Ink.seal)
            .scrollContentBackground(.hidden)
            .background(AppBackground())
            .disabled(starting)
            .overlay {
                if starting {
                    VStack(spacing: 12) {
                        ProgressView()
                        Text(chapter == nil ? "正在开局…" : "正在写前情提要…").font(TypeScale.label).foregroundStyle(Ink.ink2)
                    }
                    .padding(24)
                    .background(Ink.raised, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                }
            }
            .navigationTitle("《\(book.title)》")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) { Button("取消") { dismiss() }.disabled(starting) }
                ToolbarItem(placement: .topBarTrailing) {
                    Button("开聊") { start() }
                        .disabled(character.isEmpty || store.isGenerating || starting)
                }
            }
            .sheet(isPresented: $managingPersonas) {
                PersonaListView().environmentObject(books)
            }
            .bookAlerts(store, books)
        }
        .tint(Ink.ink)
        .onAppear {
            guard !prepared else { return }
            prepared = true
            character = profile.characters.first?.name ?? ""
            chapter = initialChapter
            opening = initialOpening
        }
    }

    private func addGuest(_ name: String, from other: Book) {
        let guest = StoryGuest(bookID: other.id, bookTitle: other.title, character: name)
        if !guests.contains(guest) && guests.count < 3 { guests.append(guest) }
    }

    private func start() {
        let setup = AppStore.StorySetup(bookID: book.id, character: character, userRole: userRole,
                                        userCard: chosenPersona?.detail, opening: opening, chapter: chapter,
                                        instruction: instruction, guests: guests)
        starting = true
        Task {
            let ok = await store.startStory(setup)
            starting = false
            if ok { dismiss(); opened() }
        }
    }
}

// MARK: Your own characters

@MainActor
struct PersonaListView: View {
    @EnvironmentObject private var books: BookStore
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            List {
                if books.personas.isEmpty {
                    Text("把你常用的原创人物存在这里：名字、外貌、身份、性格、说话方式。开局时在「你扮演谁 → 我的人物卡」里一点就带上，任何一本书都能用。")
                        .font(TypeScale.serif(15)).foregroundStyle(Ink.ink3).listRowBackground(Color.clear)
                }
                ForEach(books.personas) { card in
                    NavigationLink {
                        PersonaEditView(card: card)
                    } label: {
                        VStack(alignment: .leading, spacing: 3) {
                            Text(card.name).font(TypeScale.serif(17)).foregroundStyle(Ink.ink)
                            Text(card.detail).font(TypeScale.tiny).foregroundStyle(Ink.ink3).lineLimit(2)
                        }.padding(.vertical, 4)
                    }
                    .listRowBackground(Color.clear)
                }
                .onDelete { books.deletePersonas(at: $0) }
            }
            .listStyle(.plain)
            .scrollContentBackground(.hidden)
            .background(AppBackground())
            .navigationTitle("我的人物卡")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) { Button("完成") { dismiss() } }
                ToolbarItem(placement: .topBarTrailing) {
                    NavigationLink { PersonaEditView(card: PersonaCard(name: "", detail: "")) } label: { Image(systemName: "plus") }
                        .accessibilityLabel("新建人物卡")
                }
            }
        }
        .tint(Ink.ink)
    }
}

@MainActor
struct PersonaEditView: View {
    @EnvironmentObject private var books: BookStore
    @Environment(\.dismiss) private var dismiss
    @State private var draft: PersonaCard

    init(card: PersonaCard) { _draft = State(initialValue: card) }

    var body: some View {
        Form {
            Section("名字") { TextField("名字", text: $draft.name) }
            Section {
                TextField("外貌、身份、性格、说话方式，和这个世界有什么关系…", text: $draft.detail, axis: .vertical).lineLimit(5...16)
            } header: { Text("人物卡") } footer: { Text("开局时会作为「你扮演的人物」一起发给模型。") }
        }
        .font(TypeScale.body)
        .tint(Ink.seal)
        .scrollContentBackground(.hidden)
        .background(AppBackground())
        .navigationTitle(draft.name.isEmpty ? "新人物卡" : draft.name)
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button("保存") { books.savePersona(draft); dismiss() }
                    .disabled(draft.name.trimmingCharacters(in: .whitespaces).isEmpty)
            }
        }
    }
}

// MARK: Reading the text

private struct StartPoint: Identifiable {
    let id = UUID()
    let chapter: Int
    let opening: String
}

@MainActor
struct ChapterListView: View {
    @EnvironmentObject private var books: BookStore
    let bookID: UUID
    let opened: () -> Void

    var body: some View {
        let titles = books.book(bookID)?.chapterTitles ?? []
        List(titles.indices, id: \.self) { index in
            NavigationLink {
                ChapterReaderView(bookID: bookID, chapter: index, opened: opened)
            } label: {
                HStack(alignment: .firstTextBaseline, spacing: 12) {
                    Text("\(index + 1)").font(TypeScale.tiny).monospacedDigit().foregroundStyle(Ink.ink3).frame(minWidth: 28, alignment: .trailing)
                    Text(titles[index]).font(TypeScale.serif(16)).foregroundStyle(Ink.ink).lineLimit(1)
                }
            }
            .listRowBackground(Color.clear)
        }
        .listStyle(.plain)
        .scrollContentBackground(.hidden)
        .background(AppBackground())
        .navigationTitle("目录")
        .navigationBarTitleDisplayMode(.inline)
    }
}

// One chapter of the original. Long-press a paragraph to start a story right there.
@MainActor
struct ChapterReaderView: View {
    @EnvironmentObject private var store: AppStore
    @EnvironmentObject private var books: BookStore
    let bookID: UUID
    let opened: () -> Void
    @State private var chapter: Int
    @State private var startPoint: StartPoint?

    init(bookID: UUID, chapter: Int, opened: @escaping () -> Void) {
        self.bookID = bookID
        self.opened = opened
        _chapter = State(initialValue: chapter)
    }

    private var book: Book? { books.book(bookID) }
    private var paragraphs: [String] {
        let chapters = books.chapters(of: bookID)
        guard chapters.indices.contains(chapter) else { return [] }
        return chapters[chapter].text.components(separatedBy: "\n").filter { !$0.trimmingCharacters(in: .whitespaces).isEmpty }
    }

    var body: some View {
        let count = book?.chapterTitles.count ?? 0
        ScrollViewReader { reader in
            ScrollView {
                LazyVStack(alignment: .leading, spacing: 14) {
                    Text(book?.chapterLabel(chapter) ?? "").font(TypeScale.subject).foregroundStyle(Ink.ink).id("top")
                    if book?.isReady == true {
                        Text("长按任意一段，可以从这里开始演。").font(TypeScale.tiny).foregroundStyle(Ink.ink3)
                    }
                    ForEach(Array(paragraphs.enumerated()), id: \.offset) { _, paragraph in
                        Text(paragraph).font(TypeScale.answer).foregroundStyle(Ink.ink).lineSpacing(6)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .contentShape(Rectangle())
                            .contextMenu {
                                if book?.isReady == true {
                                    Button("从这里开始演", systemImage: "play") {
                                        startPoint = StartPoint(chapter: chapter, opening: "从原著这一段开始：「\(paragraph.prefix(240))」")
                                    }
                                }
                                Button("复制", systemImage: "doc.on.doc") { UIPasteboard.general.string = paragraph }
                            }
                    }
                    HStack {
                        Button("上一章") { chapter -= 1; reader.scrollTo("top", anchor: .top) }.disabled(chapter <= 0)
                        Spacer()
                        Button("下一章") { chapter += 1; reader.scrollTo("top", anchor: .top) }.disabled(chapter + 1 >= count)
                    }
                    .font(TypeScale.body).padding(.vertical, 20)
                }
                .padding(.horizontal, 22).padding(.vertical, 12)
            }
        }
        .background(AppBackground())
        .navigationTitle("\(chapter + 1) / \(count)")
        .navigationBarTitleDisplayMode(.inline)
        .sheet(item: $startPoint) { point in
            if let book, let profile = book.profile {
                StartStoryView(book: book, profile: profile, initialChapter: point.chapter, initialOpening: point.opening) { opened() }
                    .environmentObject(store).environmentObject(books)
            }
        }
    }
}

// MARK: This game's settings, while playing

@MainActor
struct StorySettingsSheet: View {
    @EnvironmentObject private var store: AppStore
    @Environment(\.dismiss) private var dismiss
    let threadID: UUID
    @State private var instruction = ""
    @State private var briefing = ""
    @State private var loaded = false
    private var session: StorySession? { store.threads.first(where: { $0.id == threadID })?.story }

    var body: some View {
        NavigationStack {
            Form {
                if let session {
                    Section {
                        LabeledContent("书", value: "《\(session.bookTitle)》")
                        LabeledContent("人物", value: ([session.character] + (session.guests ?? []).map(\.character)).joined(separator: "、"))
                        LabeledContent("你扮演", value: session.userRole.isEmpty ? "你自己" : session.userRole)
                        LabeledContent("时间点", value: session.chapterTitle ?? "不限定")
                    }
                    Section {
                        TextField("例如：用小说的笔法写；每次回复末尾加一行状态栏", text: $instruction, axis: .vertical).lineLimit(3...12)
                    } header: { Text("本局玩法") } footer: { Text("保存后从下一条回答开始生效。") }
                    if session.briefing != nil {
                        Section {
                            TextField("前情提要", text: $briefing, axis: .vertical).lineLimit(4...20)
                        } header: { Text("前情提要") } footer: { Text("模型按这段理解人物此刻的处境，可以手动修正。对话顶部显示的是开局时的版本。") }
                    }
                }
            }
            .font(TypeScale.body)
            .tint(Ink.seal)
            .scrollContentBackground(.hidden)
            .background(AppBackground())
            .navigationTitle("本局设定")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) { Button("取消") { dismiss() } }
                ToolbarItem(placement: .topBarTrailing) {
                    Button("保存") {
                        store.updateStory(threadID: threadID, instruction: instruction, briefing: session?.briefing == nil ? nil : briefing)
                        dismiss()
                    }
                }
            }
        }
        .tint(Ink.ink)
        .onAppear {
            guard !loaded, let session else { return }
            loaded = true
            instruction = session.instruction ?? ""
            briefing = session.briefing ?? ""
        }
    }
}
