import SwiftUI
import UniformTypeIdentifiers

private extension View {
    // Both stores report errors; show whichever has one.
    func bookAlerts(_ store: AppStore, _ books: BookStore) -> some View {
        alert("暂时没有完成", isPresented: Binding(get: { books.errorMessage != nil || store.errorMessage != nil },
                                              set: { if !$0 { books.errorMessage = nil; store.errorMessage = nil } })) {
            Button("知道了") { books.errorMessage = nil; store.errorMessage = nil }
        } message: { Text(books.errorMessage ?? store.errorMessage ?? "") }
    }
}

// The bookshelf: import a novel as TXT, let it be read once, then talk with its people.
@MainActor
struct BookshelfView: View {
    @EnvironmentObject private var store: AppStore
    @EnvironmentObject private var books: BookStore
    @Environment(\.dismiss) private var dismiss
    let opened: () -> Void
    @State private var path: [UUID] = []

    var body: some View {
        NavigationStack(path: $path) {
            List {
                if books.books.isEmpty {
                    VStack(alignment: .leading, spacing: 16) {
                        Text("导入一本小说的 TXT 文件，Sermo 会分段读完全书，整理出人物档案、作者笔触和名场面。读完之后，选一个人物就能开聊。")
                            .font(TypeScale.serif(15)).foregroundStyle(Ink.ink3)
                        Button { pickBook() } label: { Label("导入 TXT", systemImage: "doc.badge.plus") }
                            .buttonStyle(.borderless)
                            .accessibilityIdentifier("book-import")
                    }
                    .padding(.vertical, 8)
                    .listRowBackground(Color.clear)
                }
                ForEach(books.books) { book in
                    NavigationLink(value: book.id) {
                        HStack(spacing: 14) {
                            Image(systemName: book.isReady ? "book.closed" : "book").font(.system(size: 17))
                                .foregroundStyle(Ink.ink2).frame(width: 24)
                            VStack(alignment: .leading, spacing: 3) {
                                Text(book.title).font(TypeScale.serif(17)).foregroundStyle(Ink.ink).lineLimit(1)
                                Text(BookStatusText.short(book, reading: books.readingBookID == book.id))
                                    .font(TypeScale.tiny).foregroundStyle(Ink.ink3)
                            }
                        }.padding(.vertical, 6)
                    }
                    .listRowBackground(Color.clear)
                    .accessibilityIdentifier("book-row")
                }
            }
            .listStyle(.plain)
            .scrollContentBackground(.hidden)
            .background(AppBackground())
            .navigationTitle("书架")
            .toolbar {
                ToolbarItem(placement: .topBarLeading) { Button("完成") { dismiss() } }
                ToolbarItem(placement: .topBarTrailing) {
                    Button { pickBook() } label: { Image(systemName: "plus") }.accessibilityLabel("导入小说")
                }
            }
            .navigationDestination(for: UUID.self) { id in BookDetailView(bookID: id, opened: opened) }
            .bookAlerts(store, books)
        }
        .tint(Ink.ink)
    }

    // SwiftUI's .fileImporter does not open from this sheet while the chat page
    // underneath has one of its own, so the system picker is presented directly.
    private func pickBook() {
        DocumentPicker.present([.plainText, .text, UTType(filenameExtension: "txt") ?? .plainText]) { url in
            if let id = books.importBook(from: url) { path.append(id) }
        }
    }
}

enum BookStatusText {
    static func short(_ book: Book, reading: Bool) -> String {
        let size = "\(wan(book.characterCount)) · \(book.chapterTitles.count) 章"
        if reading { return size + " · 正在读 \(book.readCount)/\(book.segments.count)" }
        switch book.status {
        case .ready: return size + " · \(book.profile?.characters.count ?? 0) 个人物"
        case .failed: return size + " · 没有读完"
        case .reading, .imported:
            return size + (book.readCount == 0 ? " · 还没读" : " · 读到 \(book.readCount)/\(book.segments.count)")
        }
    }
    static func wan(_ count: Int) -> String {
        count >= 10000 ? String(format: "%.1f 万字", Double(count) / 10000) : "\(count) 字"
    }
}

@MainActor
struct BookDetailView: View {
    @EnvironmentObject private var store: AppStore
    @EnvironmentObject private var books: BookStore
    @Environment(\.dismiss) private var dismiss
    let bookID: UUID
    let opened: () -> Void
    @State private var starting = false
    @State private var renaming = false
    @State private var renameText = ""
    @State private var confirmDelete = false
    @State private var confirmReset = false
    private var book: Book? { books.book(bookID) }
    private var isReading: Bool { books.readingBookID == bookID }

    var body: some View {
        Form {
            if let book {
                Section {
                    LabeledContent("字数", value: BookStatusText.wan(book.characterCount))
                    LabeledContent("章节", value: "\(book.chapterTitles.count) 章，分 \(book.segments.count) 段读")
                    if let cost = book.cost {
                        LabeledContent("已花费", value: Pricing.label(cost) + "（估算）")
                    }
                }
                readingSection(book)
                if let profile = book.profile, book.isReady { readySections(book, profile) }
            }
        }
        .font(TypeScale.body)
        .tint(Ink.seal)
        .scrollContentBackground(.hidden)
        .background(AppBackground())
        .navigationTitle(book?.title ?? "书")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Menu {
                    Button("重命名", systemImage: "pencil") { renameText = book?.title ?? ""; renaming = true }
                    if book?.readCount == book?.segments.count && book?.segments.isEmpty == false {
                        Button("重新整理档案", systemImage: "arrow.triangle.2.circlepath") { books.rebuildProfile(bookID) }
                            .disabled(books.isReading)
                    }
                    if (book?.readCount ?? 0) > 0 {
                        Button("从头重读", systemImage: "arrow.counterclockwise") { confirmReset = true }.disabled(books.isReading)
                    }
                    Button("从书架删除", systemImage: "trash", role: .destructive) { confirmDelete = true }
                } label: { Image(systemName: "ellipsis") }
                .accessibilityLabel("书的选项")
            }
        }
        .alert("重命名", isPresented: $renaming) {
            TextField("书名", text: $renameText)
            Button("取消", role: .cancel) { }
            Button("保存") { books.rename(bookID, to: renameText) }
        }
        .alert("从书架删除这本书？", isPresented: $confirmDelete) {
            Button("取消", role: .cancel) { }
            Button("删除", role: .destructive) { books.delete(bookID); dismiss() }
        } message: { Text("会删除正文、读书笔记和人物档案。已经开始的对话会保留，但之后不再带档案。") }
        .alert("从头重读？", isPresented: $confirmReset) {
            Button("取消", role: .cancel) { }
            Button("清空并重读", role: .destructive) { books.resetReading(bookID) }
        } message: { Text("会清空已有的读书笔记和人物档案（包括你手动改过的内容），之后需要重新阅读，会再次产生费用。") }
        .sheet(isPresented: $starting) {
            if let book, let profile = book.profile {
                StartStoryView(book: book, profile: profile) { opened() }
                    .environmentObject(store).environmentObject(books)
            }
        }
        .bookAlerts(store, books)
    }

    @ViewBuilder private func readingSection(_ book: Book) -> some View {
        let total = max(1, book.segments.count)
        if isReading {
            Section {
                ProgressView(value: Double(book.readCount), total: Double(total))
                Text(book.readCount == book.segments.count ? "全书读完了，正在整理人物档案…" : "正在读第 \(book.readCount + 1) 段，共 \(book.segments.count) 段")
                    .font(TypeScale.label).foregroundStyle(Ink.ink2)
                Button("暂停") { books.pause() }
            } footer: {
                Text("读的时候请让 Sermo 留在前台。切到后台一会儿后会暂停，读过的部分不会丢，回来点「继续阅读」即可。")
            }
        } else if !book.isReady {
            Section {
                if let issue = book.issue {
                    Text(issue).font(TypeScale.label).foregroundStyle(Ink.ink2)
                }
                if book.readCount > 0 {
                    ProgressView(value: Double(book.readCount), total: Double(total))
                }
                Button(book.readCount == 0 ? "开始阅读" : "继续阅读") { books.startReading(bookID) }
                    .disabled(books.isReading)
                    .accessibilityIdentifier("book-start-reading")
            } header: {
                Text(book.readCount == 0 ? "还没读" : "读到 \(book.readCount)/\(book.segments.count) 段")
            } footer: {
                Text("用 Flash 每次读几章做笔记，最后用 V4 Pro 整理成档案。按这本书的长度，读完预计约 \(Pricing.label(books.estimatedCost(of: book)))，实际以用量记录为准。" +
                     (books.isReading && !isReading ? "\n另一本书正在读，读完后再开始这本。" : ""))
            }
        }
    }

    @ViewBuilder private func readySections(_ book: Book, _ profile: BookProfile) -> some View {
        Section {
            Button { starting = true } label: {
                Label("选一个人物开聊", systemImage: "bubble.left.and.text.bubble.right")
            }
            .disabled(!store.hasKey || store.isGenerating)
            .accessibilityIdentifier("book-start-story")
        } footer: {
            if !profile.summary.isEmpty { Text(profile.summary) }
        }
        Section("人物") {
            ForEach(profile.characters) { character in
                NavigationLink {
                    CharacterEditView(bookID: bookID, character: character)
                } label: {
                    VStack(alignment: .leading, spacing: 2) {
                        Text(character.name)
                        if !character.identity.isEmpty {
                            Text(character.identity).font(TypeScale.tiny).foregroundStyle(Ink.ink3).lineLimit(2)
                        }
                    }
                }
            }
        }
        Section {
            NavigationLink { StyleEditView(bookID: bookID, text: profile.style.description) } label: {
                Text(profile.style.description.isEmpty ? "还没有文风描述" : profile.style.description)
                    .font(TypeScale.label).foregroundStyle(Ink.ink2).lineLimit(4)
            }
            ForEach(Array(profile.style.excerpts.enumerated()), id: \.offset) { _, excerpt in
                Text(excerpt).font(TypeScale.label).foregroundStyle(Ink.ink3)
            }
        } header: { Text("作者笔触") } footer: { Text("聊天时会带上这段描述和几段原文，让回答更像原著。") }
        if !profile.scenes.isEmpty {
            Section("名场面") {
                ForEach(profile.scenes) { scene in
                    VStack(alignment: .leading, spacing: 4) {
                        HStack {
                            Text(scene.title)
                            Spacer()
                            Text(book.chapterLabel(scene.chapter)).font(TypeScale.tiny).foregroundStyle(Ink.ink3).lineLimit(1)
                        }
                        Text(scene.summary).font(TypeScale.tiny).foregroundStyle(Ink.ink3)
                    }.padding(.vertical, 2)
                }
            }
        }
    }
}

// One character's card, editable. Changes apply to conversations from the next answer on.
@MainActor
struct CharacterEditView: View {
    @EnvironmentObject private var books: BookStore
    @Environment(\.dismiss) private var dismiss
    let bookID: UUID
    let originalName: String
    @State private var draft: BookCharacter

    init(bookID: UUID, character: BookCharacter) {
        self.bookID = bookID
        self.originalName = character.name
        _draft = State(initialValue: character)
    }

    var body: some View {
        Form {
            Section("名字") {
                TextField("名字", text: $draft.name)
                TextField("其他称呼，用顿号隔开", text: Binding(
                    get: { draft.aliases.joined(separator: "、") },
                    set: { draft.aliases = $0.components(separatedBy: CharacterSet(charactersIn: "、,，")).map { $0.trimmingCharacters(in: .whitespaces) }.filter { !$0.isEmpty } }))
            }
            field("身份", $draft.identity)
            field("性格", $draft.personality)
            field("说话方式", $draft.speech)
            field("人物关系", $draft.relationships)
            Section {
                TextField("经历", text: $draft.arc, axis: .vertical).lineLimit(3...12)
            } header: { Text("经历") } footer: { Text("全书的经历会一起发给模型。不想让人物知道后面的事，可以删掉后半部分。") }
            if !draft.quotes.isEmpty {
                Section("原著台词") {
                    ForEach(Array(draft.quotes.enumerated()), id: \.offset) { _, quote in
                        Text("「\(quote.text)」").font(TypeScale.label).foregroundStyle(Ink.ink2)
                    }
                    .onDelete { draft.quotes.remove(atOffsets: $0) }
                }
            }
        }
        .font(TypeScale.body)
        .tint(Ink.seal)
        .scrollContentBackground(.hidden)
        .background(AppBackground())
        .navigationTitle(originalName)
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button("保存") { books.updateCharacter(draft, originalName: originalName, in: bookID); dismiss() }
                    .disabled(draft.name.trimmingCharacters(in: .whitespaces).isEmpty)
            }
        }
    }

    private func field(_ title: String, _ text: Binding<String>) -> some View {
        Section(title) { TextField(title, text: text, axis: .vertical).lineLimit(2...10) }
    }
}

@MainActor
struct StyleEditView: View {
    @EnvironmentObject private var books: BookStore
    @Environment(\.dismiss) private var dismiss
    let bookID: UUID
    @State var text: String

    var body: some View {
        Form {
            Section {
                TextField("作者笔触", text: $text, axis: .vertical).lineLimit(6...20)
            } footer: { Text("写成可以照着写的要求，例如叙述视角、句子长短、对白的写法。") }
        }
        .font(TypeScale.body)
        .scrollContentBackground(.hidden)
        .background(AppBackground())
        .navigationTitle("作者笔触")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button("保存") { books.updateStyle(text, in: bookID); dismiss() }
            }
        }
    }
}

// Pick who to talk with, who you are, and optionally where it starts.
@MainActor
struct StartStoryView: View {
    @EnvironmentObject private var store: AppStore
    @Environment(\.dismiss) private var dismiss
    let book: Book
    let profile: BookProfile
    let opened: () -> Void
    @State private var character = ""
    @State private var userRole = ""
    @State private var opening = ""

    var body: some View {
        NavigationStack {
            Form {
                Section("和谁聊") {
                    Picker("人物", selection: $character) {
                        ForEach(profile.characters) { Text($0.name).tag($0.name) }
                    }
                    .accessibilityIdentifier("story-character")
                }
                Section {
                    TextField("例如：贾宝玉，或「一个刚进府的小丫鬟」", text: $userRole, axis: .vertical).lineLimit(1...3)
                    Menu("从书中人物里选") {
                        ForEach(profile.characters.filter { $0.name != character }) { person in
                            Button(person.name) { userRole = person.name }
                        }
                    }
                } header: { Text("你扮演谁") } footer: { Text("留空就是你自己。") }
                Section {
                    TextField("例如：元宵节夜里，在大观园", text: $opening, axis: .vertical).lineLimit(2...6)
                    if !profile.scenes.isEmpty {
                        Menu("从名场面开始") {
                            ForEach(profile.scenes) { scene in
                                Button(scene.title) { opening = "从原著「\(scene.title)」这一段开始：\(scene.summary)" }
                            }
                        }
                    }
                } header: { Text("开场（可选）") } footer: { Text("写时间、地点或发生了什么。留空就由人物自己开场。") }
            }
            .font(TypeScale.body)
            .tint(Ink.seal)
            .scrollContentBackground(.hidden)
            .background(AppBackground())
            .navigationTitle("《\(book.title)》")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) { Button("取消") { dismiss() } }
                ToolbarItem(placement: .topBarTrailing) {
                    Button("开聊") {
                        if store.startStory(bookID: book.id, character: character, userRole: userRole, opening: opening) {
                            dismiss()
                            opened()
                        }
                    }
                    .disabled(character.isEmpty || store.isGenerating)
                }
            }
        }
        .tint(Ink.ink)
        .onAppear { if character.isEmpty { character = profile.characters.first?.name ?? "" } }
    }
}
