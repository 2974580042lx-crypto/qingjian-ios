import SwiftUI

// Every feature and where to find it, from the same text as the manual project.
// Reading this costs nothing; asking the manual project goes to the model.
@MainActor
struct FeatureOverviewView: View {
    @EnvironmentObject private var store: AppStore
    var body: some View {
        List {
            Section {
                if store.manualDismissed {
                    Button("恢复「\(AppManual.projectName)」项目") { store.restoreManualProject() }
                } else {
                    Text("想用聊天的方式问，可以在侧栏的项目里打开「\(AppManual.projectName)」。")
                        .font(TypeScale.serif(14)).foregroundStyle(Ink.ink2)
                }
            }
            ForEach(AppManual.sections, id: \.title) { section in
                Section(section.title) {
                    ForEach(section.items, id: \.name) { item in
                        VStack(alignment: .leading, spacing: 4) {
                            Text(item.name).font(TypeScale.serif(16).weight(.semibold)).foregroundStyle(Ink.ink)
                            Text(item.how).font(TypeScale.serif(14)).foregroundStyle(Ink.ink2)
                                .fixedSize(horizontal: false, vertical: true)
                        }
                        .padding(.vertical, 4)
                    }
                }
            }
        }
        .scrollContentBackground(.hidden)
        .background(AppBackground())
        .listRowBackground(Color.clear)
        .navigationTitle("功能一览")
        .navigationBarTitleDisplayMode(.inline)
    }
}
