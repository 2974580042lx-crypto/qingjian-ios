import SwiftUI
import UniformTypeIdentifiers

// Google account for the Drive tools. Sign-in acts at once, like the ChatGPT section.
@MainActor
struct GoogleDriveSection: View {
    @ObservedObject var drive: GoogleDriveStore
    var body: some View {
        Section {
            LabeledContent("账号", value: drive.accountLabel)
                .accessibilityIdentifier("google-account")
            if drive.signingIn {
                HStack { ProgressView(); Text("请在谷歌页面登录并允许访问云盘").font(TypeScale.serif(16)) }
                Button("取消登录") { drive.cancelSignIn() }
            } else {
                Button(drive.connected ? "重新登录谷歌" : "用 Google 登录") { drive.signIn() }
                    .accessibilityIdentifier("google-sign-in")
            }
            if drive.needsSignIn && !drive.connected {
                Text("登录已过期，请重新登录。测试状态的谷歌应用大约每 7 天需要登录一次。")
                    .font(TypeScale.serif(13)).foregroundStyle(.secondary)
            }
            if let issue = drive.issue { Text(issue).font(TypeScale.serif(14)) }
            if drive.connected {
                Button("退出谷歌账号", role: .destructive) { drive.signOut() }
            }
        } header: { Text("谷歌云盘") } footer: {
            Text("在项目「⋯」里打开「谷歌云盘工具」后，这个项目里的对话可以搜索、读取和整理你的云盘。新建、改写、改名、移动和移到回收站都会先请你确认；不会永久删除文件。登录凭证保存在本机钥匙串，不进入聊天备份。")
        }
    }
}

// Daily backup into a folder picked once in the Files app.
@MainActor
struct AutoBackupSection: View {
    @EnvironmentObject private var store: AppStore
    @State private var picking = false
    var body: some View {
        Section {
            if let name = store.backupFolderName {
                LabeledContent("备份到", value: name)
                LabeledContent("上次备份", value: store.lastAutoBackup.map {
                    $0.formatted(date: .abbreviated, time: .shortened)
                } ?? "尚未备份")
                Button("立即备份") { store.autoBackupIfNeeded(force: true) }
                    .disabled(!store.canPersist)
                Button("更换文件夹") { picking = true }
                Button("停止自动备份", role: .destructive) { store.clearBackupFolder() }
            } else {
                Button { picking = true } label: { Label("选择备份文件夹", systemImage: "folder.badge.plus") }
            }
            if let issue = store.backupIssue { Text(issue).font(TypeScale.serif(13)).foregroundStyle(.secondary) }
        } header: { Text("自动备份") } footer: {
            Text("每天第一次打开 Sermo 时，把聊天备份存进你选的文件夹，例如 iCloud 云盘或谷歌云盘里的一个文件夹。只保留最近 7 天的自动备份，旧的会被替换；不含 API Key 和登录凭证。")
        }
        .fileImporter(isPresented: $picking, allowedContentTypes: [.folder]) { result in
            switch result {
            case .success(let url): store.setBackupFolder(url)
            case .failure(let error): store.errorMessage = "无法打开文件夹：\(error.localizedDescription)"
            }
        }
    }
}
