import SwiftUI
import UniformTypeIdentifiers
import UIKit

@MainActor
struct SettingsView: View {
    var embedded = false
    @EnvironmentObject private var store: AppStore
    @EnvironmentObject private var profile: ProfileStore
    @Environment(\.dismiss) private var dismiss
    @State private var draftSettings = AppSettings()
    @State private var draftKey = ""
    @State private var backupURL: URL?
    @State private var showShare = false
    @State private var showImporter = false
    @State private var checkingConnection = false
    @State private var checkedBalance: AccountBalance?
    @State private var connectionError: String?
    @State private var connectionTask: Task<Void, Never>?
    @State private var showKey = false
    @State private var saved = false
    @State private var showProfile = ProcessInfo.processInfo.arguments.contains("--preview-profile")
    @AppStorage("qingjian.reading.serif") private var serif = true
    @AppStorage("qingjian.reading.size") private var readingSize = 18.0
    @AppStorage("qingjian.reading.aiBubble") private var aiBubble = false
    @AppStorage("qingjian.haptics") private var hapticsEnabled = true
    var body: some View {
        NavigationStack {
            Form {
                Section {
                    Button { showProfile = true } label: {
                    HStack(spacing: 14) {
                        ProfileAvatar(image: profile.avatar)
                        VStack(alignment: .leading, spacing: 3) {
                            Text(profile.name).font(.system(size: 23, weight: .semibold))
                            Text(profile.handle.isEmpty ? "编辑个人资料" : "ID：\(profile.handle)").font(.caption).foregroundStyle(.secondary)
                        }
                        Spacer()
                        Image(systemName: "chevron.right").font(.system(size: 12)).foregroundStyle(.secondary)
                    }.padding(.vertical, 6)
                    }.buttonStyle(.plain)
                }.listRowBackground(Color.clear)
                Section {
                    VStack(alignment: .leading, spacing: 8) {
                        Text("API Key").font(.caption).foregroundStyle(.secondary)
                        HStack {
                            Group {
                                if showKey { TextField("粘贴 DeepSeek API Key", text: $draftKey) }
                                else { SecureField("粘贴 DeepSeek API Key", text: $draftKey) }
                            }.textInputAutocapitalization(.never).autocorrectionDisabled()
                            Button { showKey.toggle() } label: { Image(systemName: showKey ? "eye.slash" : "eye") }
                                .buttonStyle(.borderless).accessibilityLabel(showKey ? "隐藏密钥" : "显示密钥")
                        }
                    }
                    Button(action: testConnection) {
                        HStack {
                            Label(checkingConnection ? "正在验证…" : "检查密钥与余额", systemImage: "network")
                            Spacer()
                            if checkingConnection { ProgressView() }
                        }
                    }
                    .disabled(checkingConnection || draftKey.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                    if let balance = checkedBalance {
                        VStack(alignment: .leading, spacing: 6) {
                            Label(balance.isAvailable ? "密钥有效，账户余额可用" : "密钥有效，账户暂无可用余额",
                                  systemImage: balance.isAvailable ? "checkmark.circle.fill" : "exclamationmark.triangle.fill")
                                .foregroundStyle(.white.opacity(0.85))
                            if !balance.summary.isEmpty {
                                Text("账户余额：\(balance.summary)").font(.caption).foregroundStyle(.secondary)
                            }
                            if !balance.isAvailable {
                                Text("请到 DeepSeek 开放平台查看 API 余额。")
                                    .font(.caption).foregroundStyle(.secondary)
                            }
                        }
                    }
                    if let error = connectionError {
                        Label(error, systemImage: "exclamationmark.circle")
                            .font(.callout).foregroundStyle(.white)
                    }
                    Link("打开 DeepSeek 开放平台", destination: URL(string: "https://platform.deepseek.com/")!)
                } header: { Text("连接 DeepSeek") } footer: {
                    Text("测试连接只检查密钥和账户余额，不发送聊天内容。点右上角保存后，Key 才会保存在这台手机的钥匙串里，不随聊天备份导出。聊天时，消息及选定的历史上下文会传给 DeepSeek。")
                }
                Section("回答方式") {
                    Picker("模型", selection: $draftSettings.model) {
                        ForEach(DeepSeekModel.allCases) { model in Text(model.title).tag(model) }
                    }
                    Toggle("深度思考", isOn: $draftSettings.thinkingEnabled)
                    if draftSettings.thinkingEnabled {
                        Picker("思考程度", selection: $draftSettings.effort) {
                            ForEach(ThinkingEffort.allCases) { effort in Text(effort.title).tag(effort) }
                        }
                    }
                    DisclosureGroup("高级设置") {
                    Picker("每次输出上限", selection: $draftSettings.maxOutputTokens) {
                        ForEach([4096, 8192, 16384, 32768, 65536], id: \.self) { value in Text("\(value) tokens").tag(value) }
                    }
                    Picker("携带的历史消息", selection: $draftSettings.contextMessageLimit) {
                        ForEach([10, 20, 40, 80, 100, 200, 400], id: \.self) { value in Text("最近 \(value) 条").tag(value) }
                    }
                    }
                }
                Section("聊天连通性") {
                    ChatConnectionTestView(key: draftKey)
                }
                Section {
                    TextEditor(text: $draftSettings.systemPrompt).frame(minHeight: 150).font(.system(size: 15)).scrollContentBackground(.hidden)
                    HStack {
                        Button("自然聊天") { draftSettings.systemPrompt = AppSettings.defaultPrompt }
                        Spacer()
                        Button("学习讲解") { draftSettings.systemPrompt = AppSettings.learningPrompt }
                    }.font(.system(size: 13)).buttonStyle(.borderless)
                } header: { Text("系统提示词") } footer: {
                    Text("默认携带最近 200 条消息，约 100 轮对话。超长时优先保留最近的完整消息。系统提示词会随每次请求发送，思考原文与译文不占用普通聊天上下文。")
                }
                Section("阅读与外观") {
                    Toggle("侧栏触感反馈", isOn: $hapticsEnabled)
                    Toggle("宋体阅读", isOn: $serif)
                    Toggle("AI 回答使用气泡", isOn: $aiBubble)
                    VStack(alignment: .leading, spacing: 10) {
                        HStack { Text("正文字号"); Spacer(); Text("\(Int(readingSize))").foregroundStyle(.secondary) }
                        Slider(value: $readingSize, in: 15...23, step: 1)
                        Text("字体预览 Aa 123")
                            .readingStyle().padding(.vertical, 10)
                    }
                }
                Section {
                    Button {
                        backupURL = store.exportBackup()
                        showShare = backupURL != nil
                    } label: { Label("导出聊天备份", systemImage: "square.and.arrow.up") }
                    Button { showImporter = true } label: { Label("导入聊天备份", systemImage: "square.and.arrow.down") }
                        .disabled(store.isGenerating || !store.canPersist)
                } header: { Text("记录与备份") } footer: {
                    Text("导入会添加新的对话，已有编号的对话会跳过，不覆盖当前设置。备份包含对话正文与思考内容，请保存在自己的位置。")
                }
                Section {
                    LabeledContent("已保存回答的用量", value: "\(store.totalRecordedTokens) tokens")
                    Link("查看官方模型价格", destination: URL(string: "https://api-docs.deepseek.com/zh-cn/quick_start/pricing/")!)
                    Text("中断时可能没有返回用量，重新生成或删除记录也会影响本地统计；实际扣费以 DeepSeek 开放平台为准。")
                        .font(.caption).foregroundStyle(.secondary)
                } header: { Text("用量") }
                Section {
                    Text("版本 1.3.1")
                    Text("文字聊天、消息编辑、思考翻译与备份。")
                        .font(.caption).foregroundStyle(.secondary)
                }
            }
            .scrollContentBackground(.hidden)
            .background(AppBackground())
            .navigationTitle("设置")
            .toolbar(.visible, for: .tabBar)
            .toolbar {
                if !embedded {
                    ToolbarItem(placement: .topBarLeading) { Button("取消") { dismiss() } }
                }
                ToolbarItem(placement: .topBarTrailing) {
                    Button(saved ? "已保存" : "保存") {
                        if store.saveSettings(draftSettings, key: draftKey) {
                            if embedded { saved = true } else { dismiss() }
                        }
                    }.fontWeight(.semibold)
                }
            }
            .onAppear { draftSettings = store.settings; draftKey = store.apiKey }
            .onChange(of: draftKey) { _, _ in saved = false; resetConnectionCheck() }
            .onChange(of: draftSettings) { _, _ in saved = false }
            .onDisappear { resetConnectionCheck() }
            .sheet(isPresented: $showProfile) { ProfileEditor() }
            .sheet(isPresented: $showShare) {
                if let url = backupURL { ShareSheet(items: [url]) }
            }
            .fileImporter(isPresented: $showImporter, allowedContentTypes: [.json]) { result in
                switch result {
                case .success(let url): store.importBackup(url)
                case .failure(let error): store.errorMessage = "无法打开文件：\(error.localizedDescription)"
                }
            }
            .alert("暂时没有完成", isPresented: Binding(get: { store.errorMessage != nil }, set: { if !$0 { store.errorMessage = nil } })) {
                Button("知道了") { store.errorMessage = nil }
            } message: { Text(store.errorMessage ?? "") }
            .alert("备份导入", isPresented: Binding(get: { store.noticeMessage != nil }, set: { if !$0 { store.noticeMessage = nil } })) {
                Button("完成") { store.noticeMessage = nil }
            } message: { Text(store.noticeMessage ?? "") }
        }
    }

    private func resetConnectionCheck() {
        connectionTask?.cancel()
        connectionTask = nil
        checkingConnection = false
        checkedBalance = nil
        connectionError = nil
    }

    private func testConnection() {
        resetConnectionCheck()
        if store.isPreview { connectionError = "预览模式不连接网络。"; return }
        checkingConnection = true
        let keyToCheck = draftKey
        connectionTask = Task { @MainActor in
            do {
                let balance = try await DeepSeekClient().checkConnection(key: keyToCheck)
                try Task.checkCancellation()
                checkedBalance = balance
                checkingConnection = false
                connectionTask = nil
            } catch {
                guard !Task.isCancelled else { return }
                if let networkError = error as? URLError,
                   networkError.code == .notConnectedToInternet || networkError.code == .networkConnectionLost {
                    connectionError = "网络没有连通，请联网后再试。"
                } else if let networkError = error as? URLError, networkError.code == .timedOut {
                    connectionError = "验证超时，请检查网络后重试。"
                } else {
                    connectionError = error.localizedDescription
                }
                checkingConnection = false
                connectionTask = nil
            }
        }
    }
}

struct ShareSheet: UIViewControllerRepresentable {
    let items: [Any]
    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: items, applicationActivities: nil)
    }
    func updateUIViewController(_ controller: UIActivityViewController, context: Context) { }
}
