import SwiftUI
import UniformTypeIdentifiers
import UIKit

@MainActor
struct SettingsView: View {
    @EnvironmentObject private var store: AppStore
    @Environment(\.dismiss) private var dismiss
    @State private var draftSettings = AppSettings()
    @State private var draftKey = ""
    @State private var backupURL: URL?
    @State private var showShare = false
    @State private var showImporter = false
    var body: some View {
        NavigationStack {
            Form {
                Section {
                    HStack(spacing: 14) {
                        Image(systemName: "leaf.circle.fill").font(.system(size: 38)).foregroundStyle(Palette.green)
                        VStack(alignment: .leading, spacing: 3) {
                            Text("青笺").font(.title3.weight(.semibold))
                            Text("一个留给自己的聊天空间").font(.caption).foregroundStyle(.secondary)
                        }
                    }.padding(.vertical, 6)
                }
                Section {
                    SecureField("粘贴 DeepSeek API Key", text: $draftKey)
                        .textInputAutocapitalization(.never).autocorrectionDisabled()
                    Link("打开 DeepSeek 开放平台", destination: URL(string: "https://platform.deepseek.com/")!)
                } header: { Text("连接 DeepSeek") } footer: {
                    Text("Key 保存在这台手机的钥匙串里，不随聊天备份导出。发送的消息及选定的历史上下文会传给 DeepSeek。")
                }
                Section("回答方式") {
                    Picker("模型", selection: $draftSettings.model) {
                        ForEach(DeepSeekModel.allCases) { model in Text(model.title).tag(model) }
                    }
                    Toggle("深度思考", isOn: $draftSettings.thinkingEnabled)
                    if draftSettings.thinkingEnabled {
                        Picker("思考程度", selection: $draftSettings.effort) {
                            ForEach(ThinkingEffort.allCases) { effort in Text(effort.title).tag(effort) }
                        }
                    }
                    Picker("每次输出上限", selection: $draftSettings.maxOutputTokens) {
                        ForEach([4096, 8192, 16384, 32768, 65536], id: \.self) { value in Text("\(value) tokens").tag(value) }
                    }
                    Picker("携带的历史消息", selection: $draftSettings.contextMessageLimit) {
                        ForEach([10, 20, 40, 80, 100], id: \.self) { value in Text("最近 \(value) 条").tag(value) }
                    }
                }
                Section {
                    TextEditor(text: $draftSettings.systemPrompt).frame(minHeight: 140).font(.system(size: 14))
                    HStack {
                        Button("自然聊天") { draftSettings.systemPrompt = AppSettings.defaultPrompt }
                        Spacer()
                        Button("学习讲解") { draftSettings.systemPrompt = AppSettings.learningPrompt }
                    }.font(.system(size: 13))
                } header: { Text("你希望它怎样回答") } footer: {
                    Text("这段提示词会随请求发送。跨对话的自动记忆尚未加入；每个对话只携带所选数量的历史消息。")
                }
                Section {
                    Button {
                        backupURL = store.exportBackup()
                        showShare = backupURL != nil
                    } label: { Label("导出聊天备份", systemImage: "square.and.arrow.up") }
                    Button { showImporter = true } label: { Label("导入聊天备份", systemImage: "square.and.arrow.down") }
                        .disabled(store.isGenerating || !store.canPersist)
                } header: { Text("记录与备份") } footer: {
                    Text("导入会添加新的对话，已有编号的对话会跳过，不覆盖当前设置。备份包含对话正文与思考内容，请保存在自己的位置。")
                }
                Section {
                    LabeledContent("已保存回答的用量", value: "\(store.totalRecordedTokens) tokens")
                    Link("查看官方模型价格", destination: URL(string: "https://api-docs.deepseek.com/zh-cn/quick_start/pricing/")!)
                    Text("中断时可能没有返回用量，重新生成或删除记录也会影响本地统计；实际扣费以 DeepSeek 开放平台为准。")
                        .font(.caption).foregroundStyle(.secondary)
                } header: { Text("用量") }
                Section {
                    Text("青笺 1.0 · 个人使用")
                    Text("文字聊天需要联网。语音、文件上传、联网搜索和后台持续生成暂未加入。")
                        .font(.caption).foregroundStyle(.secondary)
                }
            }
            .navigationTitle("设置")
            .toolbar {
                ToolbarItem(placement: .topBarLeading) { Button("取消") { dismiss() } }
                ToolbarItem(placement: .topBarTrailing) {
                    Button("保存") {
                        if store.saveSettings(draftSettings, key: draftKey) { dismiss() }
                    }.fontWeight(.semibold)
                }
            }
            .onAppear { draftSettings = store.settings; draftKey = store.apiKey }
            .sheet(isPresented: $showShare) {
                if let url = backupURL { ShareSheet(items: [url]) }
            }
            .fileImporter(isPresented: $showImporter, allowedContentTypes: [.json]) { result in
                switch result {
                case .success(let url): store.importBackup(url)
                case .failure(let error): store.errorMessage = "无法打开文件：\(error.localizedDescription)"
                }
            }
            .alert("暂时没有完成", isPresented: Binding(get: { store.errorMessage != nil }, set: { if !$0 { store.errorMessage = nil } })) {
                Button("知道了") { store.errorMessage = nil }
            } message: { Text(store.errorMessage ?? "") }
            .alert("备份导入", isPresented: Binding(get: { store.noticeMessage != nil }, set: { if !$0 { store.noticeMessage = nil } })) {
                Button("完成") { store.noticeMessage = nil }
            } message: { Text(store.noticeMessage ?? "") }
        }
    }
}

struct ShareSheet: UIViewControllerRepresentable {
    let items: [Any]
    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: items, applicationActivities: nil)
    }
    func updateUIViewController(_ controller: UIActivityViewController, context: Context) { }
}
