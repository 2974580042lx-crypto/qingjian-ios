import UIKit
import UniformTypeIdentifiers

// Presents the system file picker straight from UIKit. SwiftUI's .fileImporter
// does not nest: inside Settings, which already has one for .json backups, a
// second importer opened with the outer one's file types, so a folder or a font
// could never be accepted and "打开" did nothing.
@MainActor
enum DocumentPicker {
    private static var current: Coordinator?

    static func present(_ types: [UTType], pick: @escaping (URL) -> Void) {
        guard let top = topViewController() else { return }
        let coordinator = Coordinator(pick: pick)
        let picker = UIDocumentPickerViewController(forOpeningContentTypes: types, asCopy: false)
        picker.allowsMultipleSelection = false
        picker.delegate = coordinator
        current = coordinator
        top.present(picker, animated: true)
    }

    private static func topViewController() -> UIViewController? {
        let window = UIApplication.shared.connectedScenes.compactMap { $0 as? UIWindowScene }
            .flatMap(\.windows).first(where: \.isKeyWindow)
        var top = window?.rootViewController
        while let next = top?.presentedViewController { top = next }
        return top
    }

    @MainActor private final class Coordinator: NSObject, UIDocumentPickerDelegate {
        let pick: (URL) -> Void
        init(pick: @escaping (URL) -> Void) { self.pick = pick }
        func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
            if let url = urls.first { pick(url) }
            DocumentPicker.current = nil
        }
        func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
            DocumentPicker.current = nil
        }
    }
}
