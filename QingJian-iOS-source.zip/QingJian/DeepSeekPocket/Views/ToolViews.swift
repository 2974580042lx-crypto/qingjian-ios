import SwiftUI

// One quiet line per tool the answer used: what it did and how it went.
struct ToolActivityList: View {
    let items: [ToolActivity]
    let signIn: () -> Void
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            ForEach(items) { item in
                HStack(alignment: .firstTextBaseline, spacing: 8) {
                    icon(for: item.status).frame(width: 16)
                    VStack(alignment: .leading, spacing: 3) {
                        Text(item.title).font(TypeScale.serif(14)).foregroundStyle(Ink.ink2).lineLimit(2)
                        if let detail = item.detail {
                            Text(detail).font(TypeScale.serif(12)).foregroundStyle(Ink.ink3).lineLimit(3)
                        }
                        if item.status == .needsSignIn {
                            Button("登录谷歌云盘", action: signIn)
                                .font(TypeScale.serif(13).weight(.semibold)).foregroundStyle(Ink.ink)
                                .padding(.horizontal, 12).frame(height: 32)
                                .background(Ink.raised, in: Capsule())
                                .buttonStyle(.plain)
                        }
                    }
                }
                .accessibilityElement(children: .combine)
            }
        }
        .padding(.vertical, 2)
        .accessibilityIdentifier("tool-activity")
    }

    @ViewBuilder private func icon(for status: ToolActivity.Status) -> some View {
        switch status {
        case .running: ProgressView().controlSize(.mini)
        case .done: Image(systemName: "checkmark").font(.system(size: 12)).foregroundStyle(Ink.ink3)
        case .failed: Image(systemName: "exclamationmark.triangle").font(.system(size: 12)).foregroundStyle(Ink.ink3)
        case .declined: Image(systemName: "hand.raised").font(.system(size: 12)).foregroundStyle(Ink.ink3)
        case .needsSignIn: Image(systemName: "person.crop.circle.badge.exclamationmark").font(.system(size: 12)).foregroundStyle(Ink.ink3)
        }
    }
}

// Asks before the model changes anything in Drive. Shows exactly what would happen.
struct ToolApprovalSheet: View {
    let approval: ToolApproval
    let answer: (Bool) -> Void
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("Sermo 想要").font(TypeScale.caption).foregroundStyle(Ink.ink3)
            Text(approval.title).font(TypeScale.heavy(20, relativeTo: .title3)).foregroundStyle(Ink.ink)
            if !approval.detail.isEmpty {
                ScrollView {
                    Text(approval.detail).font(TypeScale.serif(14)).foregroundStyle(Ink.ink2)
                        .frame(maxWidth: .infinity, alignment: .leading).textSelection(.enabled)
                        .padding(14)
                }
                .background(Ink.raised, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
            }
            Spacer(minLength: 0)
            HStack(spacing: 12) {
                Button { answer(false) } label: {
                    Text("不允许").frame(maxWidth: .infinity).frame(height: 50)
                        .background(Ink.raised, in: Capsule())
                }
                .accessibilityIdentifier("tool-decline")
                Button { answer(true) } label: {
                    Text("允许").foregroundStyle(Ink.onSolid).frame(maxWidth: .infinity).frame(height: 50)
                        .background(Ink.solid, in: Capsule())
                }
                .accessibilityIdentifier("tool-allow")
            }
            .font(TypeScale.serif(16).weight(.semibold)).foregroundStyle(Ink.ink).buttonStyle(.plain)
        }
        .padding(22)
        .background(Ink.paper)
        .presentationDetents([.medium, .large])
        .presentationDragIndicator(.visible)
    }
}

// The whole message as selectable text, for copying part of an answer.
struct SelectableTextSheet: View {
    let text: String
    @Environment(\.dismiss) private var dismiss
    private var rendered: AttributedString {
        (try? AttributedString(markdown: text, options: .init(interpretedSyntax: .inlineOnlyPreservingWhitespace))) ?? AttributedString(text)
    }
    var body: some View {
        NavigationStack {
            ScrollView {
                Text(rendered).readingStyle().lineSpacing(7).foregroundStyle(Ink.ink)
                    .textSelection(.enabled)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(20)
            }
            .background(Ink.paper)
            .navigationTitle("选择文字")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) { Button("完成") { dismiss() } }
            }
        }
        .presentationDragIndicator(.visible)
    }
}
