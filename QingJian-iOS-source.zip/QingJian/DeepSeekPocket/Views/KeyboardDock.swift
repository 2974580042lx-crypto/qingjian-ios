import SwiftUI
import UIKit

// Anchor the entire composer, including its send row, to UIKit's live keyboard
// boundary. Its hosting view does not perform a second SwiftUI keyboard inset.
@MainActor
struct KeyboardDock<Content: View>: UIViewControllerRepresentable {
    let content: Content
    init(@ViewBuilder content: () -> Content) { self.content = content() }
    func makeUIViewController(context: Context) -> DockController<Content> {
        DockController(content: content)
    }
    func updateUIViewController(_ controller: DockController<Content>, context: Context) {
        controller.host.rootView = content
        controller.view.setNeedsLayout()
    }
    static func dismantleUIViewController(_ controller: DockController<Content>, coordinator: ()) {
        controller.detachKeyboard()
    }
}

@MainActor
final class DockController<Content: View>: UIViewController {
    let host: UIHostingController<Content>
    private weak var keyboardWindow: UIWindow?
    private var keyboardLimit: NSLayoutConstraint?
    private var frameLimit: NSLayoutConstraint?
    private var frameObserver: KeyboardFrameObserver?
    private var contentHeight: NSLayoutConstraint!
    private var lastKeyboardFrame: CGRect?
    init(content: Content) {
        host = UIHostingController(rootView: content)
        super.init(nibName: nil, bundle: nil)
    }
    required init?(coder: NSCoder) { fatalError("init(coder:) is unavailable") }
    override func loadView() { view = DockPassthroughView() }
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .clear
        host.safeAreaRegions = []
        host.sizingOptions = []
        addChild(host)
        view.addSubview(host.view)
        host.view.backgroundColor = .clear
        host.view.translatesAutoresizingMaskIntoConstraints = false
        host.view.setContentCompressionResistancePriority(.required, for: .vertical)
        host.view.setContentHuggingPriority(.required, for: .vertical)
        let preferredBottom = host.view.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor)
        preferredBottom.priority = .init(999)
        contentHeight = host.view.heightAnchor.constraint(equalToConstant: 130)
        NSLayoutConstraint.activate([
            host.view.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            host.view.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            preferredBottom,
            contentHeight
        ])
        host.didMove(toParent: self)
        frameObserver = KeyboardFrameObserver { [weak self] frame, duration, options in
            self?.updateKeyboardFrame(frame, duration: duration, options: options)
        }
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        if view.bounds.width > 0 {
            let height = ceil(host.sizeThatFits(in: CGSize(width: view.bounds.width, height: .greatestFiniteMagnitude)).height)
            if height.isFinite && height > 0 && abs(contentHeight.constant - height) > 0.5 {
                contentHeight.constant = height
            }
        }
        guard let window = view.window else { return }
        if window !== keyboardWindow {
            detachKeyboard()
            keyboardWindow = window
            let limit = host.view.bottomAnchor.constraint(lessThanOrEqualTo: window.keyboardLayoutGuide.topAnchor, constant: -8)
            limit.isActive = true
            keyboardLimit = limit
        }
        refreshKeyboardLimit(in: window)
    }
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        detachKeyboard()
    }
    func detachKeyboard() {
        keyboardLimit?.isActive = false
        keyboardLimit = nil
        frameLimit?.isActive = false
        frameLimit = nil
        keyboardWindow = nil
    }
    private func updateKeyboardFrame(_ screenFrame: CGRect, duration: TimeInterval, options: UIView.AnimationOptions) {
        lastKeyboardFrame = screenFrame
        guard isViewLoaded, let window = view.window else { return }
        refreshKeyboardLimit(in: window)
        UIView.animate(withDuration: duration, delay: 0, options: options.union([.beginFromCurrentState, .allowUserInteraction])) {
            window.layoutIfNeeded()
        }
    }
    private func refreshKeyboardLimit(in window: UIWindow) {
        guard let screenFrame = lastKeyboardFrame else { return }
        let frame = window.convert(screenFrame, from: window.screen.coordinateSpace)
        let overlap = window.bounds.intersection(frame)
        guard !overlap.isNull, overlap.height > window.safeAreaInsets.bottom,
              overlap.width > window.bounds.width * 0.5 else {
            frameLimit?.isActive = false
            return
        }
        var top = frame.minY
        // An app input accessory can sit above the keyboard's reported frame.
        // Read only its visible bounds; never inspect input text or private APIs.
        KeyboardResponder.current = nil
        UIApplication.shared.sendAction(#selector(UIResponder.qingjianCaptureKeyboardResponder(_:)), to: nil, from: nil, for: nil)
        var responder = KeyboardResponder.current
        while let current = responder {
            if let accessory = current.inputAccessoryView, !accessory.isHidden, accessory.alpha > 0,
               let accessoryWindow = accessory.window {
                let local = accessory.convert(accessory.bounds, to: accessoryWindow)
                let bounds = accessoryWindow.convert(local, to: window)
                if bounds.height > 0 && bounds.intersects(window.bounds) { top = min(top, bounds.minY) }
            }
            responder = current.next
        }
        if frameLimit == nil {
            frameLimit = host.view.bottomAnchor.constraint(lessThanOrEqualTo: window.topAnchor, constant: top - 8)
        }
        if abs((frameLimit?.constant ?? 0) - (top - 8)) > 0.5 { frameLimit?.constant = top - 8 }
        frameLimit?.isActive = true
    }
}

@MainActor
private enum KeyboardResponder { static weak var current: UIResponder? }
private extension UIResponder {
    @objc func qingjianCaptureKeyboardResponder(_ sender: Any?) { KeyboardResponder.current = self }
}

@MainActor
private final class KeyboardFrameObserver: NSObject {
    let changed: (CGRect, TimeInterval, UIView.AnimationOptions) -> Void
    init(changed: @escaping (CGRect, TimeInterval, UIView.AnimationOptions) -> Void) {
        self.changed = changed
        super.init()
        NotificationCenter.default.addObserver(self, selector: #selector(update(_:)), name: UIResponder.keyboardWillChangeFrameNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(update(_:)), name: UIResponder.keyboardDidChangeFrameNotification, object: nil)
    }
    deinit { NotificationCenter.default.removeObserver(self) }
    @objc private func update(_ notification: Notification) {
        guard let frame = notification.userInfo?[UIResponder.keyboardFrameEndUserInfoKey] as? NSValue else { return }
        let duration = notification.name == UIResponder.keyboardDidChangeFrameNotification ? 0 : ((notification.userInfo?[UIResponder.keyboardAnimationDurationUserInfoKey] as? TimeInterval) ?? 0.25)
        let curve = (notification.userInfo?[UIResponder.keyboardAnimationCurveUserInfoKey] as? UInt) ?? 7
        changed(frame.cgRectValue, duration, UIView.AnimationOptions(rawValue: curve << 16))
    }
}

private final class DockPassthroughView: UIView {
    override func hitTest(_ point: CGPoint, with event: UIEvent?) -> UIView? {
        guard !isHidden, alpha > 0, isUserInteractionEnabled else { return nil }
        for child in subviews.reversed() {
            let local = convert(point, to: child)
            if let hit = child.hitTest(local, with: event) { return hit }
        }
        return nil
    }
}

// A real UIKit input accessory gives UI tests a deterministic taller keyboard.
// Normal app launches always use the regular SwiftUI text field instead.
@MainActor
struct PreviewKeyboardField: UIViewRepresentable {
    @Binding var text: String
    let isFocused: Bool
    let focusChanged: (Bool) -> Void
    func makeCoordinator() -> Coordinator { Coordinator(self) }
    func makeUIView(context: Context) -> UITextView {
        let field = UITextView()
        field.font = UIFont(name: "NotoSerifSC-Regular", size: 17) ?? .systemFont(ofSize: 17)
        field.textColor = .white
        field.backgroundColor = .clear
        field.textContainerInset = .zero
        field.textContainer.lineFragmentPadding = 0
        field.delegate = context.coordinator
        field.accessibilityIdentifier = "chat-composer"
        context.coordinator.installAccessory(on: field)
        return field
    }
    func updateUIView(_ field: UITextView, context: Context) {
        context.coordinator.owner = self
        if field.text != text { field.text = text }
        if isFocused && !field.isFirstResponder {
            DispatchQueue.main.async { [weak field, weak coordinator = context.coordinator] in
                if coordinator?.owner.isFocused == true { field?.becomeFirstResponder() }
            }
        } else if !isFocused && field.isFirstResponder { field.resignFirstResponder() }
    }
    func sizeThatFits(_ proposal: ProposedViewSize, uiView: UITextView, context: Context) -> CGSize? {
        let width = proposal.width ?? 340
        let height = uiView.sizeThatFits(CGSize(width: width, height: .greatestFiniteMagnitude)).height
        return CGSize(width: width, height: min(max(25, height), (uiView.font?.lineHeight ?? 25) * 5))
    }
    @MainActor final class Coordinator: NSObject, UITextViewDelegate {
        var owner: PreviewKeyboardField
        private var expanded = false
        init(_ owner: PreviewKeyboardField) { self.owner = owner }
        func installAccessory(on field: UITextView) {
            let accessory = PreviewKeyboardAccessory(height: expanded ? 180 : 100)
            accessory.changed = { [weak self, weak field] in
                guard let self, let field else { return }
                self.expanded.toggle()
                self.installAccessory(on: field)
                field.reloadInputViews()
            }
            field.inputAccessoryView = accessory
        }
        func textViewDidChange(_ textView: UITextView) { owner.text = textView.text }
        func textViewDidBeginEditing(_ textView: UITextView) { owner.focusChanged(true) }
        func textViewDidEndEditing(_ textView: UITextView) { owner.focusChanged(false) }
    }
}

@MainActor
private final class PreviewKeyboardAccessory: UIInputView {
    var changed: (() -> Void)?
    private let desiredHeight: CGFloat
    override var intrinsicContentSize: CGSize { CGSize(width: UIView.noIntrinsicMetric, height: desiredHeight) }
    init(height: CGFloat) {
        desiredHeight = height
        super.init(frame: CGRect(x: 0, y: 0, width: 402, height: height), inputViewStyle: .keyboard)
        allowsSelfSizing = true
        accessibilityIdentifier = "preview-keyboard-accessory"
        backgroundColor = .secondarySystemBackground
        heightAnchor.constraint(equalToConstant: height).isActive = true
        let marker = UIView()
        marker.isAccessibilityElement = true
        marker.accessibilityIdentifier = "preview-keyboard-top"
        marker.accessibilityLabel = "测试键盘上边缘"
        marker.translatesAutoresizingMaskIntoConstraints = false
        addSubview(marker)
        NSLayoutConstraint.activate([
            marker.topAnchor.constraint(equalTo: topAnchor),
            marker.leadingAnchor.constraint(equalTo: leadingAnchor),
            marker.widthAnchor.constraint(equalToConstant: 2),
            marker.heightAnchor.constraint(equalToConstant: 2)
        ])
        let button = UIButton(type: .system)
        button.setTitle("加高测试键盘", for: .normal)
        button.accessibilityIdentifier = "expand-preview-keyboard"
        button.addTarget(self, action: #selector(expand), for: .touchUpInside)
        button.translatesAutoresizingMaskIntoConstraints = false
        addSubview(button)
        NSLayoutConstraint.activate([
            button.centerXAnchor.constraint(equalTo: centerXAnchor),
            button.topAnchor.constraint(equalTo: topAnchor, constant: 12)
        ])
    }
    required init?(coder: NSCoder) { fatalError("init(coder:) is unavailable") }
    @objc private func expand() {
        changed?()
    }
}
