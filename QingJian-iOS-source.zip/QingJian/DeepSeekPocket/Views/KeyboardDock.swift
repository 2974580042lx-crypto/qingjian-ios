import SwiftUI
import UIKit

// Anchor the entire composer, including its send row, to UIKit's live keyboard
// boundary. Its hosting view does not perform a second SwiftUI keyboard inset.
@MainActor
struct KeyboardDock<Content: View>: UIViewControllerRepresentable {
    let content: Content
    init(@ViewBuilder content: () -> Content) { self.content = content() }
    func makeUIViewController(context: Context) -> DockController<Content> {
        DockController(content: content)
    }
    func updateUIViewController(_ controller: DockController<Content>, context: Context) {
        controller.host.rootView = content
        controller.host.view.invalidateIntrinsicContentSize()
    }
}

@MainActor
final class DockController<Content: View>: UIViewController {
    let host: UIHostingController<Content>
    private var installedPreviewAccessory = false
    init(content: Content) {
        host = UIHostingController(rootView: content)
        super.init(nibName: nil, bundle: nil)
    }
    required init?(coder: NSCoder) { fatalError("init(coder:) is unavailable") }
    override func loadView() { view = DockPassthroughView() }
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .clear
        host.safeAreaRegions = []
        host.sizingOptions = [.intrinsicContentSize]
        addChild(host)
        view.addSubview(host.view)
        host.view.backgroundColor = .clear
        host.view.translatesAutoresizingMaskIntoConstraints = false
        host.view.setContentCompressionResistancePriority(.required, for: .vertical)
        host.view.setContentHuggingPriority(.required, for: .vertical)
        let keyboard = view.keyboardLayoutGuide
        keyboard.usesBottomSafeArea = true
        NSLayoutConstraint.activate([
            host.view.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            host.view.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            host.view.bottomAnchor.constraint(equalTo: keyboard.topAnchor)
        ])
        host.didMove(toParent: self)
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        // Deterministic UI-test coverage for a keyboard that changes height.
        // This is unreachable in normal use and never installs an input method.
        let arguments = ProcessInfo.processInfo.arguments
        guard !installedPreviewAccessory, arguments.contains("--ui-preview"),
              arguments.contains("--preview-tall-keyboard"),
              let input = firstInput(in: host.view) else { return }
        installedPreviewAccessory = true
        let accessory = PreviewKeyboardAccessory()
        accessory.changed = { [weak input] in input?.reloadInputViews() }
        if let textView = input as? UITextView { textView.inputAccessoryView = accessory }
        else if let field = input as? UITextField { field.inputAccessoryView = accessory }
        DispatchQueue.main.async { input.reloadInputViews() }
    }
    private func firstInput(in view: UIView) -> UIView? {
        if view.isFirstResponder && (view is UITextView || view is UITextField) { return view }
        for child in view.subviews { if let input = firstInput(in: child) { return input } }
        return nil
    }
}

private final class DockPassthroughView: UIView {
    override func hitTest(_ point: CGPoint, with event: UIEvent?) -> UIView? {
        guard !isHidden, alpha > 0, isUserInteractionEnabled else { return nil }
        for child in subviews.reversed() {
            let local = convert(point, to: child)
            if let hit = child.hitTest(local, with: event) { return hit }
        }
        return nil
    }
}

@MainActor
private final class PreviewKeyboardAccessory: UIInputView {
    var changed: (() -> Void)?
    private var expanded = false
    private var heightConstraint: NSLayoutConstraint!
    init() {
        super.init(frame: CGRect(x: 0, y: 0, width: 402, height: 100), inputViewStyle: .keyboard)
        allowsSelfSizing = true
        accessibilityIdentifier = "preview-keyboard-accessory"
        backgroundColor = .secondarySystemBackground
        heightConstraint = heightAnchor.constraint(equalToConstant: 100)
        heightConstraint.isActive = true
        let marker = UIView()
        marker.isAccessibilityElement = true
        marker.accessibilityIdentifier = "preview-keyboard-top"
        marker.accessibilityLabel = "测试键盘上边缘"
        marker.translatesAutoresizingMaskIntoConstraints = false
        addSubview(marker)
        NSLayoutConstraint.activate([
            marker.topAnchor.constraint(equalTo: topAnchor),
            marker.leadingAnchor.constraint(equalTo: leadingAnchor),
            marker.widthAnchor.constraint(equalToConstant: 2),
            marker.heightAnchor.constraint(equalToConstant: 2)
        ])
        let button = UIButton(type: .system)
        button.setTitle("加高测试键盘", for: .normal)
        button.accessibilityIdentifier = "expand-preview-keyboard"
        button.addTarget(self, action: #selector(expand), for: .touchUpInside)
        button.translatesAutoresizingMaskIntoConstraints = false
        addSubview(button)
        NSLayoutConstraint.activate([
            button.centerXAnchor.constraint(equalTo: centerXAnchor),
            button.topAnchor.constraint(equalTo: topAnchor, constant: 12)
        ])
    }
    required init?(coder: NSCoder) { fatalError("init(coder:) is unavailable") }
    @objc private func expand() {
        expanded.toggle()
        heightConstraint.constant = expanded ? 180 : 100
        frame.size.height = heightConstraint.constant
        invalidateIntrinsicContentSize()
        changed?()
    }
}
