import SwiftUI
import UIKit

// Anchor the entire composer, including its send row, to UIKit's live keyboard
// boundary. Its hosting view does not perform a second SwiftUI keyboard inset.
@MainActor
struct KeyboardDock<Content: View>: UIViewControllerRepresentable {
    let content: Content
    init(@ViewBuilder content: () -> Content) { self.content = content() }
    func makeUIViewController(context: Context) -> DockController<Content> {
        DockController(content: content)
    }
    func updateUIViewController(_ controller: DockController<Content>, context: Context) {
        controller.host.rootView = content
        controller.host.view.invalidateIntrinsicContentSize()
    }
    static func dismantleUIViewController(_ controller: DockController<Content>, coordinator: ()) {
        controller.detachKeyboard()
    }
}

@MainActor
final class DockController<Content: View>: UIViewController {
    let host: UIHostingController<Content>
    private weak var keyboardWindow: UIWindow?
    private var keyboardLimit: NSLayoutConstraint?
    init(content: Content) {
        host = UIHostingController(rootView: content)
        super.init(nibName: nil, bundle: nil)
    }
    required init?(coder: NSCoder) { fatalError("init(coder:) is unavailable") }
    override func loadView() { view = DockPassthroughView() }
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .clear
        host.safeAreaRegions = []
        host.sizingOptions = [.intrinsicContentSize]
        addChild(host)
        view.addSubview(host.view)
        host.view.backgroundColor = .clear
        host.view.translatesAutoresizingMaskIntoConstraints = false
        host.view.setContentCompressionResistancePriority(.required, for: .vertical)
        host.view.setContentHuggingPriority(.required, for: .vertical)
        let preferredBottom = host.view.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor)
        preferredBottom.priority = .init(999)
        NSLayoutConstraint.activate([
            host.view.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            host.view.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            preferredBottom
        ])
        host.didMove(toParent: self)
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        guard let window = view.window, window !== keyboardWindow else { return }
        detachKeyboard()
        keyboardWindow = window
        // The window's guide is independent of ScrollView safe-area extension
        // and includes the keyboard's candidate/accessory region.
        let limit = host.view.bottomAnchor.constraint(lessThanOrEqualTo: window.keyboardLayoutGuide.topAnchor, constant: -8)
        limit.isActive = true
        keyboardLimit = limit
    }
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        detachKeyboard()
    }
    func detachKeyboard() {
        keyboardLimit?.isActive = false
        keyboardLimit = nil
        keyboardWindow = nil
    }
}

private final class DockPassthroughView: UIView {
    override func hitTest(_ point: CGPoint, with event: UIEvent?) -> UIView? {
        guard !isHidden, alpha > 0, isUserInteractionEnabled else { return nil }
        for child in subviews.reversed() {
            let local = convert(point, to: child)
            if let hit = child.hitTest(local, with: event) { return hit }
        }
        return nil
    }
}

// A real UIKit input accessory gives UI tests a deterministic taller keyboard.
// Normal app launches always use the regular SwiftUI text field instead.
@MainActor
struct PreviewKeyboardField: UIViewRepresentable {
    @Binding var text: String
    let isFocused: Bool
    let focusChanged: (Bool) -> Void
    func makeCoordinator() -> Coordinator { Coordinator(self) }
    func makeUIView(context: Context) -> UITextView {
        let field = UITextView()
        field.font = UIFont(name: "NotoSerifSC-Regular", size: 17) ?? .systemFont(ofSize: 17)
        field.textColor = .white
        field.backgroundColor = .clear
        field.textContainerInset = .zero
        field.textContainer.lineFragmentPadding = 0
        field.delegate = context.coordinator
        field.accessibilityIdentifier = "chat-composer"
        let accessory = PreviewKeyboardAccessory()
        accessory.changed = { [weak field] in field?.reloadInputViews() }
        field.inputAccessoryView = accessory
        return field
    }
    func updateUIView(_ field: UITextView, context: Context) {
        context.coordinator.owner = self
        if field.text != text { field.text = text }
        if isFocused && !field.isFirstResponder {
            DispatchQueue.main.async { [weak field, weak coordinator = context.coordinator] in
                if coordinator?.owner.isFocused == true { field?.becomeFirstResponder() }
            }
        } else if !isFocused && field.isFirstResponder { field.resignFirstResponder() }
    }
    func sizeThatFits(_ proposal: ProposedViewSize, uiView: UITextView, context: Context) -> CGSize? {
        let width = proposal.width ?? 340
        let height = uiView.sizeThatFits(CGSize(width: width, height: .greatestFiniteMagnitude)).height
        return CGSize(width: width, height: min(max(25, height), (uiView.font?.lineHeight ?? 25) * 5))
    }
    @MainActor final class Coordinator: NSObject, UITextViewDelegate {
        var owner: PreviewKeyboardField
        init(_ owner: PreviewKeyboardField) { self.owner = owner }
        func textViewDidChange(_ textView: UITextView) { owner.text = textView.text }
        func textViewDidBeginEditing(_ textView: UITextView) { owner.focusChanged(true) }
        func textViewDidEndEditing(_ textView: UITextView) { owner.focusChanged(false) }
    }
}

@MainActor
private final class PreviewKeyboardAccessory: UIInputView {
    var changed: (() -> Void)?
    private var expanded = false
    private var heightConstraint: NSLayoutConstraint!
    init() {
        super.init(frame: CGRect(x: 0, y: 0, width: 402, height: 100), inputViewStyle: .keyboard)
        allowsSelfSizing = true
        accessibilityIdentifier = "preview-keyboard-accessory"
        backgroundColor = .secondarySystemBackground
        heightConstraint = heightAnchor.constraint(equalToConstant: 100)
        heightConstraint.isActive = true
        let marker = UIView()
        marker.isAccessibilityElement = true
        marker.accessibilityIdentifier = "preview-keyboard-top"
        marker.accessibilityLabel = "测试键盘上边缘"
        marker.translatesAutoresizingMaskIntoConstraints = false
        addSubview(marker)
        NSLayoutConstraint.activate([
            marker.topAnchor.constraint(equalTo: topAnchor),
            marker.leadingAnchor.constraint(equalTo: leadingAnchor),
            marker.widthAnchor.constraint(equalToConstant: 2),
            marker.heightAnchor.constraint(equalToConstant: 2)
        ])
        let button = UIButton(type: .system)
        button.setTitle("加高测试键盘", for: .normal)
        button.accessibilityIdentifier = "expand-preview-keyboard"
        button.addTarget(self, action: #selector(expand), for: .touchUpInside)
        button.translatesAutoresizingMaskIntoConstraints = false
        addSubview(button)
        NSLayoutConstraint.activate([
            button.centerXAnchor.constraint(equalTo: centerXAnchor),
            button.topAnchor.constraint(equalTo: topAnchor, constant: 12)
        ])
    }
    required init?(coder: NSCoder) { fatalError("init(coder:) is unavailable") }
    @objc private func expand() {
        expanded.toggle()
        heightConstraint.constant = expanded ? 180 : 100
        frame.size.height = heightConstraint.constant
        invalidateIntrinsicContentSize()
        changed?()
    }
}
