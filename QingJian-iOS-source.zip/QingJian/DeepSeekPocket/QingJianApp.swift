import SwiftUI

@main
@MainActor
struct QingJianApp: App {
    @StateObject private var store = AppStore()
    @Environment(\.scenePhase) private var scenePhase
    var body: some Scene {
        WindowGroup {
            ContentView().environmentObject(store).tint(.white).preferredColorScheme(.dark)
                .onChange(of: scenePhase) { _, phase in
                    if phase != .active { store.persistNow() }
                }
        }
    }
}
