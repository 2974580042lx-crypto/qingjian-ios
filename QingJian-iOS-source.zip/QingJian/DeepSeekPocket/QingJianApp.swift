import SwiftUI

@main
@MainActor
struct QingJianApp: App {
    @StateObject private var store = AppStore()
    @StateObject private var profile = ProfileStore()
    @Environment(\.scenePhase) private var scenePhase

    init() {
        InkAppearance.apply()
    }

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(store)
                .environmentObject(profile)
                .tint(Ink.ink)
                .onChange(of: scenePhase) { _, phase in
                    if phase != .active { store.persistNow() }
                    // Not on .inactive: the Face ID prompt itself makes the app inactive.
                    if phase == .background { store.relockProjects() }
                }
        }
    }
}
