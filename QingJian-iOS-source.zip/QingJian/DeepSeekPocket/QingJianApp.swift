import SwiftUI

@main
@MainActor
struct QingJianApp: App {
    @StateObject private var store = AppStore()
    @Environment(\.scenePhase) private var scenePhase
    var body: some Scene {
        WindowGroup {
            ContentView().environmentObject(store).tint(Palette.green)
                .onChange(of: scenePhase) { _, phase in
                    if phase != .active { store.persistNow() }
                }
        }
    }
}
