import SwiftUI

@main
@MainActor
struct QingJianApp: App {
    @StateObject private var store = AppStore()
    @StateObject private var profile = ProfileStore()
    @Environment(\.scenePhase) private var scenePhase
    var body: some Scene {
        WindowGroup {
            ContentView().environmentObject(store).environmentObject(profile).tint(.white).preferredColorScheme(.dark)
                .onChange(of: scenePhase) { _, phase in
                    if phase != .active { store.persistNow() }
                }
        }
    }
}
