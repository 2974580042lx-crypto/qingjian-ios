import Foundation

final class DeepSeekClient: @unchecked Sendable {
    static let endpoint = URL(string: "https://api.deepseek.com/chat/completions")!
    static let balanceEndpoint = URL(string: "https://api.deepseek.com/user/balance")!

    func checkConnection(key: String) async throws -> AccountBalance {
        let cleanKey = try validatedKey(key)
        let configuration = URLSessionConfiguration.ephemeral
        configuration.timeoutIntervalForRequest = 20
        configuration.timeoutIntervalForResource = 30
        configuration.urlCache = nil
        let session = URLSession(configuration: configuration, delegate: SameHostRedirectDelegate(), delegateQueue: nil)
        defer { session.invalidateAndCancel() }
        var request = URLRequest(url: Self.balanceEndpoint)
        request.httpMethod = "GET"
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        request.setValue("Bearer \(cleanKey)", forHTTPHeaderField: "Authorization")
        let (data, response) = try await session.data(for: request)
        try Task.checkCancellation()
        try validateHTTPResponse(response)
        guard let balance = try? JSONDecoder().decode(AccountBalance.self, from: data) else {
            throw ChatError.invalidResponse
        }
        return balance
    }

    func stream(request payload: ChatRequest, key: String,
                onEvent: @escaping @MainActor (StreamEvent) -> Void) async throws {
        let cleanKey = try validatedKey(key)
        let configuration = URLSessionConfiguration.ephemeral
        configuration.timeoutIntervalForRequest = 120
        configuration.timeoutIntervalForResource = 900
        configuration.urlCache = nil
        let session = URLSession(configuration: configuration, delegate: SameHostRedirectDelegate(), delegateQueue: nil)
        defer { session.invalidateAndCancel() }
        var request = URLRequest(url: Self.endpoint)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("text/event-stream", forHTTPHeaderField: "Accept")
        request.setValue("Bearer \(cleanKey)", forHTTPHeaderField: "Authorization")
        request.httpBody = try JSONEncoder().encode(payload)
        let (bytes, response) = try await session.bytes(for: request)
        try validateHTTPResponse(response)
        guard let http = response as? HTTPURLResponse else { throw ChatError.invalidResponse }
        guard http.value(forHTTPHeaderField: "Content-Type")?.lowercased().contains("text/event-stream") == true else {
            throw ChatError.invalidResponse
        }
        var decoder = SSEByteDecoder()
        var done = false
        for try await byte in bytes {
            try Task.checkCancellation()
            guard let event = try decoder.consume(byte: byte) else { continue }
            await onEvent(event)
            if event.isDone { done = true; break }
        }
        if !done, let trailing = try decoder.finish() {
            await onEvent(trailing)
            done = trailing.isDone
        }
        try Task.checkCancellation()
        guard done else { throw ChatError.incompleteStream }
    }

    private func validatedKey(_ key: String) throws -> String {
        let cleanKey = key.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !cleanKey.isEmpty else { throw ChatError.missingKey }
        guard !cleanKey.contains("\n"), !cleanKey.contains("\r") else { throw ChatError.invalidKey }
        return cleanKey
    }

    private func validateHTTPResponse(_ response: URLResponse) throws {
        guard let http = response as? HTTPURLResponse else { throw ChatError.invalidResponse }
        switch http.statusCode {
        case 200...299: break
        case 401, 403: throw ChatError.invalidKey
        case 402: throw ChatError.insufficientBalance
        case 429: throw ChatError.rateLimited
        default: throw ChatError.http(http.statusCode)
        }
    }
}

private final class SameHostRedirectDelegate: NSObject, URLSessionTaskDelegate, @unchecked Sendable {
    func urlSession(_ session: URLSession, task: URLSessionTask,
                    willPerformHTTPRedirection response: HTTPURLResponse,
                    newRequest request: URLRequest,
                    completionHandler: @escaping (URLRequest?) -> Void) {
        // Never forward the credential to a different host or an HTTP endpoint.
        completionHandler(request.url?.scheme == "https" && request.url?.host == "api.deepseek.com" ? request : nil)
    }
}
