import Foundation

final class DeepSeekClient: @unchecked Sendable {
    static let endpoint = URL(string: "https://api.deepseek.com/chat/completions")!
    func stream(request payload: ChatRequest, key: String,
                onEvent: @escaping @MainActor (StreamEvent) -> Void) async throws {
        let cleanKey = key.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !cleanKey.isEmpty else { throw ChatError.missingKey }
        guard !cleanKey.contains("\n"), !cleanKey.contains("\r") else { throw ChatError.invalidKey }
        let configuration = URLSessionConfiguration.ephemeral
        configuration.timeoutIntervalForRequest = 120
        configuration.timeoutIntervalForResource = 900
        configuration.urlCache = nil
        let session = URLSession(configuration: configuration, delegate: SameHostRedirectDelegate(), delegateQueue: nil)
        defer { session.invalidateAndCancel() }
        var request = URLRequest(url: Self.endpoint)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("text/event-stream", forHTTPHeaderField: "Accept")
        request.setValue("Bearer \(cleanKey)", forHTTPHeaderField: "Authorization")
        request.httpBody = try JSONEncoder().encode(payload)
        let (bytes, response) = try await session.bytes(for: request)
        guard let http = response as? HTTPURLResponse else { throw ChatError.invalidResponse }
        switch http.statusCode {
        case 200...299: break
        case 401, 403: throw ChatError.invalidKey
        case 402: throw ChatError.insufficientBalance
        case 429: throw ChatError.rateLimited
        default: throw ChatError.http(http.statusCode)
        }
        guard http.value(forHTTPHeaderField: "Content-Type")?.lowercased().contains("text/event-stream") == true else {
            throw ChatError.invalidResponse
        }
        var decoder = SSEDecoder()
        var done = false
        for try await line in bytes.lines {
            try Task.checkCancellation()
            guard let event = try decoder.consume(line: line) else { continue }
            await onEvent(event)
            if event.isDone { done = true; break }
        }
        if !done, let trailing = try decoder.flush() {
            await onEvent(trailing)
            done = trailing.isDone
        }
        try Task.checkCancellation()
        guard done else { throw ChatError.incompleteStream }
    }
}

private final class SameHostRedirectDelegate: NSObject, URLSessionTaskDelegate, @unchecked Sendable {
    func urlSession(_ session: URLSession, task: URLSessionTask,
                    willPerformHTTPRedirection response: HTTPURLResponse,
                    newRequest request: URLRequest,
                    completionHandler: @escaping (URLRequest?) -> Void) {
        // Never forward the credential to a different host or an HTTP endpoint.
        completionHandler(request.url?.scheme == "https" && request.url?.host == "api.deepseek.com" ? request : nil)
    }
}
