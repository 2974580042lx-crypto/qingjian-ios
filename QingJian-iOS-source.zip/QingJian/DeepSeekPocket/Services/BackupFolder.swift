import Foundation

// A folder the user picked once in the Files picker (iCloud Drive, Google Drive's
// Files extension, On My iPhone…). Its security-scoped bookmark lets the app write
// there again later without iCloud entitlements, so this works with self-signing.
enum BackupFolder {
    private static let bookmarkKey = "qingjian.backup.folderBookmark"
    private static let nameKey = "qingjian.backup.folderName"
    private static let lastKey = "qingjian.backup.lastDate"
    static let prefix = "Sermo自动备份-"
    // Only files this feature wrote (by name) are ever removed, oldest first.
    static let keepCount = 7

    static var folderName: String? { UserDefaults.standard.string(forKey: nameKey) }
    static var lastBackup: Date? {
        get { UserDefaults.standard.object(forKey: lastKey) as? Date }
        set { UserDefaults.standard.set(newValue, forKey: lastKey) }
    }

    /// Saves access to the folder; returns its display name.
    static func remember(_ url: URL) throws -> String {
        let scoped = url.startAccessingSecurityScopedResource()
        defer { if scoped { url.stopAccessingSecurityScopedResource() } }
        let bookmark = try url.bookmarkData(options: [], includingResourceValuesForKeys: nil, relativeTo: nil)
        let name = FileManager.default.displayName(atPath: url.path)
        UserDefaults.standard.set(bookmark, forKey: bookmarkKey)
        UserDefaults.standard.set(name, forKey: nameKey)
        UserDefaults.standard.removeObject(forKey: lastKey)
        return name
    }

    static func forget() {
        for key in [bookmarkKey, nameKey, lastKey] { UserDefaults.standard.removeObject(forKey: key) }
    }

    /// File name for a given day; one file per day, rewritten if run again that day.
    static func fileName(for date: Date) -> String {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.dateFormat = "yyyy-MM-dd"
        return prefix + formatter.string(from: date) + ".json"
    }

    /// Older automatic backups beyond `keep`, by name (dates sort as text).
    static func expired(_ names: [String], keep: Int = keepCount) -> [String] {
        let ours = names.filter { $0.hasPrefix(prefix) && $0.hasSuffix(".json") }.sorted(by: >)
        return Array(ours.dropFirst(keep))
    }

    /// Writes today's backup into the folder and trims old ones. Runs off the main thread.
    static func write(_ data: Data, now: Date = Date()) throws {
        guard let bookmark = UserDefaults.standard.data(forKey: bookmarkKey) else {
            throw CocoaError(.fileNoSuchFile)
        }
        var stale = false
        let folder = try URL(resolvingBookmarkData: bookmark, options: [], relativeTo: nil, bookmarkDataIsStale: &stale)
        guard folder.startAccessingSecurityScopedResource() else { throw CocoaError(.fileWriteNoPermission) }
        defer { folder.stopAccessingSecurityScopedResource() }
        if stale, let fresh = try? folder.bookmarkData(options: [], includingResourceValuesForKeys: nil, relativeTo: nil) {
            UserDefaults.standard.set(fresh, forKey: bookmarkKey)
        }
        let coordinator = NSFileCoordinator()
        var coordinationError: NSError?
        var writeError: Error?
        let target = folder.appendingPathComponent(fileName(for: now))
        coordinator.coordinate(writingItemAt: target, options: .forReplacing, error: &coordinationError) { url in
            do { try data.write(to: url, options: .atomic) } catch { writeError = error }
        }
        if let error = coordinationError ?? writeError { throw error }
        let names = (try? FileManager.default.contentsOfDirectory(atPath: folder.path)) ?? []
        for name in expired(names) {
            var removeError: NSError?
            coordinator.coordinate(writingItemAt: folder.appendingPathComponent(name), options: .forDeleting, error: &removeError) { url in
                try? FileManager.default.removeItem(at: url)
            }
        }
    }
}
