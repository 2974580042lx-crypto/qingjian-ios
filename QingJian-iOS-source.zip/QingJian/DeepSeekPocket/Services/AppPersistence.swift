import Foundation

final class AppPersistence {
    private let directory: URL
    private let file: URL
    init() throws {
        directory = try FileManager.default.url(for: .applicationSupportDirectory,
                                                in: .userDomainMask, appropriateFor: nil, create: true)
            .appendingPathComponent("QingJian", isDirectory: true)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        file = directory.appendingPathComponent("conversations.json")
    }
    func load() throws -> AppSnapshot? {
        guard FileManager.default.fileExists(atPath: file.path) else { return nil }
        return try AppSnapshot.decode(Data(contentsOf: file))
    }
    func save(_ snapshot: AppSnapshot) throws {
        let data = try snapshot.encoded()
        try data.write(to: file, options: [.atomic, .completeFileProtection])
    }
    func export(_ snapshot: AppSnapshot) throws -> URL {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyyMMdd-HHmmss"
        let url = FileManager.default.temporaryDirectory
            .appendingPathComponent("青笺备份-\(formatter.string(from: Date())).json")
        try snapshot.encoded().write(to: url, options: [.atomic, .completeFileProtection])
        return url
    }
}
