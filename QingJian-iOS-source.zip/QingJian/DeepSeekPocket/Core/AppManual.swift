import Foundation

// What Sermo can do and where to find it. One source for both the built-in
// "Sermo 说明书" project (as its document) and the feature overview in Settings.
// Update it with every feature, and bump `revision` so the project refreshes.
enum AppManual {
    static let revision = 2
    static let projectID = UUID(uuidString: "5E2B0D6A-3C1F-4A7E-9B21-5E5E2B0D6A01")!
    static let projectName = "Sermo 说明书"
    static let documentName = "Sermo 使用说明"

    struct Item: Sendable { let name: String; let how: String }
    struct Section: Sendable { let title: String; let items: [Item] }

    static let sections: [Section] = [
        Section(title: "聊天", items: [
            Item(name: "新建对话", how: "对话页右上角的笔形按钮，或侧栏底部「新建会话」。新对话会落在上次选的项目里。"),
            Item(name: "选项目", how: "新对话还没发消息时，输入框下方加号旁的文件夹按钮。选一次会记住，之后新开的对话都在这个项目里；发出第一条消息后按钮收起。"),
            Item(name: "模型和思考档位", how: "输入框下方的药丸（例如 Flash High）。可选 Flash 或 V4 Pro，思考档位 Off / Low / High / Max。只有 Flash 能看图片。"),
            Item(name: "添加内容", how: "输入框左下的加号：从相册选图片、导入文字文件、粘贴文字。"),
            Item(name: "手动联网", how: "输入框下方的地球按钮（DeepSeek）。打开后这一次先搜索、读取排名靠前的几个网页正文，再回答；会多一次搜索费用。想让模型自己决定何时搜索，用项目里的「联网工具」。"),
            Item(name: "停止生成", how: "生成时发送按钮变成停止按钮，点一下即可。"),
            Item(name: "复制、编辑、重新生成", how: "回答下方的按钮；或长按任意消息打开菜单。编辑你的消息时可以「保存并重新发送」。"),
            Item(name: "选择部分文字", how: "长按回答 → 选择文字，在弹出页里自由选择并复制。"),
            Item(name: "思考过程", how: "回答上方的思考行，点开看完整时间线，可切换原文、中文、双语。"),
            Item(name: "猜你回复", how: "回答完后给出 1～3 条回复草稿，点一下填进输入框，改完再自己发。在设置「回复建议」里开关。"),
            Item(name: "排版", how: "回答里的列表、标题、引用、分隔线和表格会自动排好；表格太宽时可以左右滑动。"),
            Item(name: "高光", how: "回答里的粗体画成半高荧光笔，每条回答最多两处，其余保持粗体。颜色在设置「文字高光」里改。瑞士风格不画高光，粗体改为蓝色。"),
            Item(name: "对话管理", how: "标题旁的「⋯」：重命名、置顶、移到项目、导出为 Markdown。"),
        ]),
        Section(title: "侧栏", items: [
            Item(name: "打开侧栏", how: "对话页左上角按钮，或从屏幕左边向右滑。"),
            Item(name: "最近与全部对话", how: "侧栏列出最近的对话；「查看全部」里可以多选、全选，批量移进项目或删除。长按对话可重命名、移出项目、删除。"),
            Item(name: "设置", how: "侧栏左下角的头像。"),
        ]),
        Section(title: "项目", items: [
            Item(name: "什么是项目", how: "一组对话共用的指令、资料和默认设置。项目里的对话只用项目指令，不叠加设置里的系统提示词，适合每个角色或每类工作各开一个。"),
            Item(name: "新建与打开", how: "侧栏进入项目页，右上角加号新建；可以固定到侧栏。"),
            Item(name: "指令和资料", how: "项目页的「添加指令」写身份、语气和规矩；「添加文件」放资料，每份资料可单独开关，打开的资料每次都会随请求发送。"),
            Item(name: "项目「⋯」菜单", how: "重命名、服务（DeepSeek 或 ChatGPT 订阅）、默认模型与思考、谷歌云盘工具、GitHub 工具、联网工具、告诉角色时间流逝、面容 ID 锁、删除项目。"),
            Item(name: "项目记忆", how: "ChatGPT 订阅的项目可开「自动整理记忆」，离开对话后把要点记下来；项目页里可查看、修改、清空。"),
            Item(name: "面容 ID 锁", how: "上锁的项目打开前要验证；App 退到后台后会重新上锁。"),
        ]),
        Section(title: "书架", items: [
            Item(name: "导入小说", how: "侧栏「书架」，右上角加号（或空书架里的「导入 TXT 或 EPUB」）导入 TXT 或 EPUB（没有加密、不是纯图片的都行）；也可以在「文件」App 里长按 TXT →「共享」→ 选 Sermo。UTF-8、GBK、Big5 编码都能认，最大 40 MB；会自动分章。正文存在手机本地，不进聊天备份。"),
            Item(name: "读书", how: "打开书点「开始阅读」：Flash 每次读几章做笔记，最后 V4 Pro 整理成人物档案、作者笔触和名场面。做笔记的模型可在「开始阅读」上方选 Flash 或 V4 Pro（Pro 更细更准，约贵四倍）。开始前会显示预计花费，以及现在是不是高峰时段。读的时候让 Sermo 留在前台；中途暂停或失败，读过的部分都会保留，点「继续阅读」接着读。"),
            Item(name: "查看和修改档案", how: "读完后书页里列出人物、作者笔触、原文片段和名场面。点人物可以改身份、性格、说话方式、关系、经历，删掉不想要的台词；「⋯」里可以重新整理档案或从头重读。"),
            Item(name: "选人物开聊", how: "书页里「选一个人物开聊」：选人物；选时间点（从第几章开始，或从名场面开始）；写你扮演谁（书中人物、自己写，或「我的人物卡」）；可写开场。选了时间点会先写一段前情提要放在对话最上面，人物只知道这之前的事。人物会先开口。聊天时自动带上人物档案和原著笔触，提到书里的人名、地名、物品时，会悄悄附上原著里相关的段落（不超过时间点）。"),
            Item(name: "跟着原著走", how: "开聊页「剧情走向」选「跟着原著走」：按原著一段一段往前演，你的选择改变细节，但大事照原著发生；一段演完自动进入下一段，人物知道的事也跟着往后走。原著里没有你的段落，可以选「把我卷进去」（你当旁观者、知情人）或「跳到有我的地方」（用旁白交代中间发生的事）。进度在「⋯ → 本局设定」里看，也能手动推进或回到上一段。"),
            Item(name: "本局玩法", how: "开聊时最下面的「本局玩法」写给模型的规矩，比如小说笔法、旁白、状态栏，这一局一直有效、优先于其他设定。聊天中在标题旁「⋯ → 本局设定」里改玩法、修正前情提要。"),
            Item(name: "读原文", how: "书页里「读原文」按目录翻章节，会自动记住读到哪一章，目录顶上有「继续阅读」；长按一段可以「在这里放书签」。读完的书长按任意一段，选「从这里开始演」，就以这一段为开场、这一章为时间点开局。"),
            Item(name: "人物精读", how: "书页点开一个人物，最上面「精读这个人物」：用 V4 Pro 把他的全部笔记、台词和原文片段再读一遍，写出更细的人物卡（不同情境下的反应、对不同人的态度、绝不会说或做的事）。一个人物大约几毛钱，做一次即可。"),
            Item(name: "文风精读", how: "书页「作者笔触」里「精读文风」：读全书各处约 30 段原文，写出更具体的文风规则、标志性写法和「原著不会这样写」的清单，并换上最有代表性的原文片段。"),
            Item(name: "原著片段", how: "每局开聊时，会自动从原著（时间点之前）挑几段这个人物说话做事的原文一起发给模型，让人物更像原著。"),
            Item(name: "台词库", how: "App 在手机上直接把书里的对白抠出来，记下是谁说的、怎么说的（笑道、冷笑道、哭道……）、在第几章，不花钱。每次回复前，按这人正在和谁说话、你这句话的情绪、时间点之前，挑几句他自己的原话放在最新消息旁边，让说话的语气更像本人。已读好的书直接可用。"),
            Item(name: "他在想什么", how: "书架对话里长按人物的回答，选「他在想什么」，看他说这段话时心里真正在想什么（第一人称内心独白）。单独生成，不写进剧情，人物也不知道你看过；看过的会存着，可以重写。"),
            Item(name: "这里不像", how: "聊天中长按人物的回答，选「这里不像…」，写一句他其实会怎样。会记进这个人物的人物卡，之后每一局都带上；在人物卡里可以查看、删除。"),
            Item(name: "我的人物卡", how: "书架右上角的人物图标，存你自己的原创人物（外貌、身份、性格、说话方式），开局时在「你扮演谁 → 我的人物卡」里一点就带上，任何书都能用。"),
            Item(name: "跨书客串", how: "开局时「加一位客串人物」，从书架上另一本读完的书里请一个人物进来，由模型一起扮演，最多 3 位。"),
        ]),
        Section(title: "提示词变量与时间", items: [
            Item(name: "变量", how: "在系统提示词或项目指令里写 {{时间}}、{{日期}}、{{星期}}、{{名字}}、{{模型}}（也可写 {{time}}、{{date}}、{{weekday}}、{{user}}、{{model}}），发送时自动换成当前的值。想让角色只在需要时提起时间，可以写「当前时间：{{时间}}，仅作背景，不要主动提起」。"),
            Item(name: "告诉角色时间流逝", how: "项目「⋯」里打开。对话的第一条消息、或隔了两小时以上再发消息时，悄悄告诉模型现在几点、过去了多久；连续聊天时什么都不加。"),
        ]),
        Section(title: "工具", items: [
            Item(name: "工具是什么", how: "让模型自己决定去查云盘或代码仓库。只在项目「⋯」里打开了对应开关的 DeepSeek 项目里生效，其他对话（包括角色扮演）请求里不带任何工具。"),
            Item(name: "联网工具", how: "在项目里打开「联网工具」后，模型自己判断要不要搜索、搜什么，可以连续搜几次，也能直接读取你发的链接。搜到的来源显示在回答下方。适合论文、查资料类项目；角色扮演项目不要打开。"),
            Item(name: "谷歌云盘", how: "先在设置「谷歌云盘」里用 Google 登录，再在项目里打开「谷歌云盘工具」。可以搜索、列出、读取谷歌文档、表格、幻灯片和文本文件，也能新建、改写文本文件、建文件夹、改名移动、移到回收站。PDF 和图片暂不能读。测试状态的登录约 7 天要重新登录一次。"),
            Item(name: "GitHub", how: "在设置「GitHub」里粘贴细粒度令牌（Contents、Pull requests 读写，Actions 只读），再在项目里打开「GitHub 工具」。可以看代码、搜索、在 sermo/ 开头的分支上提交、开 PR、看 GitHub Actions 的编译结果和报错；不会碰默认分支，合并由你在 GitHub 上决定。"),
            Item(name: "写入前确认", how: "任何新建、修改、移动、移到回收站、提交、开 PR 都会先弹出确认页，写清要做什么；点「允许」才执行，关掉就算拒绝。没有永久删除。"),
            Item(name: "工具记录", how: "每次调用工具，回答上方会留一行记录：做了什么、成功或失败、是否被你拒绝。登录过期时这里会出现登录按钮。"),
        ]),
        Section(title: "设置", items: [
            Item(name: "高峰时段", how: "DeepSeek 北京时间工作日 9–12 点、14–18 点是高峰价，其余时间和周末减半。侧栏余额下方、输入框模型菜单顶部和书页里都会写现在是哪个时段、到几点结束。"),
            Item(name: "用量日历", how: "设置最上方，按天显示 token 和估算花费，区分高峰与空闲时段。"),
            Item(name: "DeepSeek Key", how: "「连接 DeepSeek」里粘贴 API Key，可测试连接和查看余额；点右上角保存后才写入钥匙串。"),
            Item(name: "ChatGPT 订阅", how: "用 ChatGPT 账号登录，用套餐额度回答，不按次扣钱；在项目的「服务」里选它。"),
            Item(name: "回答方式", how: "默认模型、深度思考、思考程度、每次输出上限、携带的历史消息条数。"),
            Item(name: "系统提示词", how: "不在项目里的对话使用它；有「自然聊天」「学习讲解」两个模板，也可以写提示词变量。"),
            Item(name: "界面风格", how: "「阅读与外观 → 界面风格」在纸笺和瑞士之间切换，立刻生效。纸笺是暖纸色、宋体、荧光高光；瑞士是灰白底、黑体、蓝色粗体、网格线和方角，问答前标 Q.01 / A.01，对话开头有大标题。对话和设置都不受影响。"),
            Item(name: "阅读与外观", how: "界面风格、侧栏触感、字体（内置宋体、系统字体、导入自己的字体；瑞士风格固定用黑体）、AI 回答气泡、正文字号。"),
            Item(name: "导入字体", how: "「阅读与外观 → 字体」选「自定义字体」，从文件里导入 .ttf 或 .otf，可分别导入常规和粗体。全局生效，可随时恢复默认。字体不进备份。"),
            Item(name: "备份", how: "「记录与备份」可手动导出、导入；「自动备份」选一个文件夹（iCloud 云盘、谷歌云盘等）后，每天第一次打开时自动备份，保留最近 7 份。备份不含 API Key、登录凭证和字体。"),
        ]),
    ]

    /// The document text the manual project hands to the model.
    static var document: String {
        var lines = ["以下是 Sermo 这个 App 的使用说明。用户问怎么用时，根据它回答：说清入口在哪、按什么顺序操作，尽量简短。说明里没有的功能，直接说目前没有，不要编造。", ""]
        for section in sections {
            lines.append("【\(section.title)】")
            for item in section.items { lines.append("- \(item.name)：\(item.how)") }
            lines.append("")
        }
        return lines.joined(separator: "\n")
    }

    /// The project as it is first created; later only its document is kept current.
    static func newProject() -> ChatProject {
        var project = ChatProject(id: projectID, name: projectName)
        project.instructions = "你是 Sermo 的使用向导，回答用户关于这个 App 怎么用的问题。"
        project.documents = [ProjectDocument(name: documentName, text: document)]
        project.model = .flash
        project.thinkingEnabled = false
        project.isPinned = true
        return project
    }

    /// Brings the manual document of an existing project up to date, keeping the
    /// user's own instructions and other documents. Nil when nothing changed.
    static func refreshed(_ project: ChatProject) -> ChatProject? {
        var next = project
        if let index = next.documents.firstIndex(where: { $0.name == documentName }) {
            guard next.documents[index].text != document else { return nil }
            next.documents[index].text = document
        } else {
            next.documents.insert(ProjectDocument(name: documentName, text: document), at: 0)
        }
        next.updatedAt = Date()
        return next
    }
}
