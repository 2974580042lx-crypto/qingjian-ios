import Foundation

struct APIMessage: Encodable, Equatable, Sendable {
    let role: String
    let content: String
}

struct ChatRequest: Encodable, Sendable {
    let model: String
    let messages: [APIMessage]
    let stream = true
    let streamOptions = StreamOptions()
    let thinking: Thinking
    let reasoningEffort: String?
    let maxTokens: Int
    struct Thinking: Encodable, Sendable { let type: String }
    struct StreamOptions: Encodable, Sendable {
        let includeUsage = true
        enum CodingKeys: String, CodingKey { case includeUsage = "include_usage" }
    }
    enum CodingKeys: String, CodingKey {
        case model, messages, stream, thinking
        case streamOptions = "stream_options"
        case reasoningEffort = "reasoning_effort"
        case maxTokens = "max_tokens"
    }
    init(settings: AppSettings, messages: [ChatMessage]) {
        let config = settings.validated()
        model = config.model.rawValue
        thinking = Thinking(type: config.thinkingEnabled ? "enabled" : "disabled")
        reasoningEffort = config.thinkingEnabled ? config.effort.rawValue : nil
        maxTokens = config.maxOutputTokens
        // Failed/unfinished answers remain visible locally, but do not masquerade
        // as complete assistant responses in subsequent API calls.
        var history = messages.filter {
            !$0.content.isEmpty && ($0.role == .user || $0.state == .complete)
        }
        history = Array(history.suffix(config.contextMessageLimit))
        while history.first?.role == .assistant { history.removeFirst() }
        var outgoing: [APIMessage] = []
        if !config.systemPrompt.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            outgoing.append(APIMessage(role: "system", content: config.systemPrompt))
        }
        outgoing.append(contentsOf: history.map { APIMessage(role: $0.role.rawValue, content: $0.content) })
        self.messages = outgoing
    }
}

struct StreamEvent: Equatable, Sendable {
    var content = ""
    var reasoning = ""
    var usage: TokenUsage?
    var finishReason: String?
    var isDone = false
}

// Reads SSE events, including comments, CRLF and multi-line data fields.
// URLSession.AsyncBytes.lines handles UTF-8 fragmentation before this layer.
struct SSEDecoder {
    private var dataLines: [String] = []
    mutating func consume(line rawLine: String) throws -> StreamEvent? {
        let line = rawLine.hasSuffix("\r") ? String(rawLine.dropLast()) : rawLine
        if line.isEmpty { return try flush() }
        if line.hasPrefix("data:") {
            var value = String(line.dropFirst(5))
            if value.hasPrefix(" ") { value.removeFirst() }
            dataLines.append(value)
        }
        return nil
    }
    mutating func flush() throws -> StreamEvent? {
        guard !dataLines.isEmpty else { return nil }
        let payload = dataLines.joined(separator: "\n")
        dataLines.removeAll(keepingCapacity: true)
        if payload.trimmingCharacters(in: .whitespacesAndNewlines) == "[DONE]" {
            return StreamEvent(isDone: true)
        }
        guard let data = payload.data(using: .utf8) else { throw ChatError.malformedStream }
        let chunk: APIChunk
        do { chunk = try JSONDecoder().decode(APIChunk.self, from: data) }
        catch { throw ChatError.malformedStream }
        if chunk.error != nil { throw ChatError.server("DeepSeek 在生成过程中返回错误，请重试。") }
        guard chunk.choices != nil || chunk.usage != nil else { throw ChatError.malformedStream }
        let choice = chunk.choices?.first
        return StreamEvent(content: choice?.delta?.content ?? "",
                           reasoning: choice?.delta?.reasoningContent ?? "",
                           usage: chunk.usage, finishReason: choice?.finishReason)
    }
    private struct APIChunk: Decodable {
        let choices: [Choice]?
        let usage: TokenUsage?
        let error: APIError?
        struct APIError: Decodable { let message: String? }
        struct Choice: Decodable {
            let delta: Delta?
            let finishReason: String?
            enum CodingKeys: String, CodingKey { case delta; case finishReason = "finish_reason" }
        }
        struct Delta: Decodable {
            let content: String?
            let reasoningContent: String?
            enum CodingKeys: String, CodingKey { case content; case reasoningContent = "reasoning_content" }
        }
    }
}
