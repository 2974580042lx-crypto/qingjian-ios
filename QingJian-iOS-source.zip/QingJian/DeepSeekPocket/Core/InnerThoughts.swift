import Foundation

// 「他在想什么」: one request, separate from the story. It carries the same system
// prompt and the conversation up to the answer (so DeepSeek's cache covers almost all
// of it), then asks for the character's inner monologue in that moment.
enum InnerThoughts {
    static func request(settings: AppSettings, systemPrompt: String, messages: [ChatMessage], answerID: UUID,
                        character: String) throws -> ChatRequest {
        guard let index = messages.firstIndex(where: { $0.id == answerID }), messages[index].role == .assistant,
              !messages[index].content.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            throw ChatError.server("等这条回答写完再看心里话。")
        }
        var history = Array(messages[...index])
        history.append(ChatMessage(role: .user, content: """
        （幕后，不属于剧情：）请写出\(character)在说上面最后那段话、做那些事的时候，心里真正在想什么。
        用\(character)的第一人称内心独白，150 到 300 字，口吻和见识都是他自己的；可以和嘴上说的不一样，写出没说出口的真实想法、顾虑和情绪。
        不要写对白，不要推进剧情，不要加标题或说明，只写这段独白。
        """))
        var config = settings
        config.thinkingEnabled = false
        config.maxOutputTokens = 1500
        return ChatRequest(settings: config, messages: history, systemPrompt: systemPrompt)
    }
}
