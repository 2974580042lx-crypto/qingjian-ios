import Foundation

// A conversation started from the bookshelf: one character from one book.
// Optional on ChatThread, so conversations from earlier releases still load.
struct StorySession: Codable, Equatable, Sendable {
    var bookID: UUID
    var bookTitle: String
    var character: String
    // Who you are in the scene: a person from the book, or your own description. Empty means yourself.
    var userRole = ""
    // Your own note for the opening, e.g. where and when it starts.
    var opening = ""
}

enum StoryPrompt {
    /// The system prompt for a bookshelf conversation. Without the book's profile
    /// (deleted from the shelf) the conversation keeps going on what it said so far.
    static func compose(_ session: StorySession, book: Book?) -> String {
        guard let profile = book?.profile,
              let character = profile.characters.first(where: { $0.name == session.character }) else {
            return "你在扮演小说《\(session.bookTitle)》里的\(session.character)。这本书已从书架移除，请按照目前为止的对话保持人物的性格和说话方式，继续扮演。"
        }
        var parts: [String] = []
        let role = session.userRole.trimmingCharacters(in: .whitespacesAndNewlines)
        parts.append("""
        你在和用户进行基于小说《\(session.bookTitle)》的角色扮演。你扮演\(character.name)，用户扮演\(role.isEmpty ? "他自己" : role)。
        - 始终以\(character.name)的身份说话和行动，性格、说话方式、见识都要和原著一致，不要出戏，不要提到自己是 AI，也不要解释设定。
        - 对白直接写出来，必要的动作、神态用（）简短交代；书里其他人物可以自然出现，由你来写，但他们也要像原著。
        - 不替用户扮演的人物说话、做决定或描写其内心，把回应的机会留给用户。
        - 每次回复篇幅适中，停在需要用户回应的地方。
        """)
        let opening = session.opening.trimmingCharacters(in: .whitespacesAndNewlines)
        if !opening.isEmpty { parts.append("【开场设定】\n" + opening) }

        var card = ["【\(character.name)】"]
        if !character.aliases.isEmpty { card.append("又称：" + character.aliases.joined(separator: "、")) }
        for (label, value) in [("身份", character.identity), ("性格", character.personality), ("说话方式", character.speech),
                               ("人物关系", character.relationships), ("经历", character.arc)] where !value.isEmpty {
            card.append("\(label)：\(value)")
        }
        if !character.quotes.isEmpty {
            card.append("原著台词（体会语气，不要照搬）：")
            card.append(contentsOf: character.quotes.prefix(6).map { "「\($0.text)」" })
        }
        parts.append(card.joined(separator: "\n"))

        // A person from the book played by the user gets a short card too.
        if let user = profile.characters.first(where: { $0.name != character.name && $0.allNames.contains(role) }) {
            parts.append("【用户扮演的\(user.name)】\n" + [user.identity, user.personality, user.relationships].filter { !$0.isEmpty }.joined(separator: "\n"))
        }
        let others = profile.characters.filter { $0.name != character.name && !$0.allNames.contains(role) }.prefix(12)
        if !others.isEmpty {
            parts.append("【书中其他人物】\n" + others.map { "- \($0.name)：\($0.identity.isEmpty ? $0.personality : $0.identity)" }.joined(separator: "\n"))
        }
        if !profile.summary.isEmpty { parts.append("【全书梗概】\n" + profile.summary) }
        if !profile.style.description.isEmpty || !profile.style.excerpts.isEmpty {
            var style = ["【原著笔触】描写和叙述要贴近原著的语感："]
            if !profile.style.description.isEmpty { style.append(profile.style.description) }
            if !profile.style.excerpts.isEmpty {
                style.append("原文片段（体会笔触，不要照抄）：")
                style.append(contentsOf: profile.style.excerpts.prefix(4).map { "「\($0)」" })
            }
            parts.append(style.joined(separator: "\n"))
        }
        return parts.joined(separator: "\n\n")
    }

    /// Names and terms worth looking up in the text when the conversation mentions them.
    static func vocabulary(of profile: BookProfile) -> [String] {
        var words = profile.terms.map(\.term)
        for character in profile.characters { words += character.allNames }
        return Array(Set(words.filter { $0.count >= 2 }))
    }

    /// What the newest user message gets in front of it, for this request only.
    static func passageNote(terms: [String], passages: [String], profile: BookProfile) -> String? {
        guard !passages.isEmpty else { return nil }
        var lines = ["（以下是原著里和这句话相关的段落与名词，供你保持设定一致，不要照抄，也不要提到这段说明。）"]
        for term in terms {
            if let entry = profile.terms.first(where: { $0.term == term }) { lines.append("· \(entry.term)：\(entry.note)") }
        }
        lines.append(contentsOf: passages.map { "「\($0)」" })
        lines.append("（以上为参考。）")
        return lines.joined(separator: "\n")
    }
}
