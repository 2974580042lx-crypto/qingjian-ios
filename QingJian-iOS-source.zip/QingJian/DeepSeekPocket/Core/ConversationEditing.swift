import Foundation

enum ConversationEditing {
    static func editedCopy(of original: ChatThread, messageID: UUID, text: String) throws -> ChatThread {
        let clean = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !clean.isEmpty, clean.count <= 100000,
              let index = original.messages.firstIndex(where: { $0.id == messageID }) else {
            throw ChatError.server("请填写有效的消息内容。")
        }
        var copy = fork(original, through: index, suffix: "修改")
        copy.messages[index].content = clean
        copy.messages[index].reasoning = ""
        copy.messages[index].state = .complete
        copy.messages[index].note = "已手动编辑"
        return copy
    }

    static func retryCopy(of original: ChatThread) throws -> ChatThread {
        guard original.messages.last?.role == .assistant,
              let index = original.messages.lastIndex(where: { $0.role == .user }) else {
            throw ChatError.server("这个对话还没有可以重新生成的回答。")
        }
        return fork(original, through: index, suffix: "重试")
    }

    private static func fork(_ original: ChatThread, through index: Int, suffix: String) -> ChatThread {
        var copy = original
        copy.id = UUID()
        copy.parentThreadID = original.id
        copy.title = String(original.title.prefix(28)) + " · " + suffix
        copy.createdAt = Date()
        copy.updatedAt = copy.createdAt
        copy.draft = nil
        copy.isPinned = false
        copy.messages = Array(original.messages.prefix(index + 1)).map { message in
            var clone = message
            clone.id = UUID()
            clone.usage = nil // Copied history must not be counted as a new paid request.
            clone.isBookmarked = false
            return clone
        }
        return copy
    }
}
