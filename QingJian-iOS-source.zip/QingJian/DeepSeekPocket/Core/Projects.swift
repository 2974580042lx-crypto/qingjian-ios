import Foundation

// A text the project hands to the model with every request, switched on or off one by one.
struct ProjectDocument: Identifiable, Codable, Equatable, Sendable {
    var id = UUID()
    var name: String
    var text: String
    var isIncluded = true
}

struct ChatProject: Identifiable, Codable, Equatable, Sendable {
    // Included documents travel with every request, so their size is capped.
    static let documentCharacterLimit = 100_000
    var id = UUID()
    var name: String
    var instructions = ""
    var documents: [ProjectDocument] = []
    // Defaults applied when a new conversation starts inside the project.
    var model: DeepSeekModel?
    var thinkingEnabled: Bool?
    var effort: ThinkingEffort?
    var isLocked = false
    var createdAt = Date()
    // Optional: projects saved by 1.5.0 have no such key. Pinned projects fold out in the sidebar.
    var isPinned: Bool?
    var updatedAt = Date()
    // Added in 1.5.2, all optional so saved 1.5.x projects still load.
    var provider: AIProvider?
    var subscriptionModel: String?
    var subscriptionEffort: SubscriptionEffort?
    // Memory: points the project's model keeps across conversations. Only ChatGPT projects
    // write it automatically, and only while autoMemory is not switched off.
    var autoMemory: Bool?
    var memory: String?
    var memoryUpdatedAt: Date?
    // Thread id → number of messages already folded into the memory.
    var memorizedCounts: [String: Int]?
    static let memoryCharacterLimit = 4000
    // Google Drive tools (1.5.8). Off unless switched on; DeepSeek projects only.
    var driveTools: Bool?
    // GitHub tools and noticing time passing (1.6.0), both off unless switched on.
    var githubTools: Bool?
    var timeAwareness: Bool?
    // The model's own web search and page reading.
    var webTools: Bool?

    var service: AIProvider { provider ?? .deepSeek }
    var usesDriveTools: Bool { service == .deepSeek && driveTools == true }
    var usesGitHubTools: Bool { service == .deepSeek && githubTools == true }
    var usesWebTools: Bool { service == .deepSeek && webTools == true }
    var remembers: Bool { service == .chatGPT && autoMemory != false }
    var includedCharacters: Int { documents.filter(\.isIncluded).reduce(0) { $0 + $1.text.count } }

    // Conversations in a project use only this, never the global prompt.
    var systemPrompt: String {
        composedPrompt(instructions: instructions)
    }

    /// Only user-authored instructions are templates; reference documents and
    /// saved memory must retain their literal braces (including the manual).
    func systemPrompt(resolving context: PromptVariables.Context) -> String {
        composedPrompt(instructions: PromptVariables.apply(instructions, context))
    }

    private func composedPrompt(instructions: String) -> String {
        var parts: [String] = []
        let clean = instructions.trimmingCharacters(in: .whitespacesAndNewlines)
        if !clean.isEmpty { parts.append(clean) }
        let included = documents.filter { $0.isIncluded && !$0.text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }
        if !included.isEmpty {
            parts.append("以下是这个项目的资料，回答时可以参考：")
            for document in included { parts.append("《\(document.name)》\n\(document.text)") }
        }
        if let memory = memory?.trimmingCharacters(in: .whitespacesAndNewlines), !memory.isEmpty {
            parts.append("以下是这个项目以往对话里记下的要点，回答时可以参考，不必复述：\n\(memory)")
        }
        return parts.joined(separator: "\n\n")
    }

    func validate() throws {
        guard !name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty, name.count <= 80,
              instructions.count <= 20000, documents.count <= 50,
              (memory ?? "").count <= Self.memoryCharacterLimit,
              Set(documents.map(\.id)).count == documents.count,
              documents.allSatisfy({ $0.name.count <= 200 && $0.text.count <= Self.documentCharacterLimit }),
              includedCharacters <= Self.documentCharacterLimit else {
            throw ChatError.invalidBackup("备份中有项目的名称、指令或资料不符合要求。")
        }
    }
}

// Markdown copy of one conversation, for sharing or handing to another tool.
enum ConversationExport {
    static func markdown(_ thread: ChatThread, userName: String) -> String {
        var lines = ["# \(thread.title)", "", thread.createdAt.formatted(date: .long, time: .shortened), ""]
        for message in thread.messages where !message.content.isEmpty {
            if let character = message.discussionCharacter {
                lines.append(message.role == .user ? "**\(userName) · 问\(character)**" : "**\(character) · 角色回答（依据原文演绎）**")
            } else {
                lines.append(message.role == .user ? "**\(userName)**" : "**Sermo**")
            }
            lines.append("")
            lines.append(message.content)
            lines.append("")
        }
        return lines.joined(separator: "\n")
    }

    static func fileName(for thread: ChatThread) -> String {
        let banned = CharacterSet(charactersIn: "/\\:*?\"<>|\n\r")
        let base = thread.title.components(separatedBy: banned).joined().trimmingCharacters(in: .whitespaces)
        return String((base.isEmpty ? "对话" : base).prefix(40)) + ".md"
    }
}
