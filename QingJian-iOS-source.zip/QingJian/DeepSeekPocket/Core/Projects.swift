import Foundation

// A text the project hands to the model with every request, switched on or off one by one.
struct ProjectDocument: Identifiable, Codable, Equatable, Sendable {
    var id = UUID()
    var name: String
    var text: String
    var isIncluded = true
}

struct ChatProject: Identifiable, Codable, Equatable, Sendable {
    // Included documents travel with every request, so their size is capped.
    static let documentCharacterLimit = 100_000
    var id = UUID()
    var name: String
    var instructions = ""
    var documents: [ProjectDocument] = []
    // Defaults applied when a new conversation starts inside the project.
    var model: DeepSeekModel?
    var thinkingEnabled: Bool?
    var effort: ThinkingEffort?
    var isLocked = false
    var createdAt = Date()
    var updatedAt = Date()

    var includedCharacters: Int { documents.filter(\.isIncluded).reduce(0) { $0 + $1.text.count } }

    // Conversations in a project use only this, never the global prompt.
    var systemPrompt: String {
        var parts: [String] = []
        let clean = instructions.trimmingCharacters(in: .whitespacesAndNewlines)
        if !clean.isEmpty { parts.append(clean) }
        let included = documents.filter { $0.isIncluded && !$0.text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }
        if !included.isEmpty {
            parts.append("以下是这个项目的资料，回答时可以参考：")
            for document in included { parts.append("《\(document.name)》\n\(document.text)") }
        }
        return parts.joined(separator: "\n\n")
    }

    func validate() throws {
        guard !name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty, name.count <= 80,
              instructions.count <= 20000, documents.count <= 50,
              Set(documents.map(\.id)).count == documents.count,
              documents.allSatisfy({ $0.name.count <= 200 && $0.text.count <= Self.documentCharacterLimit }),
              includedCharacters <= Self.documentCharacterLimit else {
            throw ChatError.invalidBackup("备份中有项目的名称、指令或资料不符合要求。")
        }
    }
}

// Markdown copy of one conversation, for sharing or handing to another tool.
enum ConversationExport {
    static func markdown(_ thread: ChatThread, userName: String) -> String {
        var lines = ["# \(thread.title)", "", thread.createdAt.formatted(date: .long, time: .shortened), ""]
        for message in thread.messages where !message.content.isEmpty {
            lines.append(message.role == .user ? "**\(userName)**" : "**Vox**")
            lines.append("")
            lines.append(message.content)
            lines.append("")
        }
        return lines.joined(separator: "\n")
    }

    static func fileName(for thread: ChatThread) -> String {
        let banned = CharacterSet(charactersIn: "/\\:*?\"<>|\n\r")
        let base = thread.title.components(separatedBy: banned).joined().trimmingCharacters(in: .whitespaces)
        return String((base.isEmpty ? "对话" : base).prefix(40)) + ".md"
    }
}
