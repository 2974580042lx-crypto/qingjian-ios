import Foundation

enum MessageRole: String, Codable, Sendable { case user, assistant }
enum MessageState: String, Codable, Sendable { case complete, streaming, stopped, failed }
enum DeepSeekModel: String, Codable, CaseIterable, Identifiable, Sendable {
    case flash = "deepseek-flash"
    case pro = "deepseek-v4-pro"
    var id: String { rawValue }
    var title: String { self == .flash ? "Flash" : "V4 Pro" }
}
enum ThinkingEffort: String, Codable, CaseIterable, Identifiable, Sendable {
    case low, high, max
    var id: String { rawValue }
    var title: String {
        switch self { case .low: return "轻量"; case .high: return "标准"; case .max: return "深入" }
    }
}

struct TokenUsage: Codable, Equatable, Sendable {
    let promptTokens: Int
    let completionTokens: Int
    let cachedTokens: Int
    var totalTokens: Int { promptTokens + completionTokens }
    init(promptTokens: Int, completionTokens: Int, cachedTokens: Int = 0) {
        self.promptTokens = max(0, promptTokens)
        self.completionTokens = max(0, completionTokens)
        self.cachedTokens = min(max(0, cachedTokens), max(0, promptTokens))
    }
    enum CodingKeys: String, CodingKey {
        case promptTokens = "prompt_tokens"
        case completionTokens = "completion_tokens"
        case cachedTokens = "prompt_cache_hit_tokens"
        case promptDetails = "prompt_tokens_details"
    }
    private struct PromptDetails: Decodable { let cached_tokens: Int? }
    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        let prompt = try c.decode(Int.self, forKey: .promptTokens)
        let output = try c.decode(Int.self, forKey: .completionTokens)
        let cached = try c.decodeIfPresent(Int.self, forKey: .cachedTokens)
            ?? c.decodeIfPresent(PromptDetails.self, forKey: .promptDetails)?.cached_tokens ?? 0
        self.init(promptTokens: prompt, completionTokens: output, cachedTokens: cached)
    }
    func encode(to encoder: Encoder) throws {
        var c = encoder.container(keyedBy: CodingKeys.self)
        try c.encode(promptTokens, forKey: .promptTokens)
        try c.encode(completionTokens, forKey: .completionTokens)
        try c.encode(cachedTokens, forKey: .cachedTokens)
    }
}

struct ChatMessage: Identifiable, Codable, Equatable, Sendable {
    var id = UUID()
    var role: MessageRole
    var content = ""
    var reasoning = ""
    var createdAt = Date()
    var state: MessageState = .complete
    var usage: TokenUsage?
    var note: String?
    var isBookmarked: Bool?
}

struct ChatThread: Identifiable, Codable, Equatable, Sendable {
    var id = UUID()
    var title = "新的对话"
    var createdAt = Date()
    var updatedAt = Date()
    var messages: [ChatMessage] = []
    var draft: String?
    var isPinned: Bool?
    var parentThreadID: UUID?
    var preview: String {
        messages.last(where: { !$0.content.isEmpty })?.content.replacingOccurrences(of: "\n", with: " ") ?? "留一页空白，等一个想法。"
    }
}

struct AppSettings: Codable, Equatable, Sendable {
    static let defaultPrompt = "请用简体中文自然交流，回答清楚、具体，先说重点。遇到不确定的事实请明确说明，必要时提醒核验来源。不要编造文献、链接或已经完成的操作。"
    static let learningPrompt = "你是一位耐心的学习伙伴。优先用简体中文，先用生活例子解释，再讲概念与区别，最后给一个简短的主动回忆问题。涉及历史史料或学术观点时，区分事实与解释，不编造文献和引文。"
    var model: DeepSeekModel = .flash
    var thinkingEnabled = true
    var effort: ThinkingEffort = .high
    var systemPrompt = Self.defaultPrompt
    var maxOutputTokens = 16384
    var contextMessageLimit = 40
    func validated() -> AppSettings {
        var copy = self
        copy.maxOutputTokens = min(max(copy.maxOutputTokens, 1024), 65536)
        copy.contextMessageLimit = min(max(copy.contextMessageLimit, 2), 100)
        copy.systemPrompt = String(copy.systemPrompt.prefix(20000))
        return copy
    }
}

// API keys are intentionally not part of this structure or any exported backup.
struct AppSnapshot: Codable, Sendable {
    var version = 1
    var exportedAt = Date()
    var settings: AppSettings
    var threads: [ChatThread]
    var activeThreadID: UUID?
    func validate() throws {
        guard version == 1 else { throw ChatError.invalidBackup("这个备份的版本暂不支持。") }
        guard threads.count <= 2000 else { throw ChatError.invalidBackup("备份中的对话数量过多。") }
        guard Set(threads.map(\.id)).count == threads.count else {
            throw ChatError.invalidBackup("备份中有重复的对话编号。")
        }
        for thread in threads {
            guard thread.messages.count <= 20000,
                  Set(thread.messages.map(\.id)).count == thread.messages.count else {
                throw ChatError.invalidBackup("备份中的消息数量或编号不正确。")
            }
        }
    }
    static func decode(_ data: Data) throws -> AppSnapshot {
        guard data.count <= 50 * 1024 * 1024 else { throw ChatError.invalidBackup("请选择小于 50 MB 的备份文件。") }
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        let result = try decoder.decode(Self.self, from: data)
        try result.validate()
        return result
    }
    func encoded() throws -> Data {
        try validate()
        let encoder = JSONEncoder()
        encoder.dateEncodingStrategy = .iso8601
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys, .withoutEscapingSlashes]
        return try encoder.encode(self)
    }
}

enum ChatError: LocalizedError {
    case missingKey, invalidKey, insufficientBalance, rateLimited
    case http(Int), invalidResponse, malformedStream, incompleteStream
    case server(String), invalidBackup(String)
    var errorDescription: String? {
        switch self {
        case .missingKey: return "先在设置里填写你的 DeepSeek API Key。"
        case .invalidKey: return "API Key 未通过验证，请检查或重新填写。"
        case .insufficientBalance: return "DeepSeek API 余额不足，请到开放平台查看。"
        case .rateLimited: return "请求暂时过多，稍等一会儿再试。"
        case .http(let code): return "DeepSeek 返回 HTTP \(code)，请稍后重试。"
        case .invalidResponse: return "收到的响应格式不正确。"
        case .malformedStream: return "收到的数据流无法解析，已保留收到的内容。"
        case .incompleteStream: return "连接在回答完成前中断，已保留收到的内容。"
        case .server(let message): return message
        case .invalidBackup(let message): return message
        }
    }
}
