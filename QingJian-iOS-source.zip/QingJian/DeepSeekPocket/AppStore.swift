import Foundation
import Combine

@MainActor
final class AppStore: ObservableObject {
    @Published private(set) var threads: [ChatThread] = []
    @Published var activeThreadID: UUID?
    @Published private(set) var settings = AppSettings()
    @Published private(set) var apiKey = ""
    @Published private(set) var generatingThreadID: UUID?
    @Published var errorMessage: String?
    @Published var noticeMessage: String?
    @Published private(set) var canPersist = true
    private var persistence: AppPersistence?
    private var generationTask: Task<Void, Never>?
    private var lastSave = Date.distantPast
    private var draftSaveTask: Task<Void, Never>?
    let isPreview: Bool

    var isGenerating: Bool { generatingThreadID != nil }
    var hasKey: Bool { !apiKey.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }
    var activeThread: ChatThread? { threads.first(where: { $0.id == activeThreadID }) }
    var sortedThreads: [ChatThread] {
        threads.sorted {
            if ($0.isPinned == true) != ($1.isPinned == true) { return $0.isPinned == true }
            return $0.updatedAt > $1.updatedAt
        }
    }
    var activeDraft: String { activeThread?.draft ?? "" }
    var totalRecordedTokens: Int {
        threads.reduce(0) { total, thread in total + thread.messages.reduce(0) { $0 + ($1.usage?.totalTokens ?? 0) } }
    }

    init(preview: Bool = ProcessInfo.processInfo.arguments.contains("--ui-preview")) {
        isPreview = preview
        if preview {
            settings.thinkingEnabled = false
            apiKey = "preview"
            var thread = ChatThread()
            thread.title = "把想法慢慢聊清楚"
            if !ProcessInfo.processInfo.arguments.contains("--preview-empty") {
                thread.messages = [
                    ChatMessage(role: .user, content: "我想把生活过得从容一点。"),
                    ChatMessage(role: .assistant, content: "不必一下子改变所有事情。\n\n先给今天留一点空白。比如把一件事做慢一点，把一段话听完整，或是安静地读完几页书。\n\n### 从一件小事开始\n\n今晚，写下最想留住的一个瞬间。明天再回头看，你会慢慢发现自己的节奏。", isBookmarked: true)
                ]
            }
            var second = ChatThread(); second.title = "读书时留下的想法"
            second.messages = [ChatMessage(role: .user, content: "怎样读懂一段史料？")]
            threads = [thread, second]; activeThreadID = thread.id
            return
        }
        do {
            persistence = try AppPersistence()
            if let snapshot = try persistence?.load() {
                settings = snapshot.settings.validated()
                threads = snapshot.threads
                activeThreadID = snapshot.activeThreadID
                for ti in threads.indices {
                    for mi in threads[ti].messages.indices where threads[ti].messages[mi].state == .streaming {
                        threads[ti].messages[mi].state = .stopped
                        threads[ti].messages[mi].note = "上次生成中断了，收到的内容已保留。"
                    }
                }
            }
        } catch {
            canPersist = false
            errorMessage = "无法读取本机记录，原文件没有被覆盖。\(error.localizedDescription)"
        }
        do { apiKey = try KeychainStore.read() }
        catch { errorMessage = error.localizedDescription }
        if threads.isEmpty { threads = [ChatThread()] }
        if !threads.contains(where: { $0.id == activeThreadID }) { activeThreadID = threads.first?.id }
    }

    func createThread() {
        guard canPersist else { return }
        let old = threads, oldID = activeThreadID
        if let empty = threads.first(where: { $0.messages.isEmpty && ($0.draft ?? "").isEmpty }) {
            activeThreadID = empty.id
        } else {
            guard threads.count < 2000 else { errorMessage = "对话数量已达上限，请先导出并整理记录。"; return }
            let thread = ChatThread()
            threads.insert(thread, at: 0)
            activeThreadID = thread.id
        }
        if !persistNow() { threads = old; activeThreadID = oldID }
    }
    func select(_ id: UUID) { activeThreadID = id; persistNow() }
    func deleteThread(_ id: UUID) {
        guard generatingThreadID != id else { return }
        let old = threads, oldID = activeThreadID
        threads.removeAll { $0.id == id }
        if threads.isEmpty { threads = [ChatThread()] }
        if activeThreadID == id { activeThreadID = sortedThreads.first?.id }
        if !persistNow() { threads = old; activeThreadID = oldID }
    }
    func renameThread(_ id: UUID, title: String) {
        guard let index = threads.firstIndex(where: { $0.id == id }) else { return }
        let clean = title.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !clean.isEmpty else { return }
        let old = threads
        threads[index].title = String(clean.prefix(80))
        if !persistNow() { threads = old }
    }
    func togglePinned(_ id: UUID) {
        guard let index = threads.firstIndex(where: { $0.id == id }) else { return }
        let old = threads
        threads[index].isPinned = !(threads[index].isPinned == true)
        if !persistNow() { threads = old }
    }
    func toggleBookmark(threadID: UUID, messageID: UUID) {
        guard let ti = threads.firstIndex(where: { $0.id == threadID }),
              let mi = threads[ti].messages.firstIndex(where: { $0.id == messageID }) else { return }
        let old = threads
        threads[ti].messages[mi].isBookmarked = !(threads[ti].messages[mi].isBookmarked == true)
        if !persistNow() { threads = old }
    }
    func setDraft(_ text: String) {
        guard let ti = threads.firstIndex(where: { $0.id == activeThreadID }) else { return }
        threads[ti].draft = text
        draftSaveTask?.cancel()
        draftSaveTask = Task { [weak self] in
            do { try await Task.sleep(nanoseconds: 600_000_000) } catch { return }
            self?.persistNow()
        }
    }
    func setModel(_ model: DeepSeekModel) {
        let old = settings
        settings.model = model
        if !persistNow() { settings = old }
    }
    func saveSettings(_ next: AppSettings, key: String) -> Bool {
        let cleanKey = key.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !cleanKey.contains("\n"), !cleanKey.contains("\r") else {
            errorMessage = "API Key 里有换行，请重新粘贴完整的一行。"
            return false
        }
        do { try KeychainStore.save(cleanKey) }
        catch { errorMessage = error.localizedDescription; return false }
        let old = settings
        apiKey = cleanKey
        settings = next.validated()
        if !persistNow() { settings = old; return false }
        return true
    }
    func toggleThinking() {
        let old = settings
        settings.thinkingEnabled.toggle()
        if !persistNow() { settings = old }
    }
    @discardableResult func send(_ text: String) -> Bool {
        guard !isGenerating, canPersist else { return false }
        guard hasKey else { errorMessage = ChatError.missingKey.localizedDescription; return false }
        let clean = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !clean.isEmpty else { return false }
        guard clean.count <= 100000 else { errorMessage = "这段文字太长，请分段发送。"; return false }
        guard let threadID = activeThreadID, let ti = threads.firstIndex(where: { $0.id == threadID }) else { return false }
        draftSaveTask?.cancel()
        let old = threads
        if threads[ti].messages.isEmpty { threads[ti].title = String(clean.prefix(20)).replacingOccurrences(of: "\n", with: " ") }
        threads[ti].messages.append(ChatMessage(role: .user, content: clean))
        threads[ti].draft = ""
        if startGeneration(threadID: threadID) { return true }
        threads = old
        return false
    }
    func regenerate() {
        guard !isGenerating, hasKey, canPersist, let threadID = activeThreadID,
              let ti = threads.firstIndex(where: { $0.id == threadID }),
              threads[ti].messages.last?.role == .assistant else { return }
        do { _ = installBranch(try ConversationEditing.retryCopy(of: threads[ti]), generate: true) }
        catch { errorMessage = error.localizedDescription }
    }
    func editMessage(_ id: UUID, text: String, resend: Bool) -> Bool {
        guard !isGenerating, canPersist, let original = activeThread else { return false }
        if resend && !hasKey { errorMessage = ChatError.missingKey.localizedDescription; return false }
        do {
            let branch = try ConversationEditing.editedCopy(of: original, messageID: id, text: text)
            return installBranch(branch, generate: resend && branch.messages.last?.role == .user)
        } catch { errorMessage = error.localizedDescription; return false }
    }
    private func installBranch(_ branch: ChatThread, generate: Bool) -> Bool {
        guard threads.count < 2000 else { errorMessage = "对话数量已达上限，请先整理历史。"; return false }
        let old = threads, oldID = activeThreadID
        threads.insert(branch, at: 0); activeThreadID = branch.id
        let saved = generate ? startGeneration(threadID: branch.id) : persistNow()
        if !saved { threads = old; activeThreadID = oldID }
        return saved
    }
    func stopGeneration() { generationTask?.cancel() }
    @discardableResult private func startGeneration(threadID: UUID) -> Bool {
        guard let ti = threads.firstIndex(where: { $0.id == threadID }) else { return false }
        if isPreview {
            threads[ti].messages.append(ChatMessage(role: .assistant, content: "这是界面预览中的示例回答。"))
            return true
        }
        let old = threads
        let request = ChatRequest(settings: settings, messages: threads[ti].messages)
        let answer = ChatMessage(role: .assistant, state: .streaming)
        threads[ti].messages.append(answer)
        threads[ti].updatedAt = Date()
        let key = apiKey
        guard persistNow() else { threads = old; return false }
        generatingThreadID = threadID
        generationTask = Task { [weak self] in
            guard let self else { return }
            do {
                try await DeepSeekClient().stream(request: request, key: key) { [weak self] event in
                    self?.receive(event, threadID: threadID, messageID: answer.id)
                }
                self.finish(threadID: threadID, messageID: answer.id, state: .complete)
            } catch {
                if Task.isCancelled || error is CancellationError || (error as? URLError)?.code == .cancelled {
                    self.finish(threadID: threadID, messageID: answer.id, state: .stopped, note: "已停止生成。")
                } else {
                    let detail = (error as? URLError).map { self.networkMessage($0) } ?? error.localizedDescription
                    self.finish(threadID: threadID, messageID: answer.id, state: .failed, note: detail)
                }
            }
            self.generatingThreadID = nil
            self.generationTask = nil
            self.persistNow()
        }
        return true
    }
    private func receive(_ event: StreamEvent, threadID: UUID, messageID: UUID) {
        guard let ti = threads.firstIndex(where: { $0.id == threadID }),
              let mi = threads[ti].messages.firstIndex(where: { $0.id == messageID }) else { return }
        threads[ti].messages[mi].content += event.content
        threads[ti].messages[mi].reasoning += event.reasoning
        if let usage = event.usage { threads[ti].messages[mi].usage = usage }
        if let reason = event.finishReason {
            switch reason {
            case "length": threads[ti].messages[mi].note = "达到本次输出上限。可在设置里提高上限后重新生成。"
            case "content_filter": threads[ti].messages[mi].note = "服务端未完整返回这次回答。"
            case "insufficient_system_resource", "aborted":
                threads[ti].messages[mi].note = "服务端中断了生成，可重新尝试。"
                threads[ti].messages[mi].state = .failed
            default: break
            }
        }
        if Date().timeIntervalSince(lastSave) >= 0.8 { persistNow() }
    }
    private func finish(threadID: UUID, messageID: UUID, state: MessageState, note: String? = nil) {
        guard let ti = threads.firstIndex(where: { $0.id == threadID }),
              let mi = threads[ti].messages.firstIndex(where: { $0.id == messageID }) else { return }
        if threads[ti].messages[mi].state != .failed { threads[ti].messages[mi].state = state }
        if let note { threads[ti].messages[mi].note = note }
        if state == .complete && threads[ti].messages[mi].content.isEmpty {
            threads[ti].messages[mi].state = .failed
            threads[ti].messages[mi].note = "没有收到最终回答。可提高输出上限或关闭深度思考后重试。"
        }
        threads[ti].updatedAt = Date()
    }
    private func networkMessage(_ error: URLError) -> String {
        switch error.code {
        case .notConnectedToInternet: return "当前没有联网，连上网络后再试。"
        case .timedOut: return "连接超时，已保留收到的内容。"
        default: return "网络连接中断，已保留收到的内容。"
        }
    }
    private var snapshot: AppSnapshot {
        AppSnapshot(settings: settings, threads: threads, activeThreadID: activeThreadID)
    }
    @discardableResult func persistNow() -> Bool {
        if isPreview { return true }
        guard canPersist, let persistence else { return false }
        do { try persistence.save(snapshot); lastSave = Date(); return true }
        catch { errorMessage = "这次记录未能保存，请保持手机解锁并检查可用空间后重试。"; return false }
    }
    func exportBackup() -> URL? {
        do { return try persistence?.export(snapshot) }
        catch { errorMessage = "无法导出备份：\(error.localizedDescription)"; return nil }
    }
    func importBackup(_ url: URL) {
        guard !isGenerating, canPersist else { return }
        let scoped = url.startAccessingSecurityScopedResource()
        defer { if scoped { url.stopAccessingSecurityScopedResource() } }
        do {
            let size = try url.resourceValues(forKeys: [.fileSizeKey]).fileSize ?? 0
            guard size <= 50 * 1024 * 1024 else { throw ChatError.invalidBackup("请选择小于 50 MB 的备份文件。") }
            let incoming = try AppSnapshot.decode(Data(contentsOf: url))
            let knownIDs = Set(threads.map(\.id))
            var added = incoming.threads.filter { !knownIDs.contains($0.id) }
            for ti in added.indices {
                for mi in added[ti].messages.indices where added[ti].messages[mi].state == .streaming {
                    added[ti].messages[mi].state = .stopped
                    added[ti].messages[mi].note = "从备份恢复的未完成回答。"
                }
            }
            guard threads.count + added.count <= 2000 else { throw ChatError.invalidBackup("合并后的对话过多。") }
            let old = threads
            threads.append(contentsOf: added)
            guard persistNow() else { threads = old; return }
            noticeMessage = "已导入 \(added.count) 个新对话，现有记录、设置和 API Key 保持不变。"
        } catch { errorMessage = "导入失败：\(error.localizedDescription)" }
    }
}
