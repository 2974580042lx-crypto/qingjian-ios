import Foundation
import Combine

@MainActor
final class AppStore: ObservableObject {
    @Published private(set) var threads: [ChatThread] = []
    @Published var activeThreadID: UUID?
    @Published private(set) var settings = AppSettings()
    @Published private(set) var apiKey = ""
    @Published private(set) var generatingThreadID: UUID?
    @Published var errorMessage: String?
    @Published var noticeMessage: String?
    @Published private(set) var canPersist = true
    private var persistence: AppPersistence?
    private var generationTask: Task<Void, Never>?
    private var lastSave = Date.distantPast

    var isGenerating: Bool { generatingThreadID != nil }
    var hasKey: Bool { !apiKey.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }
    var activeThread: ChatThread? { threads.first(where: { $0.id == activeThreadID }) }
    var sortedThreads: [ChatThread] { threads.sorted { $0.updatedAt > $1.updatedAt } }
    var totalRecordedTokens: Int {
        threads.reduce(0) { total, thread in total + thread.messages.reduce(0) { $0 + ($1.usage?.totalTokens ?? 0) } }
    }

    init() {
        do {
            persistence = try AppPersistence()
            if let snapshot = try persistence?.load() {
                settings = snapshot.settings.validated()
                threads = snapshot.threads
                activeThreadID = snapshot.activeThreadID
                for ti in threads.indices {
                    for mi in threads[ti].messages.indices where threads[ti].messages[mi].state == .streaming {
                        threads[ti].messages[mi].state = .stopped
                        threads[ti].messages[mi].note = "上次生成中断了，收到的内容已保留。"
                    }
                }
            }
        } catch {
            canPersist = false
            errorMessage = "无法读取本机记录，原文件没有被覆盖。\(error.localizedDescription)"
        }
        do { apiKey = try KeychainStore.read() }
        catch { errorMessage = error.localizedDescription }
        if threads.isEmpty { threads = [ChatThread()] }
        if !threads.contains(where: { $0.id == activeThreadID }) { activeThreadID = threads.first?.id }
    }

    func createThread() {
        if let empty = threads.first(where: { $0.messages.isEmpty }) {
            activeThreadID = empty.id
        } else {
            let thread = ChatThread()
            threads.insert(thread, at: 0)
            activeThreadID = thread.id
        }
        persistNow()
    }
    func select(_ id: UUID) { activeThreadID = id; persistNow() }
    func deleteThread(_ id: UUID) {
        guard generatingThreadID != id else { return }
        threads.removeAll { $0.id == id }
        if threads.isEmpty { threads = [ChatThread()] }
        if activeThreadID == id { activeThreadID = sortedThreads.first?.id }
        persistNow()
    }
    func saveSettings(_ next: AppSettings, key: String) -> Bool {
        let cleanKey = key.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !cleanKey.contains("\n"), !cleanKey.contains("\r") else {
            errorMessage = "API Key 里有换行，请重新粘贴完整的一行。"
            return false
        }
        do { try KeychainStore.save(cleanKey) }
        catch { errorMessage = error.localizedDescription; return false }
        apiKey = cleanKey
        settings = next.validated()
        persistNow()
        return true
    }
    func toggleThinking() {
        settings.thinkingEnabled.toggle()
        persistNow()
    }
    @discardableResult func send(_ text: String) -> Bool {
        guard !isGenerating, canPersist else { return false }
        guard hasKey else { errorMessage = ChatError.missingKey.localizedDescription; return false }
        let clean = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !clean.isEmpty else { return false }
        guard clean.count <= 100000 else { errorMessage = "这段文字太长，请分段发送。"; return false }
        guard let threadID = activeThreadID, let ti = threads.firstIndex(where: { $0.id == threadID }) else { return false }
        if threads[ti].messages.isEmpty { threads[ti].title = String(clean.prefix(20)).replacingOccurrences(of: "\n", with: " ") }
        threads[ti].messages.append(ChatMessage(role: .user, content: clean))
        startGeneration(threadID: threadID)
        return true
    }
    func regenerate() {
        guard !isGenerating, hasKey, canPersist, let threadID = activeThreadID,
              let ti = threads.firstIndex(where: { $0.id == threadID }),
              threads[ti].messages.last?.role == .assistant else { return }
        threads[ti].messages.removeLast()
        guard threads[ti].messages.last?.role == .user else { persistNow(); return }
        startGeneration(threadID: threadID)
    }
    func stopGeneration() { generationTask?.cancel() }
    private func startGeneration(threadID: UUID) {
        guard let ti = threads.firstIndex(where: { $0.id == threadID }) else { return }
        let request = ChatRequest(settings: settings, messages: threads[ti].messages)
        let answer = ChatMessage(role: .assistant, state: .streaming)
        threads[ti].messages.append(answer)
        threads[ti].updatedAt = Date()
        generatingThreadID = threadID
        let key = apiKey
        persistNow()
        generationTask = Task { [weak self] in
            guard let self else { return }
            do {
                try await DeepSeekClient().stream(request: request, key: key) { [weak self] event in
                    self?.receive(event, threadID: threadID, messageID: answer.id)
                }
                self.finish(threadID: threadID, messageID: answer.id, state: .complete)
            } catch {
                if Task.isCancelled || error is CancellationError || (error as? URLError)?.code == .cancelled {
                    self.finish(threadID: threadID, messageID: answer.id, state: .stopped, note: "已停止生成。")
                } else {
                    let detail = (error as? URLError).map { self.networkMessage($0) } ?? error.localizedDescription
                    self.finish(threadID: threadID, messageID: answer.id, state: .failed, note: detail)
                }
            }
            self.generatingThreadID = nil
            self.generationTask = nil
            self.persistNow()
        }
    }
    private func receive(_ event: StreamEvent, threadID: UUID, messageID: UUID) {
        guard let ti = threads.firstIndex(where: { $0.id == threadID }),
              let mi = threads[ti].messages.firstIndex(where: { $0.id == messageID }) else { return }
        threads[ti].messages[mi].content += event.content
        threads[ti].messages[mi].reasoning += event.reasoning
        if let usage = event.usage { threads[ti].messages[mi].usage = usage }
        if let reason = event.finishReason {
            switch reason {
            case "length": threads[ti].messages[mi].note = "达到本次输出上限。可在设置里提高上限后重新生成。"
            case "content_filter": threads[ti].messages[mi].note = "服务端未完整返回这次回答。"
            case "insufficient_system_resource", "aborted":
                threads[ti].messages[mi].note = "服务端中断了生成，可重新尝试。"
                threads[ti].messages[mi].state = .failed
            default: break
            }
        }
        if Date().timeIntervalSince(lastSave) >= 0.8 { persistNow() }
    }
    private func finish(threadID: UUID, messageID: UUID, state: MessageState, note: String? = nil) {
        guard let ti = threads.firstIndex(where: { $0.id == threadID }),
              let mi = threads[ti].messages.firstIndex(where: { $0.id == messageID }) else { return }
        if threads[ti].messages[mi].state != .failed { threads[ti].messages[mi].state = state }
        if let note { threads[ti].messages[mi].note = note }
        if state == .complete && threads[ti].messages[mi].content.isEmpty {
            threads[ti].messages[mi].state = .failed
            threads[ti].messages[mi].note = "没有收到最终回答。可提高输出上限或关闭深度思考后重试。"
        }
        threads[ti].updatedAt = Date()
    }
    private func networkMessage(_ error: URLError) -> String {
        switch error.code {
        case .notConnectedToInternet: return "当前没有联网，连上网络后再试。"
        case .timedOut: return "连接超时，已保留收到的内容。"
        default: return "网络连接中断，已保留收到的内容。"
        }
    }
    private var snapshot: AppSnapshot {
        AppSnapshot(settings: settings, threads: threads, activeThreadID: activeThreadID)
    }
    func persistNow() {
        guard canPersist else { return }
        do { try persistence?.save(snapshot); lastSave = Date() }
        catch { errorMessage = "这次记录未能保存，请保持手机解锁后重试。" }
    }
    func exportBackup() -> URL? {
        do { return try persistence?.export(snapshot) }
        catch { errorMessage = "无法导出备份：\(error.localizedDescription)"; return nil }
    }
    func importBackup(_ url: URL) {
        guard !isGenerating, canPersist else { return }
        let scoped = url.startAccessingSecurityScopedResource()
        defer { if scoped { url.stopAccessingSecurityScopedResource() } }
        do {
            let size = try url.resourceValues(forKeys: [.fileSizeKey]).fileSize ?? 0
            guard size <= 50 * 1024 * 1024 else { throw ChatError.invalidBackup("请选择小于 50 MB 的备份文件。") }
            let incoming = try AppSnapshot.decode(Data(contentsOf: url))
            let knownIDs = Set(threads.map(\.id))
            var added = incoming.threads.filter { !knownIDs.contains($0.id) }
            for ti in added.indices {
                for mi in added[ti].messages.indices where added[ti].messages[mi].state == .streaming {
                    added[ti].messages[mi].state = .stopped
                    added[ti].messages[mi].note = "从备份恢复的未完成回答。"
                }
            }
            guard threads.count + added.count <= 2000 else { throw ChatError.invalidBackup("合并后的对话过多。") }
            threads.append(contentsOf: added)
            persistNow()
            noticeMessage = "已导入 \(added.count) 个新对话，现有记录、设置和 API Key 保持不变。"
        } catch { errorMessage = "导入失败：\(error.localizedDescription)" }
    }
}
