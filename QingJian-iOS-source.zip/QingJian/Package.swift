// swift-tools-version: 5.9
import PackageDescription

let package = Package(
    name: "DeepSeekCore",
    platforms: [.macOS(.v13)],
    products: [.library(name: "DeepSeekCore", targets: ["DeepSeekCore"])],
    targets: [
        .target(name: "DeepSeekCore", path: "DeepSeekPocket",
                exclude: ["AppStore.swift", "QingJianApp.swift", "Info.plist", "Views", "Assets.xcassets", "Resources", "Services/AppPersistence.swift", "Services/KeychainStore.swift"],
                sources: ["Core", "Services/DeepSeekClient.swift"]),
        .testTarget(name: "DeepSeekCoreTests", dependencies: ["DeepSeekCore"], path: "Tests")
    ]
)
