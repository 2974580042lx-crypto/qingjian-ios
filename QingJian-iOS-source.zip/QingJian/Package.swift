// swift-tools-version: 5.9
import PackageDescription

let package = Package(
    name: "DeepSeekCore",
    platforms: [.macOS(.v13)],
    products: [.library(name: "DeepSeekCore", targets: ["DeepSeekCore"])],
    targets: [
        .target(name: "DeepSeekCore", path: "DeepSeekPocket/Core"),
        .testTarget(name: "DeepSeekCoreTests", dependencies: ["DeepSeekCore"], path: "Tests")
    ]
)
