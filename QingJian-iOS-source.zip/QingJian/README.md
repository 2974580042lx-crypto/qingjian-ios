# 青笺 · 个人 DeepSeek iPhone 客户端

这是一个 SwiftUI 原生 iPhone App 项目。第一版用于个人文字聊天，不需要额外的聊天中转服务器。

1.0 已完成云端 Xcode 编译并交付未签名 IPA。当前源码为 1.0.1，补充设置页的“测试连接”按钮；本版验证进度见 `VALIDATION.md`。签名安装与实际 API 联调在自己的 iPhone 上进行。

## 第一版包含什么

- 直接连接 DeepSeek 官方 `https://api.deepseek.com/chat/completions` 接口。
- 支持 `deepseek-flash` 和 `deepseek-v4-pro`，默认 Flash。
- 流式文字回答、停止生成、重新生成。
- 深度思考开关与思考强度设置，思考内容可展开查看。
- 自定义系统提示词，附自然聊天、学习讲解两种起点。
- 对话列表、搜索、新建和删除；记录存储在 App 私有目录。
- JSON 备份导出和导入。导入添加新编号的对话，已存在编号会跳过。
- API Key 通过 App 设置填写，存入本机钥匙串；不写入源代码或备份。
- 设置页可测试连接，直接检查填写的密钥与官方 API 账户余额，显示成功、余额不足、密钥错误或网络错误。测试不会发送聊天内容，修改 Key 后旧结果会清除。
- 显示服务端返回的 tokens 用量，不把本地记录统计当作实际账单。
- 绿色界面和应用图标；最低 iOS 17。

语音、文件上传、联网搜索、自动跨对话记忆以及后台持续生成没有包含在这一版。轻量 Markdown 支持行内格式和代码块；复杂表格、数学排版和块级标题尚未专门排版。

## 没有 Mac：使用 GitHub 云端生成 IPA

项目内已经包含 `.github/workflows/build-ios.yml`，使用 GitHub 的 macOS 运行环境构建。这个工作流**不需要 API Key、签名证书或证书密码**。

1. 在自己的 GitHub 账户创建一个仓库，建议先用私有仓库。
2. 把本项目的内容放在仓库根目录。根目录应能看到 `Package.swift`、`DeepSeekPocket`、`QingJian.xcodeproj`，以及 `.github/workflows/build-ios.yml`。不要多套一层 `QingJian` 文件夹，也不要漏掉 `.github`。
3. 进入仓库的 **Actions**，选择 **Build iPhone IPA**，点击 **Run workflow**。主分支上传代码也会触发构建。
4. 工作流先运行核心逻辑测试，再调用 Xcode 编译 iPhone App，成功后上传构建结果。
5. 打开成功的运行记录，在 **Artifacts** 下载 **QingJian-unsigned-IPA**，解压得到 `QingJian-unsigned.ipa`。
6. 把 IPA 传到手机，使用你现有的签名工具、适用证书和描述文件签名安装。
7. 打开 **青笺 → 设置**，填写 DeepSeek API Key，点击 **测试连接**。确认结果后点右上角 **保存**，回到聊天页发一句简短的问题，检查实际聊天。

私有仓库的云端运行会使用 GitHub 账户的 Actions 额度，超出免费额度可能收费；运行前查看账户当前额度。公开仓库会公开源码，不要为获得免费构建而上传秘密材料。

若在 ChatGPT 中完成 GitHub 插件安装和账户连接，可以继续协助建立仓库、检查工作流并处理构建错误；实际可用操作以已连接插件的能力为准。

## 有 Mac：本地生成未签名 IPA

安装完整 Xcode，并完成初次启动初始化。终端进入项目目录后执行：

```bash
bash scripts/build-ipa.sh
```

成功后文件位于 `build/QingJian-unsigned.ipa`，仍需使用自己的签名方式签名安装。

也可以打开 `QingJian.xcodeproj`，选择 `QingJian` scheme，在 **Signing & Capabilities** 中设置自己的开发团队，再从 Xcode 安装到个人设备。

`scripts/generate-project.py` 用于在增加或删除 Swift 文件后重新生成 Xcode 项目。现有项目已经生成好，正常构建不需要先运行它，也无需安装 XcodeGen、CocoaPods 或额外 Swift 库。

## API Key 和签名证书分别放在哪里

- **DeepSeek API Key**：安装后在 App 设置里输入，保存在设备钥匙串。基础聊天直接连接 DeepSeek；消息正文和所选历史上下文会发给 DeepSeek。
- **签名证书及描述文件**：留在你自己的签名工具里。这里的云端工作流生成未签名安装包，无需上传它们。
- **聊天备份**：包含正文与思考内容，不包含 API Key。导出时可选择保存在自己的“文件”或 iCloud Drive 中。

升级和续签时尽量保持 Bundle ID 与签名身份一致，先导出备份。卸载应用、改变 Bundle ID 或签名身份可能使原记录或钥匙串条目无法继续访问。

## 使用时的几个实际限制

多轮对话每次发送最近的历史消息，数量可在设置中调整；未完成的助手回答不加入下一次请求。思考内容不会回传（这一版未使用工具调用）。

切换到后台、锁屏、断网或服务端中断可能导致生成停止；收到的部分会保留。停止生成并不表示服务端已生成的 tokens 不会计费。若思考用完输出上限而没有最终回答，可以提高上限或关闭思考后重试。

本地用量只统计仍保存在记录中、并且已收到用量信息的回答；删除、重新生成或流中断会影响统计。实际账单以 DeepSeek 开放平台为准。

## 官方参考

- [DeepSeek 首次调用 API](https://api-docs.deepseek.com/zh-cn/)
- [DeepSeek Chat Completions API](https://api-docs.deepseek.com/api/create-chat-completion/)
- [DeepSeek 思考模式](https://api-docs.deepseek.com/zh-cn/guides/thinking_mode/)
- [DeepSeek 模型与价格](https://api-docs.deepseek.com/zh-cn/quick_start/pricing/)
- [DeepSeek 查询账户余额](https://api-docs.deepseek.com/zh-cn/api/get-user-balance/)
- [Apple 免费个人开发团队说明](https://developer.apple.com/help/account/basics/about-your-developer-account)
- [GitHub macOS 构建环境](https://docs.github.com/en/actions/reference/runners/github-hosted-runners)

文档及请求参数按 2026-10-01 查阅的官方资料实现。
