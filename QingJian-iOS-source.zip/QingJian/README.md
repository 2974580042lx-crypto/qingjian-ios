# 青笺 1.2.2 · 个人聊天客户端

版本 1.2.2，build 10。最低 iOS 26；Bundle ID 保持 com.xiaolong.qingjian。

- 聊天列表延伸到屏幕底部，输入框与底栏采用悬浮覆盖；通过内容边距保留最后一行的阅读空间。
- 聊天内容区从任意横向位置右滑可展开侧栏，左滑收起，滑动过程跟手；区分横向拖动与纵向滚动，输入控件区保留自身手势。
- 展开和收起侧栏触发轻微触感反馈，可在设置中关闭；模拟器不能验证实际马达手感。
- 相册图片上传尚未接入聊天，加号仍为文字相关操作。
- 空白首页只保留居中英文时间问候：05:00–11:59 Good morning，12:00–17:59 Good afternoon，其余时间 Good evening。按手机本地时间每分钟刷新；无引导文案、图标或推荐问题按钮。
- 输入框提示改为“输入消息…”，侧栏与空对话不再使用抒情文案。
- 底部仅聊天和设置，两处浮动控件共用原生 clear Liquid Glass 材质。
- 聊天顶部显示 DeepSeek；侧栏新建对话使用简洁文字按钮。
- 设置顶部显示自己的头像、名字和 ID，支持系统照片选择器；资料只存本机。
- 输入框思考菜单可开关思考，并直接选择轻量、标准、深入。
- 每条回答只展示服务端返回的本次总 Token；不存在用字符数冒充 Token。
- 默认上下文 200 条，最高 400 条，超长时保留最近完整消息；UTF-8 请求正文采用保守容量限制，不冒充精确 Token 计算。
- 思考过程等回答结束后再按需翻译，支持原文、中文、双语；缓存译文随对话备份保存。
- 翻译使用当前 Key 和 Flash 模型，关闭思考；单独请求会产生额外 API 用量。译文不进入正式聊天上下文。
- 保留宋体、消息编辑、重新回答、历史搜索、置顶、改名与备份。
- 收藏界面已移除，旧备份中的收藏标记仍保留；头像资料不包含在聊天备份中。

源码未包含 API Key 或签名材料。运行 scripts/build-ipa.sh 会检查结构、运行测试、使用 Xcode 26 编译并生成未签名 IPA。设置 QINGJIAN_CAPTURE_PREVIEWS=1 时从实际模拟器捕获界面，预览模式只使用虚构数据且不联网。

已有用户先导出重要聊天记录，再沿用原证书和 Bundle ID 签名覆盖安装。云端测试与模拟器截图不等同于手机上的真实 API 调用验证。

历史验证材料只描述相应旧版本。当前验证以本次 Actions 日志和安装包核验为准。

参考：
- DeepSeek 思考参数：https://api-docs.deepseek.com/zh-cn/guides/thinking_mode/
- DeepSeek 上下文能力：https://api-docs.deepseek.com/zh-cn/quick_start/pricing/
- Apple Liquid Glass：https://developer.apple.com/documentation/swiftui/applying-liquid-glass-to-custom-views

界面回归验证：UITests/NavigationUITests.swift 使用真实模拟器触摸事件检查右半屏起滑、全高纵向滚动、最后一行可读性及键盘布局。截图脚本同时导出测试附件与 xcresult 摘要。

交互回归还验证了发送新消息后的自动滚动位置。侧栏显示状态以实际可操作性判定，隐藏但留在可访问性树中的按钮不算可见侧栏。

长对话自动跟随使用系统 ScrollPosition 的底部定位，避免按末尾虚拟占位元素定位时跳入懒加载估算的空白区域。
