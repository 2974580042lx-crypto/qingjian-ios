#!/bin/bash
set -euo pipefail
PROJECT_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
BUILD_DIR="$PROJECT_ROOT/build"
mkdir -p "$BUILD_DIR/previews"
cd "$PROJECT_ROOT"
xcodebuild -project QingJian.xcodeproj -scheme QingJian -configuration Release \
  -sdk iphonesimulator -destination 'generic/platform=iOS Simulator' \
  -derivedDataPath "$BUILD_DIR/SimulatorDerivedData" CODE_SIGNING_ALLOWED=NO ARCHS=arm64 build
APP_PATH="$BUILD_DIR/SimulatorDerivedData/Build/Products/Release-iphonesimulator/DeepSeekPocket.app"
xcrun simctl list devices available -j > "$BUILD_DIR/previews/devices.json"
UDID="$(python3 - "$BUILD_DIR/previews/devices.json" <<'PY'
import json,sys,re
data=json.load(open(sys.argv[1]))['devices']
for runtime,devices in sorted(data.items(),reverse=True):
    match=re.search(r'iOS-(\d+)',runtime)
    if not match or int(match.group(1))<26:continue
    phones=[d for d in devices if d.get('isAvailable') and d['name'].startswith('iPhone')]
    phones.sort(key=lambda d:(d['name']!='iPhone 17 Pro',d['name']!='iPhone 16 Pro',d['name']))
    if phones:
        print(phones[0]['udid'])
        break
else:raise SystemExit('No iOS 26+ simulator available')
PY
)"
xcrun simctl boot "$UDID" || true
xcrun simctl bootstatus "$UDID" -b
xcrun simctl spawn "$UDID" defaults write com.apple.keyboard.preferences DidShowContinuousPathIntroduction -bool true
xcrun simctl ui "$UDID" appearance dark
xcrun simctl status_bar "$UDID" override --time '9:41' --batteryState charged --batteryLevel 100
xcrun simctl install "$UDID" "$APP_PATH"
for screen in empty conversation long keyboard sidebar waiting thinking; do
  args=(--ui-preview)
  if [[ "$screen" != conversation ]]; then args+=("--preview-$screen"); fi
  xcrun simctl launch --terminate-running-process --stdout="$BUILD_DIR/previews/$screen.log" \
    "$UDID" com.xiaolong.qingjian "${args[@]}" -AppleLanguages '(zh-Hans)' -AppleLocale zh_CN
  sleep 3
  xcrun simctl io "$UDID" screenshot "$BUILD_DIR/previews/$screen.png"
done
echo "UI previews captured from the actual simulator app."
set +e
xcodebuild -project QingJian.xcodeproj -scheme QingJian -configuration Release \
  -sdk iphonesimulator -destination "platform=iOS Simulator,id=$UDID" \
  -derivedDataPath "$BUILD_DIR/SimulatorDerivedData" -resultBundlePath "$BUILD_DIR/UIInteractionTests.xcresult" \
  -parallel-testing-enabled NO CODE_SIGNING_ALLOWED=NO ARCHS=arm64 ONLY_ACTIVE_ARCH=YES test
UI_TEST_STATUS=$?
set -e
xcrun xcresulttool export attachments --path "$BUILD_DIR/UIInteractionTests.xcresult" \
  --output-path "$BUILD_DIR/previews/interaction-tests" || true
xcrun xcresulttool get test-results summary --path "$BUILD_DIR/UIInteractionTests.xcresult" \
  > "$BUILD_DIR/previews/interaction-tests-summary.json" || true
exit "$UI_TEST_STATUS"
